.class public final Ldev/wiojelt/turksinema/entry/DiziMomEntry;
.super Lcom/lagradost/cloudstream3/plugins/Plugin;
.source "DiziMomEntry.kt"


# annotations
.annotation runtime Lcom/lagradost/cloudstream3/plugins/CloudstreamPlugin;
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nDiziMomEntry.kt\nKotlin\n*S Kotlin\n*F\n+ 1 DiziMomEntry.kt\ndev/wiojelt/turksinema/entry/DiziMomEntry\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,33:1\n832#2:34\n862#2,2:35\n832#2:37\n862#2,2:38\n2068#2,2:40\n*S KotlinDebug\n*F\n+ 1 DiziMomEntry.kt\ndev/wiojelt/turksinema/entry/DiziMomEntry\n*L\n19#1:34\n19#1:35,2\n21#1:37\n21#1:38,2\n21#1:40,2\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\b\u0007\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0010\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\tH\u0016J\b\u0010\n\u001a\u00020\u0007H\u0016R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000Ê\u0001\u0002\b\f¨\u0006\u000b"
    }
    d2 = {
        "Ldev/wiojelt/turksinema/entry/DiziMomEntry;",
        "Lcom/lagradost/cloudstream3/plugins/Plugin;",
        "<init>",
        "()V",
        "delegate",
        "Ldev/wiojelt/turksinema/vendor/saloo_dizimom/com/keyiflerolsun/DiziMomPlugin;",
        "load",
        "",
        "context",
        "Landroid/content/Context;",
        "beforeUnload",
        "DiziMom",
        "Lcom/lagradost/cloudstream3/plugins/CloudstreamPlugin;"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation

.annotation build Lkotlin/jvm/internal/SourceDebugExtension;
    value = {
        "SMAP\nDiziMomEntry.kt\nKotlin\n*S Kotlin\n*F\n+ 1 DiziMomEntry.kt\ndev/wiojelt/turksinema/entry/DiziMomEntry\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,33:1\n832#2:34\n862#2,2:35\n832#2:37\n862#2,2:38\n2068#2,2:40\n*S KotlinDebug\n*F\n+ 1 DiziMomEntry.kt\ndev/wiojelt/turksinema/entry/DiziMomEntry\n*L\n19#1:34\n19#1:35,2\n21#1:37\n21#1:38,2\n21#1:40,2\n*E\n"
    }
.end annotation


# instance fields
.field private final delegate:Ldev/wiojelt/turksinema/vendor/saloo_dizimom/com/keyiflerolsun/DiziMomPlugin;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .registers 2

    .line 10
    invoke-direct {p0}, Lcom/lagradost/cloudstream3/plugins/Plugin;-><init>()V

    .line 12
    new-instance v0, Ldev/wiojelt/turksinema/vendor/saloo_dizimom/com/keyiflerolsun/DiziMomPlugin;

    invoke-direct {v0}, Ldev/wiojelt/turksinema/vendor/saloo_dizimom/com/keyiflerolsun/DiziMomPlugin;-><init>()V

    iput-object v0, p0, Ldev/wiojelt/turksinema/entry/DiziMomEntry;->delegate:Ldev/wiojelt/turksinema/vendor/saloo_dizimom/com/keyiflerolsun/DiziMomPlugin;

    .line 10
    return-void
.end method


# virtual methods
.method public beforeUnload()V
    .registers 2

    .line 31
    iget-object v0, p0, Ldev/wiojelt/turksinema/entry/DiziMomEntry;->delegate:Ldev/wiojelt/turksinema/vendor/saloo_dizimom/com/keyiflerolsun/DiziMomPlugin;

    invoke-virtual {v0}, Ldev/wiojelt/turksinema/vendor/saloo_dizimom/com/keyiflerolsun/DiziMomPlugin;->beforeUnload()V

    return-void
.end method

.method public load(Landroid/content/Context;)V
    .registers 20
    .param p1, "context"  # Landroid/content/Context;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param

    .line 15
    move-object/from16 v1, p0

    move-object/from16 v3, p1

    sget-object v0, Lcom/lagradost/cloudstream3/APIHolder;->INSTANCE:Lcom/lagradost/cloudstream3/APIHolder;

    invoke-virtual {v0}, Lcom/lagradost/cloudstream3/APIHolder;->getAllProviders()Lcom/lagradost/cloudstream3/utils/AtomicMutableList;

    move-result-object v2

    monitor-enter v2

    const/4 v0, 0x0

    .line 16
    .local v0, "$i$a$-synchronized-DiziMomEntry$load$selected$1":I
    :try_start_c
    sget-object v4, Lcom/lagradost/cloudstream3/APIHolder;->INSTANCE:Lcom/lagradost/cloudstream3/APIHolder;

    invoke-virtual {v4}, Lcom/lagradost/cloudstream3/APIHolder;->getAllProviders()Lcom/lagradost/cloudstream3/utils/AtomicMutableList;

    move-result-object v4

    check-cast v4, Ljava/lang/Iterable;

    invoke-static {v4}, Lkotlin/collections/CollectionsKt;->toSet(Ljava/lang/Iterable;)Ljava/util/Set;

    move-result-object v4

    .line 17
    .local v4, "before":Ljava/util/Set;
    iget-object v5, v1, Ldev/wiojelt/turksinema/entry/DiziMomEntry;->delegate:Ldev/wiojelt/turksinema/vendor/saloo_dizimom/com/keyiflerolsun/DiziMomPlugin;

    invoke-virtual {v1}, Ldev/wiojelt/turksinema/entry/DiziMomEntry;->getFilename()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ldev/wiojelt/turksinema/vendor/saloo_dizimom/com/keyiflerolsun/DiziMomPlugin;->setFilename(Ljava/lang/String;)V

    .line 18
    iget-object v5, v1, Ldev/wiojelt/turksinema/entry/DiziMomEntry;->delegate:Ldev/wiojelt/turksinema/vendor/saloo_dizimom/com/keyiflerolsun/DiziMomPlugin;

    invoke-virtual {v5, v3}, Ldev/wiojelt/turksinema/vendor/saloo_dizimom/com/keyiflerolsun/DiziMomPlugin;->load(Landroid/content/Context;)V

    .line 19
    sget-object v5, Lcom/lagradost/cloudstream3/APIHolder;->INSTANCE:Lcom/lagradost/cloudstream3/APIHolder;

    invoke-virtual {v5}, Lcom/lagradost/cloudstream3/APIHolder;->getAllProviders()Lcom/lagradost/cloudstream3/utils/AtomicMutableList;

    move-result-object v5

    check-cast v5, Ljava/lang/Iterable;

    .local v5, "$this$filterNot$iv":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 34
    .local v6, "$i$f$filterNot":I
    new-instance v7, Ljava/util/ArrayList;

    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    check-cast v7, Ljava/util/Collection;

    .local v7, "destination$iv$iv":Ljava/util/Collection;
    move-object v8, v5

    .local v8, "$this$filterNotTo$iv$iv":Ljava/lang/Iterable;
    const/4 v9, 0x0

    .line 35
    .local v9, "$i$f$filterNotTo":I
    invoke-interface {v8}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v10

    :cond_3c
    :goto_3c
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_54

    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    .local v11, "element$iv$iv":Ljava/lang/Object;
    move-object v12, v11

    check-cast v12, Lcom/lagradost/cloudstream3/MainAPI;

    .local v12, "p0":Lcom/lagradost/cloudstream3/MainAPI;
    const/4 v13, 0x0

    .line 19
    .local v13, "$i$a$-filterNot-DiziMomEntry$load$selected$1$added$1":I
    invoke-interface {v4, v12}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v14

    .line 35
    .end local v12  # "p0":Lcom/lagradost/cloudstream3/MainAPI;
    .end local v13  # "$i$a$-filterNot-DiziMomEntry$load$selected$1$added$1":I
    if-nez v14, :cond_3c

    invoke-interface {v7, v11}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_3c

    .line 36
    .end local v11  # "element$iv$iv":Ljava/lang/Object;
    :cond_54
    nop

    .end local v7  # "destination$iv$iv":Ljava/util/Collection;
    .end local v8  # "$this$filterNotTo$iv$iv":Ljava/lang/Iterable;
    .end local v9  # "$i$f$filterNotTo":I
    check-cast v7, Ljava/util/List;

    .line 34
    nop

    .end local v5  # "$this$filterNot$iv":Ljava/lang/Iterable;
    .end local v6  # "$i$f$filterNot":I
    check-cast v7, Ljava/lang/Iterable;

    .line 19
    invoke-static {v7}, Lkotlin/collections/CollectionsKt;->toList(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v5

    .line 20
    .local v5, "added":Ljava/util/List;
    const/4 v6, 0x0

    invoke-static {v5, v6}, Lkotlin/collections/CollectionsKt;->getOrNull(Ljava/util/List;I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lcom/lagradost/cloudstream3/MainAPI;

    .line 21
    .local v7, "keep":Lcom/lagradost/cloudstream3/MainAPI;
    move-object v8, v5

    check-cast v8, Ljava/lang/Iterable;

    .local v8, "$this$filterNot$iv":Ljava/lang/Iterable;
    const/4 v9, 0x0

    .line 37
    .local v9, "$i$f$filterNot":I
    new-instance v10, Ljava/util/ArrayList;

    invoke-direct {v10}, Ljava/util/ArrayList;-><init>()V

    check-cast v10, Ljava/util/Collection;

    .local v10, "destination$iv$iv":Ljava/util/Collection;
    move-object v11, v8

    .local v11, "$this$filterNotTo$iv$iv":Ljava/lang/Iterable;
    const/4 v12, 0x0

    .line 38
    .local v12, "$i$f$filterNotTo":I
    invoke-interface {v11}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v13

    :cond_76
    :goto_76
    invoke-interface {v13}, Ljava/util/Iterator;->hasNext()Z

    move-result v14

    if-eqz v14, :cond_92

    invoke-interface {v13}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v14

    .local v14, "element$iv$iv":Ljava/lang/Object;
    move-object v15, v14

    check-cast v15, Lcom/lagradost/cloudstream3/MainAPI;

    .local v15, "it":Lcom/lagradost/cloudstream3/MainAPI;
    const/16 v16, 0x0

    .line 21
    .local v16, "$i$a$-filterNot-DiziMomEntry$load$selected$1$1":I
    if-ne v15, v7, :cond_8a

    const/16 v17, 0x1

    goto :goto_8c

    :cond_8a
    move/from16 v17, v6

    .line 38
    .end local v15  # "it":Lcom/lagradost/cloudstream3/MainAPI;
    .end local v16  # "$i$a$-filterNot-DiziMomEntry$load$selected$1$1":I
    :goto_8c
    if-nez v17, :cond_76

    invoke-interface {v10, v14}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_76

    .line 39
    .end local v14  # "element$iv$iv":Ljava/lang/Object;
    :cond_92
    nop

    .end local v10  # "destination$iv$iv":Ljava/util/Collection;
    .end local v11  # "$this$filterNotTo$iv$iv":Ljava/lang/Iterable;
    .end local v12  # "$i$f$filterNotTo":I
    move-object v6, v10

    check-cast v6, Ljava/util/List;

    .line 37
    nop

    .end local v8  # "$this$filterNot$iv":Ljava/lang/Iterable;
    .end local v9  # "$i$f$filterNot":I
    check-cast v6, Ljava/lang/Iterable;

    .line 21
    nop

    .local v6, "$this$forEach$iv":Ljava/lang/Iterable;
    const/4 v8, 0x0

    .line 40
    .local v8, "$i$f$forEach":I
    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :goto_9f
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_be

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    .local v10, "element$iv":Ljava/lang/Object;
    move-object v11, v10

    check-cast v11, Lcom/lagradost/cloudstream3/MainAPI;

    .local v11, "provider":Lcom/lagradost/cloudstream3/MainAPI;
    const/4 v12, 0x0

    .line 22
    .local v12, "$i$a$-forEach-DiziMomEntry$load$selected$1$2":I
    sget-object v13, Lcom/lagradost/cloudstream3/APIHolder;->INSTANCE:Lcom/lagradost/cloudstream3/APIHolder;

    invoke-virtual {v13, v11}, Lcom/lagradost/cloudstream3/APIHolder;->removePluginMapping(Lcom/lagradost/cloudstream3/MainAPI;)V

    .line 23
    sget-object v13, Lcom/lagradost/cloudstream3/APIHolder;->INSTANCE:Lcom/lagradost/cloudstream3/APIHolder;

    invoke-virtual {v13}, Lcom/lagradost/cloudstream3/APIHolder;->getAllProviders()Lcom/lagradost/cloudstream3/utils/AtomicMutableList;

    move-result-object v13

    invoke-virtual {v13, v11}, Lcom/lagradost/cloudstream3/utils/AtomicMutableList;->remove(Ljava/lang/Object;)Z
    :try_end_bb
    .catchall {:try_start_c .. :try_end_bb} :catchall_d8

    .line 24
    nop

    .line 40
    .end local v11  # "provider":Lcom/lagradost/cloudstream3/MainAPI;
    .end local v12  # "$i$a$-forEach-DiziMomEntry$load$selected$1$2":I
    nop

    .end local v10  # "element$iv":Ljava/lang/Object;
    goto :goto_9f

    .line 41
    :cond_be
    nop

    .line 25
    .end local v6  # "$this$forEach$iv":Ljava/lang/Iterable;
    .end local v8  # "$i$f$forEach":I
    nop

    .line 15
    .end local v0  # "$i$a$-synchronized-DiziMomEntry$load$selected$1":I
    .end local v4  # "before":Ljava/util/Set;
    .end local v5  # "added":Ljava/util/List;
    .end local v7  # "keep":Lcom/lagradost/cloudstream3/MainAPI;
    monitor-exit v2

    move-object v0, v7

    .line 27
    .local v0, "selected":Lcom/lagradost/cloudstream3/MainAPI;
    sget-object v2, Ldev/wiojelt/turksinema/common/DomainUpdateUi;->INSTANCE:Ldev/wiojelt/turksinema/common/DomainUpdateUi;

    move-object v4, v1

    check-cast v4, Lcom/lagradost/cloudstream3/plugins/Plugin;

    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->listOfNotNull(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v5

    invoke-virtual {v2, v4, v3, v5}, Ldev/wiojelt/turksinema/common/DomainUpdateUi;->attach(Lcom/lagradost/cloudstream3/plugins/Plugin;Landroid/content/Context;Ljava/util/List;)V

    .line 28
    sget-object v2, Ldev/wiojelt/turksinema/common/SupportNotice;->INSTANCE:Ldev/wiojelt/turksinema/common/SupportNotice;

    const/4 v6, 0x6

    const/4 v7, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static/range {v2 .. v7}, Ldev/wiojelt/turksinema/common/SupportNotice;->showIfDue$default(Ldev/wiojelt/turksinema/common/SupportNotice;Landroid/content/Context;Ljava/lang/String;ZILjava/lang/Object;)V

    .line 29
    return-void

    .line 15
    .end local v0  # "selected":Lcom/lagradost/cloudstream3/MainAPI;
    :catchall_d8
    move-exception v0

    monitor-exit v2

    throw v0
.end method

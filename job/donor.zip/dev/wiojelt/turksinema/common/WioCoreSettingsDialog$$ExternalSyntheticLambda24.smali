.class public final synthetic Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda24;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x13
    versionHash = "7bbc1d7254613ffaa026de47d975f73968361ef3e5d7b818ce0a83a33039c6b8"
.end annotation


# instance fields
.field public final synthetic f$0:Landroid/widget/EditText;

.field public final synthetic f$1:Landroid/content/Context;

.field public final synthetic f$2:Z

.field public final synthetic f$3:Lcom/google/android/material/button/MaterialButton;

.field public final synthetic f$4:Lkotlin/jvm/functions/Function1;

.field public final synthetic f$5:Ljava/lang/String;

.field public final synthetic f$6:Landroid/app/Dialog;


# direct methods
.method public synthetic constructor <init>(Landroid/widget/EditText;Landroid/content/Context;ZLcom/google/android/material/button/MaterialButton;Lkotlin/jvm/functions/Function1;Ljava/lang/String;Landroid/app/Dialog;)V
    .registers 8

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda24;->f$0:Landroid/widget/EditText;

    iput-object p2, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda24;->f$1:Landroid/content/Context;

    iput-boolean p3, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda24;->f$2:Z

    iput-object p4, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda24;->f$3:Lcom/google/android/material/button/MaterialButton;

    iput-object p5, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda24;->f$4:Lkotlin/jvm/functions/Function1;

    iput-object p6, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda24;->f$5:Ljava/lang/String;

    iput-object p7, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda24;->f$6:Landroid/app/Dialog;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 10

    .line 0
    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda24;->f$0:Landroid/widget/EditText;

    iget-object v1, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda24;->f$1:Landroid/content/Context;

    iget-boolean v2, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda24;->f$2:Z

    iget-object v3, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda24;->f$3:Lcom/google/android/material/button/MaterialButton;

    iget-object v4, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda24;->f$4:Lkotlin/jvm/functions/Function1;

    iget-object v5, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda24;->f$5:Ljava/lang/String;

    iget-object v6, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda24;->f$6:Landroid/app/Dialog;

    move-object v7, p1

    invoke-static/range {v0 .. v7}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->$r8$lambda$ubUm-7Rn_fhV2-6jf9Uz8cEkSWE(Landroid/widget/EditText;Landroid/content/Context;ZLcom/google/android/material/button/MaterialButton;Lkotlin/jvm/functions/Function1;Ljava/lang/String;Landroid/app/Dialog;Landroid/view/View;)V

    return-void
.end method

.class public final synthetic Ldev/wiojelt/turksinema/common/WioPollNotice$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x13
    versionHash = "7bbc1d7254613ffaa026de47d975f73968361ef3e5d7b818ce0a83a33039c6b8"
.end annotation


# instance fields
.field public final synthetic f$0:Landroid/os/Handler;

.field public final synthetic f$1:Landroid/app/Activity;

.field public final synthetic f$2:Landroid/app/Dialog;


# direct methods
.method public synthetic constructor <init>(Landroid/os/Handler;Landroid/app/Activity;Landroid/app/Dialog;)V
    .registers 4

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/wiojelt/turksinema/common/WioPollNotice$$ExternalSyntheticLambda2;->f$0:Landroid/os/Handler;

    iput-object p2, p0, Ldev/wiojelt/turksinema/common/WioPollNotice$$ExternalSyntheticLambda2;->f$1:Landroid/app/Activity;

    iput-object p3, p0, Ldev/wiojelt/turksinema/common/WioPollNotice$$ExternalSyntheticLambda2;->f$2:Landroid/app/Dialog;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 5

    .line 0
    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioPollNotice$$ExternalSyntheticLambda2;->f$0:Landroid/os/Handler;

    iget-object v1, p0, Ldev/wiojelt/turksinema/common/WioPollNotice$$ExternalSyntheticLambda2;->f$1:Landroid/app/Activity;

    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioPollNotice$$ExternalSyntheticLambda2;->f$2:Landroid/app/Dialog;

    invoke-static {v0, v1, v2, p1}, Ldev/wiojelt/turksinema/common/WioPollNotice;->$r8$lambda$sAM3bh7IydkvKxU-J0XbSYgBxVA(Landroid/os/Handler;Landroid/app/Activity;Landroid/app/Dialog;Landroid/view/View;)V

    return-void
.end method

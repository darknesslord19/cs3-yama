.class public final Ldev/wiojelt/turksinema/common/WioPollNotice$showDialog$countdownRunnable$1;
.super Ljava/lang/Object;
.source "WioPollNotice.kt"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog(Landroid/app/Activity;Landroid/content/SharedPreferences;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nWioPollNotice.kt\nKotlin\n*S Kotlin\n*F\n+ 1 WioPollNotice.kt\ndev/wiojelt/turksinema/common/WioPollNotice$showDialog$countdownRunnable$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,468:1\n1#2:469\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0011\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\b\u0010\u0002\u001a\u00020\u0003H\u0016¨\u0006\u0004"
    }
    d2 = {
        "dev/wiojelt/turksinema/common/WioPollNotice$showDialog$countdownRunnable$1",
        "Ljava/lang/Runnable;",
        "run",
        "",
        "DiziMom"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation

.annotation build Lkotlin/jvm/internal/SourceDebugExtension;
    value = {
        "SMAP\nWioPollNotice.kt\nKotlin\n*S Kotlin\n*F\n+ 1 WioPollNotice.kt\ndev/wiojelt/turksinema/common/WioPollNotice$showDialog$countdownRunnable$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,468:1\n1#2:469\n*E\n"
    }
.end annotation


# instance fields
.field final synthetic $activity:Landroid/app/Activity;

.field final synthetic $autoTargetUrl:Ljava/lang/String;

.field final synthetic $countdownHandler:Landroid/os/Handler;

.field final synthetic $countdownText:Landroid/widget/TextView;

.field final synthetic $dialog:Landroid/app/Dialog;

.field final synthetic $elapsedMs:Lkotlin/jvm/internal/Ref$LongRef;

.field final synthetic $progressBar:Landroid/widget/ProgressBar;

.field final synthetic $totalDurationMs:J


# direct methods
.method constructor <init>(Lkotlin/jvm/internal/Ref$LongRef;JLandroid/widget/ProgressBar;Landroid/widget/TextView;Landroid/os/Handler;Landroid/app/Activity;Ljava/lang/String;Landroid/app/Dialog;)V
    .registers 10
    .param p1, "$elapsedMs"  # Lkotlin/jvm/internal/Ref$LongRef;
    .param p2, "$totalDurationMs"  # J
    .param p4, "$progressBar"  # Landroid/widget/ProgressBar;
    .param p5, "$countdownText"  # Landroid/widget/TextView;
    .param p6, "$countdownHandler"  # Landroid/os/Handler;
    .param p7, "$activity"  # Landroid/app/Activity;
    .param p8, "$autoTargetUrl"  # Ljava/lang/String;
    .param p9, "$dialog"  # Landroid/app/Dialog;

    iput-object p1, p0, Ldev/wiojelt/turksinema/common/WioPollNotice$showDialog$countdownRunnable$1;->$elapsedMs:Lkotlin/jvm/internal/Ref$LongRef;

    iput-wide p2, p0, Ldev/wiojelt/turksinema/common/WioPollNotice$showDialog$countdownRunnable$1;->$totalDurationMs:J

    iput-object p4, p0, Ldev/wiojelt/turksinema/common/WioPollNotice$showDialog$countdownRunnable$1;->$progressBar:Landroid/widget/ProgressBar;

    iput-object p5, p0, Ldev/wiojelt/turksinema/common/WioPollNotice$showDialog$countdownRunnable$1;->$countdownText:Landroid/widget/TextView;

    iput-object p6, p0, Ldev/wiojelt/turksinema/common/WioPollNotice$showDialog$countdownRunnable$1;->$countdownHandler:Landroid/os/Handler;

    iput-object p7, p0, Ldev/wiojelt/turksinema/common/WioPollNotice$showDialog$countdownRunnable$1;->$activity:Landroid/app/Activity;

    iput-object p8, p0, Ldev/wiojelt/turksinema/common/WioPollNotice$showDialog$countdownRunnable$1;->$autoTargetUrl:Ljava/lang/String;

    iput-object p9, p0, Ldev/wiojelt/turksinema/common/WioPollNotice$showDialog$countdownRunnable$1;->$dialog:Landroid/app/Dialog;

    .line 238
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 8

    .line 240
    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioPollNotice$showDialog$countdownRunnable$1;->$elapsedMs:Lkotlin/jvm/internal/Ref$LongRef;

    iget-object v1, p0, Ldev/wiojelt/turksinema/common/WioPollNotice$showDialog$countdownRunnable$1;->$elapsedMs:Lkotlin/jvm/internal/Ref$LongRef;

    iget-wide v1, v1, Lkotlin/jvm/internal/Ref$LongRef;->element:J

    const-wide/16 v3, 0x64

    add-long/2addr v1, v3

    iput-wide v1, v0, Lkotlin/jvm/internal/Ref$LongRef;->element:J

    .line 241
    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioPollNotice$showDialog$countdownRunnable$1;->$elapsedMs:Lkotlin/jvm/internal/Ref$LongRef;

    iget-wide v0, v0, Lkotlin/jvm/internal/Ref$LongRef;->element:J

    long-to-float v0, v0

    iget-wide v1, p0, Ldev/wiojelt/turksinema/common/WioPollNotice$showDialog$countdownRunnable$1;->$totalDurationMs:J

    long-to-float v1, v1

    div-float/2addr v0, v1

    const/4 v1, 0x0

    const/high16 v2, 0x3f800000  # 1.0f

    invoke-static {v0, v1, v2}, Lkotlin/ranges/RangesKt;->coerceIn(FFF)F

    move-result v0

    .line 242
    .local v0, "progressFraction":F
    iget-object v1, p0, Ldev/wiojelt/turksinema/common/WioPollNotice$showDialog$countdownRunnable$1;->$progressBar:Landroid/widget/ProgressBar;

    const/high16 v2, 0x447a0000  # 1000.0f

    mul-float/2addr v2, v0

    float-to-int v2, v2

    invoke-virtual {v1, v2}, Landroid/widget/ProgressBar;->setProgress(I)V

    .line 244
    iget-wide v1, p0, Ldev/wiojelt/turksinema/common/WioPollNotice$showDialog$countdownRunnable$1;->$totalDurationMs:J

    iget-object v5, p0, Ldev/wiojelt/turksinema/common/WioPollNotice$showDialog$countdownRunnable$1;->$elapsedMs:Lkotlin/jvm/internal/Ref$LongRef;

    iget-wide v5, v5, Lkotlin/jvm/internal/Ref$LongRef;->element:J

    sub-long/2addr v1, v5

    const-wide/16 v5, 0x3e7

    add-long/2addr v1, v5

    const-wide/16 v5, 0x3e8

    div-long/2addr v1, v5

    long-to-int v1, v1

    .line 245
    .local v1, "secondsRemaining":I
    if-lez v1, :cond_64

    .line 246
    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioPollNotice$showDialog$countdownRunnable$1;->$countdownText:Landroid/widget/TextView;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "⏳ "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, "s • Otomatik ankete yönlendiriliyorsunuz"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    check-cast v5, Ljava/lang/CharSequence;

    invoke-virtual {v2, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 247
    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioPollNotice$showDialog$countdownRunnable$1;->$countdownHandler:Landroid/os/Handler;

    move-object v5, p0

    check-cast v5, Ljava/lang/Runnable;

    invoke-virtual {v2, v5, v3, v4}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    move-result v2

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    check-cast v2, Ljava/io/Serializable;

    goto :goto_9f

    .line 249
    :cond_64
    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioPollNotice$showDialog$countdownRunnable$1;->$progressBar:Landroid/widget/ProgressBar;

    const/16 v3, 0x3e8

    invoke-virtual {v2, v3}, Landroid/widget/ProgressBar;->setProgress(I)V

    .line 250
    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioPollNotice$showDialog$countdownRunnable$1;->$countdownText:Landroid/widget/TextView;

    const-string v3, "\ud83d\ude80 Yönlendiriliyor..."

    check-cast v3, Ljava/lang/CharSequence;

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 251
    sget-object v2, Ldev/wiojelt/turksinema/common/WioPollNotice;->INSTANCE:Ldev/wiojelt/turksinema/common/WioPollNotice;

    iget-object v3, p0, Ldev/wiojelt/turksinema/common/WioPollNotice$showDialog$countdownRunnable$1;->$activity:Landroid/app/Activity;

    check-cast v3, Landroid/content/Context;

    iget-object v4, p0, Ldev/wiojelt/turksinema/common/WioPollNotice$showDialog$countdownRunnable$1;->$autoTargetUrl:Ljava/lang/String;

    invoke-static {v2, v3, v4}, Ldev/wiojelt/turksinema/common/WioPollNotice;->access$openUrl(Ldev/wiojelt/turksinema/common/WioPollNotice;Landroid/content/Context;Ljava/lang/String;)V

    .line 252
    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioPollNotice$showDialog$countdownRunnable$1;->$dialog:Landroid/app/Dialog;

    :try_start_81
    sget-object v3, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v3, p0

    check-cast v3, Ldev/wiojelt/turksinema/common/WioPollNotice$showDialog$countdownRunnable$1;

    .line 469
    .local v3, "$this$run_u24lambda_u240":Ldev/wiojelt/turksinema/common/WioPollNotice$showDialog$countdownRunnable$1;
    const/4 v4, 0x0

    .line 252
    .local v4, "$i$a$-runCatching-WioPollNotice$showDialog$countdownRunnable$1$run$1":I
    invoke-virtual {v2}, Landroid/app/Dialog;->dismiss()V

    .end local v3  # "$this$run_u24lambda_u240":Ldev/wiojelt/turksinema/common/WioPollNotice$showDialog$countdownRunnable$1;
    .end local v4  # "$i$a$-runCatching-WioPollNotice$showDialog$countdownRunnable$1$run$1":I
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    invoke-static {v2}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2
    :try_end_90
    .catchall {:try_start_81 .. :try_end_90} :catchall_91

    goto :goto_9c

    :catchall_91
    move-exception v2

    sget-object v3, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v2}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v2

    invoke-static {v2}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    :goto_9c
    invoke-static {v2}, Lkotlin/Result;->box-impl(Ljava/lang/Object;)Lkotlin/Result;

    .line 254
    :goto_9f
    return-void
.end method

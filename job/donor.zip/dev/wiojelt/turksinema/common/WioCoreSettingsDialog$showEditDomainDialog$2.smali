.class public final Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$showEditDomainDialog$2;
.super Ljava/lang/Object;
.source "WioCoreSettingsDialog.kt"

# interfaces
.implements Landroid/text/TextWatcher;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;ZIILkotlin/jvm/functions/Function1;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000%\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\r\n\u0000\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J*\u0010\u0002\u001a\u00020\u00032\b\u0010\u0004\u001a\u0004\u0018\u00010\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\u00072\u0006\u0010\t\u001a\u00020\u0007H\u0016J*\u0010\n\u001a\u00020\u00032\b\u0010\u0004\u001a\u0004\u0018\u00010\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\u000b\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\u0007H\u0016J\u0012\u0010\f\u001a\u00020\u00032\b\u0010\u0004\u001a\u0004\u0018\u00010\rH\u0016¨\u0006\u000e"
    }
    d2 = {
        "dev/wiojelt/turksinema/common/WioCoreSettingsDialog$showEditDomainDialog$2",
        "Landroid/text/TextWatcher;",
        "beforeTextChanged",
        "",
        "s",
        "",
        "start",
        "",
        "count",
        "after",
        "onTextChanged",
        "before",
        "afterTextChanged",
        "Landroid/text/Editable;",
        "DiziMom"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $btnIncrement:Lcom/google/android/material/button/MaterialButton;

.field final synthetic $englishLabels:Z

.field final synthetic $input:Landroid/widget/EditText;


# direct methods
.method constructor <init>(Landroid/widget/EditText;Lcom/google/android/material/button/MaterialButton;Z)V
    .registers 4
    .param p1, "$input"  # Landroid/widget/EditText;
    .param p2, "$btnIncrement"  # Lcom/google/android/material/button/MaterialButton;
    .param p3, "$englishLabels"  # Z

    iput-object p1, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$showEditDomainDialog$2;->$input:Landroid/widget/EditText;

    iput-object p2, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$showEditDomainDialog$2;->$btnIncrement:Lcom/google/android/material/button/MaterialButton;

    iput-boolean p3, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$showEditDomainDialog$2;->$englishLabels:Z

    .line 264
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public afterTextChanged(Landroid/text/Editable;)V
    .registers 2
    .param p1, "s"  # Landroid/text/Editable;

    .line 267
    return-void
.end method

.method public beforeTextChanged(Ljava/lang/CharSequence;III)V
    .registers 5
    .param p1, "s"  # Ljava/lang/CharSequence;
    .param p2, "start"  # I
    .param p3, "count"  # I
    .param p4, "after"  # I

    .line 265
    return-void
.end method

.method public onTextChanged(Ljava/lang/CharSequence;III)V
    .registers 8
    .param p1, "s"  # Ljava/lang/CharSequence;
    .param p2, "start"  # I
    .param p3, "before"  # I
    .param p4, "count"  # I

    .line 266
    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$showEditDomainDialog$2;->$input:Landroid/widget/EditText;

    iget-object v1, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$showEditDomainDialog$2;->$btnIncrement:Lcom/google/android/material/button/MaterialButton;

    iget-boolean v2, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$showEditDomainDialog$2;->$englishLabels:Z

    invoke-static {v0, v1, v2}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->access$showEditDomainDialog$updateIncrementBtn(Landroid/widget/EditText;Lcom/google/android/material/button/MaterialButton;Z)V

    return-void
.end method

.class public final Ldev/wiojelt/turksinema/common/WioPollNotice;
.super Ljava/lang/Object;
.source "WioPollNotice.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000@\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\t\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0006\u0010\u000f\u001a\u00020\u0005J\"\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u00132\b\b\u0002\u0010\u0014\u001a\u00020\u00052\b\b\u0002\u0010\u0015\u001a\u00020\u000eJ \u0010\u0016\u001a\u00020\u00112\u0006\u0010\u0017\u001a\u00020\u00182\u0006\u0010\u0019\u001a\u00020\u001a2\u0006\u0010\u0014\u001a\u00020\u0005H\u0002J\u0018\u0010\u001b\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u001c\u001a\u00020\u0005H\u0002R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u000eX\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u001d"
    }
    d2 = {
        "Ldev/wiojelt/turksinema/common/WioPollNotice;",
        "",
        "<init>",
        "()V",
        "PREFS",
        "",
        "LAST_DAY",
        "KEY_VOTED",
        "POLL_END_TIME_MS",
        "",
        "URL_STRAWPOLL_SINEMA",
        "URL_STRAWPOLL_SPOR",
        "URL_TELEGRAM_POST",
        "isShownThisSession",
        "",
        "getRemainingTimeText",
        "showIfDue",
        "",
        "context",
        "Landroid/content/Context;",
        "category",
        "force",
        "showDialog",
        "activity",
        "Landroid/app/Activity;",
        "prefs",
        "Landroid/content/SharedPreferences;",
        "openUrl",
        "url",
        "DiziMom"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final INSTANCE:Ldev/wiojelt/turksinema/common/WioPollNotice;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field private static final KEY_VOTED:Ljava/lang/String; = "poll_post_23_voted"
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field private static final LAST_DAY:Ljava/lang/String; = "poll_post_23_last_day"
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field public static final POLL_END_TIME_MS:J = 0x1a0e2cf6208L

.field private static final PREFS:Ljava/lang/String; = "wio_global_poll_notice"
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field public static final URL_STRAWPOLL_SINEMA:Ljava/lang/String; = "https://strawpoll.com/bVg8BO3NryY"
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field public static final URL_STRAWPOLL_SPOR:Ljava/lang/String; = "https://strawpoll.com/61gD9paj9Zw"
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field public static final URL_TELEGRAM_POST:Ljava/lang/String; = "https://t.me/wiolandcs3/23"
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field private static volatile isShownThisSession:Z


# direct methods
.method public static synthetic $r8$lambda$ix1ATpm2uHgfyTqSAFQCv2Ge-Bo(Landroid/os/Handler;Landroid/app/Dialog;Landroid/view/View;)V
    .registers 3

    invoke-static {p0, p1, p2}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$lambda$24$0(Landroid/os/Handler;Landroid/app/Dialog;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$mwg09k24HtvB9vqLKAiDOwmL-Cc(Landroid/os/Handler;Landroid/app/Activity;Landroid/app/Dialog;Landroid/view/View;)V
    .registers 4

    invoke-static {p0, p1, p2, p3}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$lambda$12$2(Landroid/os/Handler;Landroid/app/Activity;Landroid/app/Dialog;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$sAM3bh7IydkvKxU-J0XbSYgBxVA(Landroid/os/Handler;Landroid/app/Activity;Landroid/app/Dialog;Landroid/view/View;)V
    .registers 4

    invoke-static {p0, p1, p2, p3}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$lambda$17$2(Landroid/os/Handler;Landroid/app/Activity;Landroid/app/Dialog;Landroid/view/View;)V

    return-void
.end method

.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Ldev/wiojelt/turksinema/common/WioPollNotice;

    invoke-direct {v0}, Ldev/wiojelt/turksinema/common/WioPollNotice;-><init>()V

    sput-object v0, Ldev/wiojelt/turksinema/common/WioPollNotice;->INSTANCE:Ldev/wiojelt/turksinema/common/WioPollNotice;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 25
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static final synthetic access$openUrl(Ldev/wiojelt/turksinema/common/WioPollNotice;Landroid/content/Context;Ljava/lang/String;)V
    .registers 3
    .param p0, "$this"  # Ldev/wiojelt/turksinema/common/WioPollNotice;
    .param p1, "context"  # Landroid/content/Context;
    .param p2, "url"  # Ljava/lang/String;

    .line 25
    invoke-direct {p0, p1, p2}, Ldev/wiojelt/turksinema/common/WioPollNotice;->openUrl(Landroid/content/Context;Ljava/lang/String;)V

    return-void
.end method

.method private final openUrl(Landroid/content/Context;Ljava/lang/String;)V
    .registers 8
    .param p1, "context"  # Landroid/content/Context;
    .param p2, "url"  # Ljava/lang/String;

    .line 463
    :try_start_0
    sget-object v0, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v0, p0

    check-cast v0, Ldev/wiojelt/turksinema/common/WioPollNotice;

    .local v0, "$this$openUrl_u24lambda_u240":Ldev/wiojelt/turksinema/common/WioPollNotice;
    const/4 v1, 0x0

    .line 464
    .local v1, "$i$a$-runCatching-WioPollNotice$openUrl$1":I
    new-instance v2, Landroid/content/Intent;

    const-string v3, "android.intent.action.VIEW"

    invoke-static {p2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v4

    invoke-direct {v2, v3, v4}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    const/high16 v3, 0x10000000

    invoke-virtual {v2, v3}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v2

    invoke-virtual {p1, v2}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 465
    nop

    .end local v0  # "$this$openUrl_u24lambda_u240":Ldev/wiojelt/turksinema/common/WioPollNotice;
    .end local v1  # "$i$a$-runCatching-WioPollNotice$openUrl$1":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 463
    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_20
    .catchall {:try_start_0 .. :try_end_20} :catchall_21

    goto :goto_2b

    :catchall_21
    move-exception v0

    sget-object v1, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v0}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    .line 466
    :goto_2b
    return-void
.end method

.method private final showDialog(Landroid/app/Activity;Landroid/content/SharedPreferences;Ljava/lang/String;)V
    .registers 54
    .param p1, "activity"  # Landroid/app/Activity;
    .param p2, "prefs"  # Landroid/content/SharedPreferences;
    .param p3, "category"  # Ljava/lang/String;

    .line 78
    move-object/from16 v10, p3

    invoke-virtual/range {p1 .. p1}, Landroid/app/Activity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v11, v0, Landroid/util/DisplayMetrics;->density:F

    .line 81
    .local v11, "density":F
    invoke-virtual/range {p1 .. p1}, Landroid/app/Activity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v12, v0, Landroid/util/DisplayMetrics;->widthPixels:I

    .line 82
    .local v12, "screenWidth":I
    int-to-float v0, v12

    const v1, 0x3f6147ae  # 0.88f

    mul-float/2addr v0, v1

    float-to-int v0, v0

    const/16 v1, 0x140

    invoke-static {v11, v1}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v1

    const/16 v2, 0x1ae

    invoke-static {v11, v2}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v2

    invoke-static {v0, v1, v2}, Lkotlin/ranges/RangesKt;->coerceIn(III)I

    move-result v13

    .line 84
    .local v13, "dialogWidth":I
    new-instance v9, Landroid/app/Dialog;

    move-object/from16 v0, p1

    check-cast v0, Landroid/content/Context;

    invoke-direct {v9, v0}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    .line 85
    .local v9, "dialog":Landroid/app/Dialog;
    const/4 v14, 0x1

    invoke-virtual {v9, v14}, Landroid/app/Dialog;->requestWindowFeature(I)Z

    .line 88
    const/4 v15, 0x0

    invoke-virtual {v9, v15}, Landroid/app/Dialog;->setCancelable(Z)V

    .line 89
    invoke-virtual {v9, v15}, Landroid/app/Dialog;->setCanceledOnTouchOutside(Z)V

    .line 92
    new-instance v0, Landroid/widget/LinearLayout;

    move-object/from16 v1, p1

    check-cast v1, Landroid/content/Context;

    invoke-direct {v0, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v1, v0

    .local v1, "$this$showDialog_u24lambda_u240":Landroid/widget/LinearLayout;
    const/4 v2, 0x0

    .line 93
    .local v2, "$i$a$-apply-WioPollNotice$showDialog$root$1":I
    invoke-virtual {v1, v14}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 94
    invoke-virtual {v1, v14}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 95
    new-instance v3, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v3}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object v4, v3

    .local v4, "$this$showDialog_u24lambda_u240_u240":Landroid/graphics/drawable/GradientDrawable;
    const/4 v5, 0x0

    .line 96
    .local v5, "$i$a$-apply-WioPollNotice$showDialog$root$1$1":I
    const-string v6, "#F20D0E12"

    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v6

    invoke-virtual {v4, v6}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 97
    const/16 v6, 0x1c

    invoke-static {v11, v6}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v6

    int-to-float v6, v6

    invoke-virtual {v4, v6}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 98
    invoke-static {v11, v14}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v6

    const-string v7, "#33FFFFFF"

    invoke-static {v7}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v8

    invoke-virtual {v4, v6, v8}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 99
    nop

    .line 95
    .end local v4  # "$this$showDialog_u24lambda_u240_u240":Landroid/graphics/drawable/GradientDrawable;
    .end local v5  # "$i$a$-apply-WioPollNotice$showDialog$root$1$1":I
    check-cast v3, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v1, v3}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 100
    const/16 v3, 0x16

    invoke-static {v11, v3}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v4

    invoke-static {v11, v3}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v5

    invoke-static {v11, v3}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v3

    const/16 v6, 0x14

    invoke-static {v11, v6}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v6

    invoke-virtual {v1, v4, v5, v3, v6}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 101
    nop

    .line 92
    .end local v1  # "$this$showDialog_u24lambda_u240":Landroid/widget/LinearLayout;
    .end local v2  # "$i$a$-apply-WioPollNotice$showDialog$root$1":I
    nop

    .line 104
    .local v0, "root":Landroid/widget/LinearLayout;
    new-instance v1, Landroid/widget/LinearLayout;

    move-object/from16 v2, p1

    check-cast v2, Landroid/content/Context;

    invoke-direct {v1, v2}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v2, v1

    .local v2, "$this$showDialog_u24lambda_u241":Landroid/widget/LinearLayout;
    const/4 v3, 0x0

    .line 105
    .local v3, "$i$a$-apply-WioPollNotice$showDialog$headerRow$1":I
    invoke-virtual {v2, v15}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 106
    const/16 v4, 0x11

    invoke-virtual {v2, v4}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 107
    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v6, -0x1

    const/4 v8, -0x2

    invoke-direct {v5, v6, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object/from16 v16, v5

    .local v16, "$this$showDialog_u24lambda_u241_u240":Landroid/widget/LinearLayout$LayoutParams;
    const/16 v17, 0x0

    .line 108
    .local v17, "$i$a$-apply-WioPollNotice$showDialog$headerRow$1$1":I
    const/16 v8, 0xe

    invoke-static {v11, v8}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v4

    move-object/from16 v6, v16

    .end local v16  # "$this$showDialog_u24lambda_u241_u240":Landroid/widget/LinearLayout$LayoutParams;
    .local v6, "$this$showDialog_u24lambda_u241_u240":Landroid/widget/LinearLayout$LayoutParams;
    invoke-virtual {v6, v15, v15, v15, v4}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 109
    nop

    .line 107
    .end local v6  # "$this$showDialog_u24lambda_u241_u240":Landroid/widget/LinearLayout$LayoutParams;
    .end local v17  # "$i$a$-apply-WioPollNotice$showDialog$headerRow$1$1":I
    check-cast v5, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v2, v5}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 110
    nop

    .line 104
    .end local v2  # "$this$showDialog_u24lambda_u241":Landroid/widget/LinearLayout;
    .end local v3  # "$i$a$-apply-WioPollNotice$showDialog$headerRow$1":I
    nop

    .line 113
    .local v1, "headerRow":Landroid/widget/LinearLayout;
    new-instance v2, Landroid/widget/LinearLayout;

    move-object/from16 v3, p1

    check-cast v3, Landroid/content/Context;

    invoke-direct {v2, v3}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v3, v2

    .local v3, "$this$showDialog_u24lambda_u242":Landroid/widget/LinearLayout;
    const/4 v4, 0x0

    .line 114
    .local v4, "$i$a$-apply-WioPollNotice$showDialog$badgePill$1":I
    invoke-virtual {v3, v15}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 115
    const/16 v5, 0x10

    invoke-virtual {v3, v5}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 116
    new-instance v6, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v6}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object/from16 v16, v6

    .local v16, "$this$showDialog_u24lambda_u242_u240":Landroid/graphics/drawable/GradientDrawable;
    const/16 v17, 0x0

    .line 117
    .local v17, "$i$a$-apply-WioPollNotice$showDialog$badgePill$1$1":I
    const-string v20, "#181A20"

    invoke-static/range {v20 .. v20}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v5

    move-object/from16 v15, v16

    .end local v16  # "$this$showDialog_u24lambda_u242_u240":Landroid/graphics/drawable/GradientDrawable;
    .local v15, "$this$showDialog_u24lambda_u242_u240":Landroid/graphics/drawable/GradientDrawable;
    invoke-virtual {v15, v5}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 118
    const/16 v5, 0x64

    invoke-static {v11, v5}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v8

    int-to-float v8, v8

    invoke-virtual {v15, v8}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 119
    invoke-static {v11, v14}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v8

    invoke-static {v7}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v7

    invoke-virtual {v15, v8, v7}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 120
    nop

    .line 116
    .end local v15  # "$this$showDialog_u24lambda_u242_u240":Landroid/graphics/drawable/GradientDrawable;
    .end local v17  # "$i$a$-apply-WioPollNotice$showDialog$badgePill$1$1":I
    check-cast v6, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v3, v6}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 121
    const/16 v6, 0xc

    invoke-static {v11, v6}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v7

    const/4 v15, 0x5

    invoke-static {v11, v15}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v8

    const/16 v6, 0xe

    invoke-static {v11, v6}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v5

    invoke-static {v11, v15}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v6

    invoke-virtual {v3, v7, v8, v5, v6}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 122
    nop

    .line 113
    .end local v3  # "$this$showDialog_u24lambda_u242":Landroid/widget/LinearLayout;
    .end local v4  # "$i$a$-apply-WioPollNotice$showDialog$badgePill$1":I
    nop

    .line 124
    .local v2, "badgePill":Landroid/widget/LinearLayout;
    new-instance v3, Landroid/widget/TextView;

    move-object/from16 v4, p1

    check-cast v4, Landroid/content/Context;

    invoke-direct {v3, v4}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v4, v3

    .local v4, "$this$showDialog_u24lambda_u243":Landroid/widget/TextView;
    const/4 v5, 0x0

    .line 125
    .local v5, "$i$a$-apply-WioPollNotice$showDialog$redDot$1":I
    const-string v6, "●"

    check-cast v6, Ljava/lang/CharSequence;

    invoke-virtual {v4, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 126
    const/high16 v6, 0x41100000  # 9.0f

    invoke-virtual {v4, v6}, Landroid/widget/TextView;->setTextSize(F)V

    .line 127
    const-string v6, "#E01E2B"

    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v7

    invoke-virtual {v4, v7}, Landroid/widget/TextView;->setTextColor(I)V

    .line 128
    const/4 v7, 0x6

    invoke-static {v11, v7}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v8

    const/4 v7, 0x0

    invoke-virtual {v4, v7, v7, v8, v7}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 129
    nop

    .line 124
    .end local v4  # "$this$showDialog_u24lambda_u243":Landroid/widget/TextView;
    .end local v5  # "$i$a$-apply-WioPollNotice$showDialog$redDot$1":I
    move-object/from16 v24, v3

    .line 130
    .local v24, "redDot":Landroid/widget/TextView;
    move-object/from16 v3, v24

    check-cast v3, Landroid/view/View;

    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 132
    new-instance v3, Landroid/widget/TextView;

    move-object/from16 v4, p1

    check-cast v4, Landroid/content/Context;

    invoke-direct {v3, v4}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v4, v3

    .local v4, "$this$showDialog_u24lambda_u244":Landroid/widget/TextView;
    const/4 v5, 0x0

    .line 133
    .local v5, "$i$a$-apply-WioPollNotice$showDialog$badgeText$1":I
    const-string v7, "TOPLULUK OYLAMASI"

    check-cast v7, Ljava/lang/CharSequence;

    invoke-virtual {v4, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 134
    const/high16 v7, 0x41200000  # 10.0f

    invoke-virtual {v4, v7}, Landroid/widget/TextView;->setTextSize(F)V

    .line 135
    sget-object v7, Landroid/graphics/Typeface;->MONOSPACE:Landroid/graphics/Typeface;

    invoke-virtual {v4, v7}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 136
    invoke-virtual {v4}, Landroid/widget/TextView;->getTypeface()Landroid/graphics/Typeface;

    move-result-object v7

    invoke-virtual {v4, v7, v14}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 137
    const-string v7, "#EEEEEE"

    invoke-static {v7}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v7

    invoke-virtual {v4, v7}, Landroid/widget/TextView;->setTextColor(I)V

    .line 138
    const v7, 0x3da3d70a  # 0.08f

    invoke-virtual {v4, v7}, Landroid/widget/TextView;->setLetterSpacing(F)V

    .line 139
    nop

    .line 132
    .end local v4  # "$this$showDialog_u24lambda_u244":Landroid/widget/TextView;
    .end local v5  # "$i$a$-apply-WioPollNotice$showDialog$badgeText$1":I
    move-object/from16 v25, v3

    .line 140
    .local v25, "badgeText":Landroid/widget/TextView;
    move-object/from16 v3, v25

    check-cast v3, Landroid/view/View;

    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 141
    move-object v3, v2

    check-cast v3, Landroid/view/View;

    invoke-virtual {v1, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 142
    move-object v3, v1

    check-cast v3, Landroid/view/View;

    invoke-virtual {v0, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 145
    new-instance v3, Landroid/widget/TextView;

    move-object/from16 v4, p1

    check-cast v4, Landroid/content/Context;

    invoke-direct {v3, v4}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v4, v3

    .local v4, "$this$showDialog_u24lambda_u245":Landroid/widget/TextView;
    const/4 v5, 0x0

    .line 146
    .local v5, "$i$a$-apply-WioPollNotice$showDialog$questionTitle$1":I
    const-string v7, "Hangi kaynaklar kalmalı?"

    check-cast v7, Ljava/lang/CharSequence;

    invoke-virtual {v4, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 147
    const/high16 v7, 0x41980000  # 19.0f

    invoke-virtual {v4, v7}, Landroid/widget/TextView;->setTextSize(F)V

    .line 148
    const/4 v7, 0x0

    invoke-virtual {v4, v7, v14}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 149
    const/4 v8, -0x1

    invoke-virtual {v4, v8}, Landroid/widget/TextView;->setTextColor(I)V

    .line 150
    const/16 v7, 0x11

    invoke-virtual {v4, v7}, Landroid/widget/TextView;->setGravity(I)V

    .line 151
    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v15, -0x2

    invoke-direct {v7, v8, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object v8, v7

    .local v8, "$this$showDialog_u24lambda_u245_u240":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v15, 0x0

    .line 152
    .local v15, "$i$a$-apply-WioPollNotice$showDialog$questionTitle$1$1":I
    const/4 v14, 0x4

    move-object/from16 v28, v1

    .end local v1  # "headerRow":Landroid/widget/LinearLayout;
    .local v28, "headerRow":Landroid/widget/LinearLayout;
    invoke-static {v11, v14}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v1

    const/4 v14, 0x0

    invoke-virtual {v8, v14, v14, v14, v1}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 153
    nop

    .line 151
    .end local v8  # "$this$showDialog_u24lambda_u245_u240":Landroid/widget/LinearLayout$LayoutParams;
    .end local v15  # "$i$a$-apply-WioPollNotice$showDialog$questionTitle$1$1":I
    check-cast v7, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v4, v7}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 154
    nop

    .line 145
    .end local v4  # "$this$showDialog_u24lambda_u245":Landroid/widget/TextView;
    .end local v5  # "$i$a$-apply-WioPollNotice$showDialog$questionTitle$1":I
    move-object v14, v3

    .line 155
    .local v14, "questionTitle":Landroid/widget/TextView;
    move-object v1, v14

    check-cast v1, Landroid/view/View;

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 158
    new-instance v1, Landroid/widget/TextView;

    move-object/from16 v3, p1

    check-cast v3, Landroid/content/Context;

    invoke-direct {v1, v3}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v3, v1

    .local v3, "$this$showDialog_u24lambda_u246":Landroid/widget/TextView;
    const/4 v4, 0x0

    .line 159
    .local v4, "$i$a$-apply-WioPollNotice$showDialog$questionSub$1":I
    const-string v5, "Gereksizler silinecek, sadece en çok oy alanlar kalacak.\nKullandığınız en iyi 5 sağlayıcıyı oylayın."

    check-cast v5, Ljava/lang/CharSequence;

    invoke-virtual {v3, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 160
    const/high16 v5, 0x41480000  # 12.5f

    invoke-virtual {v3, v5}, Landroid/widget/TextView;->setTextSize(F)V

    .line 161
    const-string v15, "#8E95A5"

    invoke-static {v15}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {v3, v5}, Landroid/widget/TextView;->setTextColor(I)V

    .line 162
    const/16 v7, 0x11

    invoke-virtual {v3, v7}, Landroid/widget/TextView;->setGravity(I)V

    .line 163
    const/4 v5, 0x2

    invoke-static {v11, v5}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v7

    int-to-float v7, v7

    const/high16 v8, 0x3fa00000  # 1.25f

    invoke-virtual {v3, v7, v8}, Landroid/widget/TextView;->setLineSpacing(FF)V

    .line 164
    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v5, -0x2

    const/4 v8, -0x1

    invoke-direct {v7, v8, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object v5, v7

    .local v5, "$this$showDialog_u24lambda_u246_u240":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v8, 0x0

    .line 165
    .local v8, "$i$a$-apply-WioPollNotice$showDialog$questionSub$1$1":I
    move/from16 v31, v12

    .end local v12  # "screenWidth":I
    .local v31, "screenWidth":I
    const/16 v12, 0xa

    move-object/from16 v32, v1

    invoke-static {v11, v12}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v1

    const/4 v12, 0x0

    invoke-virtual {v5, v12, v12, v12, v1}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 166
    nop

    .line 164
    .end local v5  # "$this$showDialog_u24lambda_u246_u240":Landroid/widget/LinearLayout$LayoutParams;
    .end local v8  # "$i$a$-apply-WioPollNotice$showDialog$questionSub$1$1":I
    check-cast v7, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v3, v7}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 167
    nop

    .line 158
    .end local v3  # "$this$showDialog_u24lambda_u246":Landroid/widget/TextView;
    .end local v4  # "$i$a$-apply-WioPollNotice$showDialog$questionSub$1":I
    nop

    .line 168
    .local v32, "questionSub":Landroid/widget/TextView;
    move-object/from16 v1, v32

    check-cast v1, Landroid/view/View;

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 171
    new-instance v1, Landroid/widget/TextView;

    move-object/from16 v3, p1

    check-cast v3, Landroid/content/Context;

    invoke-direct {v1, v3}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v3, v1

    .local v3, "$this$showDialog_u24lambda_u247":Landroid/widget/TextView;
    const/4 v4, 0x0

    .line 172
    .local v4, "$i$a$-apply-WioPollNotice$showDialog$remainingPill$1":I
    sget-object v5, Ldev/wiojelt/turksinema/common/WioPollNotice;->INSTANCE:Ldev/wiojelt/turksinema/common/WioPollNotice;

    invoke-virtual {v5}, Ldev/wiojelt/turksinema/common/WioPollNotice;->getRemainingTimeText()Ljava/lang/String;

    move-result-object v5

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "⏱️ Oylamanın bitmesine "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    check-cast v5, Ljava/lang/CharSequence;

    invoke-virtual {v3, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 173
    const/high16 v12, 0x41380000  # 11.5f

    invoke-virtual {v3, v12}, Landroid/widget/TextView;->setTextSize(F)V

    .line 174
    const-string v5, "#A1A1AA"

    invoke-static {v5}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {v3, v5}, Landroid/widget/TextView;->setTextColor(I)V

    .line 175
    new-instance v5, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v5}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object v7, v5

    .local v7, "$this$showDialog_u24lambda_u247_u240":Landroid/graphics/drawable/GradientDrawable;
    const/4 v8, 0x0

    .line 176
    .local v8, "$i$a$-apply-WioPollNotice$showDialog$remainingPill$1$1":I
    const-string v34, "#141519"

    invoke-static/range {v34 .. v34}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v12

    invoke-virtual {v7, v12}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 177
    move-object/from16 v22, v1

    const/16 v12, 0x64

    invoke-static {v11, v12}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v1

    int-to-float v1, v1

    invoke-virtual {v7, v1}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 178
    const/4 v1, 0x1

    invoke-static {v11, v1}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v12

    const-string v1, "#22FFFFFF"

    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v7, v12, v1}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 179
    nop

    .line 175
    .end local v7  # "$this$showDialog_u24lambda_u247_u240":Landroid/graphics/drawable/GradientDrawable;
    .end local v8  # "$i$a$-apply-WioPollNotice$showDialog$remainingPill$1$1":I
    check-cast v5, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v3, v5}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 180
    const/16 v1, 0xc

    invoke-static {v11, v1}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v5

    const/4 v7, 0x5

    invoke-static {v11, v7}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v8

    invoke-static {v11, v1}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v12

    invoke-static {v11, v7}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v1

    invoke-virtual {v3, v5, v8, v12, v1}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 181
    const/16 v7, 0x11

    invoke-virtual {v3, v7}, Landroid/widget/TextView;->setGravity(I)V

    .line 182
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v5, -0x2

    invoke-direct {v1, v5, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object v5, v1

    .local v5, "$this$showDialog_u24lambda_u247_u241":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v7, 0x0

    .line 183
    .local v7, "$i$a$-apply-WioPollNotice$showDialog$remainingPill$1$2":I
    const/16 v8, 0xe

    invoke-static {v11, v8}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v12

    const/4 v8, 0x0

    invoke-virtual {v5, v8, v8, v8, v12}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 184
    nop

    .line 182
    .end local v5  # "$this$showDialog_u24lambda_u247_u241":Landroid/widget/LinearLayout$LayoutParams;
    .end local v7  # "$i$a$-apply-WioPollNotice$showDialog$remainingPill$1$2":I
    check-cast v1, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v3, v1}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 185
    nop

    .line 171
    .end local v3  # "$this$showDialog_u24lambda_u247":Landroid/widget/TextView;
    .end local v4  # "$i$a$-apply-WioPollNotice$showDialog$remainingPill$1":I
    nop

    .line 186
    .local v22, "remainingPill":Landroid/widget/TextView;
    move-object/from16 v1, v22

    check-cast v1, Landroid/view/View;

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 188
    nop

    .line 189
    const-string v1, "SPOR"

    invoke-static {v10, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2ea

    const-string v1, "https://strawpoll.com/61gD9paj9Zw"

    move-object v8, v1

    goto :goto_2f7

    .line 190
    :cond_2ea
    const-string v1, "SINEMA"

    invoke-static {v10, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    const-string v3, "https://strawpoll.com/bVg8BO3NryY"

    if-eqz v1, :cond_2f6

    move-object v8, v3

    goto :goto_2f7

    .line 191
    :cond_2f6
    move-object v8, v3

    .line 188
    :goto_2f7
    nop

    .line 195
    .local v8, "autoTargetUrl":Ljava/lang/String;
    new-instance v1, Landroid/widget/LinearLayout;

    move-object/from16 v3, p1

    check-cast v3, Landroid/content/Context;

    invoke-direct {v1, v3}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v3, v1

    .local v3, "$this$showDialog_u24lambda_u248":Landroid/widget/LinearLayout;
    const/4 v4, 0x0

    .line 196
    .local v4, "$i$a$-apply-WioPollNotice$showDialog$countdownBox$1":I
    const/4 v5, 0x1

    invoke-virtual {v3, v5}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 197
    const/16 v7, 0x11

    invoke-virtual {v3, v7}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 198
    new-instance v5, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v5}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object v7, v5

    .local v7, "$this$showDialog_u24lambda_u248_u240":Landroid/graphics/drawable/GradientDrawable;
    const/4 v12, 0x0

    .line 199
    .local v12, "$i$a$-apply-WioPollNotice$showDialog$countdownBox$1$1":I
    const-string v36, "#121419"

    move-object/from16 v37, v1

    invoke-static/range {v36 .. v36}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v7, v1}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 200
    move-object/from16 v36, v2

    const/16 v1, 0xc

    .end local v2  # "badgePill":Landroid/widget/LinearLayout;
    .local v36, "badgePill":Landroid/widget/LinearLayout;
    invoke-static {v11, v1}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v2

    int-to-float v1, v2

    invoke-virtual {v7, v1}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 201
    const/4 v1, 0x1

    invoke-static {v11, v1}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v2

    const-string v1, "#1E222B"

    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v7, v2, v1}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 202
    nop

    .line 198
    .end local v7  # "$this$showDialog_u24lambda_u248_u240":Landroid/graphics/drawable/GradientDrawable;
    .end local v12  # "$i$a$-apply-WioPollNotice$showDialog$countdownBox$1$1":I
    check-cast v5, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v3, v5}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 203
    const/16 v1, 0xc

    invoke-static {v11, v1}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v2

    const/16 v5, 0x9

    invoke-static {v11, v5}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v5

    invoke-static {v11, v1}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v7

    const/16 v12, 0x9

    invoke-static {v11, v12}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v12

    invoke-virtual {v3, v2, v5, v7, v12}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 204
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v5, -0x1

    const/4 v7, -0x2

    invoke-direct {v2, v5, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object v5, v2

    .local v5, "$this$showDialog_u24lambda_u248_u241":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v7, 0x0

    .line 205
    .local v7, "$i$a$-apply-WioPollNotice$showDialog$countdownBox$1$2":I
    invoke-static {v11, v1}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v1

    const/4 v12, 0x0

    invoke-virtual {v5, v12, v12, v12, v1}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 206
    nop

    .line 204
    .end local v5  # "$this$showDialog_u24lambda_u248_u241":Landroid/widget/LinearLayout$LayoutParams;
    .end local v7  # "$i$a$-apply-WioPollNotice$showDialog$countdownBox$1$2":I
    check-cast v2, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v3, v2}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 207
    nop

    .line 195
    .end local v3  # "$this$showDialog_u24lambda_u248":Landroid/widget/LinearLayout;
    .end local v4  # "$i$a$-apply-WioPollNotice$showDialog$countdownBox$1":I
    move-object/from16 v12, v37

    .line 209
    .local v12, "countdownBox":Landroid/widget/LinearLayout;
    new-instance v5, Landroid/widget/TextView;

    move-object/from16 v1, p1

    check-cast v1, Landroid/content/Context;

    invoke-direct {v5, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v1, v5

    .local v1, "$this$showDialog_u24lambda_u249":Landroid/widget/TextView;
    const/4 v2, 0x0

    .line 210
    .local v2, "$i$a$-apply-WioPollNotice$showDialog$countdownText$1":I
    const-string v3, "⏳ 10s • Otomatik ankete yönlendiriliyorsunuz"

    check-cast v3, Ljava/lang/CharSequence;

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 211
    const/high16 v3, 0x41380000  # 11.5f

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setTextSize(F)V

    .line 212
    sget-object v3, Landroid/graphics/Typeface;->MONOSPACE:Landroid/graphics/Typeface;

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 213
    invoke-virtual {v1}, Landroid/widget/TextView;->getTypeface()Landroid/graphics/Typeface;

    move-result-object v3

    const/4 v4, 0x1

    invoke-virtual {v1, v3, v4}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 214
    const-string v3, "#D1D5DB"

    invoke-static {v3}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setTextColor(I)V

    .line 215
    const/16 v7, 0x11

    invoke-virtual {v1, v7}, Landroid/widget/TextView;->setGravity(I)V

    .line 216
    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v4, -0x1

    const/4 v7, -0x2

    invoke-direct {v3, v4, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object v4, v3

    .local v4, "$this$showDialog_u24lambda_u249_u240":Landroid/widget/LinearLayout$LayoutParams;
    const/16 v17, 0x0

    .line 217
    .local v17, "$i$a$-apply-WioPollNotice$showDialog$countdownText$1$1":I
    const/4 v7, 0x6

    invoke-static {v11, v7}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v7

    move/from16 v23, v2

    const/4 v2, 0x0

    .end local v2  # "$i$a$-apply-WioPollNotice$showDialog$countdownText$1":I
    .local v23, "$i$a$-apply-WioPollNotice$showDialog$countdownText$1":I
    invoke-virtual {v4, v2, v2, v2, v7}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 218
    nop

    .line 216
    .end local v4  # "$this$showDialog_u24lambda_u249_u240":Landroid/widget/LinearLayout$LayoutParams;
    .end local v17  # "$i$a$-apply-WioPollNotice$showDialog$countdownText$1$1":I
    check-cast v3, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 219
    nop

    .line 209
    .end local v1  # "$this$showDialog_u24lambda_u249":Landroid/widget/TextView;
    .end local v23  # "$i$a$-apply-WioPollNotice$showDialog$countdownText$1":I
    nop

    .line 220
    .local v5, "countdownText":Landroid/widget/TextView;
    move-object v1, v5

    check-cast v1, Landroid/view/View;

    invoke-virtual {v12, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 223
    new-instance v4, Landroid/widget/ProgressBar;

    move-object/from16 v1, p1

    check-cast v1, Landroid/content/Context;

    const v2, 0x1010078

    const/4 v3, 0x0

    invoke-direct {v4, v1, v3, v2}, Landroid/widget/ProgressBar;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    move-object v1, v4

    .local v1, "$this$showDialog_u24lambda_u2410":Landroid/widget/ProgressBar;
    const/4 v2, 0x0

    .line 224
    .local v2, "$i$a$-apply-WioPollNotice$showDialog$progressBar$1":I
    const/16 v7, 0x3e8

    invoke-virtual {v1, v7}, Landroid/widget/ProgressBar;->setMax(I)V

    .line 225
    const/4 v7, 0x0

    invoke-virtual {v1, v7}, Landroid/widget/ProgressBar;->setProgress(I)V

    .line 226
    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v6

    invoke-static {v6}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v6

    invoke-virtual {v1, v6}, Landroid/widget/ProgressBar;->setProgressTintList(Landroid/content/res/ColorStateList;)V

    .line 227
    const-string v6, "#252833"

    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v6

    invoke-static {v6}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v6

    invoke-virtual {v1, v6}, Landroid/widget/ProgressBar;->setProgressBackgroundTintList(Landroid/content/res/ColorStateList;)V

    .line 228
    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v7, 0x4

    invoke-static {v11, v7}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v7

    const/4 v3, -0x1

    invoke-direct {v6, v3, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    check-cast v6, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v1, v6}, Landroid/widget/ProgressBar;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 229
    nop

    .line 223
    .end local v1  # "$this$showDialog_u24lambda_u2410":Landroid/widget/ProgressBar;
    .end local v2  # "$i$a$-apply-WioPollNotice$showDialog$progressBar$1":I
    nop

    .line 230
    .local v4, "progressBar":Landroid/widget/ProgressBar;
    move-object v1, v4

    check-cast v1, Landroid/view/View;

    invoke-virtual {v12, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 231
    move-object v1, v12

    check-cast v1, Landroid/view/View;

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 234
    new-instance v6, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v6, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 235
    .local v6, "countdownHandler":Landroid/os/Handler;
    move/from16 v19, v3

    const-wide/16 v2, 0x2710

    .line 236
    .local v2, "totalDurationMs":J
    new-instance v1, Lkotlin/jvm/internal/Ref$LongRef;

    invoke-direct {v1}, Lkotlin/jvm/internal/Ref$LongRef;-><init>()V

    .line 238
    .local v1, "elapsedMs":Lkotlin/jvm/internal/Ref$LongRef;
    move-object v7, v0

    .end local v0  # "root":Landroid/widget/LinearLayout;
    .local v7, "root":Landroid/widget/LinearLayout;
    new-instance v0, Ldev/wiojelt/turksinema/common/WioPollNotice$showDialog$countdownRunnable$1;

    move-object v10, v7

    move-object/from16 v16, v12

    move-object/from16 v17, v14

    const/16 v12, 0xe

    const/16 v14, 0x10

    move-object/from16 v7, p1

    .end local v7  # "root":Landroid/widget/LinearLayout;
    .end local v12  # "countdownBox":Landroid/widget/LinearLayout;
    .end local v14  # "questionTitle":Landroid/widget/TextView;
    .local v10, "root":Landroid/widget/LinearLayout;
    .local v16, "countdownBox":Landroid/widget/LinearLayout;
    .local v17, "questionTitle":Landroid/widget/TextView;
    invoke-direct/range {v0 .. v9}, Ldev/wiojelt/turksinema/common/WioPollNotice$showDialog$countdownRunnable$1;-><init>(Lkotlin/jvm/internal/Ref$LongRef;JLandroid/widget/ProgressBar;Landroid/widget/TextView;Landroid/os/Handler;Landroid/app/Activity;Ljava/lang/String;Landroid/app/Dialog;)V

    .line 257
    .local v0, "countdownRunnable":Ldev/wiojelt/turksinema/common/WioPollNotice$showDialog$countdownRunnable$1;
    new-instance v12, Ldev/wiojelt/turksinema/common/WioPollNotice$$ExternalSyntheticLambda0;

    invoke-direct {v12, v6}, Ldev/wiojelt/turksinema/common/WioPollNotice$$ExternalSyntheticLambda0;-><init>(Landroid/os/Handler;)V

    invoke-virtual {v9, v12}, Landroid/app/Dialog;->setOnDismissListener(Landroid/content/DialogInterface$OnDismissListener;)V

    .line 263
    new-instance v12, Landroid/widget/LinearLayout;

    move-object v14, v7

    check-cast v14, Landroid/content/Context;

    invoke-direct {v12, v14}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v14, v12

    .local v14, "$this$showDialog_u24lambda_u2412":Landroid/widget/LinearLayout;
    const/16 v26, 0x0

    .line 264
    .local v26, "$i$a$-apply-WioPollNotice$showDialog$cardSinema$1":I
    move-object/from16 v29, v0

    const/4 v0, 0x0

    .end local v0  # "countdownRunnable":Ldev/wiojelt/turksinema/common/WioPollNotice$showDialog$countdownRunnable$1;
    .local v29, "countdownRunnable":Ldev/wiojelt/turksinema/common/WioPollNotice$showDialog$countdownRunnable$1;
    invoke-virtual {v14, v0}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 265
    const/16 v0, 0x10

    invoke-virtual {v14, v0}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 266
    new-instance v30, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct/range {v30 .. v30}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object/from16 v34, v30

    .local v34, "$this$showDialog_u24lambda_u2412_u240":Landroid/graphics/drawable/GradientDrawable;
    const/16 v37, 0x0

    .line 267
    .local v37, "$i$a$-apply-WioPollNotice$showDialog$cardSinema$1$1":I
    const-string v23, "#16181F"

    invoke-static/range {v23 .. v23}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    move-object/from16 v45, v1

    move-object/from16 v1, v34

    .end local v34  # "$this$showDialog_u24lambda_u2412_u240":Landroid/graphics/drawable/GradientDrawable;
    .local v1, "$this$showDialog_u24lambda_u2412_u240":Landroid/graphics/drawable/GradientDrawable;
    .local v45, "elapsedMs":Lkotlin/jvm/internal/Ref$LongRef;
    invoke-virtual {v1, v0}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 268
    move-wide/from16 v46, v2

    const/16 v0, 0x10

    .end local v2  # "totalDurationMs":J
    .local v46, "totalDurationMs":J
    invoke-static {v11, v0}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v2

    int-to-float v0, v2

    invoke-virtual {v1, v0}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 269
    const/4 v0, 0x1

    invoke-static {v11, v0}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v2

    const-string v0, "#2E3342"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {v1, v2, v0}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 270
    nop

    .line 266
    .end local v1  # "$this$showDialog_u24lambda_u2412_u240":Landroid/graphics/drawable/GradientDrawable;
    .end local v37  # "$i$a$-apply-WioPollNotice$showDialog$cardSinema$1$1":I
    move-object/from16 v0, v30

    check-cast v0, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v14, v0}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 271
    const/16 v0, 0x10

    invoke-static {v11, v0}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v1

    const/16 v2, 0xe

    invoke-static {v11, v2}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v3

    move-object/from16 v41, v4

    .end local v4  # "progressBar":Landroid/widget/ProgressBar;
    .local v41, "progressBar":Landroid/widget/ProgressBar;
    invoke-static {v11, v0}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v4

    invoke-static {v11, v2}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v0

    invoke-virtual {v14, v1, v3, v4, v0}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 272
    const/4 v1, 0x1

    invoke-virtual {v14, v1}, Landroid/widget/LinearLayout;->setFocusable(Z)V

    .line 273
    invoke-virtual {v14, v1}, Landroid/widget/LinearLayout;->setClickable(Z)V

    .line 274
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v1, -0x2

    const/4 v3, -0x1

    invoke-direct {v0, v3, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object v1, v0

    .local v1, "$this$showDialog_u24lambda_u2412_u241":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v2, 0x0

    .line 275
    .local v2, "$i$a$-apply-WioPollNotice$showDialog$cardSinema$1$2":I
    const/16 v3, 0xa

    invoke-static {v11, v3}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v4

    const/4 v3, 0x0

    invoke-virtual {v1, v3, v3, v3, v4}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 276
    nop

    .line 274
    .end local v1  # "$this$showDialog_u24lambda_u2412_u241":Landroid/widget/LinearLayout$LayoutParams;
    .end local v2  # "$i$a$-apply-WioPollNotice$showDialog$cardSinema$1$2":I
    check-cast v0, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v14, v0}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 277
    new-instance v0, Ldev/wiojelt/turksinema/common/WioPollNotice$$ExternalSyntheticLambda1;

    invoke-direct {v0, v6, v7, v9}, Ldev/wiojelt/turksinema/common/WioPollNotice$$ExternalSyntheticLambda1;-><init>(Landroid/os/Handler;Landroid/app/Activity;Landroid/app/Dialog;)V

    invoke-virtual {v14, v0}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 282
    nop

    .line 263
    .end local v14  # "$this$showDialog_u24lambda_u2412":Landroid/widget/LinearLayout;
    .end local v26  # "$i$a$-apply-WioPollNotice$showDialog$cardSinema$1":I
    nop

    .line 284
    .local v12, "cardSinema":Landroid/widget/LinearLayout;
    new-instance v0, Landroid/widget/LinearLayout;

    move-object v1, v7

    check-cast v1, Landroid/content/Context;

    invoke-direct {v0, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v1, v0

    .local v1, "$this$showDialog_u24lambda_u2413":Landroid/widget/LinearLayout;
    const/4 v2, 0x0

    .line 285
    .local v2, "$i$a$-apply-WioPollNotice$showDialog$sinemaContent$1":I
    const/4 v4, 0x1

    invoke-virtual {v1, v4}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 286
    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v4, 0x3f800000  # 1.0f

    move-object/from16 v26, v0

    const/4 v0, -0x2

    const/4 v14, 0x0

    invoke-direct {v3, v14, v0, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    check-cast v3, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v1, v3}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 287
    nop

    .line 284
    .end local v1  # "$this$showDialog_u24lambda_u2413":Landroid/widget/LinearLayout;
    .end local v2  # "$i$a$-apply-WioPollNotice$showDialog$sinemaContent$1":I
    move-object/from16 v0, v26

    .line 288
    .local v0, "sinemaContent":Landroid/widget/LinearLayout;
    new-instance v1, Landroid/widget/TextView;

    move-object v2, v7

    check-cast v2, Landroid/content/Context;

    invoke-direct {v1, v2}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v2, v1

    .local v2, "$this$showDialog_u24lambda_u2414":Landroid/widget/TextView;
    const/4 v3, 0x0

    .line 289
    .local v3, "$i$a$-apply-WioPollNotice$showDialog$sinemaTitle$1":I
    const-string v14, "\ud83c\udfac Sinema & Dizi Anketi"

    check-cast v14, Ljava/lang/CharSequence;

    invoke-virtual {v2, v14}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 290
    const/high16 v14, 0x41600000  # 14.0f

    invoke-virtual {v2, v14}, Landroid/widget/TextView;->setTextSize(F)V

    .line 291
    const/4 v4, 0x0

    const/4 v14, 0x1

    invoke-virtual {v2, v4, v14}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 292
    const/4 v14, -0x1

    invoke-virtual {v2, v14}, Landroid/widget/TextView;->setTextColor(I)V

    .line 293
    nop

    .line 288
    .end local v2  # "$this$showDialog_u24lambda_u2414":Landroid/widget/TextView;
    .end local v3  # "$i$a$-apply-WioPollNotice$showDialog$sinemaTitle$1":I
    nop

    .line 294
    .local v1, "sinemaTitle":Landroid/widget/TextView;
    new-instance v2, Landroid/widget/TextView;

    move-object v3, v7

    check-cast v3, Landroid/content/Context;

    invoke-direct {v2, v3}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v3, v2

    .local v3, "$this$showDialog_u24lambda_u2415":Landroid/widget/TextView;
    const/4 v14, 0x0

    .line 295
    .local v14, "$i$a$-apply-WioPollNotice$showDialog$sinemaDesc$1":I
    const-string v30, "66 sağlayıcı arasından en iyi 5\'ini seç"

    move-object/from16 v4, v30

    check-cast v4, Ljava/lang/CharSequence;

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 296
    const/high16 v4, 0x41380000  # 11.5f

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setTextSize(F)V

    .line 297
    invoke-static {v15}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setTextColor(I)V

    .line 298
    move-object/from16 v30, v1

    const/4 v4, 0x2

    .end local v1  # "sinemaTitle":Landroid/widget/TextView;
    .local v30, "sinemaTitle":Landroid/widget/TextView;
    invoke-static {v11, v4}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v1

    const/4 v4, 0x0

    invoke-virtual {v3, v4, v1, v4, v4}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 299
    nop

    .line 294
    .end local v3  # "$this$showDialog_u24lambda_u2415":Landroid/widget/TextView;
    .end local v14  # "$i$a$-apply-WioPollNotice$showDialog$sinemaDesc$1":I
    nop

    .line 300
    .local v2, "sinemaDesc":Landroid/widget/TextView;
    move-object/from16 v1, v30

    check-cast v1, Landroid/view/View;

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 301
    move-object v1, v2

    check-cast v1, Landroid/view/View;

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 302
    move-object v1, v0

    check-cast v1, Landroid/view/View;

    invoke-virtual {v12, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 304
    new-instance v1, Landroid/widget/TextView;

    move-object v3, v7

    check-cast v3, Landroid/content/Context;

    invoke-direct {v1, v3}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v3, v1

    .local v3, "$this$showDialog_u24lambda_u2416":Landroid/widget/TextView;
    const/4 v4, 0x0

    .line 305
    .local v4, "$i$a$-apply-WioPollNotice$showDialog$sinemaBadge$1":I
    const-string v14, "OY VER ↗"

    check-cast v14, Ljava/lang/CharSequence;

    invoke-virtual {v3, v14}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 306
    const/high16 v14, 0x41280000  # 10.5f

    invoke-virtual {v3, v14}, Landroid/widget/TextView;->setTextSize(F)V

    .line 307
    sget-object v14, Landroid/graphics/Typeface;->MONOSPACE:Landroid/graphics/Typeface;

    invoke-virtual {v3, v14}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 308
    invoke-virtual {v3}, Landroid/widget/TextView;->getTypeface()Landroid/graphics/Typeface;

    move-result-object v14

    move-object/from16 v34, v0

    const/4 v0, 0x1

    .end local v0  # "sinemaContent":Landroid/widget/LinearLayout;
    .local v34, "sinemaContent":Landroid/widget/LinearLayout;
    invoke-virtual {v3, v14, v0}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 309
    const-string v0, "#60A5FA"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {v3, v0}, Landroid/widget/TextView;->setTextColor(I)V

    .line 310
    new-instance v0, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v0}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object v14, v0

    .local v14, "$this$showDialog_u24lambda_u2416_u240":Landroid/graphics/drawable/GradientDrawable;
    const/16 v37, 0x0

    .line 311
    .local v37, "$i$a$-apply-WioPollNotice$showDialog$sinemaBadge$1$1":I
    const-string v38, "#17263C"

    move-object/from16 v39, v0

    invoke-static/range {v38 .. v38}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {v14, v0}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 312
    move-object/from16 v38, v1

    const/16 v0, 0x64

    invoke-static {v11, v0}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v1

    int-to-float v1, v1

    invoke-virtual {v14, v1}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 313
    const/4 v1, 0x1

    invoke-static {v11, v1}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v0

    const-string v1, "#2563EB"

    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v14, v0, v1}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 314
    nop

    .line 310
    .end local v14  # "$this$showDialog_u24lambda_u2416_u240":Landroid/graphics/drawable/GradientDrawable;
    .end local v37  # "$i$a$-apply-WioPollNotice$showDialog$sinemaBadge$1$1":I
    move-object/from16 v0, v39

    check-cast v0, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v3, v0}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 315
    const/16 v0, 0xa

    invoke-static {v11, v0}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v1

    move-object/from16 v48, v2

    const/4 v14, 0x5

    .end local v2  # "sinemaDesc":Landroid/widget/TextView;
    .local v48, "sinemaDesc":Landroid/widget/TextView;
    invoke-static {v11, v14}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v2

    move/from16 v37, v4

    .end local v4  # "$i$a$-apply-WioPollNotice$showDialog$sinemaBadge$1":I
    .local v37, "$i$a$-apply-WioPollNotice$showDialog$sinemaBadge$1":I
    invoke-static {v11, v0}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v4

    invoke-static {v11, v14}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v0

    invoke-virtual {v3, v1, v2, v4, v0}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 316
    nop

    .line 304
    .end local v3  # "$this$showDialog_u24lambda_u2416":Landroid/widget/TextView;
    .end local v37  # "$i$a$-apply-WioPollNotice$showDialog$sinemaBadge$1":I
    move-object/from16 v0, v38

    .line 317
    .local v0, "sinemaBadge":Landroid/widget/TextView;
    move-object v1, v0

    check-cast v1, Landroid/view/View;

    invoke-virtual {v12, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 318
    move-object v1, v12

    check-cast v1, Landroid/view/View;

    invoke-virtual {v10, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 321
    new-instance v1, Landroid/widget/LinearLayout;

    move-object v2, v7

    check-cast v2, Landroid/content/Context;

    invoke-direct {v1, v2}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v2, v1

    .local v2, "$this$showDialog_u24lambda_u2417":Landroid/widget/LinearLayout;
    const/4 v3, 0x0

    .line 322
    .local v3, "$i$a$-apply-WioPollNotice$showDialog$cardSpor$1":I
    const/4 v14, 0x0

    invoke-virtual {v2, v14}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 323
    const/16 v14, 0x10

    invoke-virtual {v2, v14}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 324
    new-instance v4, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v4}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object/from16 v37, v4

    .local v37, "$this$showDialog_u24lambda_u2417_u240":Landroid/graphics/drawable/GradientDrawable;
    const/16 v38, 0x0

    .line 325
    .local v38, "$i$a$-apply-WioPollNotice$showDialog$cardSpor$1$1":I
    const-string v23, "#16181F"

    invoke-static/range {v23 .. v23}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v14

    move-object/from16 v49, v0

    move-object/from16 v0, v37

    .end local v37  # "$this$showDialog_u24lambda_u2417_u240":Landroid/graphics/drawable/GradientDrawable;
    .local v0, "$this$showDialog_u24lambda_u2417_u240":Landroid/graphics/drawable/GradientDrawable;
    .local v49, "sinemaBadge":Landroid/widget/TextView;
    invoke-virtual {v0, v14}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 326
    move-object/from16 v37, v1

    const/16 v14, 0x10

    invoke-static {v11, v14}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v1

    int-to-float v1, v1

    invoke-virtual {v0, v1}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 327
    const/4 v1, 0x1

    invoke-static {v11, v1}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v14

    const-string v1, "#2E3342"

    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v14, v1}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 328
    nop

    .line 324
    .end local v0  # "$this$showDialog_u24lambda_u2417_u240":Landroid/graphics/drawable/GradientDrawable;
    .end local v38  # "$i$a$-apply-WioPollNotice$showDialog$cardSpor$1$1":I
    check-cast v4, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v2, v4}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 329
    const/16 v14, 0x10

    invoke-static {v11, v14}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v0

    const/16 v1, 0xe

    invoke-static {v11, v1}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v4

    invoke-static {v11, v14}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v14

    move/from16 v23, v3

    .end local v3  # "$i$a$-apply-WioPollNotice$showDialog$cardSpor$1":I
    .local v23, "$i$a$-apply-WioPollNotice$showDialog$cardSpor$1":I
    invoke-static {v11, v1}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v3

    invoke-virtual {v2, v0, v4, v14, v3}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 330
    const/4 v1, 0x1

    invoke-virtual {v2, v1}, Landroid/widget/LinearLayout;->setFocusable(Z)V

    .line 331
    invoke-virtual {v2, v1}, Landroid/widget/LinearLayout;->setClickable(Z)V

    .line 332
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v1, -0x2

    const/4 v3, -0x1

    invoke-direct {v0, v3, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object v1, v0

    .local v1, "$this$showDialog_u24lambda_u2417_u241":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v3, 0x0

    .line 333
    .local v3, "$i$a$-apply-WioPollNotice$showDialog$cardSpor$1$2":I
    const/16 v4, 0xe

    invoke-static {v11, v4}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v4

    const/4 v14, 0x0

    invoke-virtual {v1, v14, v14, v14, v4}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 334
    nop

    .line 332
    .end local v1  # "$this$showDialog_u24lambda_u2417_u241":Landroid/widget/LinearLayout$LayoutParams;
    .end local v3  # "$i$a$-apply-WioPollNotice$showDialog$cardSpor$1$2":I
    check-cast v0, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v2, v0}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 335
    new-instance v0, Ldev/wiojelt/turksinema/common/WioPollNotice$$ExternalSyntheticLambda2;

    invoke-direct {v0, v6, v7, v9}, Ldev/wiojelt/turksinema/common/WioPollNotice$$ExternalSyntheticLambda2;-><init>(Landroid/os/Handler;Landroid/app/Activity;Landroid/app/Dialog;)V

    invoke-virtual {v2, v0}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 340
    nop

    .line 321
    .end local v2  # "$this$showDialog_u24lambda_u2417":Landroid/widget/LinearLayout;
    .end local v23  # "$i$a$-apply-WioPollNotice$showDialog$cardSpor$1":I
    move-object/from16 v0, v37

    .line 342
    .local v0, "cardSpor":Landroid/widget/LinearLayout;
    new-instance v1, Landroid/widget/LinearLayout;

    move-object v2, v7

    check-cast v2, Landroid/content/Context;

    invoke-direct {v1, v2}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v2, v1

    .local v2, "$this$showDialog_u24lambda_u2418":Landroid/widget/LinearLayout;
    const/4 v3, 0x0

    .line 343
    .local v3, "$i$a$-apply-WioPollNotice$showDialog$sporContent$1":I
    const/4 v4, 0x1

    invoke-virtual {v2, v4}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 344
    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v21, v1

    move/from16 v23, v3

    const/4 v1, 0x0

    const/4 v3, -0x2

    const/high16 v14, 0x3f800000  # 1.0f

    .end local v3  # "$i$a$-apply-WioPollNotice$showDialog$sporContent$1":I
    .local v23, "$i$a$-apply-WioPollNotice$showDialog$sporContent$1":I
    invoke-direct {v4, v1, v3, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    check-cast v4, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v2, v4}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 345
    nop

    .line 342
    .end local v2  # "$this$showDialog_u24lambda_u2418":Landroid/widget/LinearLayout;
    .end local v23  # "$i$a$-apply-WioPollNotice$showDialog$sporContent$1":I
    move-object/from16 v1, v21

    .line 346
    .local v1, "sporContent":Landroid/widget/LinearLayout;
    new-instance v2, Landroid/widget/TextView;

    move-object v3, v7

    check-cast v3, Landroid/content/Context;

    invoke-direct {v2, v3}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v3, v2

    .local v3, "$this$showDialog_u24lambda_u2419":Landroid/widget/TextView;
    const/4 v4, 0x0

    .line 347
    .local v4, "$i$a$-apply-WioPollNotice$showDialog$sporTitle$1":I
    const-string v14, "⚽ Canlı TV & Spor Anketi"

    check-cast v14, Ljava/lang/CharSequence;

    invoke-virtual {v3, v14}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 348
    const/high16 v14, 0x41600000  # 14.0f

    invoke-virtual {v3, v14}, Landroid/widget/TextView;->setTextSize(F)V

    .line 349
    move-object/from16 v21, v2

    const/4 v2, 0x0

    const/4 v14, 0x1

    invoke-virtual {v3, v2, v14}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 350
    const/4 v14, -0x1

    invoke-virtual {v3, v14}, Landroid/widget/TextView;->setTextColor(I)V

    .line 351
    nop

    .line 346
    .end local v3  # "$this$showDialog_u24lambda_u2419":Landroid/widget/TextView;
    .end local v4  # "$i$a$-apply-WioPollNotice$showDialog$sporTitle$1":I
    nop

    .line 352
    .local v21, "sporTitle":Landroid/widget/TextView;
    new-instance v2, Landroid/widget/TextView;

    move-object v3, v7

    check-cast v3, Landroid/content/Context;

    invoke-direct {v2, v3}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v3, v2

    .local v3, "$this$showDialog_u24lambda_u2420":Landroid/widget/TextView;
    const/4 v4, 0x0

    .line 353
    .local v4, "$i$a$-apply-WioPollNotice$showDialog$sporDesc$1":I
    const-string v14, "Canlı maç ve spor kaynaklarını belirle"

    check-cast v14, Ljava/lang/CharSequence;

    invoke-virtual {v3, v14}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 354
    const/high16 v14, 0x41380000  # 11.5f

    invoke-virtual {v3, v14}, Landroid/widget/TextView;->setTextSize(F)V

    .line 355
    invoke-static {v15}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v14

    invoke-virtual {v3, v14}, Landroid/widget/TextView;->setTextColor(I)V

    .line 356
    const/4 v14, 0x2

    invoke-static {v11, v14}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v14

    const/4 v15, 0x0

    invoke-virtual {v3, v15, v14, v15, v15}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 357
    nop

    .line 352
    .end local v3  # "$this$showDialog_u24lambda_u2420":Landroid/widget/TextView;
    .end local v4  # "$i$a$-apply-WioPollNotice$showDialog$sporDesc$1":I
    nop

    .line 358
    .local v2, "sporDesc":Landroid/widget/TextView;
    move-object/from16 v3, v21

    check-cast v3, Landroid/view/View;

    invoke-virtual {v1, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 359
    move-object v3, v2

    check-cast v3, Landroid/view/View;

    invoke-virtual {v1, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 360
    move-object v3, v1

    check-cast v3, Landroid/view/View;

    invoke-virtual {v0, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 362
    new-instance v3, Landroid/widget/TextView;

    move-object v4, v7

    check-cast v4, Landroid/content/Context;

    invoke-direct {v3, v4}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v4, v3

    .local v4, "$this$showDialog_u24lambda_u2421":Landroid/widget/TextView;
    const/4 v14, 0x0

    .line 363
    .local v14, "$i$a$-apply-WioPollNotice$showDialog$sporBadge$1":I
    const-string v15, "OY VER ↗"

    check-cast v15, Ljava/lang/CharSequence;

    invoke-virtual {v4, v15}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 364
    const/high16 v15, 0x41280000  # 10.5f

    invoke-virtual {v4, v15}, Landroid/widget/TextView;->setTextSize(F)V

    .line 365
    sget-object v15, Landroid/graphics/Typeface;->MONOSPACE:Landroid/graphics/Typeface;

    invoke-virtual {v4, v15}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 366
    invoke-virtual {v4}, Landroid/widget/TextView;->getTypeface()Landroid/graphics/Typeface;

    move-result-object v15

    move-object/from16 v23, v1

    const/4 v1, 0x1

    .end local v1  # "sporContent":Landroid/widget/LinearLayout;
    .local v23, "sporContent":Landroid/widget/LinearLayout;
    invoke-virtual {v4, v15, v1}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 367
    const-string v1, "#4ADE80"

    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v4, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 368
    new-instance v1, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v1}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object v15, v1

    .local v15, "$this$showDialog_u24lambda_u2421_u240":Landroid/graphics/drawable/GradientDrawable;
    const/16 v35, 0x0

    .line 369
    .local v35, "$i$a$-apply-WioPollNotice$showDialog$sporBadge$1$1":I
    const-string v37, "#142B1E"

    move-object/from16 v38, v1

    invoke-static/range {v37 .. v37}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v15, v1}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 370
    move-object/from16 v44, v2

    const/16 v1, 0x64

    .end local v2  # "sporDesc":Landroid/widget/TextView;
    .local v44, "sporDesc":Landroid/widget/TextView;
    invoke-static {v11, v1}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v2

    int-to-float v1, v2

    invoke-virtual {v15, v1}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 371
    const/4 v1, 0x1

    invoke-static {v11, v1}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v2

    const-string v1, "#16A34A"

    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v15, v2, v1}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 372
    nop

    .line 368
    .end local v15  # "$this$showDialog_u24lambda_u2421_u240":Landroid/graphics/drawable/GradientDrawable;
    .end local v35  # "$i$a$-apply-WioPollNotice$showDialog$sporBadge$1$1":I
    move-object/from16 v1, v38

    check-cast v1, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v4, v1}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 373
    const/16 v1, 0xa

    invoke-static {v11, v1}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v2

    move-object/from16 v27, v3

    const/4 v15, 0x5

    invoke-static {v11, v15}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v3

    invoke-static {v11, v1}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v1

    invoke-static {v11, v15}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v15

    invoke-virtual {v4, v2, v3, v1, v15}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 374
    nop

    .line 362
    .end local v4  # "$this$showDialog_u24lambda_u2421":Landroid/widget/TextView;
    .end local v14  # "$i$a$-apply-WioPollNotice$showDialog$sporBadge$1":I
    nop

    .line 375
    .local v27, "sporBadge":Landroid/widget/TextView;
    move-object/from16 v1, v27

    check-cast v1, Landroid/view/View;

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 376
    move-object v1, v0

    check-cast v1, Landroid/view/View;

    invoke-virtual {v10, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 379
    new-instance v1, Landroid/widget/LinearLayout;

    move-object v2, v7

    check-cast v2, Landroid/content/Context;

    invoke-direct {v1, v2}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v2, v1

    .local v2, "$this$showDialog_u24lambda_u2422":Landroid/widget/LinearLayout;
    const/4 v3, 0x0

    .line 380
    .local v3, "$i$a$-apply-WioPollNotice$showDialog$bottomRow$1":I
    const/4 v14, 0x0

    invoke-virtual {v2, v14}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 381
    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v14, 0x2a

    invoke-static {v11, v14}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v14

    const/4 v15, -0x1

    invoke-direct {v4, v15, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    check-cast v4, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v2, v4}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 382
    nop

    .line 379
    .end local v2  # "$this$showDialog_u24lambda_u2422":Landroid/widget/LinearLayout;
    .end local v3  # "$i$a$-apply-WioPollNotice$showDialog$bottomRow$1":I
    nop

    .line 385
    .local v1, "bottomRow":Landroid/widget/LinearLayout;
    new-instance v2, Lcom/google/android/material/button/MaterialButton;

    move-object v3, v7

    check-cast v3, Landroid/content/Context;

    invoke-direct {v2, v3}, Lcom/google/android/material/button/MaterialButton;-><init>(Landroid/content/Context;)V

    move-object v3, v2

    .local v3, "$this$showDialog_u24lambda_u2423":Lcom/google/android/material/button/MaterialButton;
    const/4 v4, 0x0

    .line 386
    .local v4, "$i$a$-apply-WioPollNotice$showDialog$btnVoted$1":I
    const-string v14, "Oy Verdim"

    check-cast v14, Ljava/lang/CharSequence;

    invoke-virtual {v3, v14}, Lcom/google/android/material/button/MaterialButton;->setText(Ljava/lang/CharSequence;)V

    .line 387
    const/high16 v14, 0x41400000  # 12.0f

    invoke-virtual {v3, v14}, Lcom/google/android/material/button/MaterialButton;->setTextSize(F)V

    .line 388
    const/4 v14, 0x1

    const/4 v15, 0x0

    invoke-virtual {v3, v15, v14}, Lcom/google/android/material/button/MaterialButton;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 389
    const-string v14, "#9CA3AF"

    invoke-static {v14}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v14

    invoke-virtual {v3, v14}, Lcom/google/android/material/button/MaterialButton;->setTextColor(I)V

    .line 390
    const-string v14, "#16181D"

    invoke-static {v14}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v14

    invoke-static {v14}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v14

    invoke-virtual {v3, v14}, Lcom/google/android/material/button/MaterialButton;->setBackgroundTintList(Landroid/content/res/ColorStateList;)V

    .line 391
    const-string v14, "#292D38"

    invoke-static {v14}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v14

    invoke-static {v14}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v14

    invoke-virtual {v3, v14}, Lcom/google/android/material/button/MaterialButton;->setStrokeColor(Landroid/content/res/ColorStateList;)V

    .line 392
    const/4 v14, 0x1

    invoke-static {v11, v14}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v15

    invoke-virtual {v3, v15}, Lcom/google/android/material/button/MaterialButton;->setStrokeWidth(I)V

    .line 393
    const/16 v14, 0x64

    invoke-static {v11, v14}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v15

    invoke-virtual {v3, v15}, Lcom/google/android/material/button/MaterialButton;->setCornerRadius(I)V

    .line 394
    const/4 v14, 0x0

    invoke-virtual {v3, v14}, Lcom/google/android/material/button/MaterialButton;->setInsetTop(I)V

    .line 395
    invoke-virtual {v3, v14}, Lcom/google/android/material/button/MaterialButton;->setInsetBottom(I)V

    .line 396
    invoke-virtual {v3, v14}, Lcom/google/android/material/button/MaterialButton;->setAllCaps(Z)V

    .line 397
    const/4 v15, 0x1

    invoke-virtual {v3, v15}, Lcom/google/android/material/button/MaterialButton;->setMaxLines(I)V

    .line 398
    const/16 v14, 0x11

    invoke-virtual {v3, v14}, Lcom/google/android/material/button/MaterialButton;->setGravity(I)V

    .line 399
    invoke-virtual {v3, v15}, Lcom/google/android/material/button/MaterialButton;->setFocusable(Z)V

    .line 400
    new-instance v14, Landroid/widget/LinearLayout$LayoutParams;

    const v15, 0x3f8ccccd  # 1.1f

    move-object/from16 v33, v0

    move-object/from16 v35, v2

    const/4 v0, 0x0

    const/4 v2, -0x1

    .end local v0  # "cardSpor":Landroid/widget/LinearLayout;
    .local v33, "cardSpor":Landroid/widget/LinearLayout;
    invoke-direct {v14, v0, v2, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    move-object v2, v14

    .local v2, "$this$showDialog_u24lambda_u2423_u240":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v15, 0x0

    .line 401
    .local v15, "$i$a$-apply-WioPollNotice$showDialog$btnVoted$1$1":I
    move/from16 v37, v4

    .end local v4  # "$i$a$-apply-WioPollNotice$showDialog$btnVoted$1":I
    .local v37, "$i$a$-apply-WioPollNotice$showDialog$btnVoted$1":I
    const/16 v4, 0x8

    invoke-static {v11, v4}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v4

    invoke-virtual {v2, v0, v0, v4, v0}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 402
    nop

    .line 400
    .end local v2  # "$this$showDialog_u24lambda_u2423_u240":Landroid/widget/LinearLayout$LayoutParams;
    .end local v15  # "$i$a$-apply-WioPollNotice$showDialog$btnVoted$1$1":I
    check-cast v14, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v3, v14}, Lcom/google/android/material/button/MaterialButton;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 403
    nop

    .line 385
    .end local v3  # "$this$showDialog_u24lambda_u2423":Lcom/google/android/material/button/MaterialButton;
    .end local v37  # "$i$a$-apply-WioPollNotice$showDialog$btnVoted$1":I
    move-object/from16 v42, v35

    .line 406
    .local v42, "btnVoted":Lcom/google/android/material/button/MaterialButton;
    new-instance v0, Lcom/google/android/material/button/MaterialButton;

    move-object v2, v7

    check-cast v2, Landroid/content/Context;

    invoke-direct {v0, v2}, Lcom/google/android/material/button/MaterialButton;-><init>(Landroid/content/Context;)V

    move-object v2, v0

    .local v2, "$this$showDialog_u24lambda_u2424":Lcom/google/android/material/button/MaterialButton;
    const/4 v3, 0x0

    .line 407
    .local v3, "$i$a$-apply-WioPollNotice$showDialog$btnClose$1":I
    const-string v4, "Kapat"

    check-cast v4, Ljava/lang/CharSequence;

    invoke-virtual {v2, v4}, Lcom/google/android/material/button/MaterialButton;->setText(Ljava/lang/CharSequence;)V

    .line 408
    const/high16 v4, 0x41400000  # 12.0f

    invoke-virtual {v2, v4}, Lcom/google/android/material/button/MaterialButton;->setTextSize(F)V

    .line 409
    const/4 v14, 0x1

    const/4 v15, 0x0

    invoke-virtual {v2, v15, v14}, Lcom/google/android/material/button/MaterialButton;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 410
    const-string v4, "#9CA3AF"

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v2, v4}, Lcom/google/android/material/button/MaterialButton;->setTextColor(I)V

    .line 411
    const-string v4, "#16181D"

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    invoke-static {v4}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v4

    invoke-virtual {v2, v4}, Lcom/google/android/material/button/MaterialButton;->setBackgroundTintList(Landroid/content/res/ColorStateList;)V

    .line 412
    const-string v4, "#292D38"

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    invoke-static {v4}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v4

    invoke-virtual {v2, v4}, Lcom/google/android/material/button/MaterialButton;->setStrokeColor(Landroid/content/res/ColorStateList;)V

    .line 413
    const/4 v14, 0x1

    invoke-static {v11, v14}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v4

    invoke-virtual {v2, v4}, Lcom/google/android/material/button/MaterialButton;->setStrokeWidth(I)V

    .line 414
    const/16 v14, 0x64

    invoke-static {v11, v14}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$dp(FI)I

    move-result v4

    invoke-virtual {v2, v4}, Lcom/google/android/material/button/MaterialButton;->setCornerRadius(I)V

    .line 415
    const/4 v14, 0x0

    invoke-virtual {v2, v14}, Lcom/google/android/material/button/MaterialButton;->setInsetTop(I)V

    .line 416
    invoke-virtual {v2, v14}, Lcom/google/android/material/button/MaterialButton;->setInsetBottom(I)V

    .line 417
    invoke-virtual {v2, v14}, Lcom/google/android/material/button/MaterialButton;->setAllCaps(Z)V

    .line 418
    const/4 v4, 0x1

    invoke-virtual {v2, v4}, Lcom/google/android/material/button/MaterialButton;->setMaxLines(I)V

    .line 419
    const/16 v15, 0x11

    invoke-virtual {v2, v15}, Lcom/google/android/material/button/MaterialButton;->setGravity(I)V

    .line 420
    invoke-virtual {v2, v4}, Lcom/google/android/material/button/MaterialButton;->setFocusable(Z)V

    .line 421
    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v18, v0

    const/4 v0, -0x1

    const/high16 v15, 0x3f800000  # 1.0f

    invoke-direct {v4, v14, v0, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    check-cast v4, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v2, v4}, Lcom/google/android/material/button/MaterialButton;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 422
    new-instance v0, Ldev/wiojelt/turksinema/common/WioPollNotice$$ExternalSyntheticLambda3;

    invoke-direct {v0, v6, v9}, Ldev/wiojelt/turksinema/common/WioPollNotice$$ExternalSyntheticLambda3;-><init>(Landroid/os/Handler;Landroid/app/Dialog;)V

    invoke-virtual {v2, v0}, Lcom/google/android/material/button/MaterialButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 426
    nop

    .line 406
    .end local v2  # "$this$showDialog_u24lambda_u2424":Lcom/google/android/material/button/MaterialButton;
    .end local v3  # "$i$a$-apply-WioPollNotice$showDialog$btnClose$1":I
    move-object/from16 v43, v18

    .line 428
    .local v43, "btnClose":Lcom/google/android/material/button/MaterialButton;
    new-instance v37, Ldev/wiojelt/turksinema/common/WioPollNotice$$ExternalSyntheticLambda4;

    move-object/from16 v39, p2

    move-object/from16 v40, v5

    move-object/from16 v38, v6

    .end local v5  # "countdownText":Landroid/widget/TextView;
    .end local v6  # "countdownHandler":Landroid/os/Handler;
    .local v38, "countdownHandler":Landroid/os/Handler;
    .local v40, "countdownText":Landroid/widget/TextView;
    invoke-direct/range {v37 .. v43}, Ldev/wiojelt/turksinema/common/WioPollNotice$$ExternalSyntheticLambda4;-><init>(Landroid/os/Handler;Landroid/content/SharedPreferences;Landroid/widget/TextView;Landroid/widget/ProgressBar;Lcom/google/android/material/button/MaterialButton;Lcom/google/android/material/button/MaterialButton;)V

    move-object/from16 v2, v37

    move-object/from16 v4, v41

    move-object/from16 v0, v42

    .end local v38  # "countdownHandler":Landroid/os/Handler;
    .end local v40  # "countdownText":Landroid/widget/TextView;
    .end local v41  # "progressBar":Landroid/widget/ProgressBar;
    .end local v42  # "btnVoted":Lcom/google/android/material/button/MaterialButton;
    .local v0, "btnVoted":Lcom/google/android/material/button/MaterialButton;
    .local v4, "progressBar":Landroid/widget/ProgressBar;
    .restart local v5  # "countdownText":Landroid/widget/TextView;
    .restart local v6  # "countdownHandler":Landroid/os/Handler;
    invoke-virtual {v0, v2}, Lcom/google/android/material/button/MaterialButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 443
    move-object v2, v0

    check-cast v2, Landroid/view/View;

    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 444
    move-object/from16 v2, v43

    check-cast v2, Landroid/view/View;

    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 445
    move-object v2, v1

    check-cast v2, Landroid/view/View;

    invoke-virtual {v10, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 447
    move-object v2, v10

    check-cast v2, Landroid/view/View;

    invoke-virtual {v9, v2}, Landroid/app/Dialog;->setContentView(Landroid/view/View;)V

    .line 450
    invoke-virtual {v9}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v2

    if-eqz v2, :cond_8eb

    .local v2, "win":Landroid/view/Window;
    const/4 v3, 0x0

    .line 451
    .local v3, "$i$a$-let-WioPollNotice$showDialog$3":I
    const/4 v15, -0x2

    invoke-virtual {v2, v13, v15}, Landroid/view/Window;->setLayout(II)V

    .line 452
    new-instance v14, Landroid/graphics/drawable/ColorDrawable;

    const/4 v15, 0x0

    invoke-direct {v14, v15}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    check-cast v14, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v2, v14}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 453
    const/high16 v14, 0x3f400000  # 0.75f

    invoke-virtual {v2, v14}, Landroid/view/Window;->setDimAmount(F)V

    .line 454
    nop

    .end local v2  # "win":Landroid/view/Window;
    .end local v3  # "$i$a$-let-WioPollNotice$showDialog$3":I
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 450
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 456
    :cond_8eb
    invoke-virtual {v9}, Landroid/app/Dialog;->show()V

    .line 459
    move-object/from16 v2, v29

    check-cast v2, Ljava/lang/Runnable;

    const-wide/16 v14, 0x64

    invoke-virtual {v6, v2, v14, v15}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 460
    return-void
.end method

.method private static final showDialog$dp(FI)I
    .registers 3
    .param p0, "density"  # F
    .param p1, "v"  # I

    .line 79
    int-to-float v0, p1

    mul-float/2addr v0, p0

    float-to-int v0, v0

    return v0
.end method

.method static final showDialog$lambda$11(Landroid/os/Handler;Landroid/content/DialogInterface;)V
    .registers 3
    .param p0, "$countdownHandler"  # Landroid/os/Handler;
    .param p1, "it"  # Landroid/content/DialogInterface;

    .line 258
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    .line 259
    return-void
.end method

.method private static final showDialog$lambda$12$2(Landroid/os/Handler;Landroid/app/Activity;Landroid/app/Dialog;Landroid/view/View;)V
    .registers 7
    .param p0, "$countdownHandler"  # Landroid/os/Handler;
    .param p1, "$activity"  # Landroid/app/Activity;
    .param p2, "$dialog"  # Landroid/app/Dialog;
    .param p3, "it"  # Landroid/view/View;

    .line 278
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    .line 279
    sget-object v0, Ldev/wiojelt/turksinema/common/WioPollNotice;->INSTANCE:Ldev/wiojelt/turksinema/common/WioPollNotice;

    move-object v1, p1

    check-cast v1, Landroid/content/Context;

    const-string v2, "https://strawpoll.com/bVg8BO3NryY"

    invoke-direct {v0, v1, v2}, Ldev/wiojelt/turksinema/common/WioPollNotice;->openUrl(Landroid/content/Context;Ljava/lang/String;)V

    .line 280
    invoke-virtual {p2}, Landroid/app/Dialog;->dismiss()V

    .line 281
    return-void
.end method

.method private static final showDialog$lambda$17$2(Landroid/os/Handler;Landroid/app/Activity;Landroid/app/Dialog;Landroid/view/View;)V
    .registers 7
    .param p0, "$countdownHandler"  # Landroid/os/Handler;
    .param p1, "$activity"  # Landroid/app/Activity;
    .param p2, "$dialog"  # Landroid/app/Dialog;
    .param p3, "it"  # Landroid/view/View;

    .line 336
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    .line 337
    sget-object v0, Ldev/wiojelt/turksinema/common/WioPollNotice;->INSTANCE:Ldev/wiojelt/turksinema/common/WioPollNotice;

    move-object v1, p1

    check-cast v1, Landroid/content/Context;

    const-string v2, "https://strawpoll.com/61gD9paj9Zw"

    invoke-direct {v0, v1, v2}, Ldev/wiojelt/turksinema/common/WioPollNotice;->openUrl(Landroid/content/Context;Ljava/lang/String;)V

    .line 338
    invoke-virtual {p2}, Landroid/app/Dialog;->dismiss()V

    .line 339
    return-void
.end method

.method private static final showDialog$lambda$24$0(Landroid/os/Handler;Landroid/app/Dialog;Landroid/view/View;)V
    .registers 4
    .param p0, "$countdownHandler"  # Landroid/os/Handler;
    .param p1, "$dialog"  # Landroid/app/Dialog;
    .param p2, "it"  # Landroid/view/View;

    .line 423
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    .line 424
    invoke-virtual {p1}, Landroid/app/Dialog;->dismiss()V

    .line 425
    return-void
.end method

.method static final showDialog$lambda$25(Landroid/os/Handler;Landroid/content/SharedPreferences;Landroid/widget/TextView;Landroid/widget/ProgressBar;Lcom/google/android/material/button/MaterialButton;Lcom/google/android/material/button/MaterialButton;Landroid/view/View;)V
    .registers 10
    .param p0, "$countdownHandler"  # Landroid/os/Handler;
    .param p1, "$prefs"  # Landroid/content/SharedPreferences;
    .param p2, "$countdownText"  # Landroid/widget/TextView;
    .param p3, "$progressBar"  # Landroid/widget/ProgressBar;
    .param p4, "$btnVoted"  # Lcom/google/android/material/button/MaterialButton;
    .param p5, "$btnClose"  # Lcom/google/android/material/button/MaterialButton;
    .param p6, "it"  # Landroid/view/View;

    .line 429
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    .line 430
    invoke-interface {p1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "poll_post_23_voted"

    const/4 v2, 0x1

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 431
    const-string v0, "✓ Oyunuz kaydedildi, teşekkür ederiz!"

    check-cast v0, Ljava/lang/CharSequence;

    invoke-virtual {p2, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 432
    const/16 v0, 0x8

    invoke-virtual {p3, v0}, Landroid/widget/ProgressBar;->setVisibility(I)V

    .line 433
    const-string v0, "Teşekkürler! ✓"

    check-cast v0, Ljava/lang/CharSequence;

    invoke-virtual {p4, v0}, Lcom/google/android/material/button/MaterialButton;->setText(Ljava/lang/CharSequence;)V

    .line 434
    const-string v0, "#4ADE80"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p4, v0}, Lcom/google/android/material/button/MaterialButton;->setTextColor(I)V

    .line 435
    const-string v0, "#14231A"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    invoke-static {v0}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v0

    invoke-virtual {p4, v0}, Lcom/google/android/material/button/MaterialButton;->setBackgroundTintList(Landroid/content/res/ColorStateList;)V

    .line 436
    const-string v0, "#236E3F"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    invoke-static {v0}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v0

    invoke-virtual {p4, v0}, Lcom/google/android/material/button/MaterialButton;->setStrokeColor(Landroid/content/res/ColorStateList;)V

    .line 437
    const/4 v0, 0x0

    invoke-virtual {p4, v0}, Lcom/google/android/material/button/MaterialButton;->setEnabled(Z)V

    .line 438
    const/4 v0, -0x1

    invoke-virtual {p5, v0}, Lcom/google/android/material/button/MaterialButton;->setTextColor(I)V

    .line 439
    const-string v0, "#252833"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    invoke-static {v0}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v0

    invoke-virtual {p5, v0}, Lcom/google/android/material/button/MaterialButton;->setBackgroundTintList(Landroid/content/res/ColorStateList;)V

    .line 440
    const-string v0, "#80FFFFFF"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    invoke-static {v0}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v0

    invoke-virtual {p5, v0}, Lcom/google/android/material/button/MaterialButton;->setStrokeColor(Landroid/content/res/ColorStateList;)V

    .line 441
    return-void
.end method

.method public static synthetic showIfDue$default(Ldev/wiojelt/turksinema/common/WioPollNotice;Landroid/content/Context;Ljava/lang/String;ZILjava/lang/Object;)V
    .registers 6

    .line 48
    and-int/lit8 p5, p4, 0x2

    if-eqz p5, :cond_6

    const-string p2, "ALL"

    :cond_6
    and-int/lit8 p4, p4, 0x4

    if-eqz p4, :cond_b

    const/4 p3, 0x0

    :cond_b
    invoke-virtual {p0, p1, p2, p3}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showIfDue(Landroid/content/Context;Ljava/lang/String;Z)V

    return-void
.end method


# virtual methods
.method public final getRemainingTimeText()Ljava/lang/String;
    .registers 8
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 41
    const-wide v0, 0x1a0e2cf6208L

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    sub-long/2addr v0, v2

    .line 42
    .local v0, "diff":J
    const-wide/16 v2, 0x0

    cmp-long v2, v0, v2

    if-gtz v2, :cond_13

    const-string v2, "Sona Erdi"

    return-object v2

    .line 43
    :cond_13
    const-wide/32 v2, 0x5265c00

    div-long v2, v0, v2

    long-to-int v2, v2

    .line 44
    .local v2, "days":I
    const-wide/32 v3, 0x36ee80

    div-long v3, v0, v3

    const-wide/16 v5, 0x18

    rem-long/2addr v3, v5

    long-to-int v3, v3

    .line 45
    .local v3, "hours":I
    const-string v4, " saat kaldı"

    new-instance v5, Ljava/lang/StringBuilder;

    if-lez v2, :cond_36

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, " gün "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    goto :goto_39

    :cond_36
    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    :goto_39
    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    return-object v4
.end method

.method public final showIfDue(Landroid/content/Context;Ljava/lang/String;Z)V
    .registers 4
    .param p1, "context"  # Landroid/content/Context;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p2, "category"  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p3, "force"  # Z

    .line 51
    return-void
.end method

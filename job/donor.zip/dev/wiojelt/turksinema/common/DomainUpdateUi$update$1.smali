.class final Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;
.super Lkotlin/coroutines/jvm/internal/ContinuationImpl;
.source "DomainUpdateUi.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldev/wiojelt/turksinema/common/DomainUpdateUi;->update(Landroid/content/Context;Ljava/util/List;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "dev.wiojelt.turksinema.common.DomainUpdateUi"
    f = "DomainUpdateUi.kt"
    i = {
        0x0,
        0x0,
        0x0,
        0x0,
        0x1,
        0x1,
        0x1,
        0x1,
        0x1,
        0x1,
        0x1,
        0x1,
        0x1,
        0x1,
        0x1,
        0x1,
        0x1,
        0x1,
        0x1,
        0x1
    }
    l = {
        0x81,
        0xa1
    }
    m = "update"
    n = {
        "context",
        "providers",
        "prefs",
        "$this$update_u24lambda_u240",
        "context",
        "providers",
        "prefs",
        "directory",
        "reachable",
        "changed",
        "tlds",
        "$this$forEach$iv",
        "element$iv",
        "provider",
        "baseName",
        "dynamicCandidates",
        "candidates",
        "host",
        "candidate",
        "$this$update_u24lambda_u241_u244"
    }
    nl = {
        0x81,
        0xa1
    }
    s = {
        "L$0",
        "L$1",
        "L$2",
        "L$3",
        "L$0",
        "L$1",
        "L$2",
        "L$3",
        "L$4",
        "L$5",
        "L$6",
        "L$7",
        "L$9",
        "L$10",
        "L$11",
        "L$12",
        "L$13",
        "L$14",
        "L$16",
        "L$17"
    }
    v = 0x2
.end annotation


# instance fields
.field L$0:Ljava/lang/Object;

.field L$1:Ljava/lang/Object;

.field L$10:Ljava/lang/Object;

.field L$11:Ljava/lang/Object;

.field L$12:Ljava/lang/Object;

.field L$13:Ljava/lang/Object;

.field L$14:Ljava/lang/Object;

.field L$15:Ljava/lang/Object;

.field L$16:Ljava/lang/Object;

.field L$17:Ljava/lang/Object;

.field L$2:Ljava/lang/Object;

.field L$3:Ljava/lang/Object;

.field L$4:Ljava/lang/Object;

.field L$5:Ljava/lang/Object;

.field L$6:Ljava/lang/Object;

.field L$7:Ljava/lang/Object;

.field L$8:Ljava/lang/Object;

.field L$9:Ljava/lang/Object;

.field label:I

.field synthetic result:Ljava/lang/Object;

.field final synthetic this$0:Ldev/wiojelt/turksinema/common/DomainUpdateUi;


# direct methods
.method constructor <init>(Ldev/wiojelt/turksinema/common/DomainUpdateUi;Lkotlin/coroutines/Continuation;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ldev/wiojelt/turksinema/common/DomainUpdateUi;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->this$0:Ldev/wiojelt/turksinema/common/DomainUpdateUi;

    invoke-direct {p0, p2}, Lkotlin/coroutines/jvm/internal/ContinuationImpl;-><init>(Lkotlin/coroutines/Continuation;)V

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5
    .param p1  # Ljava/lang/Object;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation

    iput-object p1, p0, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->result:Ljava/lang/Object;

    iget v0, p0, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->label:I

    const/high16 v1, -0x80000000

    or-int/2addr v0, v1

    iput v0, p0, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->label:I

    iget-object v0, p0, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->this$0:Ldev/wiojelt/turksinema/common/DomainUpdateUi;

    const/4 v1, 0x0

    move-object v2, p0

    check-cast v2, Lkotlin/coroutines/Continuation;

    invoke-static {v0, v1, v1, v2}, Ldev/wiojelt/turksinema/common/DomainUpdateUi;->access$update(Ldev/wiojelt/turksinema/common/DomainUpdateUi;Landroid/content/Context;Ljava/util/List;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.class public final synthetic Ldev/wiojelt/turksinema/common/DomainUpdateUi$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x13
    versionHash = "7bbc1d7254613ffaa026de47d975f73968361ef3e5d7b818ce0a83a33039c6b8"
.end annotation


# instance fields
.field public final synthetic f$0:Ljava/util/List;

.field public final synthetic f$1:Ljava/util/List;

.field public final synthetic f$2:Landroid/content/Context;

.field public final synthetic f$3:Landroid/content/SharedPreferences;


# direct methods
.method public synthetic constructor <init>(Ljava/util/List;Ljava/util/List;Landroid/content/Context;Landroid/content/SharedPreferences;)V
    .registers 5

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/wiojelt/turksinema/common/DomainUpdateUi$$ExternalSyntheticLambda3;->f$0:Ljava/util/List;

    iput-object p2, p0, Ldev/wiojelt/turksinema/common/DomainUpdateUi$$ExternalSyntheticLambda3;->f$1:Ljava/util/List;

    iput-object p3, p0, Ldev/wiojelt/turksinema/common/DomainUpdateUi$$ExternalSyntheticLambda3;->f$2:Landroid/content/Context;

    iput-object p4, p0, Ldev/wiojelt/turksinema/common/DomainUpdateUi$$ExternalSyntheticLambda3;->f$3:Landroid/content/SharedPreferences;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 5

    .line 0
    iget-object v0, p0, Ldev/wiojelt/turksinema/common/DomainUpdateUi$$ExternalSyntheticLambda3;->f$0:Ljava/util/List;

    iget-object v1, p0, Ldev/wiojelt/turksinema/common/DomainUpdateUi$$ExternalSyntheticLambda3;->f$1:Ljava/util/List;

    iget-object v2, p0, Ldev/wiojelt/turksinema/common/DomainUpdateUi$$ExternalSyntheticLambda3;->f$2:Landroid/content/Context;

    iget-object v3, p0, Ldev/wiojelt/turksinema/common/DomainUpdateUi$$ExternalSyntheticLambda3;->f$3:Landroid/content/SharedPreferences;

    invoke-static {v0, v1, v2, v3}, Ldev/wiojelt/turksinema/common/DomainUpdateUi;->show$lambda$1(Ljava/util/List;Ljava/util/List;Landroid/content/Context;Landroid/content/SharedPreferences;)Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

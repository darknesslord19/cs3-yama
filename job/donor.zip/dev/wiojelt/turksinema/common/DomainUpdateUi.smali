.class public final Ldev/wiojelt/turksinema/common/DomainUpdateUi;
.super Ljava/lang/Object;
.source "DomainUpdateUi.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nDomainUpdateUi.kt\nKotlin\n*S Kotlin\n*F\n+ 1 DomainUpdateUi.kt\ndev/wiojelt/turksinema/common/DomainUpdateUi\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 3 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,177:1\n2068#2:178\n2069#2:180\n1739#2:181\n1814#2,3:182\n2068#2:185\n1739#2:186\n1814#2,3:187\n1544#2:190\n1633#2,2:191\n1739#2:193\n1814#2,3:194\n1635#2,3:197\n1795#2,10:200\n2068#2:210\n2069#2:212\n1805#2:213\n2069#2:214\n2068#2,2:215\n2068#2,2:217\n2068#2,2:219\n2068#2,2:221\n1#3:179\n1#3:211\n*S KotlinDebug\n*F\n+ 1 DomainUpdateUi.kt\ndev/wiojelt/turksinema/common/DomainUpdateUi\n*L\n31#1:178\n31#1:180\n57#1:181\n57#1:182,3\n135#1:185\n140#1:186\n140#1:187,3\n145#1:190\n145#1:191,2\n147#1:193\n147#1:194,3\n145#1:197,3\n158#1:200,10\n158#1:210\n158#1:212\n158#1:213\n135#1:214\n86#1:215,2\n87#1:217,2\n93#1:219,2\n94#1:221,2\n158#1:211\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000H\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\t\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0002\b\u0002\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J$\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000b2\f\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u000e0\rJ\u0010\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u0005H\u0002J\u0012\u0010\u0012\u001a\u0004\u0018\u00010\u00052\u0006\u0010\u0011\u001a\u00020\u0005H\u0002J@\u0010\u0013\u001a\u00020\u00072\u0006\u0010\n\u001a\u00020\u000b2\f\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u000e0\r2\n\b\u0002\u0010\u0014\u001a\u0004\u0018\u00010\u00052\n\b\u0002\u0010\u0015\u001a\u0004\u0018\u00010\u00052\n\b\u0002\u0010\u0016\u001a\u0004\u0018\u00010\u0005J,\u0010\u0017\u001a\u00020\u00072\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\u0018\u001a\u00020\u000e2\u0012\u0010\u0019\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00070\u001aH\u0002J0\u0010\u001b\u001a\u000e\u0012\u0004\u0012\u00020\u001d\u0012\u0004\u0012\u00020\u001d0\u001c2\u0006\u0010\n\u001a\u00020\u000b2\f\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u000e0\rH\u0082@¢\u0006\u0002\u0010\u001eR\u000e\u0010\u0004\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000¨\u0006\u001f"
    }
    d2 = {
        "Ldev/wiojelt/turksinema/common/DomainUpdateUi;",
        "",
        "<init>",
        "()V",
        "DIRECTORY",
        "",
        "attach",
        "",
        "plugin",
        "Lcom/lagradost/cloudstream3/plugins/Plugin;",
        "context",
        "Landroid/content/Context;",
        "providers",
        "",
        "Lcom/lagradost/cloudstream3/MainAPI;",
        "validOrigin",
        "",
        "value",
        "origin",
        "show",
        "brandPrefix",
        "brandSuffix",
        "brandTitleTag",
        "showEditDialog",
        "provider",
        "onSave",
        "Lkotlin/Function1;",
        "update",
        "Lkotlin/Pair;",
        "",
        "(Landroid/content/Context;Ljava/util/List;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;",
        "DiziMom"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation

.annotation build Lkotlin/jvm/internal/SourceDebugExtension;
    value = {
        "SMAP\nDomainUpdateUi.kt\nKotlin\n*S Kotlin\n*F\n+ 1 DomainUpdateUi.kt\ndev/wiojelt/turksinema/common/DomainUpdateUi\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 3 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,177:1\n2068#2:178\n2069#2:180\n1739#2:181\n1814#2,3:182\n2068#2:185\n1739#2:186\n1814#2,3:187\n1544#2:190\n1633#2,2:191\n1739#2:193\n1814#2,3:194\n1635#2,3:197\n1795#2,10:200\n2068#2:210\n2069#2:212\n1805#2:213\n2069#2:214\n2068#2,2:215\n2068#2,2:217\n2068#2,2:219\n2068#2,2:221\n1#3:179\n1#3:211\n*S KotlinDebug\n*F\n+ 1 DomainUpdateUi.kt\ndev/wiojelt/turksinema/common/DomainUpdateUi\n*L\n31#1:178\n31#1:180\n57#1:181\n57#1:182,3\n135#1:185\n140#1:186\n140#1:187,3\n145#1:190\n145#1:191,2\n147#1:193\n147#1:194,3\n145#1:197,3\n158#1:200,10\n158#1:210\n158#1:212\n158#1:213\n135#1:214\n86#1:215,2\n87#1:217,2\n93#1:219,2\n94#1:221,2\n158#1:211\n*E\n"
    }
.end annotation


# static fields
.field private static final DIRECTORY:Ljava/lang/String; = "https://raw.githubusercontent.com/Wiojelt/TurkSinema/main/domains.json"
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field public static final INSTANCE:Ldev/wiojelt/turksinema/common/DomainUpdateUi;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field


# direct methods
.method public static synthetic $r8$lambda$MvuhmcLxXoVOh8la4YQSZPuNrKE(Landroid/content/SharedPreferences;Lcom/lagradost/cloudstream3/MainAPI;Landroid/content/Context;Z)Lkotlin/Unit;
    .registers 4

    invoke-static {p0, p1, p2, p3}, Ldev/wiojelt/turksinema/common/DomainUpdateUi;->show$lambda$0$0(Landroid/content/SharedPreferences;Lcom/lagradost/cloudstream3/MainAPI;Landroid/content/Context;Z)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$lpIQ9AQL7SrC2F-e-o7KJVJV3Qc(Lcom/lagradost/cloudstream3/MainAPI;Landroid/content/SharedPreferences;Ljava/lang/String;)Lkotlin/Unit;
    .registers 3

    invoke-static {p0, p1, p2}, Ldev/wiojelt/turksinema/common/DomainUpdateUi;->show$lambda$0$1(Lcom/lagradost/cloudstream3/MainAPI;Landroid/content/SharedPreferences;Ljava/lang/String;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Ldev/wiojelt/turksinema/common/DomainUpdateUi;

    invoke-direct {v0}, Ldev/wiojelt/turksinema/common/DomainUpdateUi;-><init>()V

    sput-object v0, Ldev/wiojelt/turksinema/common/DomainUpdateUi;->INSTANCE:Ldev/wiojelt/turksinema/common/DomainUpdateUi;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 26
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static final synthetic access$update(Ldev/wiojelt/turksinema/common/DomainUpdateUi;Landroid/content/Context;Ljava/util/List;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 5
    .param p0, "$this"  # Ldev/wiojelt/turksinema/common/DomainUpdateUi;
    .param p1, "context"  # Landroid/content/Context;
    .param p2, "providers"  # Ljava/util/List;
    .param p3, "$completion"  # Lkotlin/coroutines/Continuation;

    .line 26
    invoke-direct {p0, p1, p2, p3}, Ldev/wiojelt/turksinema/common/DomainUpdateUi;->update(Landroid/content/Context;Ljava/util/List;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method static final attach$lambda$1(Ljava/util/List;Landroid/content/Context;)Lkotlin/Unit;
    .registers 10
    .param p0, "$providers"  # Ljava/util/List;
    .param p1, "ui"  # Landroid/content/Context;

    .line 34
    sget-object v0, Ldev/wiojelt/turksinema/common/DomainUpdateUi;->INSTANCE:Ldev/wiojelt/turksinema/common/DomainUpdateUi;

    const/16 v6, 0x1c

    const/4 v7, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    move-object v2, p0

    move-object v1, p1

    .end local p0  # "$providers":Ljava/util/List;
    .end local p1  # "ui":Landroid/content/Context;
    .local v1, "ui":Landroid/content/Context;
    .local v2, "$providers":Ljava/util/List;
    invoke-static/range {v0 .. v7}, Ldev/wiojelt/turksinema/common/DomainUpdateUi;->show$default(Ldev/wiojelt/turksinema/common/DomainUpdateUi;Landroid/content/Context;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method private final origin(Ljava/lang/String;)Ljava/lang/String;
    .registers 8
    .param p1, "value"  # Ljava/lang/String;

    .line 45
    nop

    .line 42
    :try_start_1
    sget-object v0, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v0, p0

    check-cast v0, Ldev/wiojelt/turksinema/common/DomainUpdateUi;

    .local v0, "$this$origin_u24lambda_u240":Ldev/wiojelt/turksinema/common/DomainUpdateUi;
    const/4 v1, 0x0

    .line 43
    .local v1, "$i$a$-runCatching-DomainUpdateUi$origin$1":I
    new-instance v2, Ljava/net/URI;

    move-object v3, p1

    check-cast v3, Ljava/lang/CharSequence;

    invoke-static {v3}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/net/URI;-><init>(Ljava/lang/String;)V

    .line 44
    .local v2, "uri":Ljava/net/URI;
    invoke-virtual {v2}, Ljava/net/URI;->getScheme()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2}, Ljava/net/URI;->getAuthority()Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v5, "://"

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const-string v4, "/"

    check-cast v4, Ljava/lang/CharSequence;

    invoke-static {v3, v4}, Lkotlin/text/StringsKt;->removeSuffix(Ljava/lang/String;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v3

    .line 42
    .end local v0  # "$this$origin_u24lambda_u240":Ldev/wiojelt/turksinema/common/DomainUpdateUi;
    .end local v1  # "$i$a$-runCatching-DomainUpdateUi$origin$1":I
    .end local v2  # "uri":Ljava/net/URI;
    invoke-static {v3}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0
    :try_end_42
    .catchall {:try_start_1 .. :try_end_42} :catchall_43

    goto :goto_4e

    :catchall_43
    move-exception v0

    sget-object v1, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v0}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    .line 45
    :goto_4e
    invoke-static {v0}, Lkotlin/Result;->isFailure-impl(Ljava/lang/Object;)Z

    move-result v1

    const/4 v2, 0x0

    if-eqz v1, :cond_56

    move-object v0, v2

    :cond_56
    check-cast v0, Ljava/lang/String;

    if-eqz v0, :cond_64

    .line 42
    nop

    .line 45
    move-object v1, v0

    .line 179
    .local v1, "p0":Ljava/lang/String;
    const/4 v3, 0x0

    .line 45
    .local v3, "$i$a$-takeIf-DomainUpdateUi$origin$2":I
    invoke-direct {p0, v1}, Ldev/wiojelt/turksinema/common/DomainUpdateUi;->validOrigin(Ljava/lang/String;)Z

    move-result v1

    .end local v1  # "p0":Ljava/lang/String;
    .end local v3  # "$i$a$-takeIf-DomainUpdateUi$origin$2":I
    if-eqz v1, :cond_64

    move-object v2, v0

    :cond_64
    return-object v2
.end method

.method public static synthetic show$default(Ldev/wiojelt/turksinema/common/DomainUpdateUi;Landroid/content/Context;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)V
    .registers 9

    .line 47
    and-int/lit8 p7, p6, 0x4

    const/4 v0, 0x0

    if-eqz p7, :cond_6

    .line 50
    move-object p3, v0

    .line 47
    :cond_6
    and-int/lit8 p7, p6, 0x8

    if-eqz p7, :cond_b

    .line 51
    move-object p4, v0

    .line 47
    :cond_b
    and-int/lit8 p6, p6, 0x10

    if-eqz p6, :cond_10

    .line 52
    move-object p5, v0

    .line 47
    :cond_10
    invoke-virtual/range {p0 .. p5}, Ldev/wiojelt/turksinema/common/DomainUpdateUi;->show(Landroid/content/Context;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method private static final show$lambda$0$0(Landroid/content/SharedPreferences;Lcom/lagradost/cloudstream3/MainAPI;Landroid/content/Context;Z)Lkotlin/Unit;
    .registers 7
    .param p0, "$disabledPrefs"  # Landroid/content/SharedPreferences;
    .param p1, "$provider"  # Lcom/lagradost/cloudstream3/MainAPI;
    .param p2, "$context"  # Landroid/content/Context;
    .param p3, "isChecked"  # Z

    .line 64
    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-virtual {p1}, Lcom/lagradost/cloudstream3/MainAPI;->getName()Ljava/lang/String;

    move-result-object v1

    xor-int/lit8 v2, p3, 0x1

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 65
    sget-object v0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->INSTANCE:Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;

    invoke-virtual {v0, p2}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->clearCache(Landroid/content/Context;)J

    .line 66
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final show$lambda$0$1(Lcom/lagradost/cloudstream3/MainAPI;Landroid/content/SharedPreferences;Ljava/lang/String;)Lkotlin/Unit;
    .registers 5
    .param p0, "$provider"  # Lcom/lagradost/cloudstream3/MainAPI;
    .param p1, "$prefs"  # Landroid/content/SharedPreferences;
    .param p2, "newDomain"  # Ljava/lang/String;

    .line 68
    invoke-virtual {p0, p2}, Lcom/lagradost/cloudstream3/MainAPI;->setMainUrl(Ljava/lang/String;)V

    .line 69
    invoke-interface {p1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-virtual {p0}, Lcom/lagradost/cloudstream3/MainAPI;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1, p2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 70
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final show$lambda$1(Ljava/util/List;Ljava/util/List;Landroid/content/Context;Landroid/content/SharedPreferences;)Lkotlin/Unit;
    .registers 13
    .param p0, "$providers"  # Ljava/util/List;
    .param p1, "$items"  # Ljava/util/List;
    .param p2, "$context"  # Landroid/content/Context;
    .param p3, "$disabledPrefs"  # Landroid/content/SharedPreferences;

    .line 86
    move-object v0, p0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$forEach$iv":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 215
    .local v1, "$i$f$forEach":I
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_8
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_28

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    .local v3, "element$iv":Ljava/lang/Object;
    move-object v4, v3

    check-cast v4, Lcom/lagradost/cloudstream3/MainAPI;

    .local v4, "it":Lcom/lagradost/cloudstream3/MainAPI;
    const/4 v5, 0x0

    .line 86
    .local v5, "$i$a$-forEach-DomainUpdateUi$show$config$1$1":I
    invoke-interface {p3}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v6

    invoke-virtual {v4}, Lcom/lagradost/cloudstream3/MainAPI;->getName()Ljava/lang/String;

    move-result-object v7

    const/4 v8, 0x0

    invoke-interface {v6, v7, v8}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v6

    invoke-interface {v6}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 215
    .end local v4  # "it":Lcom/lagradost/cloudstream3/MainAPI;
    .end local v5  # "$i$a$-forEach-DomainUpdateUi$show$config$1$1":I
    nop

    .end local v3  # "element$iv":Ljava/lang/Object;
    goto :goto_8

    .line 216
    :cond_28
    nop

    .line 87
    .end local v0  # "$this$forEach$iv":Ljava/lang/Iterable;
    .end local v1  # "$i$f$forEach":I
    move-object v0, p1

    check-cast v0, Ljava/lang/Iterable;

    .restart local v0  # "$this$forEach$iv":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 217
    .restart local v1  # "$i$f$forEach":I
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_31
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_45

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    .restart local v3  # "element$iv":Ljava/lang/Object;
    move-object v4, v3

    check-cast v4, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;

    .local v4, "it":Ldev/wiojelt/turksinema/common/WioProviderSettingItem;
    const/4 v5, 0x0

    .line 87
    .local v5, "$i$a$-forEach-DomainUpdateUi$show$config$1$2":I
    const/4 v6, 0x1

    invoke-virtual {v4, v6}, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->setEnabled(Z)V

    .line 217
    .end local v4  # "it":Ldev/wiojelt/turksinema/common/WioProviderSettingItem;
    .end local v5  # "$i$a$-forEach-DomainUpdateUi$show$config$1$2":I
    nop

    .end local v3  # "element$iv":Ljava/lang/Object;
    goto :goto_31

    .line 218
    :cond_45
    nop

    .line 88
    .end local v0  # "$this$forEach$iv":Ljava/lang/Iterable;
    .end local v1  # "$i$f$forEach":I
    sget-object v0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->INSTANCE:Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;

    invoke-virtual {v0, p2}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->clearCache(Landroid/content/Context;)J

    .line 89
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final show$lambda$2(Ljava/util/List;Ljava/util/List;Landroid/content/Context;Landroid/content/SharedPreferences;)Lkotlin/Unit;
    .registers 13
    .param p0, "$providers"  # Ljava/util/List;
    .param p1, "$items"  # Ljava/util/List;
    .param p2, "$context"  # Landroid/content/Context;
    .param p3, "$disabledPrefs"  # Landroid/content/SharedPreferences;

    .line 93
    move-object v0, p0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$forEach$iv":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 219
    .local v1, "$i$f$forEach":I
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_8
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_28

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    .local v3, "element$iv":Ljava/lang/Object;
    move-object v4, v3

    check-cast v4, Lcom/lagradost/cloudstream3/MainAPI;

    .local v4, "it":Lcom/lagradost/cloudstream3/MainAPI;
    const/4 v5, 0x0

    .line 93
    .local v5, "$i$a$-forEach-DomainUpdateUi$show$config$2$1":I
    invoke-interface {p3}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v6

    invoke-virtual {v4}, Lcom/lagradost/cloudstream3/MainAPI;->getName()Ljava/lang/String;

    move-result-object v7

    const/4 v8, 0x1

    invoke-interface {v6, v7, v8}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v6

    invoke-interface {v6}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 219
    .end local v4  # "it":Lcom/lagradost/cloudstream3/MainAPI;
    .end local v5  # "$i$a$-forEach-DomainUpdateUi$show$config$2$1":I
    nop

    .end local v3  # "element$iv":Ljava/lang/Object;
    goto :goto_8

    .line 220
    :cond_28
    nop

    .line 94
    .end local v0  # "$this$forEach$iv":Ljava/lang/Iterable;
    .end local v1  # "$i$f$forEach":I
    move-object v0, p1

    check-cast v0, Ljava/lang/Iterable;

    .restart local v0  # "$this$forEach$iv":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 221
    .restart local v1  # "$i$f$forEach":I
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_31
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_45

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    .restart local v3  # "element$iv":Ljava/lang/Object;
    move-object v4, v3

    check-cast v4, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;

    .local v4, "it":Ldev/wiojelt/turksinema/common/WioProviderSettingItem;
    const/4 v5, 0x0

    .line 94
    .local v5, "$i$a$-forEach-DomainUpdateUi$show$config$2$2":I
    const/4 v6, 0x0

    invoke-virtual {v4, v6}, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->setEnabled(Z)V

    .line 221
    .end local v4  # "it":Ldev/wiojelt/turksinema/common/WioProviderSettingItem;
    .end local v5  # "$i$a$-forEach-DomainUpdateUi$show$config$2$2":I
    nop

    .end local v3  # "element$iv":Ljava/lang/Object;
    goto :goto_31

    .line 222
    :cond_45
    nop

    .line 95
    .end local v0  # "$this$forEach$iv":Ljava/lang/Iterable;
    .end local v1  # "$i$f$forEach":I
    sget-object v0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->INSTANCE:Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;

    invoke-virtual {v0, p2}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->clearCache(Landroid/content/Context;)J

    .line 96
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final show$lambda$3(Landroid/content/Context;)Lkotlin/Unit;
    .registers 10
    .param p0, "$context"  # Landroid/content/Context;

    .line 102
    sget-object v0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->INSTANCE:Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;

    invoke-virtual {v0, p0}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->clearCache(Landroid/content/Context;)J

    move-result-wide v0

    .line 103
    .local v0, "freed":J
    long-to-double v2, v0

    const-wide/high16 v4, 0x4130000000000000L  # 1048576.0

    div-double/2addr v2, v4

    .line 104
    .local v2, "mb":D
    const-wide v4, 0x3fb999999999999aL  # 0.1

    cmpl-double v4, v2, v4

    const/4 v5, 0x0

    if-ltz v4, :cond_31

    .line 105
    sget-object v4, Lkotlin/jvm/internal/StringCompanionObject;->INSTANCE:Lkotlin/jvm/internal/StringCompanionObject;

    sget-object v4, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-static {v2, v3}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v6

    const/4 v7, 0x1

    new-array v8, v7, [Ljava/lang/Object;

    aput-object v6, v8, v5

    invoke-static {v8, v7}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v6

    const-string v7, "✓ Ayarlar kaydedildi · %.1f MB önbellek temizlendi"

    invoke-static {v4, v7, v6}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    const-string v6, "format(...)"

    invoke-static {v4, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    goto :goto_33

    .line 107
    :cond_31
    const-string v4, "✓ Ayarlar kaydedildi · Önbellek temizlendi"

    .line 104
    :goto_33
    nop

    .line 109
    .local v4, "msg":Ljava/lang/String;
    move-object v6, v4

    check-cast v6, Ljava/lang/CharSequence;

    invoke-static {p0, v6, v5}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v5

    invoke-virtual {v5}, Landroid/widget/Toast;->show()V

    .line 110
    sget-object v5, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v5
.end method

.method private final showEditDialog(Landroid/content/Context;Lcom/lagradost/cloudstream3/MainAPI;Lkotlin/jvm/functions/Function1;)V
    .registers 14
    .param p1, "context"  # Landroid/content/Context;
    .param p2, "provider"  # Lcom/lagradost/cloudstream3/MainAPI;
    .param p3, "onSave"  # Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lcom/lagradost/cloudstream3/MainAPI;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 119
    sget-object v0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->INSTANCE:Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;

    .line 120
    nop

    .line 121
    invoke-virtual {p2}, Lcom/lagradost/cloudstream3/MainAPI;->getName()Ljava/lang/String;

    move-result-object v2

    .line 122
    invoke-virtual {p2}, Lcom/lagradost/cloudstream3/MainAPI;->getMainUrl()Ljava/lang/String;

    move-result-object v3

    .line 119
    nop

    .line 123
    nop

    .line 119
    const/16 v8, 0x38

    const/4 v9, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object v1, p1

    move-object v7, p3

    .end local p1  # "context":Landroid/content/Context;
    .end local p3  # "onSave":Lkotlin/jvm/functions/Function1;
    .local v1, "context":Landroid/content/Context;
    .local v7, "onSave":Lkotlin/jvm/functions/Function1;
    invoke-static/range {v0 .. v9}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog$default(Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;ZIILkotlin/jvm/functions/Function1;ILjava/lang/Object;)V

    .line 125
    return-void
.end method

.method private final update(Landroid/content/Context;Ljava/util/List;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 54
    .param p1, "context"  # Landroid/content/Context;
    .param p2, "providers"  # Ljava/util/List;
    .param p3, "$completion"  # Lkotlin/coroutines/Continuation;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/List<",
            "+",
            "Lcom/lagradost/cloudstream3/MainAPI;",
            ">;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lkotlin/Pair<",
            "Ljava/lang/Integer;",
            "Ljava/lang/Integer;",
            ">;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    move-object/from16 v1, p0

    move-object/from16 v2, p3

    const-string v3, ""

    instance-of v0, v2, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;

    if-eqz v0, :cond_1a

    move-object v0, v2

    check-cast v0, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;

    iget v4, v0, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->label:I

    const/high16 v5, -0x80000000

    and-int/2addr v4, v5

    if-eqz v4, :cond_1a

    iget v4, v0, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->label:I

    sub-int/2addr v4, v5

    iput v4, v0, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->label:I

    goto :goto_1f

    :cond_1a
    new-instance v0, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;

    invoke-direct {v0, v1, v2}, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;-><init>(Ldev/wiojelt/turksinema/common/DomainUpdateUi;Lkotlin/coroutines/Continuation;)V

    :goto_1f
    move-object v4, v0

    .local v4, "$continuation":Lkotlin/coroutines/Continuation;
    iget-object v5, v4, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->result:Ljava/lang/Object;

    .local v5, "$result":Ljava/lang/Object;
    invoke-static {}, Lkotlin/coroutines/intrinsics/IntrinsicsKt;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object v6

    .line 127
    iget v0, v4, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->label:I

    packed-switch v0, :pswitch_data_6b4

    .end local v4  # "$continuation":Lkotlin/coroutines/Continuation;
    .end local v5  # "$result":Ljava/lang/Object;
    .end local p0  # "this":Ldev/wiojelt/turksinema/common/DomainUpdateUi;
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    .restart local v4  # "$continuation":Lkotlin/coroutines/Continuation;
    .restart local v5  # "$result":Ljava/lang/Object;
    .restart local p0  # "this":Ldev/wiojelt/turksinema/common/DomainUpdateUi;
    :pswitch_33  #0x2
    const/4 v11, 0x0

    .local v11, "$i$f$forEach":I
    const/4 v12, 0x0

    .local v12, "$i$a$-forEach-DomainUpdateUi$update$2":I
    const/4 v0, 0x0

    .local v0, "$i$a$-runCatching-DomainUpdateUi$update$2$response$1":I
    iget-object v13, v4, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->L$17:Ljava/lang/Object;

    check-cast v13, Ldev/wiojelt/turksinema/common/DomainUpdateUi;

    .local v13, "$this$update_u24lambda_u241_u244":Ldev/wiojelt/turksinema/common/DomainUpdateUi;
    iget-object v14, v4, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->L$16:Ljava/lang/Object;

    check-cast v14, Ljava/lang/String;

    .local v14, "candidate":Ljava/lang/String;
    iget-object v15, v4, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->L$15:Ljava/lang/Object;

    check-cast v15, Ljava/util/Iterator;

    iget-object v7, v4, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->L$14:Ljava/lang/Object;

    check-cast v7, Ljava/lang/String;

    .local v7, "host":Ljava/lang/String;
    iget-object v9, v4, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->L$13:Ljava/lang/Object;

    check-cast v9, Ljava/util/List;

    .local v9, "candidates":Ljava/util/List;
    iget-object v10, v4, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->L$12:Ljava/lang/Object;

    check-cast v10, Ljava/util/List;

    .local v10, "dynamicCandidates":Ljava/util/List;
    iget-object v8, v4, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->L$11:Ljava/lang/Object;

    check-cast v8, Ljava/lang/String;

    move/from16 v20, v0

    .end local v0  # "$i$a$-runCatching-DomainUpdateUi$update$2$response$1":I
    .local v8, "baseName":Ljava/lang/String;
    .local v20, "$i$a$-runCatching-DomainUpdateUi$update$2$response$1":I
    iget-object v0, v4, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->L$10:Ljava/lang/Object;

    move-object/from16 v21, v0

    check-cast v21, Lcom/lagradost/cloudstream3/MainAPI;

    .local v21, "provider":Lcom/lagradost/cloudstream3/MainAPI;
    iget-object v1, v4, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->L$9:Ljava/lang/Object;

    .local v1, "element$iv":Ljava/lang/Object;
    iget-object v0, v4, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->L$8:Ljava/lang/Object;

    move-object/from16 v22, v0

    check-cast v22, Ljava/util/Iterator;

    iget-object v0, v4, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->L$7:Ljava/lang/Object;

    move-object/from16 v23, v0

    check-cast v23, Ljava/lang/Iterable;

    .local v23, "$this$forEach$iv":Ljava/lang/Iterable;
    iget-object v0, v4, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->L$6:Ljava/lang/Object;

    move-object/from16 v24, v0

    check-cast v24, Ljava/util/List;

    .local v24, "tlds":Ljava/util/List;
    iget-object v0, v4, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->L$5:Ljava/lang/Object;

    move-object/from16 v25, v0

    check-cast v25, Lkotlin/jvm/internal/Ref$IntRef;

    .local v25, "changed":Lkotlin/jvm/internal/Ref$IntRef;
    iget-object v0, v4, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->L$4:Ljava/lang/Object;

    move-object/from16 v26, v0

    check-cast v26, Lkotlin/jvm/internal/Ref$IntRef;

    .local v26, "reachable":Lkotlin/jvm/internal/Ref$IntRef;
    iget-object v0, v4, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->L$3:Ljava/lang/Object;

    move-object/from16 v27, v0

    check-cast v27, Lorg/json/JSONObject;

    .local v27, "directory":Lorg/json/JSONObject;
    iget-object v0, v4, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->L$2:Ljava/lang/Object;

    move-object/from16 v28, v0

    check-cast v28, Landroid/content/SharedPreferences;

    .local v28, "prefs":Landroid/content/SharedPreferences;
    iget-object v0, v4, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->L$1:Ljava/lang/Object;

    move-object/from16 v29, v0

    check-cast v29, Ljava/util/List;

    .end local p2  # "providers":Ljava/util/List;
    .local v29, "providers":Ljava/util/List;
    iget-object v0, v4, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->L$0:Ljava/lang/Object;

    move-object/from16 v30, v0

    check-cast v30, Landroid/content/Context;

    .end local p1  # "context":Landroid/content/Context;
    .local v30, "context":Landroid/content/Context;
    :try_start_92
    invoke-static {v5}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V
    :try_end_95
    .catchall {:try_start_92 .. :try_end_95} :catchall_ac

    move-object/from16 v16, v1

    move-object/from16 v17, v7

    move/from16 v0, v20

    move-object/from16 v18, v22

    move-object/from16 v19, v26

    move-object/from16 v20, v27

    const/4 v1, 0x2

    const/16 v31, 0x1

    move-object/from16 v22, v3

    move-object v7, v6

    move-object/from16 v3, p0

    move-object v6, v5

    goto/16 :goto_53c

    .line 161
    .end local v13  # "$this$update_u24lambda_u241_u244":Ldev/wiojelt/turksinema/common/DomainUpdateUi;
    .end local v20  # "$i$a$-runCatching-DomainUpdateUi$update$2$response$1":I
    :catchall_ac
    move-exception v0

    move-object/from16 v16, v1

    move-object/from16 v18, v22

    move-object/from16 v19, v26

    move-object/from16 v20, v27

    const/4 v1, 0x2

    const/16 v31, 0x1

    move-object/from16 v22, v3

    move-object/from16 v3, p0

    goto/16 :goto_5c5

    .line 127
    .end local v1  # "element$iv":Ljava/lang/Object;
    .end local v7  # "host":Ljava/lang/String;
    .end local v8  # "baseName":Ljava/lang/String;
    .end local v9  # "candidates":Ljava/util/List;
    .end local v10  # "dynamicCandidates":Ljava/util/List;
    .end local v11  # "$i$f$forEach":I
    .end local v12  # "$i$a$-forEach-DomainUpdateUi$update$2":I
    .end local v14  # "candidate":Ljava/lang/String;
    .end local v21  # "provider":Lcom/lagradost/cloudstream3/MainAPI;
    .end local v23  # "$this$forEach$iv":Ljava/lang/Iterable;
    .end local v24  # "tlds":Ljava/util/List;
    .end local v25  # "changed":Lkotlin/jvm/internal/Ref$IntRef;
    .end local v26  # "reachable":Lkotlin/jvm/internal/Ref$IntRef;
    .end local v27  # "directory":Lorg/json/JSONObject;
    .end local v28  # "prefs":Landroid/content/SharedPreferences;
    .end local v29  # "providers":Ljava/util/List;
    .end local v30  # "context":Landroid/content/Context;
    .restart local p1  # "context":Landroid/content/Context;
    .restart local p2  # "providers":Ljava/util/List;
    :pswitch_be  #0x1
    const/4 v0, 0x0

    .local v0, "$i$a$-runCatching-DomainUpdateUi$update$directory$1":I
    iget-object v1, v4, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->L$3:Ljava/lang/Object;

    check-cast v1, Ldev/wiojelt/turksinema/common/DomainUpdateUi;

    .local v1, "$this$update_u24lambda_u240":Ldev/wiojelt/turksinema/common/DomainUpdateUi;
    iget-object v7, v4, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->L$2:Ljava/lang/Object;

    check-cast v7, Landroid/content/SharedPreferences;

    .local v7, "prefs":Landroid/content/SharedPreferences;
    iget-object v8, v4, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->L$1:Ljava/lang/Object;

    check-cast v8, Ljava/util/List;

    .end local p2  # "providers":Ljava/util/List;
    .local v8, "providers":Ljava/util/List;
    iget-object v9, v4, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->L$0:Ljava/lang/Object;

    check-cast v9, Landroid/content/Context;

    .end local p1  # "context":Landroid/content/Context;
    .local v9, "context":Landroid/content/Context;
    :try_start_cf
    invoke-static {v5}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V
    :try_end_d2
    .catchall {:try_start_cf .. :try_end_d2} :catchall_de

    move-object/from16 v22, v3

    move-object/from16 v18, v4

    move-object/from16 v24, v5

    const/4 v2, 0x0

    const/4 v3, 0x2

    move-object v4, v1

    move-object v1, v6

    goto/16 :goto_15c

    .line 129
    .end local v0  # "$i$a$-runCatching-DomainUpdateUi$update$directory$1":I
    .end local v1  # "$this$update_u24lambda_u240":Ldev/wiojelt/turksinema/common/DomainUpdateUi;
    :catchall_de
    move-exception v0

    move-object/from16 v22, v3

    move-object/from16 v18, v4

    move-object/from16 v24, v5

    move-object v1, v6

    const/4 v2, 0x0

    const/4 v3, 0x2

    goto/16 :goto_19b

    .line 127
    .end local v7  # "prefs":Landroid/content/SharedPreferences;
    .end local v8  # "providers":Ljava/util/List;
    .end local v9  # "context":Landroid/content/Context;
    .restart local p1  # "context":Landroid/content/Context;
    .restart local p2  # "providers":Ljava/util/List;
    :pswitch_ea  #0x0
    invoke-static {v5}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 128
    const-string v0, "turksinema_domains"

    move-object/from16 v1, p1

    const/4 v7, 0x0

    invoke-virtual {v1, v0, v7}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v8

    .line 129
    .local v8, "prefs":Landroid/content/SharedPreferences;
    :try_start_f6
    sget-object v0, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object/from16 v0, p0

    check-cast v0, Ldev/wiojelt/turksinema/common/DomainUpdateUi;

    .line 179
    .local v0, "$this$update_u24lambda_u240":Ldev/wiojelt/turksinema/common/DomainUpdateUi;
    const/16 v21, 0x0

    .line 129
    .local v21, "$i$a$-runCatching-DomainUpdateUi$update$directory$1":I
    invoke-static {}, Lcom/lagradost/cloudstream3/MainActivityKt;->getApp()Lcom/lagradost/nicehttp/Requests;

    move-result-object v9
    :try_end_102
    .catchall {:try_start_f6 .. :try_end_102} :catchall_189

    move-object v10, v5

    .end local v5  # "$result":Ljava/lang/Object;
    .local v10, "$result":Ljava/lang/Object;
    :try_start_103
    const-string v5, "https://raw.githubusercontent.com/Wiojelt/TurkSinema/main/domains.json"

    invoke-static {v1}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v11

    iput-object v11, v4, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->L$0:Ljava/lang/Object;

    move-object/from16 v11, p2

    iput-object v11, v4, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->L$1:Ljava/lang/Object;

    iput-object v8, v4, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->L$2:Ljava/lang/Object;

    invoke-static {v0}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v12

    iput-object v12, v4, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->L$3:Ljava/lang/Object;

    const/4 v12, 0x1

    iput v12, v4, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->label:I
    :try_end_11a
    .catchall {:try_start_103 .. :try_end_11a} :catchall_176

    move-object v13, v6

    const/4 v6, 0x0

    move/from16 v19, v7

    const/4 v7, 0x0

    move-object v14, v8

    .end local v8  # "prefs":Landroid/content/SharedPreferences;
    .local v14, "prefs":Landroid/content/SharedPreferences;
    const/4 v8, 0x0

    move-object/from16 v18, v4

    move-object v4, v9

    .end local v4  # "$continuation":Lkotlin/coroutines/Continuation;
    .local v18, "$continuation":Lkotlin/coroutines/Continuation;
    const/4 v9, 0x0

    move-object v15, v10

    .end local v10  # "$result":Ljava/lang/Object;
    .local v15, "$result":Ljava/lang/Object;
    const/4 v10, 0x0

    const/4 v11, 0x0

    move/from16 v20, v12

    const/4 v12, 0x0

    move-object/from16 v22, v13

    move-object/from16 v23, v14

    .end local v14  # "prefs":Landroid/content/SharedPreferences;
    .local v23, "prefs":Landroid/content/SharedPreferences;
    const-wide/16 v13, 0xa

    move-object/from16 v24, v15

    .end local v15  # "$result":Ljava/lang/Object;
    .local v24, "$result":Ljava/lang/Object;
    const/4 v15, 0x0

    const/16 v25, 0x2

    const/16 v16, 0x0

    const/16 v26, 0x0

    const/16 v17, 0x0

    move/from16 v27, v19

    const/16 v19, 0xefe

    move/from16 v28, v20

    const/16 v20, 0x0

    move-object/from16 v1, v22

    move-object/from16 v2, v26

    move-object/from16 v22, v3

    move/from16 v3, v25

    :try_start_14c
    invoke-static/range {v4 .. v20}, Lcom/lagradost/nicehttp/Requests;->get$default(Lcom/lagradost/nicehttp/Requests;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;ZILjava/util/concurrent/TimeUnit;JLokhttp3/Interceptor;ZLcom/lagradost/nicehttp/ResponseParser;Lkotlin/coroutines/Continuation;ILjava/lang/Object;)Ljava/lang/Object;

    move-result-object v5
    :try_end_150
    .catchall {:try_start_14c .. :try_end_150} :catchall_16e

    if-ne v5, v1, :cond_153

    .line 127
    return-object v1

    .line 129
    :cond_153
    move-object/from16 v9, p1

    move-object/from16 v8, p2

    move-object v4, v0

    move/from16 v0, v21

    move-object/from16 v7, v23

    .end local v21  # "$i$a$-runCatching-DomainUpdateUi$update$directory$1":I
    .end local v23  # "prefs":Landroid/content/SharedPreferences;
    .end local p1  # "context":Landroid/content/Context;
    .end local p2  # "providers":Ljava/util/List;
    .local v0, "$i$a$-runCatching-DomainUpdateUi$update$directory$1":I
    .local v4, "$this$update_u24lambda_u240":Ldev/wiojelt/turksinema/common/DomainUpdateUi;
    .restart local v7  # "prefs":Landroid/content/SharedPreferences;
    .local v8, "providers":Ljava/util/List;
    .restart local v9  # "context":Landroid/content/Context;
    :goto_15c
    :try_start_15c
    check-cast v5, Lcom/lagradost/nicehttp/NiceResponse;

    invoke-virtual {v5}, Lcom/lagradost/nicehttp/NiceResponse;->getText()Ljava/lang/String;

    move-result-object v5

    new-instance v6, Lorg/json/JSONObject;

    invoke-direct {v6, v5}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .end local v0  # "$i$a$-runCatching-DomainUpdateUi$update$directory$1":I
    .end local v4  # "$this$update_u24lambda_u240":Ldev/wiojelt/turksinema/common/DomainUpdateUi;
    invoke-static {v6}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0
    :try_end_16b
    .catchall {:try_start_15c .. :try_end_16b} :catchall_16c

    goto :goto_1a5

    :catchall_16c
    move-exception v0

    goto :goto_19b

    .end local v7  # "prefs":Landroid/content/SharedPreferences;
    .end local v8  # "providers":Ljava/util/List;
    .end local v9  # "context":Landroid/content/Context;
    .restart local v23  # "prefs":Landroid/content/SharedPreferences;
    .restart local p1  # "context":Landroid/content/Context;
    .restart local p2  # "providers":Ljava/util/List;
    :catchall_16e
    move-exception v0

    move-object/from16 v9, p1

    move-object/from16 v8, p2

    move-object/from16 v7, v23

    goto :goto_19b

    .end local v18  # "$continuation":Lkotlin/coroutines/Continuation;
    .end local v23  # "prefs":Landroid/content/SharedPreferences;
    .end local v24  # "$result":Ljava/lang/Object;
    .local v4, "$continuation":Lkotlin/coroutines/Continuation;
    .local v8, "prefs":Landroid/content/SharedPreferences;
    .restart local v10  # "$result":Ljava/lang/Object;
    :catchall_176
    move-exception v0

    move-object/from16 v22, v3

    move-object/from16 v18, v4

    move-object v1, v6

    move-object/from16 v23, v8

    move-object/from16 v24, v10

    const/4 v2, 0x0

    const/4 v3, 0x2

    move-object/from16 v9, p1

    move-object/from16 v8, p2

    move-object/from16 v7, v23

    .end local v4  # "$continuation":Lkotlin/coroutines/Continuation;
    .end local v8  # "prefs":Landroid/content/SharedPreferences;
    .end local v10  # "$result":Ljava/lang/Object;
    .restart local v18  # "$continuation":Lkotlin/coroutines/Continuation;
    .restart local v23  # "prefs":Landroid/content/SharedPreferences;
    .restart local v24  # "$result":Ljava/lang/Object;
    goto :goto_19b

    .end local v18  # "$continuation":Lkotlin/coroutines/Continuation;
    .end local v23  # "prefs":Landroid/content/SharedPreferences;
    .end local v24  # "$result":Ljava/lang/Object;
    .restart local v4  # "$continuation":Lkotlin/coroutines/Continuation;
    .restart local v5  # "$result":Ljava/lang/Object;
    .restart local v8  # "prefs":Landroid/content/SharedPreferences;
    :catchall_189
    move-exception v0

    move-object/from16 v22, v3

    move-object/from16 v18, v4

    move-object/from16 v24, v5

    move-object v1, v6

    move-object/from16 v23, v8

    const/4 v2, 0x0

    const/4 v3, 0x2

    move-object/from16 v9, p1

    move-object/from16 v8, p2

    move-object/from16 v7, v23

    .end local v4  # "$continuation":Lkotlin/coroutines/Continuation;
    .end local v5  # "$result":Ljava/lang/Object;
    .end local p1  # "context":Landroid/content/Context;
    .end local p2  # "providers":Ljava/util/List;
    .restart local v7  # "prefs":Landroid/content/SharedPreferences;
    .local v8, "providers":Ljava/util/List;
    .restart local v9  # "context":Landroid/content/Context;
    .restart local v18  # "$continuation":Lkotlin/coroutines/Continuation;
    .restart local v24  # "$result":Ljava/lang/Object;
    :goto_19b
    sget-object v4, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v0}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    :goto_1a5
    move-object/from16 v49, v9

    move-object v9, v0

    move-object/from16 v0, v49

    .end local v9  # "context":Landroid/content/Context;
    .local v0, "context":Landroid/content/Context;
    invoke-static {v9}, Lkotlin/Result;->isFailure-impl(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_1b1

    move-object v9, v2

    :cond_1b1
    move-object v4, v9

    check-cast v4, Lorg/json/JSONObject;

    .line 130
    .local v4, "directory":Lorg/json/JSONObject;
    new-instance v5, Lkotlin/jvm/internal/Ref$IntRef;

    invoke-direct {v5}, Lkotlin/jvm/internal/Ref$IntRef;-><init>()V

    .line 131
    .local v5, "reachable":Lkotlin/jvm/internal/Ref$IntRef;
    new-instance v6, Lkotlin/jvm/internal/Ref$IntRef;

    invoke-direct {v6}, Lkotlin/jvm/internal/Ref$IntRef;-><init>()V

    .line 133
    .local v6, "changed":Lkotlin/jvm/internal/Ref$IntRef;
    const-string v41, "one"

    const-string v42, "top"

    const-string v32, "to"

    const-string v33, "org"

    const-string v34, "net"

    const-string v35, "com"

    const-string v36, "co"

    const-string v37, "me"

    const-string v38, "cc"

    const-string v39, "tv"

    const-string v40, "is"

    filled-new-array/range {v32 .. v42}, [Ljava/lang/String;

    move-result-object v9

    invoke-static {v9}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v9

    .line 135
    .local v9, "tlds":Ljava/util/List;
    move-object v10, v8

    check-cast v10, Ljava/lang/Iterable;

    .local v10, "$this$forEach$iv":Ljava/lang/Iterable;
    const/4 v11, 0x0

    .line 185
    .restart local v11  # "$i$f$forEach":I
    invoke-interface {v10}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v12

    move-object/from16 v15, p0

    move v13, v11

    move-object v14, v12

    move-object v11, v9

    move-object v12, v10

    move-object v9, v7

    move-object v10, v8

    move-object v8, v1

    move-object v7, v6

    move-object/from16 v1, p3

    move-object v6, v5

    move-object v5, v4

    move-object v4, v0

    .end local v0  # "context":Landroid/content/Context;
    .end local v8  # "providers":Ljava/util/List;
    .end local p0  # "this":Ldev/wiojelt/turksinema/common/DomainUpdateUi;
    .end local p3  # "$completion":Lkotlin/coroutines/Continuation;
    .local v1, "$completion":Lkotlin/coroutines/Continuation;
    .local v4, "context":Landroid/content/Context;
    .local v5, "directory":Lorg/json/JSONObject;
    .local v6, "reachable":Lkotlin/jvm/internal/Ref$IntRef;
    .local v7, "changed":Lkotlin/jvm/internal/Ref$IntRef;
    .local v9, "prefs":Landroid/content/SharedPreferences;
    .local v10, "providers":Ljava/util/List;
    .local v11, "tlds":Ljava/util/List;
    .local v12, "$this$forEach$iv":Ljava/lang/Iterable;
    .local v13, "$i$f$forEach":I
    .local v15, "this":Ldev/wiojelt/turksinema/common/DomainUpdateUi;
    :goto_1f3
    invoke-interface {v14}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_6a1

    invoke-interface {v14}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v16

    .local v16, "element$iv":Ljava/lang/Object;
    move-object/from16 v17, v16

    check-cast v17, Lcom/lagradost/cloudstream3/MainAPI;

    .local v17, "provider":Lcom/lagradost/cloudstream3/MainAPI;
    const/16 v19, 0x0

    .line 136
    .local v19, "$i$a$-forEach-DomainUpdateUi$update$2":I
    sget-object v0, Ldev/wiojelt/turksinema/common/DomainUpdateUi;->INSTANCE:Ldev/wiojelt/turksinema/common/DomainUpdateUi;

    :try_start_205
    sget-object v20, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    .line 179
    .local v0, "$this$update_u24lambda_u241_u240":Ldev/wiojelt/turksinema/common/DomainUpdateUi;
    const/16 v20, 0x0

    .line 136
    .local v20, "$i$a$-runCatching-DomainUpdateUi$update$2$host$1":I
    new-instance v2, Ljava/net/URI;

    invoke-virtual/range {v17 .. v17}, Lcom/lagradost/cloudstream3/MainAPI;->getMainUrl()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/net/URI;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2}, Ljava/net/URI;->getHost()Ljava/lang/String;

    move-result-object v2

    if-nez v2, :cond_21a

    move-object/from16 v2, v22

    .end local v0  # "$this$update_u24lambda_u241_u240":Ldev/wiojelt/turksinema/common/DomainUpdateUi;
    .end local v20  # "$i$a$-runCatching-DomainUpdateUi$update$2$host$1":I
    :cond_21a
    invoke-static {v2}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0
    :try_end_21e
    .catchall {:try_start_205 .. :try_end_21e} :catchall_21f

    goto :goto_22a

    :catchall_21f
    move-exception v0

    sget-object v2, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v0}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    :goto_22a
    invoke-static {v0}, Lkotlin/Result;->isFailure-impl(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_232

    move-object/from16 v0, v22

    :cond_232
    check-cast v0, Ljava/lang/String;

    .line 137
    .local v0, "host":Ljava/lang/String;
    const/16 v2, 0x2e

    move-object/from16 p1, v1

    const/4 v1, 0x0

    const/4 v3, 0x2

    .end local v1  # "$completion":Lkotlin/coroutines/Continuation;
    .local p1, "$completion":Lkotlin/coroutines/Continuation;
    invoke-static {v0, v2, v1, v3, v1}, Lkotlin/text/StringsKt;->substringBeforeLast$default(Ljava/lang/String;CLjava/lang/String;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    const-string v1, "www."

    check-cast v1, Ljava/lang/CharSequence;

    invoke-static {v2, v1}, Lkotlin/text/StringsKt;->removePrefix(Ljava/lang/String;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v1

    .line 139
    .local v1, "baseName":Ljava/lang/String;
    move-object v2, v1

    check-cast v2, Ljava/lang/CharSequence;

    invoke-static {v2}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_3cf

    .line 140
    move-object v2, v11

    check-cast v2, Ljava/lang/Iterable;

    .local v2, "$this$map$iv":Ljava/lang/Iterable;
    const/4 v3, 0x0

    .line 186
    .local v3, "$i$f$map":I
    move-object/from16 p2, v0

    .end local v0  # "host":Ljava/lang/String;
    .local p2, "host":Ljava/lang/String;
    new-instance v0, Ljava/util/ArrayList;

    move/from16 p3, v3

    .end local v3  # "$i$f$map":I
    .local p3, "$i$f$map":I
    const/16 v3, 0xa

    move-object/from16 v20, v4

    .end local v4  # "context":Landroid/content/Context;
    .local v20, "context":Landroid/content/Context;
    invoke-static {v2, v3}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v4

    invoke-direct {v0, v4}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v0, Ljava/util/Collection;

    .local v0, "destination$iv$iv":Ljava/util/Collection;
    move-object v4, v2

    .local v4, "$this$mapTo$iv$iv":Ljava/lang/Iterable;
    const/16 v21, 0x0

    .line 187
    .local v21, "$i$f$mapTo":I
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v23

    :goto_26d
    invoke-interface/range {v23 .. v23}, Ljava/util/Iterator;->hasNext()Z

    move-result v28

    const-string v3, "."

    move-object/from16 v30, v2

    .end local v2  # "$this$map$iv":Ljava/lang/Iterable;
    .local v30, "$this$map$iv":Ljava/lang/Iterable;
    const-string v2, "https://"

    if-eqz v28, :cond_2ac

    invoke-interface/range {v23 .. v23}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v28

    .line 188
    .local v28, "item$iv$iv":Ljava/lang/Object;
    move-object/from16 v32, v4

    .end local v4  # "$this$mapTo$iv$iv":Ljava/lang/Iterable;
    .local v32, "$this$mapTo$iv$iv":Ljava/lang/Iterable;
    move-object/from16 v4, v28

    check-cast v4, Ljava/lang/String;

    .local v4, "it":Ljava/lang/String;
    const/16 v33, 0x0

    .line 140
    .local v33, "$i$a$-map-DomainUpdateUi$update$2$dynamicCandidates$baseCandidates$1":I
    move-object/from16 v34, v8

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 188
    .end local v4  # "it":Ljava/lang/String;
    .end local v33  # "$i$a$-map-DomainUpdateUi$update$2$dynamicCandidates$baseCandidates$1":I
    invoke-interface {v0, v2}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    move-object/from16 v2, v30

    move-object/from16 v4, v32

    move-object/from16 v8, v34

    const/16 v3, 0xa

    goto :goto_26d

    .line 189
    .end local v28  # "item$iv$iv":Ljava/lang/Object;
    .end local v32  # "$this$mapTo$iv$iv":Ljava/lang/Iterable;
    .local v4, "$this$mapTo$iv$iv":Ljava/lang/Iterable;
    :cond_2ac
    move-object/from16 v32, v4

    move-object/from16 v34, v8

    .end local v0  # "destination$iv$iv":Ljava/util/Collection;
    .end local v4  # "$this$mapTo$iv$iv":Ljava/lang/Iterable;
    .end local v21  # "$i$f$mapTo":I
    check-cast v0, Ljava/util/List;

    .line 186
    nop

    .line 140
    .end local v30  # "$this$map$iv":Ljava/lang/Iterable;
    .end local p3  # "$i$f$map":I
    nop

    .line 141
    .local v0, "baseCandidates":Ljava/util/List;
    new-instance v4, Lkotlin/text/Regex;

    const-string v8, "(\\d+)"

    invoke-direct {v4, v8}, Lkotlin/text/Regex;-><init>(Ljava/lang/String;)V

    move-object v8, v1

    check-cast v8, Ljava/lang/CharSequence;

    move-object/from16 p3, v1

    move-object/from16 v21, v9

    move-object/from16 v23, v10

    const/4 v1, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x0

    .end local v1  # "baseName":Ljava/lang/String;
    .end local v9  # "prefs":Landroid/content/SharedPreferences;
    .end local v10  # "providers":Ljava/util/List;
    .local v21, "prefs":Landroid/content/SharedPreferences;
    .local v23, "providers":Ljava/util/List;
    .local p3, "baseName":Ljava/lang/String;
    invoke-static {v4, v8, v9, v1, v10}, Lkotlin/text/Regex;->findAll$default(Lkotlin/text/Regex;Ljava/lang/CharSequence;IILjava/lang/Object;)Lkotlin/sequences/Sequence;

    move-result-object v4

    invoke-static {v4}, Lkotlin/sequences/SequencesKt;->lastOrNull(Lkotlin/sequences/Sequence;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lkotlin/text/MatchResult;

    .line 142
    .local v1, "digitsMatch":Lkotlin/text/MatchResult;
    if-eqz v1, :cond_3b8

    .line 143
    invoke-interface {v1}, Lkotlin/text/MatchResult;->getValue()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Lkotlin/text/StringsKt;->toLongOrNull(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v4

    .line 144
    .local v4, "num":Ljava/lang/Long;
    if-eqz v4, :cond_3ab

    .line 145
    new-instance v8, Lkotlin/ranges/IntRange;

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-direct {v8, v10, v9}, Lkotlin/ranges/IntRange;-><init>(II)V

    check-cast v8, Ljava/lang/Iterable;

    .local v8, "$this$flatMap$iv":Ljava/lang/Iterable;
    const/4 v9, 0x0

    .line 190
    .local v9, "$i$f$flatMap":I
    new-instance v28, Ljava/util/ArrayList;

    invoke-direct/range {v28 .. v28}, Ljava/util/ArrayList;-><init>()V

    move/from16 v31, v10

    move-object/from16 v10, v28

    check-cast v10, Ljava/util/Collection;

    .local v10, "destination$iv$iv":Ljava/util/Collection;
    move-object/from16 v28, v8

    .local v28, "$this$flatMapTo$iv$iv":Ljava/lang/Iterable;
    const/16 v30, 0x0

    .line 191
    .local v30, "$i$f$flatMapTo":I
    invoke-interface/range {v28 .. v28}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v32

    :goto_2fa
    invoke-interface/range {v32 .. v32}, Ljava/util/Iterator;->hasNext()Z

    move-result v33

    if-eqz v33, :cond_39c

    move-object/from16 v33, v32

    check-cast v33, Lkotlin/collections/IntIterator;

    invoke-virtual/range {v33 .. v33}, Lkotlin/collections/IntIterator;->nextInt()I

    move-result v33

    .line 192
    .local v33, "element$iv$iv":I
    move/from16 v35, v33

    .local v35, "step":I
    const/16 v36, 0x0

    .line 146
    .local v36, "$i$a$-flatMap-DomainUpdateUi$update$2$dynamicCandidates$numericCandidates$1":I
    move-object/from16 v37, v0

    .end local v0  # "baseCandidates":Ljava/util/List;
    .local v37, "baseCandidates":Ljava/util/List;
    invoke-interface {v1}, Lkotlin/text/MatchResult;->getRange()Lkotlin/ranges/IntRange;

    move-result-object v0

    invoke-virtual {v4}, Ljava/lang/Long;->longValue()J

    move-result-wide v38

    move-object/from16 v40, v1

    move/from16 v41, v9

    move/from16 v1, v35

    move-object/from16 v35, v8

    .end local v8  # "$this$flatMap$iv":Ljava/lang/Iterable;
    .end local v9  # "$i$f$flatMap":I
    .local v1, "step":I
    .local v35, "$this$flatMap$iv":Ljava/lang/Iterable;
    .local v40, "digitsMatch":Lkotlin/text/MatchResult;
    .local v41, "$i$f$flatMap":I
    int-to-long v8, v1

    add-long v38, v38, v8

    invoke-static/range {v38 .. v39}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v8

    check-cast v8, Ljava/lang/CharSequence;

    move-object/from16 v9, p3

    check-cast v9, Ljava/lang/CharSequence;

    invoke-static {v9, v0, v8}, Lkotlin/text/StringsKt;->replaceRange(Ljava/lang/CharSequence;Lkotlin/ranges/IntRange;Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    .line 147
    .local v0, "incrementedBase":Ljava/lang/String;
    move-object v8, v11

    check-cast v8, Ljava/lang/Iterable;

    .local v8, "$this$map$iv":Ljava/lang/Iterable;
    const/4 v9, 0x0

    .line 193
    .local v9, "$i$f$map":I
    move/from16 v38, v1

    .end local v1  # "step":I
    .local v38, "step":I
    new-instance v1, Ljava/util/ArrayList;

    move-object/from16 v39, v4

    move/from16 v29, v9

    const/16 v4, 0xa

    .end local v4  # "num":Ljava/lang/Long;
    .end local v9  # "$i$f$map":I
    .local v29, "$i$f$map":I
    .local v39, "num":Ljava/lang/Long;
    invoke-static {v8, v4}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v9

    invoke-direct {v1, v9}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v1, Ljava/util/Collection;

    .local v1, "destination$iv$iv":Ljava/util/Collection;
    move-object v9, v8

    .local v9, "$this$mapTo$iv$iv":Ljava/lang/Iterable;
    const/16 v42, 0x0

    .line 194
    .local v42, "$i$f$mapTo":I
    invoke-interface {v9}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v43

    :goto_351
    invoke-interface/range {v43 .. v43}, Ljava/util/Iterator;->hasNext()Z

    move-result v44

    if-eqz v44, :cond_384

    invoke-interface/range {v43 .. v43}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v44

    .line 195
    .local v44, "item$iv$iv":Ljava/lang/Object;
    move-object/from16 v4, v44

    check-cast v4, Ljava/lang/String;

    .local v4, "it":Ljava/lang/String;
    const/16 v46, 0x0

    .line 147
    .local v46, "$i$a$-map-DomainUpdateUi$update$2$dynamicCandidates$numericCandidates$1$1":I
    move-object/from16 v47, v8

    .end local v8  # "$this$map$iv":Ljava/lang/Iterable;
    .local v47, "$this$map$iv":Ljava/lang/Iterable;
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 195
    .end local v4  # "it":Ljava/lang/String;
    .end local v46  # "$i$a$-map-DomainUpdateUi$update$2$dynamicCandidates$numericCandidates$1$1":I
    invoke-interface {v1, v4}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    move-object/from16 v8, v47

    const/16 v4, 0xa

    goto :goto_351

    .line 196
    .end local v44  # "item$iv$iv":Ljava/lang/Object;
    .end local v47  # "$this$map$iv":Ljava/lang/Iterable;
    .restart local v8  # "$this$map$iv":Ljava/lang/Iterable;
    :cond_384
    move-object/from16 v47, v8

    .end local v1  # "destination$iv$iv":Ljava/util/Collection;
    .end local v8  # "$this$map$iv":Ljava/lang/Iterable;
    .end local v9  # "$this$mapTo$iv$iv":Ljava/lang/Iterable;
    .end local v42  # "$i$f$mapTo":I
    .restart local v47  # "$this$map$iv":Ljava/lang/Iterable;
    check-cast v1, Ljava/util/List;

    .line 193
    nop

    .end local v29  # "$i$f$map":I
    .end local v47  # "$this$map$iv":Ljava/lang/Iterable;
    check-cast v1, Ljava/lang/Iterable;

    .line 147
    nop

    .line 192
    .end local v0  # "incrementedBase":Ljava/lang/String;
    .end local v36  # "$i$a$-flatMap-DomainUpdateUi$update$2$dynamicCandidates$numericCandidates$1":I
    .end local v38  # "step":I
    nop

    .line 197
    .local v1, "list$iv$iv":Ljava/lang/Iterable;
    invoke-static {v10, v1}, Lkotlin/collections/CollectionsKt;->addAll(Ljava/util/Collection;Ljava/lang/Iterable;)Z

    move-object/from16 v8, v35

    move-object/from16 v0, v37

    move-object/from16 v4, v39

    move-object/from16 v1, v40

    move/from16 v9, v41

    goto/16 :goto_2fa

    .line 199
    .end local v33  # "element$iv$iv":I
    .end local v35  # "$this$flatMap$iv":Ljava/lang/Iterable;
    .end local v37  # "baseCandidates":Ljava/util/List;
    .end local v39  # "num":Ljava/lang/Long;
    .end local v40  # "digitsMatch":Lkotlin/text/MatchResult;
    .end local v41  # "$i$f$flatMap":I
    .local v0, "baseCandidates":Ljava/util/List;
    .local v1, "digitsMatch":Lkotlin/text/MatchResult;
    .local v4, "num":Ljava/lang/Long;
    .local v8, "$this$flatMap$iv":Ljava/lang/Iterable;
    .local v9, "$i$f$flatMap":I
    :cond_39c
    move-object/from16 v37, v0

    move-object/from16 v40, v1

    move-object/from16 v39, v4

    move-object/from16 v35, v8

    move/from16 v41, v9

    .end local v0  # "baseCandidates":Ljava/util/List;
    .end local v1  # "digitsMatch":Lkotlin/text/MatchResult;
    .end local v4  # "num":Ljava/lang/Long;
    .end local v8  # "$this$flatMap$iv":Ljava/lang/Iterable;
    .end local v9  # "$i$f$flatMap":I
    .end local v10  # "destination$iv$iv":Ljava/util/Collection;
    .end local v28  # "$this$flatMapTo$iv$iv":Ljava/lang/Iterable;
    .end local v30  # "$i$f$flatMapTo":I
    .restart local v35  # "$this$flatMap$iv":Ljava/lang/Iterable;
    .restart local v37  # "baseCandidates":Ljava/util/List;
    .restart local v39  # "num":Ljava/lang/Long;
    .restart local v40  # "digitsMatch":Lkotlin/text/MatchResult;
    .restart local v41  # "$i$f$flatMap":I
    move-object v0, v10

    check-cast v0, Ljava/util/List;

    .line 190
    nop

    .end local v35  # "$this$flatMap$iv":Ljava/lang/Iterable;
    .end local v41  # "$i$f$flatMap":I
    goto :goto_3c2

    .line 149
    .end local v37  # "baseCandidates":Ljava/util/List;
    .end local v39  # "num":Ljava/lang/Long;
    .end local v40  # "digitsMatch":Lkotlin/text/MatchResult;
    .restart local v0  # "baseCandidates":Ljava/util/List;
    .restart local v1  # "digitsMatch":Lkotlin/text/MatchResult;
    .restart local v4  # "num":Ljava/lang/Long;
    :cond_3ab
    move-object/from16 v37, v0

    move-object/from16 v40, v1

    move-object/from16 v39, v4

    const/16 v31, 0x1

    .end local v0  # "baseCandidates":Ljava/util/List;
    .end local v1  # "digitsMatch":Lkotlin/text/MatchResult;
    .end local v4  # "num":Ljava/lang/Long;
    .restart local v37  # "baseCandidates":Ljava/util/List;
    .restart local v39  # "num":Ljava/lang/Long;
    .restart local v40  # "digitsMatch":Lkotlin/text/MatchResult;
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v0

    .end local v39  # "num":Ljava/lang/Long;
    goto :goto_3c2

    .line 150
    .end local v37  # "baseCandidates":Ljava/util/List;
    .end local v40  # "digitsMatch":Lkotlin/text/MatchResult;
    .restart local v0  # "baseCandidates":Ljava/util/List;
    .restart local v1  # "digitsMatch":Lkotlin/text/MatchResult;
    :cond_3b8
    move-object/from16 v37, v0

    move-object/from16 v40, v1

    const/16 v31, 0x1

    .end local v0  # "baseCandidates":Ljava/util/List;
    .end local v1  # "digitsMatch":Lkotlin/text/MatchResult;
    .restart local v37  # "baseCandidates":Ljava/util/List;
    .restart local v40  # "digitsMatch":Lkotlin/text/MatchResult;
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v0

    .line 142
    :goto_3c2
    nop

    .line 151
    .local v0, "numericCandidates":Ljava/util/List;
    move-object/from16 v1, v37

    check-cast v1, Ljava/util/Collection;

    move-object v2, v0

    check-cast v2, Ljava/lang/Iterable;

    invoke-static {v1, v2}, Lkotlin/collections/CollectionsKt;->plus(Ljava/util/Collection;Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v0

    .end local v0  # "numericCandidates":Ljava/util/List;
    .end local v37  # "baseCandidates":Ljava/util/List;
    .end local v40  # "digitsMatch":Lkotlin/text/MatchResult;
    goto :goto_3e1

    .line 152
    .end local v20  # "context":Landroid/content/Context;
    .end local v21  # "prefs":Landroid/content/SharedPreferences;
    .end local v23  # "providers":Ljava/util/List;
    .end local p2  # "host":Ljava/lang/String;
    .end local p3  # "baseName":Ljava/lang/String;
    .local v0, "host":Ljava/lang/String;
    .local v1, "baseName":Ljava/lang/String;
    .local v4, "context":Landroid/content/Context;
    .local v9, "prefs":Landroid/content/SharedPreferences;
    .local v10, "providers":Ljava/util/List;
    :cond_3cf
    move-object/from16 p2, v0

    move-object/from16 p3, v1

    move-object/from16 v20, v4

    move-object/from16 v34, v8

    move-object/from16 v21, v9

    move-object/from16 v23, v10

    const/16 v31, 0x1

    .end local v0  # "host":Ljava/lang/String;
    .end local v1  # "baseName":Ljava/lang/String;
    .end local v4  # "context":Landroid/content/Context;
    .end local v9  # "prefs":Landroid/content/SharedPreferences;
    .end local v10  # "providers":Ljava/util/List;
    .restart local v20  # "context":Landroid/content/Context;
    .restart local v21  # "prefs":Landroid/content/SharedPreferences;
    .restart local v23  # "providers":Ljava/util/List;
    .restart local p2  # "host":Ljava/lang/String;
    .restart local p3  # "baseName":Ljava/lang/String;
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v0

    .line 139
    :goto_3e1
    nop

    .line 154
    .local v0, "dynamicCandidates":Ljava/util/List;
    invoke-static {}, Lkotlin/collections/CollectionsKt;->createListBuilder()Ljava/util/List;

    move-result-object v1

    move-object v2, v1

    .local v2, "$this$update_u24lambda_u241_u243":Ljava/util/List;
    const/4 v3, 0x0

    .line 155
    .local v3, "$i$a$-buildList-DomainUpdateUi$update$2$candidates$1":I
    if-eqz v5, :cond_40f

    invoke-virtual/range {v17 .. v17}, Lcom/lagradost/cloudstream3/MainAPI;->getName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v5, v4}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v4

    if-eqz v4, :cond_40f

    .line 179
    .local v4, "array":Lorg/json/JSONArray;
    const/4 v8, 0x0

    .line 155
    .local v8, "$i$a$-let-DomainUpdateUi$update$2$candidates$1$1":I
    const/4 v9, 0x0

    .local v9, "i":I
    invoke-virtual {v4}, Lorg/json/JSONArray;->length()I

    move-result v10

    :goto_3fa
    if-ge v9, v10, :cond_40a

    move-object/from16 v28, v0

    .end local v0  # "dynamicCandidates":Ljava/util/List;
    .local v28, "dynamicCandidates":Ljava/util/List;
    invoke-virtual {v4, v9}, Lorg/json/JSONArray;->optString(I)Ljava/lang/String;

    move-result-object v0

    invoke-interface {v2, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-int/lit8 v9, v9, 0x1

    move-object/from16 v0, v28

    goto :goto_3fa

    .end local v28  # "dynamicCandidates":Ljava/util/List;
    .restart local v0  # "dynamicCandidates":Ljava/util/List;
    :cond_40a
    move-object/from16 v28, v0

    .end local v0  # "dynamicCandidates":Ljava/util/List;
    .end local v4  # "array":Lorg/json/JSONArray;
    .end local v8  # "$i$a$-let-DomainUpdateUi$update$2$candidates$1$1":I
    .end local v9  # "i":I
    .restart local v28  # "dynamicCandidates":Ljava/util/List;
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    goto :goto_411

    .end local v28  # "dynamicCandidates":Ljava/util/List;
    .restart local v0  # "dynamicCandidates":Ljava/util/List;
    :cond_40f
    move-object/from16 v28, v0

    .line 156
    .end local v0  # "dynamicCandidates":Ljava/util/List;
    .restart local v28  # "dynamicCandidates":Ljava/util/List;
    :goto_411
    invoke-virtual/range {v17 .. v17}, Lcom/lagradost/cloudstream3/MainAPI;->getMainUrl()Ljava/lang/String;

    move-result-object v0

    invoke-interface {v2, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 157
    move-object/from16 v0, v28

    check-cast v0, Ljava/util/Collection;

    invoke-interface {v2, v0}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    .line 158
    nop

    .line 154
    .end local v2  # "$this$update_u24lambda_u241_u243":Ljava/util/List;
    .end local v3  # "$i$a$-buildList-DomainUpdateUi$update$2$candidates$1":I
    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->build(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .line 158
    sget-object v1, Ldev/wiojelt/turksinema/common/DomainUpdateUi;->INSTANCE:Ldev/wiojelt/turksinema/common/DomainUpdateUi;

    .local v0, "$this$mapNotNull$iv":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 200
    .local v2, "$i$f$mapNotNull":I
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    check-cast v3, Ljava/util/Collection;

    .local v3, "destination$iv$iv":Ljava/util/Collection;
    move-object v4, v0

    .local v4, "$this$mapNotNullTo$iv$iv":Ljava/lang/Iterable;
    const/4 v8, 0x0

    .line 209
    .local v8, "$i$f$mapNotNullTo":I
    move-object v9, v4

    .local v9, "$this$forEach$iv$iv$iv":Ljava/lang/Iterable;
    const/4 v10, 0x0

    .line 210
    .local v10, "$i$f$forEach":I
    invoke-interface {v9}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v29

    :goto_438
    invoke-interface/range {v29 .. v29}, Ljava/util/Iterator;->hasNext()Z

    move-result v30

    if-eqz v30, :cond_45c

    invoke-interface/range {v29 .. v29}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v30

    .local v30, "element$iv$iv$iv":Ljava/lang/Object;
    move-object/from16 v32, v30

    .local v32, "element$iv$iv":Ljava/lang/Object;
    const/16 v33, 0x0

    .line 209
    .local v33, "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1$iv$iv":I
    move-object/from16 v35, v0

    .end local v0  # "$this$mapNotNull$iv":Ljava/lang/Iterable;
    .local v35, "$this$mapNotNull$iv":Ljava/lang/Iterable;
    move-object/from16 v0, v32

    check-cast v0, Ljava/lang/String;

    .local v0, "p0":Ljava/lang/String;
    const/16 v36, 0x0

    .line 158
    .local v36, "$i$a$-mapNotNull-DomainUpdateUi$update$2$candidates$2":I
    invoke-direct {v1, v0}, Ldev/wiojelt/turksinema/common/DomainUpdateUi;->origin(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 209
    .end local v0  # "p0":Ljava/lang/String;
    .end local v36  # "$i$a$-mapNotNull-DomainUpdateUi$update$2$candidates$2":I
    if-eqz v0, :cond_459

    .line 211
    .local v0, "it$iv$iv":Ljava/lang/Object;
    const/16 v36, 0x0

    .line 209
    .local v36, "$i$a$-let-CollectionsKt___CollectionsKt$mapNotNullTo$1$1$iv$iv":I
    invoke-interface {v3, v0}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 210
    .end local v0  # "it$iv$iv":Ljava/lang/Object;
    .end local v32  # "element$iv$iv":Ljava/lang/Object;
    .end local v33  # "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1$iv$iv":I
    .end local v36  # "$i$a$-let-CollectionsKt___CollectionsKt$mapNotNullTo$1$1$iv$iv":I
    :cond_459
    move-object/from16 v0, v35

    .end local v30  # "element$iv$iv$iv":Ljava/lang/Object;
    goto :goto_438

    .line 212
    .end local v35  # "$this$mapNotNull$iv":Ljava/lang/Iterable;
    .local v0, "$this$mapNotNull$iv":Ljava/lang/Iterable;
    :cond_45c
    move-object/from16 v35, v0

    .line 213
    .end local v0  # "$this$mapNotNull$iv":Ljava/lang/Iterable;
    .end local v9  # "$this$forEach$iv$iv$iv":Ljava/lang/Iterable;
    .end local v10  # "$i$f$forEach":I
    .restart local v35  # "$this$mapNotNull$iv":Ljava/lang/Iterable;
    nop

    .end local v3  # "destination$iv$iv":Ljava/util/Collection;
    .end local v4  # "$this$mapNotNullTo$iv$iv":Ljava/lang/Iterable;
    .end local v8  # "$i$f$mapNotNullTo":I
    move-object v0, v3

    check-cast v0, Ljava/util/List;

    .line 200
    nop

    .end local v2  # "$i$f$mapNotNull":I
    .end local v35  # "$this$mapNotNull$iv":Ljava/lang/Iterable;
    check-cast v0, Ljava/lang/Iterable;

    .line 158
    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->distinct(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v0

    .line 154
    nop

    .line 160
    .local v0, "candidates":Ljava/util/List;
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    move v2, v13

    move-object v13, v11

    move v11, v2

    move-object/from16 v8, p3

    move-object v9, v0

    move-object v2, v6

    move-object/from16 v4, v17

    move-object/from16 v3, v18

    move-object/from16 v30, v20

    move-object/from16 v29, v23

    move-object/from16 p3, v24

    move-object/from16 v10, v28

    move-object/from16 v6, v34

    move-object/from16 v17, p2

    move-object/from16 v23, v12

    move-object/from16 p2, v15

    move/from16 v12, v19

    move-object v15, v1

    move-object v1, v7

    move-object/from16 v7, v21

    .end local v0  # "candidates":Ljava/util/List;
    .end local v6  # "reachable":Lkotlin/jvm/internal/Ref$IntRef;
    .end local v15  # "this":Ldev/wiojelt/turksinema/common/DomainUpdateUi;
    .end local v18  # "$continuation":Lkotlin/coroutines/Continuation;
    .end local v19  # "$i$a$-forEach-DomainUpdateUi$update$2":I
    .end local v20  # "context":Landroid/content/Context;
    .end local v21  # "prefs":Landroid/content/SharedPreferences;
    .end local v24  # "$result":Ljava/lang/Object;
    .end local v28  # "dynamicCandidates":Ljava/util/List;
    .local v1, "changed":Lkotlin/jvm/internal/Ref$IntRef;
    .local v2, "reachable":Lkotlin/jvm/internal/Ref$IntRef;
    .local v3, "$continuation":Lkotlin/coroutines/Continuation;
    .local v4, "provider":Lcom/lagradost/cloudstream3/MainAPI;
    .local v7, "prefs":Landroid/content/SharedPreferences;
    .local v8, "baseName":Ljava/lang/String;
    .local v9, "candidates":Ljava/util/List;
    .local v10, "dynamicCandidates":Ljava/util/List;
    .local v11, "$i$f$forEach":I
    .local v12, "$i$a$-forEach-DomainUpdateUi$update$2":I
    .local v13, "tlds":Ljava/util/List;
    .local v17, "host":Ljava/lang/String;
    .local v23, "$this$forEach$iv":Ljava/lang/Iterable;
    .local v29, "providers":Ljava/util/List;
    .local v30, "context":Landroid/content/Context;
    .local p2, "this":Ldev/wiojelt/turksinema/common/DomainUpdateUi;
    .local p3, "$result":Ljava/lang/Object;
    :goto_48f
    invoke-interface {v15}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_67a

    invoke-interface {v15}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v18, v8

    .end local v8  # "baseName":Ljava/lang/String;
    .local v18, "baseName":Ljava/lang/String;
    move-object v8, v0

    check-cast v8, Ljava/lang/String;

    .line 161
    .local v8, "candidate":Ljava/lang/String;
    sget-object v0, Ldev/wiojelt/turksinema/common/DomainUpdateUi;->INSTANCE:Ldev/wiojelt/turksinema/common/DomainUpdateUi;

    :try_start_4a0
    sget-object v19, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    .line 179
    .local v0, "$this$update_u24lambda_u241_u244":Ldev/wiojelt/turksinema/common/DomainUpdateUi;
    const/16 v19, 0x0

    .line 161
    .local v19, "$i$a$-runCatching-DomainUpdateUi$update$2$response$1":I
    invoke-static {}, Lcom/lagradost/cloudstream3/MainActivityKt;->getApp()Lcom/lagradost/nicehttp/Requests;

    move-result-object v32

    move-object/from16 v20, v0

    .end local v0  # "$this$update_u24lambda_u241_u244":Ldev/wiojelt/turksinema/common/DomainUpdateUi;
    .local v20, "$this$update_u24lambda_u241_u244":Ldev/wiojelt/turksinema/common/DomainUpdateUi;
    invoke-static/range {v30 .. v30}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    iput-object v0, v3, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->L$0:Ljava/lang/Object;

    invoke-static/range {v29 .. v29}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    iput-object v0, v3, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->L$1:Ljava/lang/Object;

    iput-object v7, v3, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->L$2:Ljava/lang/Object;

    iput-object v5, v3, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->L$3:Ljava/lang/Object;

    iput-object v2, v3, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->L$4:Ljava/lang/Object;

    iput-object v1, v3, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->L$5:Ljava/lang/Object;

    iput-object v13, v3, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->L$6:Ljava/lang/Object;

    invoke-static/range {v23 .. v23}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    iput-object v0, v3, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->L$7:Ljava/lang/Object;

    iput-object v14, v3, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->L$8:Ljava/lang/Object;

    invoke-static/range {v16 .. v16}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    iput-object v0, v3, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->L$9:Ljava/lang/Object;

    iput-object v4, v3, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->L$10:Ljava/lang/Object;

    invoke-static/range {v18 .. v18}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    iput-object v0, v3, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->L$11:Ljava/lang/Object;

    invoke-static {v10}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    iput-object v0, v3, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->L$12:Ljava/lang/Object;

    invoke-static {v9}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    iput-object v0, v3, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->L$13:Ljava/lang/Object;

    invoke-static/range {v17 .. v17}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    iput-object v0, v3, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->L$14:Ljava/lang/Object;

    iput-object v15, v3, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->L$15:Ljava/lang/Object;

    iput-object v8, v3, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->L$16:Ljava/lang/Object;

    invoke-static/range {v20 .. v20}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    iput-object v0, v3, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->L$17:Ljava/lang/Object;
    :try_end_4f2
    .catchall {:try_start_4a0 .. :try_end_4f2} :catchall_5a1

    move-object/from16 v21, v1

    const/4 v1, 0x2

    .end local v1  # "changed":Lkotlin/jvm/internal/Ref$IntRef;
    .local v21, "changed":Lkotlin/jvm/internal/Ref$IntRef;
    :try_start_4f5
    iput v1, v3, Ldev/wiojelt/turksinema/common/DomainUpdateUi$update$1;->label:I
    :try_end_4f7
    .catchall {:try_start_4f5 .. :try_end_4f7} :catchall_57f

    const/16 v34, 0x0

    const/16 v35, 0x0

    const/16 v36, 0x0

    const/16 v37, 0x0

    const/16 v38, 0x0

    const/16 v39, 0x0

    const/16 v40, 0x0

    const-wide/16 v41, 0x5

    const/16 v43, 0x0

    const/16 v44, 0x0

    const/16 v45, 0x0

    const/16 v47, 0xefe

    const/16 v48, 0x0

    move-object/from16 v46, v3

    move-object/from16 v33, v8

    .end local v3  # "$continuation":Lkotlin/coroutines/Continuation;
    .end local v8  # "candidate":Ljava/lang/String;
    .local v33, "candidate":Ljava/lang/String;
    .local v46, "$continuation":Lkotlin/coroutines/Continuation;
    :try_start_515
    invoke-static/range {v32 .. v48}, Lcom/lagradost/nicehttp/Requests;->get$default(Lcom/lagradost/nicehttp/Requests;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;ZILjava/util/concurrent/TimeUnit;JLokhttp3/Interceptor;ZLcom/lagradost/nicehttp/ResponseParser;Lkotlin/coroutines/Continuation;ILjava/lang/Object;)Ljava/lang/Object;

    move-result-object v0
    :try_end_519
    .catchall {:try_start_515 .. :try_end_519} :catchall_561

    if-ne v0, v6, :cond_51c

    .line 127
    return-object v6

    .line 161
    :cond_51c
    move-object/from16 v3, p2

    move-object/from16 v28, v7

    move-object/from16 v24, v13

    move-object/from16 v8, v18

    move-object/from16 v13, v20

    move-object/from16 v25, v21

    move-object/from16 v21, v4

    move-object/from16 v20, v5

    move-object v7, v6

    move-object/from16 v18, v14

    move-object/from16 v14, v33

    move-object/from16 v4, v46

    move-object/from16 v6, p3

    move-object v5, v0

    move/from16 v0, v19

    move-object/from16 v19, v2

    move-object/from16 v2, p1

    .end local v5  # "directory":Lorg/json/JSONObject;
    .end local v7  # "prefs":Landroid/content/SharedPreferences;
    .end local v18  # "baseName":Ljava/lang/String;
    .end local v33  # "candidate":Ljava/lang/String;
    .end local v46  # "$continuation":Lkotlin/coroutines/Continuation;
    .end local p1  # "$completion":Lkotlin/coroutines/Continuation;
    .end local p2  # "this":Ldev/wiojelt/turksinema/common/DomainUpdateUi;
    .end local p3  # "$result":Ljava/lang/Object;
    .local v0, "$i$a$-runCatching-DomainUpdateUi$update$2$response$1":I
    .local v2, "$completion":Lkotlin/coroutines/Continuation;
    .local v3, "this":Ldev/wiojelt/turksinema/common/DomainUpdateUi;
    .local v4, "$continuation":Lkotlin/coroutines/Continuation;
    .local v6, "$result":Ljava/lang/Object;
    .local v8, "baseName":Ljava/lang/String;
    .local v13, "$this$update_u24lambda_u241_u244":Ldev/wiojelt/turksinema/common/DomainUpdateUi;
    .local v14, "candidate":Ljava/lang/String;
    .local v19, "reachable":Lkotlin/jvm/internal/Ref$IntRef;
    .local v20, "directory":Lorg/json/JSONObject;
    .local v21, "provider":Lcom/lagradost/cloudstream3/MainAPI;
    .local v24, "tlds":Ljava/util/List;
    .restart local v25  # "changed":Lkotlin/jvm/internal/Ref$IntRef;
    .local v28, "prefs":Landroid/content/SharedPreferences;
    :goto_53c
    :try_start_53c
    check-cast v5, Lcom/lagradost/nicehttp/NiceResponse;

    .end local v0  # "$i$a$-runCatching-DomainUpdateUi$update$2$response$1":I
    .end local v13  # "$this$update_u24lambda_u241_u244":Ldev/wiojelt/turksinema/common/DomainUpdateUi;
    invoke-static {v5}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0
    :try_end_542
    .catchall {:try_start_53c .. :try_end_542} :catchall_55a

    move-object v5, v6

    move v13, v11

    move-object v6, v4

    move-object v11, v9

    move-object/from16 v4, v19

    move-object v9, v8

    move-object/from16 v19, v17

    move-object v8, v7

    move-object/from16 v17, v16

    move-object/from16 v7, v21

    move-object/from16 v16, v15

    move-object v15, v14

    move v14, v12

    move-object v12, v10

    move-object v10, v0

    move-object/from16 v0, v25

    goto/16 :goto_5e4

    :catchall_55a
    move-exception v0

    move-object v5, v6

    move-object v6, v7

    move-object/from16 v7, v17

    goto/16 :goto_5c5

    .end local v3  # "this":Ldev/wiojelt/turksinema/common/DomainUpdateUi;
    .end local v6  # "$result":Ljava/lang/Object;
    .end local v8  # "baseName":Ljava/lang/String;
    .end local v14  # "candidate":Ljava/lang/String;
    .end local v19  # "reachable":Lkotlin/jvm/internal/Ref$IntRef;
    .end local v20  # "directory":Lorg/json/JSONObject;
    .end local v24  # "tlds":Ljava/util/List;
    .end local v25  # "changed":Lkotlin/jvm/internal/Ref$IntRef;
    .end local v28  # "prefs":Landroid/content/SharedPreferences;
    .local v2, "reachable":Lkotlin/jvm/internal/Ref$IntRef;
    .local v4, "provider":Lcom/lagradost/cloudstream3/MainAPI;
    .restart local v5  # "directory":Lorg/json/JSONObject;
    .restart local v7  # "prefs":Landroid/content/SharedPreferences;
    .local v13, "tlds":Ljava/util/List;
    .restart local v18  # "baseName":Ljava/lang/String;
    .local v21, "changed":Lkotlin/jvm/internal/Ref$IntRef;
    .restart local v33  # "candidate":Ljava/lang/String;
    .restart local v46  # "$continuation":Lkotlin/coroutines/Continuation;
    .restart local p1  # "$completion":Lkotlin/coroutines/Continuation;
    .restart local p2  # "this":Ldev/wiojelt/turksinema/common/DomainUpdateUi;
    .restart local p3  # "$result":Ljava/lang/Object;
    :catchall_561
    move-exception v0

    move-object/from16 v3, p2

    move-object/from16 v19, v2

    move-object/from16 v20, v5

    move-object/from16 v28, v7

    move-object/from16 v24, v13

    move-object/from16 v7, v17

    move-object/from16 v8, v18

    move-object/from16 v25, v21

    move-object/from16 v2, p1

    move-object/from16 v5, p3

    move-object/from16 v21, v4

    move-object/from16 v18, v14

    move-object/from16 v14, v33

    move-object/from16 v4, v46

    goto :goto_5c5

    .end local v33  # "candidate":Ljava/lang/String;
    .end local v46  # "$continuation":Lkotlin/coroutines/Continuation;
    .local v3, "$continuation":Lkotlin/coroutines/Continuation;
    .local v8, "candidate":Ljava/lang/String;
    :catchall_57f
    move-exception v0

    move-object/from16 v46, v3

    move-object/from16 v33, v8

    move-object/from16 v3, p2

    move-object/from16 v19, v2

    move-object/from16 v20, v5

    move-object/from16 v28, v7

    move-object/from16 v24, v13

    move-object/from16 v7, v17

    move-object/from16 v8, v18

    move-object/from16 v25, v21

    move-object/from16 v2, p1

    move-object/from16 v5, p3

    move-object/from16 v21, v4

    move-object/from16 v18, v14

    move-object/from16 v14, v33

    move-object/from16 v4, v46

    .end local v3  # "$continuation":Lkotlin/coroutines/Continuation;
    .end local v8  # "candidate":Ljava/lang/String;
    .restart local v33  # "candidate":Ljava/lang/String;
    .restart local v46  # "$continuation":Lkotlin/coroutines/Continuation;
    goto :goto_5c5

    .end local v21  # "changed":Lkotlin/jvm/internal/Ref$IntRef;
    .end local v33  # "candidate":Ljava/lang/String;
    .end local v46  # "$continuation":Lkotlin/coroutines/Continuation;
    .restart local v1  # "changed":Lkotlin/jvm/internal/Ref$IntRef;
    .restart local v3  # "$continuation":Lkotlin/coroutines/Continuation;
    .restart local v8  # "candidate":Ljava/lang/String;
    :catchall_5a1
    move-exception v0

    move-object/from16 v21, v1

    move-object/from16 v46, v3

    move-object/from16 v33, v8

    const/4 v1, 0x2

    move-object/from16 v3, p2

    move-object/from16 v19, v2

    move-object/from16 v20, v5

    move-object/from16 v28, v7

    move-object/from16 v24, v13

    move-object/from16 v7, v17

    move-object/from16 v8, v18

    move-object/from16 v25, v21

    move-object/from16 v2, p1

    move-object/from16 v5, p3

    move-object/from16 v21, v4

    move-object/from16 v18, v14

    move-object/from16 v14, v33

    move-object/from16 v4, v46

    .end local v1  # "changed":Lkotlin/jvm/internal/Ref$IntRef;
    .end local v13  # "tlds":Ljava/util/List;
    .end local v17  # "host":Ljava/lang/String;
    .end local v18  # "baseName":Ljava/lang/String;
    .end local p1  # "$completion":Lkotlin/coroutines/Continuation;
    .end local p2  # "this":Ldev/wiojelt/turksinema/common/DomainUpdateUi;
    .end local p3  # "$result":Ljava/lang/Object;
    .local v2, "$completion":Lkotlin/coroutines/Continuation;
    .local v3, "this":Ldev/wiojelt/turksinema/common/DomainUpdateUi;
    .local v4, "$continuation":Lkotlin/coroutines/Continuation;
    .local v5, "$result":Ljava/lang/Object;
    .local v7, "host":Ljava/lang/String;
    .local v8, "baseName":Ljava/lang/String;
    .restart local v14  # "candidate":Ljava/lang/String;
    .restart local v19  # "reachable":Lkotlin/jvm/internal/Ref$IntRef;
    .restart local v20  # "directory":Lorg/json/JSONObject;
    .local v21, "provider":Lcom/lagradost/cloudstream3/MainAPI;
    .restart local v24  # "tlds":Ljava/util/List;
    .restart local v25  # "changed":Lkotlin/jvm/internal/Ref$IntRef;
    .restart local v28  # "prefs":Landroid/content/SharedPreferences;
    :goto_5c5
    sget-object v13, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v0}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    move v13, v11

    move-object v11, v9

    move-object v9, v8

    move-object v8, v6

    move-object v6, v4

    move-object/from16 v4, v19

    move-object/from16 v19, v7

    move-object/from16 v17, v16

    move-object/from16 v16, v15

    move-object v15, v14

    move v14, v12

    move-object v12, v10

    move-object v10, v0

    move-object/from16 v7, v21

    move-object/from16 v0, v25

    .end local v8  # "baseName":Ljava/lang/String;
    .end local v10  # "dynamicCandidates":Ljava/util/List;
    .end local v16  # "element$iv":Ljava/lang/Object;
    .end local v21  # "provider":Lcom/lagradost/cloudstream3/MainAPI;
    .end local v25  # "changed":Lkotlin/jvm/internal/Ref$IntRef;
    .local v0, "changed":Lkotlin/jvm/internal/Ref$IntRef;
    .local v4, "reachable":Lkotlin/jvm/internal/Ref$IntRef;
    .local v6, "$continuation":Lkotlin/coroutines/Continuation;
    .local v7, "provider":Lcom/lagradost/cloudstream3/MainAPI;
    .local v9, "baseName":Ljava/lang/String;
    .local v11, "candidates":Ljava/util/List;
    .local v12, "dynamicCandidates":Ljava/util/List;
    .local v13, "$i$f$forEach":I
    .local v14, "$i$a$-forEach-DomainUpdateUi$update$2":I
    .local v15, "candidate":Ljava/lang/String;
    .local v17, "element$iv":Ljava/lang/Object;
    .local v19, "host":Ljava/lang/String;
    :goto_5e4
    invoke-static {v10}, Lkotlin/Result;->isFailure-impl(Ljava/lang/Object;)Z

    move-result v21

    if-eqz v21, :cond_5eb

    const/4 v10, 0x0

    :cond_5eb
    check-cast v10, Lcom/lagradost/nicehttp/NiceResponse;

    if-nez v10, :cond_5f5

    move-object/from16 v21, v0

    move-object/from16 p1, v2

    goto/16 :goto_65b

    .line 162
    .local v10, "response":Lcom/lagradost/nicehttp/NiceResponse;
    :cond_5f5
    invoke-virtual {v10}, Lcom/lagradost/nicehttp/NiceResponse;->getCode()I

    move-result v1

    move-object/from16 p1, v2

    .end local v2  # "$completion":Lkotlin/coroutines/Continuation;
    .restart local p1  # "$completion":Lkotlin/coroutines/Continuation;
    const/16 v2, 0xc8

    if-gt v2, v1, :cond_606

    const/16 v2, 0x190

    if-ge v1, v2, :cond_606

    move/from16 v1, v31

    goto :goto_607

    :cond_606
    const/4 v1, 0x0

    :goto_607
    if-eqz v1, :cond_659

    .line 163
    sget-object v1, Ldev/wiojelt/turksinema/common/DomainUpdateUi;->INSTANCE:Ldev/wiojelt/turksinema/common/DomainUpdateUi;

    invoke-virtual {v10}, Lcom/lagradost/nicehttp/NiceResponse;->getUrl()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ldev/wiojelt/turksinema/common/DomainUpdateUi;->origin(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    if-nez v1, :cond_616

    move-object v1, v15

    .line 164
    .local v1, "resolved":Ljava/lang/String;
    :cond_616
    iget v2, v4, Lkotlin/jvm/internal/Ref$IntRef;->element:I

    add-int/lit8 v2, v2, 0x1

    iput v2, v4, Lkotlin/jvm/internal/Ref$IntRef;->element:I

    .line 165
    invoke-virtual {v7}, Lcom/lagradost/cloudstream3/MainAPI;->getMainUrl()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_62f

    .line 166
    invoke-virtual {v7, v1}, Lcom/lagradost/cloudstream3/MainAPI;->setMainUrl(Ljava/lang/String;)V

    .line 167
    iget v2, v0, Lkotlin/jvm/internal/Ref$IntRef;->element:I

    add-int/lit8 v2, v2, 0x1

    iput v2, v0, Lkotlin/jvm/internal/Ref$IntRef;->element:I

    .line 169
    :cond_62f
    invoke-interface/range {v28 .. v28}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    move-object/from16 v21, v0

    .end local v0  # "changed":Lkotlin/jvm/internal/Ref$IntRef;
    .local v21, "changed":Lkotlin/jvm/internal/Ref$IntRef;
    invoke-virtual {v7}, Lcom/lagradost/cloudstream3/MainAPI;->getName()Ljava/lang/String;

    move-result-object v0

    invoke-interface {v2, v0, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 170
    move-object v15, v3

    move-object v0, v8

    move-object v8, v9

    move-object v9, v11

    move-object v10, v12

    move v12, v14

    move-object/from16 v16, v17

    move-object/from16 v14, v18

    move-object/from16 v11, v24

    move-object/from16 v24, v5

    move-object/from16 v18, v6

    move-object/from16 v5, v20

    move-object v6, v4

    move-object v4, v7

    move-object/from16 v7, v19

    move-object/from16 v1, p1

    goto :goto_691

    .line 162
    .end local v1  # "resolved":Ljava/lang/String;
    .end local v21  # "changed":Lkotlin/jvm/internal/Ref$IntRef;
    .restart local v0  # "changed":Lkotlin/jvm/internal/Ref$IntRef;
    :cond_659
    move-object/from16 v21, v0

    .line 160
    .end local v10  # "response":Lcom/lagradost/nicehttp/NiceResponse;
    .end local v15  # "candidate":Ljava/lang/String;
    .end local p1  # "$completion":Lkotlin/coroutines/Continuation;
    .restart local v2  # "$completion":Lkotlin/coroutines/Continuation;
    :goto_65b
    move-object/from16 p2, v3

    move-object v2, v4

    move-object/from16 p3, v5

    move-object v3, v6

    move-object v4, v7

    move-object v6, v8

    move-object v8, v9

    move-object v9, v11

    move-object v10, v12

    move v11, v13

    move v12, v14

    move-object/from16 v15, v16

    move-object/from16 v16, v17

    move-object/from16 v14, v18

    move-object/from16 v17, v19

    move-object/from16 v5, v20

    move-object/from16 v1, v21

    move-object/from16 v13, v24

    move-object/from16 v7, v28

    .end local v0  # "changed":Lkotlin/jvm/internal/Ref$IntRef;
    .end local v2  # "$completion":Lkotlin/coroutines/Continuation;
    .restart local v21  # "changed":Lkotlin/jvm/internal/Ref$IntRef;
    .restart local p1  # "$completion":Lkotlin/coroutines/Continuation;
    goto/16 :goto_48f

    .end local v6  # "$continuation":Lkotlin/coroutines/Continuation;
    .end local v14  # "$i$a$-forEach-DomainUpdateUi$update$2":I
    .end local v19  # "host":Ljava/lang/String;
    .end local v20  # "directory":Lorg/json/JSONObject;
    .end local v21  # "changed":Lkotlin/jvm/internal/Ref$IntRef;
    .end local v24  # "tlds":Ljava/util/List;
    .end local v28  # "prefs":Landroid/content/SharedPreferences;
    .local v1, "changed":Lkotlin/jvm/internal/Ref$IntRef;
    .local v2, "reachable":Lkotlin/jvm/internal/Ref$IntRef;
    .local v3, "$continuation":Lkotlin/coroutines/Continuation;
    .local v4, "provider":Lcom/lagradost/cloudstream3/MainAPI;
    .local v5, "directory":Lorg/json/JSONObject;
    .local v7, "prefs":Landroid/content/SharedPreferences;
    .restart local v8  # "baseName":Ljava/lang/String;
    .local v9, "candidates":Ljava/util/List;
    .local v10, "dynamicCandidates":Ljava/util/List;
    .local v11, "$i$f$forEach":I
    .local v12, "$i$a$-forEach-DomainUpdateUi$update$2":I
    .local v13, "tlds":Ljava/util/List;
    .restart local v16  # "element$iv":Ljava/lang/Object;
    .local v17, "host":Ljava/lang/String;
    .restart local p2  # "this":Ldev/wiojelt/turksinema/common/DomainUpdateUi;
    .restart local p3  # "$result":Ljava/lang/Object;
    :cond_67a
    move-object/from16 v21, v1

    move-object/from16 v46, v3

    move-object/from16 v18, v8

    .end local v1  # "changed":Lkotlin/jvm/internal/Ref$IntRef;
    .end local v3  # "$continuation":Lkotlin/coroutines/Continuation;
    .end local v8  # "baseName":Ljava/lang/String;
    .restart local v18  # "baseName":Ljava/lang/String;
    .restart local v21  # "changed":Lkotlin/jvm/internal/Ref$IntRef;
    .restart local v46  # "$continuation":Lkotlin/coroutines/Continuation;
    move-object v0, v13

    move v13, v11

    move-object v11, v0

    move-object/from16 v15, p2

    move-object/from16 v24, p3

    move-object v0, v6

    move-object/from16 v28, v7

    move-object/from16 v7, v17

    move-object/from16 v18, v46

    move-object v6, v2

    move-object/from16 v1, p1

    .line 173
    .end local v2  # "reachable":Lkotlin/jvm/internal/Ref$IntRef;
    .end local v17  # "host":Ljava/lang/String;
    .end local v46  # "$continuation":Lkotlin/coroutines/Continuation;
    .end local p1  # "$completion":Lkotlin/coroutines/Continuation;
    .end local p2  # "this":Ldev/wiojelt/turksinema/common/DomainUpdateUi;
    .end local p3  # "$result":Ljava/lang/Object;
    .local v1, "$completion":Lkotlin/coroutines/Continuation;
    .local v6, "reachable":Lkotlin/jvm/internal/Ref$IntRef;
    .local v7, "host":Ljava/lang/String;
    .restart local v8  # "baseName":Ljava/lang/String;
    .local v11, "tlds":Ljava/util/List;
    .local v13, "$i$f$forEach":I
    .local v15, "this":Ldev/wiojelt/turksinema/common/DomainUpdateUi;
    .local v18, "$continuation":Lkotlin/coroutines/Continuation;
    .local v24, "$result":Ljava/lang/Object;
    .restart local v28  # "prefs":Landroid/content/SharedPreferences;
    :goto_691
    nop

    .line 185
    .end local v4  # "provider":Lcom/lagradost/cloudstream3/MainAPI;
    .end local v7  # "host":Ljava/lang/String;
    .end local v8  # "baseName":Ljava/lang/String;
    .end local v9  # "candidates":Ljava/util/List;
    .end local v10  # "dynamicCandidates":Ljava/util/List;
    .end local v12  # "$i$a$-forEach-DomainUpdateUi$update$2":I
    .end local v16  # "element$iv":Ljava/lang/Object;
    move-object v8, v0

    move-object/from16 v7, v21

    move-object/from16 v12, v23

    move-object/from16 v9, v28

    move-object/from16 v10, v29

    move-object/from16 v4, v30

    const/4 v2, 0x0

    const/4 v3, 0x2

    goto/16 :goto_1f3

    .line 214
    .end local v21  # "changed":Lkotlin/jvm/internal/Ref$IntRef;
    .end local v23  # "$this$forEach$iv":Ljava/lang/Iterable;
    .end local v28  # "prefs":Landroid/content/SharedPreferences;
    .end local v29  # "providers":Ljava/util/List;
    .end local v30  # "context":Landroid/content/Context;
    .local v4, "context":Landroid/content/Context;
    .local v7, "changed":Lkotlin/jvm/internal/Ref$IntRef;
    .local v9, "prefs":Landroid/content/SharedPreferences;
    .local v10, "providers":Ljava/util/List;
    .local v12, "$this$forEach$iv":Ljava/lang/Iterable;
    :cond_6a1
    move-object/from16 p1, v1

    .line 174
    .end local v1  # "$completion":Lkotlin/coroutines/Continuation;
    .end local v12  # "$this$forEach$iv":Ljava/lang/Iterable;
    .end local v13  # "$i$f$forEach":I
    .restart local p1  # "$completion":Lkotlin/coroutines/Continuation;
    iget v0, v6, Lkotlin/jvm/internal/Ref$IntRef;->element:I

    invoke-static {v0}, Lkotlin/coroutines/jvm/internal/Boxing;->boxInt(I)Ljava/lang/Integer;

    move-result-object v0

    iget v1, v7, Lkotlin/jvm/internal/Ref$IntRef;->element:I

    invoke-static {v1}, Lkotlin/coroutines/jvm/internal/Boxing;->boxInt(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-static {v0, v1}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v0

    return-object v0

    :pswitch_data_6b4
    .packed-switch 0x0
        :pswitch_ea  #00000000
        :pswitch_be  #00000001
        :pswitch_33  #00000002
    .end packed-switch
.end method

.method private final validOrigin(Ljava/lang/String;)Z
    .registers 8
    .param p1, "value"  # Ljava/lang/String;

    .line 37
    const/4 v0, 0x0

    :try_start_1
    sget-object v1, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v1, p0

    check-cast v1, Ldev/wiojelt/turksinema/common/DomainUpdateUi;

    .local v1, "$this$validOrigin_u24lambda_u240":Ldev/wiojelt/turksinema/common/DomainUpdateUi;
    const/4 v2, 0x0

    .line 38
    .local v2, "$i$a$-runCatching-DomainUpdateUi$validOrigin$1":I
    new-instance v3, Ljava/net/URI;

    move-object v4, p1

    check-cast v4, Ljava/lang/CharSequence;

    invoke-static {v4}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v3, v4}, Ljava/net/URI;-><init>(Ljava/lang/String;)V

    .line 39
    .local v3, "uri":Ljava/net/URI;
    invoke-virtual {v3}, Ljava/net/URI;->getScheme()Ljava/lang/String;

    move-result-object v4

    const-string v5, "https"

    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_2f

    invoke-virtual {v3}, Ljava/net/URI;->getScheme()Ljava/lang/String;

    move-result-object v4

    const-string v5, "http"

    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_45

    :cond_2f
    invoke-virtual {v3}, Ljava/net/URI;->getHost()Ljava/lang/String;

    move-result-object v4

    check-cast v4, Ljava/lang/CharSequence;

    const/4 v5, 0x1

    if-eqz v4, :cond_41

    invoke-static {v4}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_3f

    goto :goto_41

    :cond_3f
    move v4, v0

    goto :goto_42

    :cond_41
    :goto_41
    move v4, v5

    :goto_42
    if-nez v4, :cond_45

    goto :goto_46

    :cond_45
    move v5, v0

    .end local v1  # "$this$validOrigin_u24lambda_u240":Ldev/wiojelt/turksinema/common/DomainUpdateUi;
    .end local v2  # "$i$a$-runCatching-DomainUpdateUi$validOrigin$1":I
    .end local v3  # "uri":Ljava/net/URI;
    :goto_46
    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    .line 37
    invoke-static {v1}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1
    :try_end_4e
    .catchall {:try_start_1 .. :try_end_4e} :catchall_4f

    goto :goto_5a

    :catchall_4f
    move-exception v1

    sget-object v2, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v1}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v1

    invoke-static {v1}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    .line 40
    :goto_5a
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    invoke-static {v1}, Lkotlin/Result;->isFailure-impl(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_65

    move-object v1, v0

    :cond_65
    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    return v0
.end method


# virtual methods
.method public final attach(Lcom/lagradost/cloudstream3/plugins/Plugin;Landroid/content/Context;Ljava/util/List;)V
    .registers 16
    .param p1, "plugin"  # Lcom/lagradost/cloudstream3/plugins/Plugin;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p2, "context"  # Landroid/content/Context;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p3, "providers"  # Ljava/util/List;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/lagradost/cloudstream3/plugins/Plugin;",
            "Landroid/content/Context;",
            "Ljava/util/List<",
            "+",
            "Lcom/lagradost/cloudstream3/MainAPI;",
            ">;)V"
        }
    .end annotation

    .line 30
    const-string v0, "turksinema_domains"

    const/4 v1, 0x0

    invoke-virtual {p2, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    .line 31
    .local v0, "prefs":Landroid/content/SharedPreferences;
    move-object v1, p3

    check-cast v1, Ljava/lang/Iterable;

    .local v1, "$this$forEach$iv":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 178
    .local v2, "$i$f$forEach":I
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_f
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_3c

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    .local v4, "element$iv":Ljava/lang/Object;
    move-object v5, v4

    check-cast v5, Lcom/lagradost/cloudstream3/MainAPI;

    .local v5, "provider":Lcom/lagradost/cloudstream3/MainAPI;
    const/4 v6, 0x0

    .line 32
    .local v6, "$i$a$-forEach-DomainUpdateUi$attach$1":I
    invoke-virtual {v5}, Lcom/lagradost/cloudstream3/MainAPI;->getName()Ljava/lang/String;

    move-result-object v7

    const/4 v8, 0x0

    invoke-interface {v0, v7, v8}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    if-eqz v7, :cond_39

    sget-object v9, Ldev/wiojelt/turksinema/common/DomainUpdateUi;->INSTANCE:Ldev/wiojelt/turksinema/common/DomainUpdateUi;

    move-object v10, v7

    .line 179
    .local v10, "p0":Ljava/lang/String;
    const/4 v11, 0x0

    .line 32
    .local v11, "$i$a$-takeIf-DomainUpdateUi$attach$1$1":I
    invoke-direct {v9, v10}, Ldev/wiojelt/turksinema/common/DomainUpdateUi;->validOrigin(Ljava/lang/String;)Z

    move-result v9

    .end local v10  # "p0":Ljava/lang/String;
    .end local v11  # "$i$a$-takeIf-DomainUpdateUi$attach$1$1":I
    if-eqz v9, :cond_33

    move-object v8, v7

    :cond_33
    if-eqz v8, :cond_39

    .line 179
    .local v8, "it":Ljava/lang/String;
    const/4 v7, 0x0

    .line 32
    .local v7, "$i$a$-let-DomainUpdateUi$attach$1$2":I
    invoke-virtual {v5, v8}, Lcom/lagradost/cloudstream3/MainAPI;->setMainUrl(Ljava/lang/String;)V

    .line 33
    .end local v7  # "$i$a$-let-DomainUpdateUi$attach$1$2":I
    .end local v8  # "it":Ljava/lang/String;
    :cond_39
    nop

    .line 178
    .end local v5  # "provider":Lcom/lagradost/cloudstream3/MainAPI;
    .end local v6  # "$i$a$-forEach-DomainUpdateUi$attach$1":I
    nop

    .end local v4  # "element$iv":Ljava/lang/Object;
    goto :goto_f

    .line 180
    :cond_3c
    nop

    .line 34
    .end local v1  # "$this$forEach$iv":Ljava/lang/Iterable;
    .end local v2  # "$i$f$forEach":I
    new-instance v1, Ldev/wiojelt/turksinema/common/DomainUpdateUi$$ExternalSyntheticLambda0;

    invoke-direct {v1, p3}, Ldev/wiojelt/turksinema/common/DomainUpdateUi$$ExternalSyntheticLambda0;-><init>(Ljava/util/List;)V

    invoke-virtual {p1, v1}, Lcom/lagradost/cloudstream3/plugins/Plugin;->setOpenSettings(Lkotlin/jvm/functions/Function1;)V

    .line 35
    return-void
.end method

.method public final show(Landroid/content/Context;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 76
    .param p1, "context"  # Landroid/content/Context;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p2, "providers"  # Ljava/util/List;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p3, "brandPrefix"  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/Nullable;
        .end annotation
    .end param
    .param p4, "brandSuffix"  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/Nullable;
        .end annotation
    .end param
    .param p5, "brandTitleTag"  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/Nullable;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/List<",
            "+",
            "Lcom/lagradost/cloudstream3/MainAPI;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 54
    move-object/from16 v0, p1

    move-object/from16 v1, p2

    const-string v2, "turksinema_domains"

    const/4 v3, 0x0

    invoke-virtual {v0, v2, v3}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v2

    .line 55
    .local v2, "prefs":Landroid/content/SharedPreferences;
    const-string v4, "turksinema_disabled_providers"

    invoke-virtual {v0, v4, v3}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v4

    .line 57
    .local v4, "disabledPrefs":Landroid/content/SharedPreferences;
    move-object v5, v1

    check-cast v5, Ljava/lang/Iterable;

    .local v5, "$this$map$iv":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 181
    .local v6, "$i$f$map":I
    new-instance v7, Ljava/util/ArrayList;

    const/16 v8, 0xa

    invoke-static {v5, v8}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v8

    invoke-direct {v7, v8}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v7, Ljava/util/Collection;

    .local v7, "destination$iv$iv":Ljava/util/Collection;
    move-object v8, v5

    .local v8, "$this$mapTo$iv$iv":Ljava/lang/Iterable;
    const/4 v9, 0x0

    .line 182
    .local v9, "$i$f$mapTo":I
    invoke-interface {v8}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v10

    :goto_28
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_72

    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    .line 183
    .local v11, "item$iv$iv":Ljava/lang/Object;
    move-object v13, v11

    check-cast v13, Lcom/lagradost/cloudstream3/MainAPI;

    .local v13, "provider":Lcom/lagradost/cloudstream3/MainAPI;
    const/4 v14, 0x0

    .line 58
    .local v14, "$i$a$-map-DomainUpdateUi$show$items$1":I
    new-instance v15, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;

    .line 59
    invoke-virtual {v13}, Lcom/lagradost/cloudstream3/MainAPI;->getName()Ljava/lang/String;

    move-result-object v16

    .line 60
    invoke-virtual {v13}, Lcom/lagradost/cloudstream3/MainAPI;->getName()Ljava/lang/String;

    move-result-object v17

    .line 58
    nop

    .line 61
    invoke-virtual {v13}, Lcom/lagradost/cloudstream3/MainAPI;->getMainUrl()Ljava/lang/String;

    move-result-object v19

    .line 62
    const/16 v18, 0x1

    invoke-virtual {v13}, Lcom/lagradost/cloudstream3/MainAPI;->getName()Ljava/lang/String;

    move-result-object v12

    invoke-interface {v4, v12, v3}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v12

    .line 58
    xor-int/lit8 v20, v12, 0x1

    .line 63
    new-instance v12, Ldev/wiojelt/turksinema/common/DomainUpdateUi$$ExternalSyntheticLambda1;

    invoke-direct {v12, v4, v13, v0}, Ldev/wiojelt/turksinema/common/DomainUpdateUi$$ExternalSyntheticLambda1;-><init>(Landroid/content/SharedPreferences;Lcom/lagradost/cloudstream3/MainAPI;Landroid/content/Context;)V

    .line 67
    new-instance v3, Ldev/wiojelt/turksinema/common/DomainUpdateUi$$ExternalSyntheticLambda2;

    invoke-direct {v3, v13, v2}, Ldev/wiojelt/turksinema/common/DomainUpdateUi$$ExternalSyntheticLambda2;-><init>(Lcom/lagradost/cloudstream3/MainAPI;Landroid/content/SharedPreferences;)V

    .line 58
    const/16 v25, 0x64

    const/16 v26, 0x0

    const/16 v18, 0x0

    const/16 v21, 0x0

    const/16 v22, 0x0

    move-object/from16 v24, v3

    move-object/from16 v23, v12

    invoke-direct/range {v15 .. v26}, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;-><init>(Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;ZZLjava/lang/String;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 71
    nop

    .line 183
    .end local v13  # "provider":Lcom/lagradost/cloudstream3/MainAPI;
    .end local v14  # "$i$a$-map-DomainUpdateUi$show$items$1":I
    invoke-interface {v7, v15}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x0

    goto :goto_28

    .line 184
    .end local v11  # "item$iv$iv":Ljava/lang/Object;
    :cond_72
    const/16 v18, 0x1

    .end local v7  # "destination$iv$iv":Ljava/util/Collection;
    .end local v8  # "$this$mapTo$iv$iv":Ljava/lang/Iterable;
    .end local v9  # "$i$f$mapTo":I
    move-object v3, v7

    check-cast v3, Ljava/util/List;

    .line 181
    nop

    .line 57
    .end local v5  # "$this$map$iv":Ljava/lang/Iterable;
    .end local v6  # "$i$f$map":I
    nop

    .line 74
    .local v3, "items":Ljava/util/List;
    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v5

    move/from16 v6, v18

    if-ne v5, v6, :cond_84

    const/16 v27, 0x1

    goto :goto_86

    :cond_84
    const/16 v27, 0x0

    .line 75
    .local v27, "isSingle":Z
    :goto_86
    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->firstOrNull(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/lagradost/cloudstream3/MainAPI;

    if-eqz v5, :cond_94

    invoke-virtual {v5}, Lcom/lagradost/cloudstream3/MainAPI;->getName()Ljava/lang/String;

    move-result-object v5

    if-nez v5, :cond_96

    :cond_94
    const-string v5, "TurkSinema"

    .line 77
    .local v5, "pName":Ljava/lang/String;
    :cond_96
    new-instance v28, Ldev/wiojelt/turksinema/common/WioSettingsConfig;

    .line 78
    if-nez p3, :cond_a4

    if-eqz v27, :cond_9f

    move-object/from16 v29, v5

    goto :goto_a6

    :cond_9f
    const-string v6, "TURK"

    move-object/from16 v29, v6

    goto :goto_a6

    :cond_a4
    move-object/from16 v29, p3

    .line 79
    :goto_a6
    if-nez p4, :cond_b2

    if-eqz v27, :cond_ad

    const-string v6, ""

    goto :goto_af

    :cond_ad
    const-string v6, "SİNEMA"

    :goto_af
    move-object/from16 v30, v6

    goto :goto_b4

    :cond_b2
    move-object/from16 v30, p4

    .line 80
    :goto_b4
    if-nez p5, :cond_c0

    if-eqz v27, :cond_bb

    const-string v6, "Alan Adı & Ayarlar"

    goto :goto_bd

    :cond_bb
    const-string v6, "Alan Adı Yönetimi"

    :goto_bd
    move-object/from16 v31, v6

    goto :goto_c2

    :cond_c0
    move-object/from16 v31, p5

    .line 81
    :goto_c2
    if-eqz v27, :cond_c7

    const-string v6, "Adres değiştiğinde \'Düzenle ✎\' ile güncelleyebilir veya otomatik tarama yapabilirsiniz."

    goto :goto_c9

    :cond_c7
    const-string v6, "Tüm kaynaklar tek merkezde · Adres değiştiğinde \'Düzenle ✎\' ile güncelleyin"

    :goto_c9
    move-object/from16 v32, v6

    .line 77
    nop

    .line 82
    nop

    .line 77
    nop

    .line 83
    nop

    .line 77
    nop

    .line 84
    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v6

    const/4 v7, 0x0

    const/4 v8, 0x1

    if-le v6, v8, :cond_e0

    .line 85
    new-instance v6, Ldev/wiojelt/turksinema/common/DomainUpdateUi$$ExternalSyntheticLambda3;

    invoke-direct {v6, v1, v3, v0, v4}, Ldev/wiojelt/turksinema/common/DomainUpdateUi$$ExternalSyntheticLambda3;-><init>(Ljava/util/List;Ljava/util/List;Landroid/content/Context;Landroid/content/SharedPreferences;)V

    move-object/from16 v56, v6

    goto :goto_e2

    .line 90
    :cond_e0
    move-object/from16 v56, v7

    .line 77
    :goto_e2
    nop

    .line 91
    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v6

    if-le v6, v8, :cond_f1

    .line 92
    new-instance v6, Ldev/wiojelt/turksinema/common/DomainUpdateUi$$ExternalSyntheticLambda4;

    invoke-direct {v6, v1, v3, v0, v4}, Ldev/wiojelt/turksinema/common/DomainUpdateUi$$ExternalSyntheticLambda4;-><init>(Ljava/util/List;Ljava/util/List;Landroid/content/Context;Landroid/content/SharedPreferences;)V

    move-object/from16 v58, v6

    goto :goto_f3

    .line 97
    :cond_f1
    move-object/from16 v58, v7

    .line 77
    :goto_f3
    nop

    .line 98
    new-instance v6, Ldev/wiojelt/turksinema/common/DomainUpdateUi$show$config$3;

    invoke-direct {v6, v0, v1, v7}, Ldev/wiojelt/turksinema/common/DomainUpdateUi$show$config$3;-><init>(Landroid/content/Context;Ljava/util/List;Lkotlin/coroutines/Continuation;)V

    move-object/from16 v62, v6

    check-cast v62, Lkotlin/jvm/functions/Function2;

    .line 101
    new-instance v6, Ldev/wiojelt/turksinema/common/DomainUpdateUi$$ExternalSyntheticLambda5;

    invoke-direct {v6, v0}, Ldev/wiojelt/turksinema/common/DomainUpdateUi$$ExternalSyntheticLambda5;-><init>(Landroid/content/Context;)V

    .line 77
    nop

    .line 111
    nop

    .line 112
    nop

    .line 77
    const/16 v68, 0x9

    const/16 v69, 0x0

    const/16 v33, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    const/16 v36, 0x0

    const/16 v37, 0x0

    const/16 v38, 0x0

    const/16 v39, 0x0

    const/16 v40, 0x0

    const/16 v41, 0x0

    const/16 v42, 0x0

    const/16 v43, 0x0

    const/16 v44, 0x0

    const/16 v45, 0x0

    const/16 v46, 0x0

    const/16 v47, 0x0

    const/16 v48, 0x0

    const/16 v49, 0x0

    const/16 v50, 0x0

    const/16 v52, 0x0

    const/16 v53, 0x0

    const/16 v54, 0x0

    const/16 v55, 0x0

    const/16 v57, 0x0

    const/16 v59, 0x0

    const/16 v60, 0x0

    const/16 v61, 0x0

    const/16 v64, 0x0

    const-string v65, "https://t.me/wiolandcs3"

    const-string v66, "https://kreosus.com/wiojelt"

    const v67, -0x28402010

    move-object/from16 v51, v3

    move-object/from16 v63, v6

    .end local v3  # "items":Ljava/util/List;
    .local v51, "items":Ljava/util/List;
    invoke-direct/range {v28 .. v69}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIIIIIIIZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;IIILjava/util/List;Ljava/lang/String;ZLjava/util/List;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function0;ZLjava/lang/String;Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object/from16 v3, v28

    .line 115
    .local v3, "config":Ldev/wiojelt/turksinema/common/WioSettingsConfig;
    sget-object v6, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->INSTANCE:Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;

    invoke-virtual {v6, v0, v3}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show(Landroid/content/Context;Ldev/wiojelt/turksinema/common/WioSettingsConfig;)V

    .line 116
    return-void
.end method

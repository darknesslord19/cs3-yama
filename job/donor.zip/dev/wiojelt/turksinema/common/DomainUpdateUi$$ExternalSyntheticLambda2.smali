.class public final synthetic Ldev/wiojelt/turksinema/common/DomainUpdateUi$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x13
    versionHash = "7bbc1d7254613ffaa026de47d975f73968361ef3e5d7b818ce0a83a33039c6b8"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/lagradost/cloudstream3/MainAPI;

.field public final synthetic f$1:Landroid/content/SharedPreferences;


# direct methods
.method public synthetic constructor <init>(Lcom/lagradost/cloudstream3/MainAPI;Landroid/content/SharedPreferences;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/wiojelt/turksinema/common/DomainUpdateUi$$ExternalSyntheticLambda2;->f$0:Lcom/lagradost/cloudstream3/MainAPI;

    iput-object p2, p0, Ldev/wiojelt/turksinema/common/DomainUpdateUi$$ExternalSyntheticLambda2;->f$1:Landroid/content/SharedPreferences;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 0
    iget-object v0, p0, Ldev/wiojelt/turksinema/common/DomainUpdateUi$$ExternalSyntheticLambda2;->f$0:Lcom/lagradost/cloudstream3/MainAPI;

    iget-object v1, p0, Ldev/wiojelt/turksinema/common/DomainUpdateUi$$ExternalSyntheticLambda2;->f$1:Landroid/content/SharedPreferences;

    check-cast p1, Ljava/lang/String;

    invoke-static {v0, v1, p1}, Ldev/wiojelt/turksinema/common/DomainUpdateUi;->$r8$lambda$lpIQ9AQL7SrC2F-e-o7KJVJV3Qc(Lcom/lagradost/cloudstream3/MainAPI;Landroid/content/SharedPreferences;Ljava/lang/String;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

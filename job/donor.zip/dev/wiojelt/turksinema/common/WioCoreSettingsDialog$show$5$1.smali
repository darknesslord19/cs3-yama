.class public final Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$5$1;
.super Ljava/lang/Object;
.source "WioCoreSettingsDialog.kt"

# interfaces
.implements Landroid/widget/SeekBar$OnSeekBarChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show(Landroid/content/Context;Ldev/wiojelt/turksinema/common/WioSettingsConfig;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000%\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\"\u0010\u0002\u001a\u00020\u00032\b\u0010\u0004\u001a\u0004\u0018\u00010\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\tH\u0016J\u0012\u0010\n\u001a\u00020\u00032\b\u0010\u0004\u001a\u0004\u0018\u00010\u0005H\u0016J\u0012\u0010\u000b\u001a\u00020\u00032\b\u0010\u0004\u001a\u0004\u0018\u00010\u0005H\u0016¨\u0006\f"
    }
    d2 = {
        "dev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$5$1",
        "Landroid/widget/SeekBar$OnSeekBarChangeListener;",
        "onProgressChanged",
        "",
        "seekBar",
        "Landroid/widget/SeekBar;",
        "progress",
        "",
        "fromUser",
        "",
        "onStartTrackingTouch",
        "onStopTrackingTouch",
        "DiziMom"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $config:Ldev/wiojelt/turksinema/common/WioSettingsConfig;

.field final synthetic $scanDurationLabel:Lkotlin/jvm/internal/Ref$ObjectRef;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/internal/Ref$ObjectRef<",
            "Landroid/widget/TextView;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $scanDurationSeekBar:Lkotlin/jvm/internal/Ref$ObjectRef;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/internal/Ref$ObjectRef<",
            "Landroid/widget/SeekBar;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Ldev/wiojelt/turksinema/common/WioSettingsConfig;Lkotlin/jvm/internal/Ref$ObjectRef;Lkotlin/jvm/internal/Ref$ObjectRef;)V
    .registers 4
    .param p1, "$config"  # Ldev/wiojelt/turksinema/common/WioSettingsConfig;
    .param p2, "$scanDurationLabel"  # Lkotlin/jvm/internal/Ref$ObjectRef;
    .param p3, "$scanDurationSeekBar"  # Lkotlin/jvm/internal/Ref$ObjectRef;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ldev/wiojelt/turksinema/common/WioSettingsConfig;",
            "Lkotlin/jvm/internal/Ref$ObjectRef<",
            "Landroid/widget/TextView;",
            ">;",
            "Lkotlin/jvm/internal/Ref$ObjectRef<",
            "Landroid/widget/SeekBar;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$5$1;->$config:Ldev/wiojelt/turksinema/common/WioSettingsConfig;

    iput-object p2, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$5$1;->$scanDurationLabel:Lkotlin/jvm/internal/Ref$ObjectRef;

    iput-object p3, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$5$1;->$scanDurationSeekBar:Lkotlin/jvm/internal/Ref$ObjectRef;

    .line 625
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onProgressChanged(Landroid/widget/SeekBar;IZ)V
    .registers 8
    .param p1, "seekBar"  # Landroid/widget/SeekBar;
    .param p2, "progress"  # I
    .param p3, "fromUser"  # Z

    .line 627
    if-eqz p3, :cond_43

    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$5$1;->$config:Ldev/wiojelt/turksinema/common/WioSettingsConfig;

    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->isTvBoxActive()Lkotlin/jvm/functions/Function0;

    move-result-object v0

    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_15

    goto :goto_43

    .line 628
    :cond_15
    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$5$1;->$config:Ldev/wiojelt/turksinema/common/WioSettingsConfig;

    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getMinScanDurationSeconds()I

    move-result v0

    add-int/2addr v0, p2

    .line 629
    .local v0, "seconds":I
    iget-object v1, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$5$1;->$scanDurationLabel:Lkotlin/jvm/internal/Ref$ObjectRef;

    iget-object v1, v1, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    check-cast v1, Landroid/widget/TextView;

    if-eqz v1, :cond_42

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Kaynak arama süresi: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " sn"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    check-cast v2, Ljava/lang/CharSequence;

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 630
    :cond_42
    return-void

    .line 627
    .end local v0  # "seconds":I
    :cond_43
    :goto_43
    return-void
.end method

.method public onStartTrackingTouch(Landroid/widget/SeekBar;)V
    .registers 2
    .param p1, "seekBar"  # Landroid/widget/SeekBar;

    .line 632
    return-void
.end method

.method public onStopTrackingTouch(Landroid/widget/SeekBar;)V
    .registers 7
    .param p1, "seekBar"  # Landroid/widget/SeekBar;

    .line 635
    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$5$1;->$config:Ldev/wiojelt/turksinema/common/WioSettingsConfig;

    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->isTvBoxActive()Lkotlin/jvm/functions/Function0;

    move-result-object v0

    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_13

    return-void

    .line 636
    :cond_13
    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$5$1;->$config:Ldev/wiojelt/turksinema/common/WioSettingsConfig;

    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getMinScanDurationSeconds()I

    move-result v0

    const/4 v1, 0x0

    if-eqz p1, :cond_21

    invoke-virtual {p1}, Landroid/widget/SeekBar;->getProgress()I

    move-result v2

    goto :goto_22

    :cond_21
    move v2, v1

    :goto_22
    add-int/2addr v0, v2

    .line 637
    .local v0, "seconds":I
    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$5$1;->$config:Ldev/wiojelt/turksinema/common/WioSettingsConfig;

    invoke-virtual {v2}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getOnScanDurationChanged()Lkotlin/jvm/functions/Function1;

    move-result-object v2

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v2, v3}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 638
    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$5$1;->$config:Ldev/wiojelt/turksinema/common/WioSettingsConfig;

    iget-object v3, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$5$1;->$scanDurationLabel:Lkotlin/jvm/internal/Ref$ObjectRef;

    iget-object v4, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$5$1;->$scanDurationSeekBar:Lkotlin/jvm/internal/Ref$ObjectRef;

    invoke-static {v2, v3, v4, v1}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->access$show$refreshScanDurationUi(Ldev/wiojelt/turksinema/common/WioSettingsConfig;Lkotlin/jvm/internal/Ref$ObjectRef;Lkotlin/jvm/internal/Ref$ObjectRef;Z)V

    .line 639
    return-void
.end method

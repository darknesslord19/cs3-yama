.class public final Ldev/wiojelt/turksinema/common/SupportNotice;
.super Ljava/lang/Object;
.source "SupportNotice.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u00006\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010 \n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\"\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000e2\b\b\u0002\u0010\u000f\u001a\u00020\u00052\b\b\u0002\u0010\u0010\u001a\u00020\bJ\u0018\u0010\u0011\u001a\u00020\f2\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u000f\u001a\u00020\u0005H\u0002J\u0018\u0010\u0014\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000e2\u0006\u0010\u0015\u001a\u00020\u0005H\u0002R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u00050\nX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0016"
    }
    d2 = {
        "Ldev/wiojelt/turksinema/common/SupportNotice;",
        "",
        "<init>",
        "()V",
        "PREFS",
        "",
        "LAST_DAY",
        "isShownThisSession",
        "",
        "MESSAGES",
        "",
        "showIfDue",
        "",
        "context",
        "Landroid/content/Context;",
        "appName",
        "force",
        "showDialog",
        "activity",
        "Landroid/app/Activity;",
        "open",
        "url",
        "DiziMom"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final INSTANCE:Ldev/wiojelt/turksinema/common/SupportNotice;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field private static final LAST_DAY:Ljava/lang/String; = "last_day"
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field private static final MESSAGES:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field private static final PREFS:Ljava/lang/String; = "wio_global_support_notice"
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field private static volatile isShownThisSession:Z


# direct methods
.method public static synthetic $r8$lambda$4HIEGX6tQf5x_Tmg2Ts898GkLrc(Landroid/app/Activity;Landroid/app/Dialog;Landroid/view/View;)V
    .registers 3

    invoke-static {p0, p1, p2}, Ldev/wiojelt/turksinema/common/SupportNotice;->showDialog$lambda$7$1(Landroid/app/Activity;Landroid/app/Dialog;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$EELV_qsuCOHTuky8DyuOSiv-v2k(Landroid/app/Activity;Landroid/app/Dialog;Landroid/view/View;)V
    .registers 3

    invoke-static {p0, p1, p2}, Ldev/wiojelt/turksinema/common/SupportNotice;->showDialog$lambda$8$1(Landroid/app/Activity;Landroid/app/Dialog;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$woInLixoqS849n6GNAw4LGgmrp4(Landroid/app/Dialog;Landroid/view/View;)V
    .registers 2

    invoke-static {p0, p1}, Ldev/wiojelt/turksinema/common/SupportNotice;->showDialog$lambda$9$0(Landroid/app/Dialog;Landroid/view/View;)V

    return-void
.end method

.method static constructor <clinit>()V
    .registers 11

    new-instance v0, Ldev/wiojelt/turksinema/common/SupportNotice;

    invoke-direct {v0}, Ldev/wiojelt/turksinema/common/SupportNotice;-><init>()V

    sput-object v0, Ldev/wiojelt/turksinema/common/SupportNotice;->INSTANCE:Ldev/wiojelt/turksinema/common/SupportNotice;

    .line 28
    nop

    .line 29
    nop

    .line 30
    nop

    .line 29
    nop

    .line 31
    nop

    .line 29
    nop

    .line 32
    nop

    .line 29
    nop

    .line 33
    nop

    .line 29
    nop

    .line 34
    nop

    .line 29
    nop

    .line 35
    nop

    .line 29
    nop

    .line 36
    nop

    .line 29
    nop

    .line 37
    nop

    .line 29
    nop

    .line 38
    const-string v10, "\ud83d\udcaa Hiçbir ticari gelirimiz yok, sadece tutku var! Eklentilerin kapanmaması ve linklerin hep canlı kalması için desteklerinizi esirgemeyin."

    const-string v1, "\ud83c\udf7f Çaylar, kahveler hazır mı? Eklentilerimiz tamamen reklamsız ve ücretsiz! Sunucuların kapanmaması ve kesintisiz yayın keyfi için Kreosus\'tan küçük bir destekle yanımızda olabilirsiniz."

    const-string v2, "\ud83d\ude80 Eklentiler hep açık kalsın, linkler hiç kopmasın! Geliştirmeye tam gaz devam edebilmemiz ve sunucuları yaşatabilmemiz için bir kahve ısmarlayabilirsiniz."

    const-string v3, "\ud83c\udf89 Reklamsız dizi, film ve spor keyfi paha biçilemez! Projeyi hep birlikte yaşatmak ve eklentilerin kapanmasını önlemek için Kreosus\'ta desteğinizi bekliyoruz."

    const-string v4, "☕ Bir fincan kahve ile eklentilerin ömrünü uzatın! Reklamsız, tertemiz yayınların kesintisiz sürmesi sizlerin güzel desteğiyle mümkün."

    const-string v5, "✨ Keyfiniz hiç bölünmesin, yayınlar kapanmasın! Gönüllü olarak sürdürdüğümüz bu projeye Kreosus\'tan küçük bir bağışla omuz verebilirsiniz."

    const-string v6, "⚡ Kesintisiz sinema ve spor heyecanı hep sürsün! Sunucularımızın ayakta kalması ve yeni kaynakların eklenmesi için bir kahvelik desteğiniz çok değerli."

    const-string v7, "\ud83c\udfaf Sıfır reklam, maksimum keyif! Eklentilerimizin uzun süre kapanmadan hizmet vermesi için Kreosus üzerinden bize katılabilirsiniz."

    const-string v8, "\ud83e\udd73 Birlikte daha güçlüyüz! Eklentileri yaşatmak, linkleri güncel tutmak ve sunucu masraflarını karşılamak için Kreosus\'tan destek olabilirsiniz."

    const-string v9, "\ud83c\udf1f En sevdiğin içerikler her an elinin altında! Bu güzel topluluğu ve eklentileri ayakta tutmak için küçük bir bağış harikalar yaratır."

    filled-new-array/range {v1 .. v10}, [Ljava/lang/String;

    move-result-object v0

    .line 29
    nop

    .line 28
    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    sput-object v0, Ldev/wiojelt/turksinema/common/SupportNotice;->MESSAGES:Ljava/util/List;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 23
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private final open(Landroid/content/Context;Ljava/lang/String;)V
    .registers 8
    .param p1, "context"  # Landroid/content/Context;
    .param p2, "url"  # Ljava/lang/String;

    .line 227
    :try_start_0
    sget-object v0, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v0, p0

    check-cast v0, Ldev/wiojelt/turksinema/common/SupportNotice;

    .local v0, "$this$open_u24lambda_u240":Ldev/wiojelt/turksinema/common/SupportNotice;
    const/4 v1, 0x0

    .line 228
    .local v1, "$i$a$-runCatching-SupportNotice$open$1":I
    new-instance v2, Landroid/content/Intent;

    const-string v3, "android.intent.action.VIEW"

    invoke-static {p2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v4

    invoke-direct {v2, v3, v4}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    const/high16 v3, 0x10000000

    invoke-virtual {v2, v3}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v2

    invoke-virtual {p1, v2}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 229
    nop

    .end local v0  # "$this$open_u24lambda_u240":Ldev/wiojelt/turksinema/common/SupportNotice;
    .end local v1  # "$i$a$-runCatching-SupportNotice$open$1":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 227
    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_20
    .catchall {:try_start_0 .. :try_end_20} :catchall_21

    goto :goto_2b

    :catchall_21
    move-exception v0

    sget-object v1, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v0}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    .line 230
    :goto_2b
    return-void
.end method

.method private final showDialog(Landroid/app/Activity;Ljava/lang/String;)V
    .registers 27
    .param p1, "activity"  # Landroid/app/Activity;
    .param p2, "appName"  # Ljava/lang/String;

    .line 47
    move-object/from16 v0, p1

    invoke-virtual {v0}, Landroid/app/Activity;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v1

    iget v1, v1, Landroid/util/DisplayMetrics;->density:F

    .line 50
    .local v1, "density":F
    invoke-virtual {v0}, Landroid/app/Activity;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v2

    iget v2, v2, Landroid/util/DisplayMetrics;->widthPixels:I

    .line 51
    .local v2, "screenWidth":I
    int-to-float v3, v2

    const v4, 0x3f6147ae  # 0.88f

    mul-float/2addr v3, v4

    float-to-int v3, v3

    const/16 v4, 0x140

    invoke-static {v1, v4}, Ldev/wiojelt/turksinema/common/SupportNotice;->showDialog$dp(FI)I

    move-result v4

    const/16 v5, 0x1ae

    invoke-static {v1, v5}, Ldev/wiojelt/turksinema/common/SupportNotice;->showDialog$dp(FI)I

    move-result v5

    invoke-static {v3, v4, v5}, Lkotlin/ranges/RangesKt;->coerceIn(III)I

    move-result v3

    .line 53
    .local v3, "dialogWidth":I
    new-instance v4, Landroid/app/Dialog;

    move-object v5, v0

    check-cast v5, Landroid/content/Context;

    invoke-direct {v4, v5}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    .line 54
    .local v4, "dialog":Landroid/app/Dialog;
    const/4 v5, 0x1

    invoke-virtual {v4, v5}, Landroid/app/Dialog;->requestWindowFeature(I)Z

    .line 55
    const/4 v6, 0x0

    invoke-virtual {v4, v6}, Landroid/app/Dialog;->setCancelable(Z)V

    .line 56
    invoke-virtual {v4, v6}, Landroid/app/Dialog;->setCanceledOnTouchOutside(Z)V

    .line 59
    new-instance v7, Landroid/widget/LinearLayout;

    move-object v8, v0

    check-cast v8, Landroid/content/Context;

    invoke-direct {v7, v8}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v8, v7

    .local v8, "$this$showDialog_u24lambda_u240":Landroid/widget/LinearLayout;
    const/4 v9, 0x0

    .line 60
    .local v9, "$i$a$-apply-SupportNotice$showDialog$root$1":I
    invoke-virtual {v8, v5}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 61
    invoke-virtual {v8, v5}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 62
    new-instance v10, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v10}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object v11, v10

    .local v11, "$this$showDialog_u24lambda_u240_u240":Landroid/graphics/drawable/GradientDrawable;
    const/4 v12, 0x0

    .line 63
    .local v12, "$i$a$-apply-SupportNotice$showDialog$root$1$1":I
    const-string v13, "#F20D0E12"

    invoke-static {v13}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v13

    invoke-virtual {v11, v13}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 64
    const/16 v13, 0x1c

    invoke-static {v1, v13}, Ldev/wiojelt/turksinema/common/SupportNotice;->showDialog$dp(FI)I

    move-result v13

    int-to-float v13, v13

    invoke-virtual {v11, v13}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 65
    invoke-static {v1, v5}, Ldev/wiojelt/turksinema/common/SupportNotice;->showDialog$dp(FI)I

    move-result v13

    const-string v14, "#33FFFFFF"

    invoke-static {v14}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v15

    invoke-virtual {v11, v13, v15}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 66
    nop

    .line 62
    .end local v11  # "$this$showDialog_u24lambda_u240_u240":Landroid/graphics/drawable/GradientDrawable;
    .end local v12  # "$i$a$-apply-SupportNotice$showDialog$root$1$1":I
    check-cast v10, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v8, v10}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 67
    const/16 v10, 0x16

    invoke-static {v1, v10}, Ldev/wiojelt/turksinema/common/SupportNotice;->showDialog$dp(FI)I

    move-result v11

    invoke-static {v1, v10}, Ldev/wiojelt/turksinema/common/SupportNotice;->showDialog$dp(FI)I

    move-result v12

    invoke-static {v1, v10}, Ldev/wiojelt/turksinema/common/SupportNotice;->showDialog$dp(FI)I

    move-result v10

    const/16 v13, 0x14

    invoke-static {v1, v13}, Ldev/wiojelt/turksinema/common/SupportNotice;->showDialog$dp(FI)I

    move-result v13

    invoke-virtual {v8, v11, v12, v10, v13}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 68
    nop

    .line 59
    .end local v8  # "$this$showDialog_u24lambda_u240":Landroid/widget/LinearLayout;
    .end local v9  # "$i$a$-apply-SupportNotice$showDialog$root$1":I
    nop

    .line 71
    .local v7, "root":Landroid/widget/LinearLayout;
    new-instance v8, Landroid/widget/LinearLayout;

    move-object v9, v0

    check-cast v9, Landroid/content/Context;

    invoke-direct {v8, v9}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v9, v8

    .local v9, "$this$showDialog_u24lambda_u241":Landroid/widget/LinearLayout;
    const/4 v10, 0x0

    .line 72
    .local v10, "$i$a$-apply-SupportNotice$showDialog$badgePill$1":I
    invoke-virtual {v9, v6}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 73
    const/16 v11, 0x10

    invoke-virtual {v9, v11}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 74
    new-instance v12, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v12}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object v13, v12

    .local v13, "$this$showDialog_u24lambda_u241_u240":Landroid/graphics/drawable/GradientDrawable;
    const/4 v15, 0x0

    .line 75
    .local v15, "$i$a$-apply-SupportNotice$showDialog$badgePill$1$1":I
    const-string v16, "#181A20"

    invoke-static/range {v16 .. v16}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v11

    invoke-virtual {v13, v11}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 76
    const/16 v11, 0x64

    invoke-static {v1, v11}, Ldev/wiojelt/turksinema/common/SupportNotice;->showDialog$dp(FI)I

    move-result v6

    int-to-float v6, v6

    invoke-virtual {v13, v6}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 77
    invoke-static {v1, v5}, Ldev/wiojelt/turksinema/common/SupportNotice;->showDialog$dp(FI)I

    move-result v6

    invoke-static {v14}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v14

    invoke-virtual {v13, v6, v14}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 78
    nop

    .line 74
    .end local v13  # "$this$showDialog_u24lambda_u241_u240":Landroid/graphics/drawable/GradientDrawable;
    .end local v15  # "$i$a$-apply-SupportNotice$showDialog$badgePill$1$1":I
    check-cast v12, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v9, v12}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 79
    const/16 v6, 0xc

    invoke-static {v1, v6}, Ldev/wiojelt/turksinema/common/SupportNotice;->showDialog$dp(FI)I

    move-result v12

    const/4 v13, 0x5

    invoke-static {v1, v13}, Ldev/wiojelt/turksinema/common/SupportNotice;->showDialog$dp(FI)I

    move-result v14

    const/16 v15, 0xe

    invoke-static {v1, v15}, Ldev/wiojelt/turksinema/common/SupportNotice;->showDialog$dp(FI)I

    move-result v11

    invoke-static {v1, v13}, Ldev/wiojelt/turksinema/common/SupportNotice;->showDialog$dp(FI)I

    move-result v13

    invoke-virtual {v9, v12, v14, v11, v13}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 80
    new-instance v11, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v12, -0x2

    invoke-direct {v11, v12, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object v13, v11

    .local v13, "$this$showDialog_u24lambda_u241_u241":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v14, 0x0

    .line 81
    .local v14, "$i$a$-apply-SupportNotice$showDialog$badgePill$1$2":I
    invoke-static {v1, v15}, Ldev/wiojelt/turksinema/common/SupportNotice;->showDialog$dp(FI)I

    move-result v6

    const/4 v15, 0x0

    invoke-virtual {v13, v15, v15, v15, v6}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 82
    nop

    .line 80
    .end local v13  # "$this$showDialog_u24lambda_u241_u241":Landroid/widget/LinearLayout$LayoutParams;
    .end local v14  # "$i$a$-apply-SupportNotice$showDialog$badgePill$1$2":I
    check-cast v11, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v9, v11}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 83
    nop

    .line 71
    .end local v9  # "$this$showDialog_u24lambda_u241":Landroid/widget/LinearLayout;
    .end local v10  # "$i$a$-apply-SupportNotice$showDialog$badgePill$1":I
    nop

    .line 85
    .local v8, "badgePill":Landroid/widget/LinearLayout;
    new-instance v6, Landroid/widget/TextView;

    move-object v9, v0

    check-cast v9, Landroid/content/Context;

    invoke-direct {v6, v9}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v9, v6

    .local v9, "$this$showDialog_u24lambda_u242":Landroid/widget/TextView;
    const/4 v10, 0x0

    .line 86
    .local v10, "$i$a$-apply-SupportNotice$showDialog$redDot$1":I
    const-string v11, "●"

    check-cast v11, Ljava/lang/CharSequence;

    invoke-virtual {v9, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 87
    const/high16 v11, 0x41100000  # 9.0f

    invoke-virtual {v9, v11}, Landroid/widget/TextView;->setTextSize(F)V

    .line 88
    const-string v11, "#E01E2B"

    invoke-static {v11}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v11

    invoke-virtual {v9, v11}, Landroid/widget/TextView;->setTextColor(I)V

    .line 89
    const/4 v11, 0x6

    invoke-static {v1, v11}, Ldev/wiojelt/turksinema/common/SupportNotice;->showDialog$dp(FI)I

    move-result v11

    const/4 v15, 0x0

    invoke-virtual {v9, v15, v15, v11, v15}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 90
    nop

    .line 85
    .end local v9  # "$this$showDialog_u24lambda_u242":Landroid/widget/TextView;
    .end local v10  # "$i$a$-apply-SupportNotice$showDialog$redDot$1":I
    nop

    .line 91
    .local v6, "redDot":Landroid/widget/TextView;
    move-object v9, v6

    check-cast v9, Landroid/view/View;

    invoke-virtual {v8, v9}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 93
    new-instance v9, Landroid/widget/TextView;

    move-object v10, v0

    check-cast v10, Landroid/content/Context;

    invoke-direct {v9, v10}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v10, v9

    .local v10, "$this$showDialog_u24lambda_u243":Landroid/widget/TextView;
    const/4 v11, 0x0

    .line 94
    .local v11, "$i$a$-apply-SupportNotice$showDialog$badgeText$1":I
    const-string v13, "TOPLULUK & DESTEK"

    check-cast v13, Ljava/lang/CharSequence;

    invoke-virtual {v10, v13}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 95
    const/high16 v13, 0x41200000  # 10.0f

    invoke-virtual {v10, v13}, Landroid/widget/TextView;->setTextSize(F)V

    .line 96
    sget-object v13, Landroid/graphics/Typeface;->MONOSPACE:Landroid/graphics/Typeface;

    invoke-virtual {v10, v13}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 97
    invoke-virtual {v10}, Landroid/widget/TextView;->getTypeface()Landroid/graphics/Typeface;

    move-result-object v13

    invoke-virtual {v10, v13, v5}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 98
    const-string v13, "#EEEEEE"

    invoke-static {v13}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v13

    invoke-virtual {v10, v13}, Landroid/widget/TextView;->setTextColor(I)V

    .line 99
    const v13, 0x3da3d70a  # 0.08f

    invoke-virtual {v10, v13}, Landroid/widget/TextView;->setLetterSpacing(F)V

    .line 100
    nop

    .line 93
    .end local v10  # "$this$showDialog_u24lambda_u243":Landroid/widget/TextView;
    .end local v11  # "$i$a$-apply-SupportNotice$showDialog$badgeText$1":I
    nop

    .line 101
    .local v9, "badgeText":Landroid/widget/TextView;
    move-object v10, v9

    check-cast v10, Landroid/view/View;

    invoke-virtual {v8, v10}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 102
    move-object v10, v8

    check-cast v10, Landroid/view/View;

    invoke-virtual {v7, v10}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 105
    new-instance v10, Landroid/widget/TextView;

    move-object v11, v0

    check-cast v11, Landroid/content/Context;

    invoke-direct {v10, v11}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v11, v10

    .local v11, "$this$showDialog_u24lambda_u244":Landroid/widget/TextView;
    const/4 v13, 0x0

    .line 106
    .local v13, "$i$a$-apply-SupportNotice$showDialog$titleView$1":I
    new-instance v14, Ljava/lang/StringBuilder;

    invoke-direct {v14}, Ljava/lang/StringBuilder;-><init>()V

    move-object/from16 v15, p2

    invoke-virtual {v14, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v14

    const-string v12, " Topluluğu"

    invoke-virtual {v14, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    check-cast v12, Ljava/lang/CharSequence;

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 107
    const/high16 v12, 0x41980000  # 19.0f

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setTextSize(F)V

    .line 108
    const/4 v12, 0x0

    invoke-virtual {v11, v12, v5}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 109
    const/4 v14, -0x1

    invoke-virtual {v11, v14}, Landroid/widget/TextView;->setTextColor(I)V

    .line 110
    const/16 v12, 0x11

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setGravity(I)V

    .line 111
    new-instance v12, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v5, -0x2

    invoke-direct {v12, v14, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object v5, v12

    .local v5, "$this$showDialog_u24lambda_u244_u240":Landroid/widget/LinearLayout$LayoutParams;
    const/16 v20, 0x0

    .line 112
    .local v20, "$i$a$-apply-SupportNotice$showDialog$titleView$1$1":I
    const/16 v14, 0xc

    invoke-static {v1, v14}, Ldev/wiojelt/turksinema/common/SupportNotice;->showDialog$dp(FI)I

    move-result v14

    move/from16 v18, v2

    const/4 v2, 0x0

    .end local v2  # "screenWidth":I
    .local v18, "screenWidth":I
    invoke-virtual {v5, v2, v2, v2, v14}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 113
    nop

    .line 111
    .end local v5  # "$this$showDialog_u24lambda_u244_u240":Landroid/widget/LinearLayout$LayoutParams;
    .end local v20  # "$i$a$-apply-SupportNotice$showDialog$titleView$1$1":I
    check-cast v12, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 114
    nop

    .line 105
    .end local v11  # "$this$showDialog_u24lambda_u244":Landroid/widget/TextView;
    .end local v13  # "$i$a$-apply-SupportNotice$showDialog$titleView$1":I
    nop

    .line 115
    .local v10, "titleView":Landroid/widget/TextView;
    move-object v2, v10

    check-cast v2, Landroid/view/View;

    invoke-virtual {v7, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 118
    new-instance v2, Landroid/widget/LinearLayout;

    move-object v5, v0

    check-cast v5, Landroid/content/Context;

    invoke-direct {v2, v5}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v5, v2

    .local v5, "$this$showDialog_u24lambda_u245":Landroid/widget/LinearLayout;
    const/4 v11, 0x0

    .line 119
    .local v11, "$i$a$-apply-SupportNotice$showDialog$descCard$1":I
    const/4 v12, 0x1

    invoke-virtual {v5, v12}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 120
    new-instance v12, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v12}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object v13, v12

    .local v13, "$this$showDialog_u24lambda_u245_u240":Landroid/graphics/drawable/GradientDrawable;
    const/4 v14, 0x0

    .line 121
    .local v14, "$i$a$-apply-SupportNotice$showDialog$descCard$1$1":I
    const-string v20, "#16181F"

    move-object/from16 v21, v2

    invoke-static/range {v20 .. v20}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v13, v2}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 122
    move-object/from16 v20, v6

    const/16 v2, 0x10

    .end local v6  # "redDot":Landroid/widget/TextView;
    .local v20, "redDot":Landroid/widget/TextView;
    invoke-static {v1, v2}, Ldev/wiojelt/turksinema/common/SupportNotice;->showDialog$dp(FI)I

    move-result v6

    int-to-float v2, v6

    invoke-virtual {v13, v2}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 123
    const/4 v2, 0x1

    invoke-static {v1, v2}, Ldev/wiojelt/turksinema/common/SupportNotice;->showDialog$dp(FI)I

    move-result v6

    const-string v2, "#2E3342"

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v13, v6, v2}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 124
    nop

    .line 120
    .end local v13  # "$this$showDialog_u24lambda_u245_u240":Landroid/graphics/drawable/GradientDrawable;
    .end local v14  # "$i$a$-apply-SupportNotice$showDialog$descCard$1$1":I
    check-cast v12, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v5, v12}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 125
    const/16 v2, 0x10

    invoke-static {v1, v2}, Ldev/wiojelt/turksinema/common/SupportNotice;->showDialog$dp(FI)I

    move-result v6

    const/16 v12, 0xe

    invoke-static {v1, v12}, Ldev/wiojelt/turksinema/common/SupportNotice;->showDialog$dp(FI)I

    move-result v13

    invoke-static {v1, v2}, Ldev/wiojelt/turksinema/common/SupportNotice;->showDialog$dp(FI)I

    move-result v14

    invoke-static {v1, v12}, Ldev/wiojelt/turksinema/common/SupportNotice;->showDialog$dp(FI)I

    move-result v12

    invoke-virtual {v5, v6, v13, v14, v12}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 126
    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v12, -0x2

    const/4 v13, -0x1

    invoke-direct {v6, v13, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object v12, v6

    .local v12, "$this$showDialog_u24lambda_u245_u241":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v13, 0x0

    .line 127
    .local v13, "$i$a$-apply-SupportNotice$showDialog$descCard$1$2":I
    invoke-static {v1, v2}, Ldev/wiojelt/turksinema/common/SupportNotice;->showDialog$dp(FI)I

    move-result v2

    const/4 v14, 0x0

    invoke-virtual {v12, v14, v14, v14, v2}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 128
    nop

    .line 126
    .end local v12  # "$this$showDialog_u24lambda_u245_u241":Landroid/widget/LinearLayout$LayoutParams;
    .end local v13  # "$i$a$-apply-SupportNotice$showDialog$descCard$1$2":I
    check-cast v6, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v5, v6}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 129
    nop

    .line 118
    .end local v5  # "$this$showDialog_u24lambda_u245":Landroid/widget/LinearLayout;
    .end local v11  # "$i$a$-apply-SupportNotice$showDialog$descCard$1":I
    move-object/from16 v2, v21

    .line 131
    .local v2, "descCard":Landroid/widget/LinearLayout;
    new-instance v5, Landroid/widget/TextView;

    move-object v6, v0

    check-cast v6, Landroid/content/Context;

    invoke-direct {v5, v6}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v6, v5

    .local v6, "$this$showDialog_u24lambda_u246":Landroid/widget/TextView;
    const/4 v11, 0x0

    .line 132
    .local v11, "$i$a$-apply-SupportNotice$showDialog$descView$1":I
    sget-object v12, Ldev/wiojelt/turksinema/common/SupportNotice;->MESSAGES:Ljava/util/List;

    check-cast v12, Ljava/util/Collection;

    sget-object v13, Lkotlin/random/Random;->Default:Lkotlin/random/Random$Default;

    check-cast v13, Lkotlin/random/Random;

    invoke-static {v12, v13}, Lkotlin/collections/CollectionsKt;->random(Ljava/util/Collection;Lkotlin/random/Random;)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ljava/lang/CharSequence;

    invoke-virtual {v6, v12}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 133
    const/high16 v12, 0x41480000  # 12.5f

    invoke-virtual {v6, v12}, Landroid/widget/TextView;->setTextSize(F)V

    .line 134
    const-string v12, "#8E95A5"

    invoke-static {v12}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v12

    invoke-virtual {v6, v12}, Landroid/widget/TextView;->setTextColor(I)V

    .line 135
    const/16 v12, 0x11

    invoke-virtual {v6, v12}, Landroid/widget/TextView;->setGravity(I)V

    .line 136
    const/4 v12, 0x2

    invoke-static {v1, v12}, Ldev/wiojelt/turksinema/common/SupportNotice;->showDialog$dp(FI)I

    move-result v12

    int-to-float v12, v12

    const/high16 v13, 0x3fa00000  # 1.25f

    invoke-virtual {v6, v12, v13}, Landroid/widget/TextView;->setLineSpacing(FF)V

    .line 137
    nop

    .line 131
    .end local v6  # "$this$showDialog_u24lambda_u246":Landroid/widget/TextView;
    .end local v11  # "$i$a$-apply-SupportNotice$showDialog$descView$1":I
    nop

    .line 138
    .local v5, "descView":Landroid/widget/TextView;
    move-object v6, v5

    check-cast v6, Landroid/view/View;

    invoke-virtual {v2, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 139
    move-object v6, v2

    check-cast v6, Landroid/view/View;

    invoke-virtual {v7, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 142
    new-instance v6, Lcom/google/android/material/button/MaterialButton;

    move-object v11, v0

    check-cast v11, Landroid/content/Context;

    invoke-direct {v6, v11}, Lcom/google/android/material/button/MaterialButton;-><init>(Landroid/content/Context;)V

    move-object v11, v6

    .local v11, "$this$showDialog_u24lambda_u247":Lcom/google/android/material/button/MaterialButton;
    const/4 v12, 0x0

    .line 143
    .local v12, "$i$a$-apply-SupportNotice$showDialog$btnKreosus$1":I
    const-string v13, "Kreosus ile Destek Ol ☕"

    check-cast v13, Ljava/lang/CharSequence;

    invoke-virtual {v11, v13}, Lcom/google/android/material/button/MaterialButton;->setText(Ljava/lang/CharSequence;)V

    .line 144
    const/high16 v13, 0x41500000  # 13.0f

    invoke-virtual {v11, v13}, Lcom/google/android/material/button/MaterialButton;->setTextSize(F)V

    .line 145
    const/4 v13, 0x0

    const/4 v14, 0x1

    invoke-virtual {v11, v13, v14}, Lcom/google/android/material/button/MaterialButton;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 146
    const-string v13, "#FFD54F"

    invoke-static {v13}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v13

    invoke-virtual {v11, v13}, Lcom/google/android/material/button/MaterialButton;->setTextColor(I)V

    .line 147
    const-string v13, "#26200A"

    invoke-static {v13}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v13

    invoke-static {v13}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v13

    invoke-virtual {v11, v13}, Lcom/google/android/material/button/MaterialButton;->setBackgroundTintList(Landroid/content/res/ColorStateList;)V

    .line 148
    const-string v13, "#664D03"

    invoke-static {v13}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v13

    invoke-static {v13}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v13

    invoke-virtual {v11, v13}, Lcom/google/android/material/button/MaterialButton;->setStrokeColor(Landroid/content/res/ColorStateList;)V

    .line 149
    const/4 v14, 0x1

    invoke-static {v1, v14}, Ldev/wiojelt/turksinema/common/SupportNotice;->showDialog$dp(FI)I

    move-result v13

    invoke-virtual {v11, v13}, Lcom/google/android/material/button/MaterialButton;->setStrokeWidth(I)V

    .line 150
    const/16 v13, 0x64

    invoke-static {v1, v13}, Ldev/wiojelt/turksinema/common/SupportNotice;->showDialog$dp(FI)I

    move-result v14

    invoke-virtual {v11, v14}, Lcom/google/android/material/button/MaterialButton;->setCornerRadius(I)V

    .line 151
    const/4 v14, 0x0

    invoke-virtual {v11, v14}, Lcom/google/android/material/button/MaterialButton;->setInsetTop(I)V

    .line 152
    invoke-virtual {v11, v14}, Lcom/google/android/material/button/MaterialButton;->setInsetBottom(I)V

    .line 153
    invoke-virtual {v11, v14}, Lcom/google/android/material/button/MaterialButton;->setAllCaps(Z)V

    .line 154
    const/4 v14, 0x1

    invoke-virtual {v11, v14}, Lcom/google/android/material/button/MaterialButton;->setMaxLines(I)V

    .line 155
    const/16 v13, 0x11

    invoke-virtual {v11, v13}, Lcom/google/android/material/button/MaterialButton;->setGravity(I)V

    .line 156
    invoke-virtual {v11, v14}, Lcom/google/android/material/button/MaterialButton;->setFocusable(Z)V

    .line 157
    invoke-virtual {v11, v14}, Lcom/google/android/material/button/MaterialButton;->setFocusableInTouchMode(Z)V

    .line 158
    new-instance v13, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v14, 0x2c

    move-object/from16 v19, v2

    .end local v2  # "descCard":Landroid/widget/LinearLayout;
    .local v19, "descCard":Landroid/widget/LinearLayout;
    invoke-static {v1, v14}, Ldev/wiojelt/turksinema/common/SupportNotice;->showDialog$dp(FI)I

    move-result v2

    const/4 v14, -0x1

    invoke-direct {v13, v14, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object v2, v13

    .local v2, "$this$showDialog_u24lambda_u247_u240":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v14, 0x0

    .line 159
    .local v14, "$i$a$-apply-SupportNotice$showDialog$btnKreosus$1$1":I
    move-object/from16 v22, v5

    .end local v5  # "descView":Landroid/widget/TextView;
    .local v22, "descView":Landroid/widget/TextView;
    const/16 v5, 0xa

    move-object/from16 v23, v6

    invoke-static {v1, v5}, Ldev/wiojelt/turksinema/common/SupportNotice;->showDialog$dp(FI)I

    move-result v6

    const/4 v5, 0x0

    invoke-virtual {v2, v5, v5, v5, v6}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 160
    nop

    .line 158
    .end local v2  # "$this$showDialog_u24lambda_u247_u240":Landroid/widget/LinearLayout$LayoutParams;
    .end local v14  # "$i$a$-apply-SupportNotice$showDialog$btnKreosus$1$1":I
    check-cast v13, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v11, v13}, Lcom/google/android/material/button/MaterialButton;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 161
    new-instance v2, Ldev/wiojelt/turksinema/common/SupportNotice$$ExternalSyntheticLambda0;

    invoke-direct {v2, v0, v4}, Ldev/wiojelt/turksinema/common/SupportNotice$$ExternalSyntheticLambda0;-><init>(Landroid/app/Activity;Landroid/app/Dialog;)V

    invoke-virtual {v11, v2}, Lcom/google/android/material/button/MaterialButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 165
    nop

    .line 142
    .end local v11  # "$this$showDialog_u24lambda_u247":Lcom/google/android/material/button/MaterialButton;
    .end local v12  # "$i$a$-apply-SupportNotice$showDialog$btnKreosus$1":I
    nop

    .line 166
    .local v23, "btnKreosus":Lcom/google/android/material/button/MaterialButton;
    move-object/from16 v2, v23

    check-cast v2, Landroid/view/View;

    invoke-virtual {v7, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 169
    new-instance v2, Lcom/google/android/material/button/MaterialButton;

    move-object v5, v0

    check-cast v5, Landroid/content/Context;

    invoke-direct {v2, v5}, Lcom/google/android/material/button/MaterialButton;-><init>(Landroid/content/Context;)V

    move-object v5, v2

    .local v5, "$this$showDialog_u24lambda_u248":Lcom/google/android/material/button/MaterialButton;
    const/4 v6, 0x0

    .line 170
    .local v6, "$i$a$-apply-SupportNotice$showDialog$btnTelegram$1":I
    const-string v11, "Telegram Kanalı ↗"

    check-cast v11, Ljava/lang/CharSequence;

    invoke-virtual {v5, v11}, Lcom/google/android/material/button/MaterialButton;->setText(Ljava/lang/CharSequence;)V

    .line 171
    const/high16 v11, 0x41500000  # 13.0f

    invoke-virtual {v5, v11}, Lcom/google/android/material/button/MaterialButton;->setTextSize(F)V

    .line 172
    const/4 v13, 0x0

    const/4 v14, 0x1

    invoke-virtual {v5, v13, v14}, Lcom/google/android/material/button/MaterialButton;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 173
    const/4 v13, -0x1

    invoke-virtual {v5, v13}, Lcom/google/android/material/button/MaterialButton;->setTextColor(I)V

    .line 174
    const-string v11, "#181B22"

    invoke-static {v11}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v11

    invoke-static {v11}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v11

    invoke-virtual {v5, v11}, Lcom/google/android/material/button/MaterialButton;->setBackgroundTintList(Landroid/content/res/ColorStateList;)V

    .line 175
    const-string v11, "#3B4252"

    invoke-static {v11}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v11

    invoke-static {v11}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v11

    invoke-virtual {v5, v11}, Lcom/google/android/material/button/MaterialButton;->setStrokeColor(Landroid/content/res/ColorStateList;)V

    .line 176
    const/4 v14, 0x1

    invoke-static {v1, v14}, Ldev/wiojelt/turksinema/common/SupportNotice;->showDialog$dp(FI)I

    move-result v11

    invoke-virtual {v5, v11}, Lcom/google/android/material/button/MaterialButton;->setStrokeWidth(I)V

    .line 177
    const/16 v13, 0x64

    invoke-static {v1, v13}, Ldev/wiojelt/turksinema/common/SupportNotice;->showDialog$dp(FI)I

    move-result v11

    invoke-virtual {v5, v11}, Lcom/google/android/material/button/MaterialButton;->setCornerRadius(I)V

    .line 178
    const/4 v14, 0x0

    invoke-virtual {v5, v14}, Lcom/google/android/material/button/MaterialButton;->setInsetTop(I)V

    .line 179
    invoke-virtual {v5, v14}, Lcom/google/android/material/button/MaterialButton;->setInsetBottom(I)V

    .line 180
    invoke-virtual {v5, v14}, Lcom/google/android/material/button/MaterialButton;->setAllCaps(Z)V

    .line 181
    const/4 v14, 0x1

    invoke-virtual {v5, v14}, Lcom/google/android/material/button/MaterialButton;->setMaxLines(I)V

    .line 182
    const/16 v13, 0x11

    invoke-virtual {v5, v13}, Lcom/google/android/material/button/MaterialButton;->setGravity(I)V

    .line 183
    invoke-virtual {v5, v14}, Lcom/google/android/material/button/MaterialButton;->setFocusable(Z)V

    .line 184
    invoke-virtual {v5, v14}, Lcom/google/android/material/button/MaterialButton;->setFocusableInTouchMode(Z)V

    .line 185
    new-instance v11, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v12, 0x2c

    invoke-static {v1, v12}, Ldev/wiojelt/turksinema/common/SupportNotice;->showDialog$dp(FI)I

    move-result v12

    const/4 v13, -0x1

    invoke-direct {v11, v13, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object v12, v11

    .local v12, "$this$showDialog_u24lambda_u248_u240":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v13, 0x0

    .line 186
    .local v13, "$i$a$-apply-SupportNotice$showDialog$btnTelegram$1$1":I
    const/16 v14, 0xa

    invoke-static {v1, v14}, Ldev/wiojelt/turksinema/common/SupportNotice;->showDialog$dp(FI)I

    move-result v14

    move-object/from16 v17, v2

    const/4 v2, 0x0

    invoke-virtual {v12, v2, v2, v2, v14}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 187
    nop

    .line 185
    .end local v12  # "$this$showDialog_u24lambda_u248_u240":Landroid/widget/LinearLayout$LayoutParams;
    .end local v13  # "$i$a$-apply-SupportNotice$showDialog$btnTelegram$1$1":I
    check-cast v11, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v5, v11}, Lcom/google/android/material/button/MaterialButton;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 188
    new-instance v2, Ldev/wiojelt/turksinema/common/SupportNotice$$ExternalSyntheticLambda1;

    invoke-direct {v2, v0, v4}, Ldev/wiojelt/turksinema/common/SupportNotice$$ExternalSyntheticLambda1;-><init>(Landroid/app/Activity;Landroid/app/Dialog;)V

    invoke-virtual {v5, v2}, Lcom/google/android/material/button/MaterialButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 192
    nop

    .line 169
    .end local v5  # "$this$showDialog_u24lambda_u248":Lcom/google/android/material/button/MaterialButton;
    .end local v6  # "$i$a$-apply-SupportNotice$showDialog$btnTelegram$1":I
    nop

    .line 193
    .local v17, "btnTelegram":Lcom/google/android/material/button/MaterialButton;
    move-object/from16 v2, v17

    check-cast v2, Landroid/view/View;

    invoke-virtual {v7, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 196
    new-instance v2, Lcom/google/android/material/button/MaterialButton;

    move-object v5, v0

    check-cast v5, Landroid/content/Context;

    invoke-direct {v2, v5}, Lcom/google/android/material/button/MaterialButton;-><init>(Landroid/content/Context;)V

    move-object v5, v2

    .local v5, "$this$showDialog_u24lambda_u249":Lcom/google/android/material/button/MaterialButton;
    const/4 v6, 0x0

    .line 197
    .local v6, "$i$a$-apply-SupportNotice$showDialog$btnClose$1":I
    const-string v11, "Daha Sonra Hatırlat"

    check-cast v11, Ljava/lang/CharSequence;

    invoke-virtual {v5, v11}, Lcom/google/android/material/button/MaterialButton;->setText(Ljava/lang/CharSequence;)V

    .line 198
    const/high16 v11, 0x41400000  # 12.0f

    invoke-virtual {v5, v11}, Lcom/google/android/material/button/MaterialButton;->setTextSize(F)V

    .line 199
    const/4 v13, 0x0

    const/4 v14, 0x1

    invoke-virtual {v5, v13, v14}, Lcom/google/android/material/button/MaterialButton;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 200
    const-string v11, "#9CA3AF"

    invoke-static {v11}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v11

    invoke-virtual {v5, v11}, Lcom/google/android/material/button/MaterialButton;->setTextColor(I)V

    .line 201
    const-string v11, "#141519"

    invoke-static {v11}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v11

    invoke-static {v11}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v11

    invoke-virtual {v5, v11}, Lcom/google/android/material/button/MaterialButton;->setBackgroundTintList(Landroid/content/res/ColorStateList;)V

    .line 202
    const-string v11, "#242730"

    invoke-static {v11}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v11

    invoke-static {v11}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v11

    invoke-virtual {v5, v11}, Lcom/google/android/material/button/MaterialButton;->setStrokeColor(Landroid/content/res/ColorStateList;)V

    .line 203
    const/4 v14, 0x1

    invoke-static {v1, v14}, Ldev/wiojelt/turksinema/common/SupportNotice;->showDialog$dp(FI)I

    move-result v11

    invoke-virtual {v5, v11}, Lcom/google/android/material/button/MaterialButton;->setStrokeWidth(I)V

    .line 204
    const/16 v13, 0x64

    invoke-static {v1, v13}, Ldev/wiojelt/turksinema/common/SupportNotice;->showDialog$dp(FI)I

    move-result v11

    invoke-virtual {v5, v11}, Lcom/google/android/material/button/MaterialButton;->setCornerRadius(I)V

    .line 205
    const/4 v14, 0x0

    invoke-virtual {v5, v14}, Lcom/google/android/material/button/MaterialButton;->setInsetTop(I)V

    .line 206
    invoke-virtual {v5, v14}, Lcom/google/android/material/button/MaterialButton;->setInsetBottom(I)V

    .line 207
    invoke-virtual {v5, v14}, Lcom/google/android/material/button/MaterialButton;->setAllCaps(Z)V

    .line 208
    const/4 v14, 0x1

    invoke-virtual {v5, v14}, Lcom/google/android/material/button/MaterialButton;->setMaxLines(I)V

    .line 209
    const/16 v13, 0x11

    invoke-virtual {v5, v13}, Lcom/google/android/material/button/MaterialButton;->setGravity(I)V

    .line 210
    invoke-virtual {v5, v14}, Lcom/google/android/material/button/MaterialButton;->setFocusable(Z)V

    .line 211
    invoke-virtual {v5, v14}, Lcom/google/android/material/button/MaterialButton;->setFocusableInTouchMode(Z)V

    .line 212
    new-instance v11, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v12, 0x28

    invoke-static {v1, v12}, Ldev/wiojelt/turksinema/common/SupportNotice;->showDialog$dp(FI)I

    move-result v12

    const/4 v13, -0x1

    invoke-direct {v11, v13, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    check-cast v11, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v5, v11}, Lcom/google/android/material/button/MaterialButton;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 213
    new-instance v11, Ldev/wiojelt/turksinema/common/SupportNotice$$ExternalSyntheticLambda2;

    invoke-direct {v11, v4}, Ldev/wiojelt/turksinema/common/SupportNotice$$ExternalSyntheticLambda2;-><init>(Landroid/app/Dialog;)V

    invoke-virtual {v5, v11}, Lcom/google/android/material/button/MaterialButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 214
    nop

    .line 196
    .end local v5  # "$this$showDialog_u24lambda_u249":Lcom/google/android/material/button/MaterialButton;
    .end local v6  # "$i$a$-apply-SupportNotice$showDialog$btnClose$1":I
    nop

    .line 215
    .local v2, "btnClose":Lcom/google/android/material/button/MaterialButton;
    move-object v5, v2

    check-cast v5, Landroid/view/View;

    invoke-virtual {v7, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 217
    move-object v5, v7

    check-cast v5, Landroid/view/View;

    invoke-virtual {v4, v5}, Landroid/app/Dialog;->setContentView(Landroid/view/View;)V

    .line 218
    invoke-virtual {v4}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v5

    if-eqz v5, :cond_45f

    .local v5, "win":Landroid/view/Window;
    const/4 v6, 0x0

    .line 219
    .local v6, "$i$a$-let-SupportNotice$showDialog$1":I
    const/4 v12, -0x2

    invoke-virtual {v5, v3, v12}, Landroid/view/Window;->setLayout(II)V

    .line 220
    new-instance v11, Landroid/graphics/drawable/ColorDrawable;

    const/4 v14, 0x0

    invoke-direct {v11, v14}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    check-cast v11, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v5, v11}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 221
    const/high16 v11, 0x3f400000  # 0.75f

    invoke-virtual {v5, v11}, Landroid/view/Window;->setDimAmount(F)V

    .line 222
    nop

    .line 218
    .end local v5  # "win":Landroid/view/Window;
    .end local v6  # "$i$a$-let-SupportNotice$showDialog$1":I
    nop

    .line 223
    :cond_45f
    invoke-virtual {v4}, Landroid/app/Dialog;->show()V

    .line 224
    return-void
.end method

.method private static final showDialog$dp(FI)I
    .registers 3
    .param p0, "density"  # F
    .param p1, "v"  # I

    .line 48
    int-to-float v0, p1

    mul-float/2addr v0, p0

    float-to-int v0, v0

    return v0
.end method

.method private static final showDialog$lambda$7$1(Landroid/app/Activity;Landroid/app/Dialog;Landroid/view/View;)V
    .registers 6
    .param p0, "$activity"  # Landroid/app/Activity;
    .param p1, "$dialog"  # Landroid/app/Dialog;
    .param p2, "it"  # Landroid/view/View;

    .line 162
    sget-object v0, Ldev/wiojelt/turksinema/common/SupportNotice;->INSTANCE:Ldev/wiojelt/turksinema/common/SupportNotice;

    move-object v1, p0

    check-cast v1, Landroid/content/Context;

    const-string v2, "https://kreosus.com/wiojelt"

    invoke-direct {v0, v1, v2}, Ldev/wiojelt/turksinema/common/SupportNotice;->open(Landroid/content/Context;Ljava/lang/String;)V

    .line 163
    invoke-virtual {p1}, Landroid/app/Dialog;->dismiss()V

    .line 164
    return-void
.end method

.method private static final showDialog$lambda$8$1(Landroid/app/Activity;Landroid/app/Dialog;Landroid/view/View;)V
    .registers 6
    .param p0, "$activity"  # Landroid/app/Activity;
    .param p1, "$dialog"  # Landroid/app/Dialog;
    .param p2, "it"  # Landroid/view/View;

    .line 189
    sget-object v0, Ldev/wiojelt/turksinema/common/SupportNotice;->INSTANCE:Ldev/wiojelt/turksinema/common/SupportNotice;

    move-object v1, p0

    check-cast v1, Landroid/content/Context;

    const-string v2, "https://t.me/wiolandcs3"

    invoke-direct {v0, v1, v2}, Ldev/wiojelt/turksinema/common/SupportNotice;->open(Landroid/content/Context;Ljava/lang/String;)V

    .line 190
    invoke-virtual {p1}, Landroid/app/Dialog;->dismiss()V

    .line 191
    return-void
.end method

.method private static final showDialog$lambda$9$0(Landroid/app/Dialog;Landroid/view/View;)V
    .registers 2
    .param p0, "$dialog"  # Landroid/app/Dialog;
    .param p1, "it"  # Landroid/view/View;

    .line 213
    invoke-virtual {p0}, Landroid/app/Dialog;->dismiss()V

    return-void
.end method

.method public static synthetic showIfDue$default(Ldev/wiojelt/turksinema/common/SupportNotice;Landroid/content/Context;Ljava/lang/String;ZILjava/lang/Object;)V
    .registers 6

    .line 41
    and-int/lit8 p5, p4, 0x2

    if-eqz p5, :cond_6

    const-string p2, "WioSinema"

    :cond_6
    and-int/lit8 p4, p4, 0x4

    if-eqz p4, :cond_b

    const/4 p3, 0x0

    :cond_b
    invoke-virtual {p0, p1, p2, p3}, Ldev/wiojelt/turksinema/common/SupportNotice;->showIfDue(Landroid/content/Context;Ljava/lang/String;Z)V

    return-void
.end method


# virtual methods
.method public final showIfDue(Landroid/content/Context;Ljava/lang/String;Z)V
    .registers 7
    .param p1, "context"  # Landroid/content/Context;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p2, "appName"  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p3, "force"  # Z

    .line 42
    move-object v0, p2

    check-cast v0, Ljava/lang/CharSequence;

    const-string v1, "Spor"

    check-cast v1, Ljava/lang/CharSequence;

    const/4 v2, 0x1

    invoke-static {v0, v1, v2}, Lkotlin/text/StringsKt;->contains(Ljava/lang/CharSequence;Ljava/lang/CharSequence;Z)Z

    move-result v0

    if-nez v0, :cond_1f

    move-object v0, p2

    check-cast v0, Ljava/lang/CharSequence;

    const-string v1, "IPTV"

    check-cast v1, Ljava/lang/CharSequence;

    invoke-static {v0, v1, v2}, Lkotlin/text/StringsKt;->contains(Ljava/lang/CharSequence;Ljava/lang/CharSequence;Z)Z

    move-result v0

    if-eqz v0, :cond_1c

    goto :goto_1f

    :cond_1c
    const-string v0, "SINEMA"

    goto :goto_21

    :cond_1f
    :goto_1f
    const-string v0, "SPOR"

    .line 43
    .local v0, "target":Ljava/lang/String;
    :goto_21
    sget-object v1, Ldev/wiojelt/turksinema/common/WioPollNotice;->INSTANCE:Ldev/wiojelt/turksinema/common/WioPollNotice;

    invoke-virtual {v1, p1, v0, p3}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showIfDue(Landroid/content/Context;Ljava/lang/String;Z)V

    .line 44
    return-void
.end method

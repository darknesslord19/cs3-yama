.class final Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1;
.super Lkotlin/coroutines/jvm/internal/SuspendLambda;
.source "WioCoreSettingsDialog.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show(Landroid/content/Context;Ldev/wiojelt/turksinema/common/WioSettingsConfig;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/SuspendLambda;",
        "Lkotlin/jvm/functions/Function2<",
        "Lkotlinx/coroutines/CoroutineScope;",
        "Lkotlin/coroutines/Continuation<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"
    }
    d2 = {
        "<anonymous>",
        "",
        "Lkotlinx/coroutines/CoroutineScope;"
    }
    k = 0x3
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "dev.wiojelt.turksinema.common.WioCoreSettingsDialog$show$17$1"
    f = "WioCoreSettingsDialog.kt"
    i = {}
    l = {
        0x462
    }
    m = "invokeSuspend"
    n = {}
    nl = {
        0x469
    }
    s = {}
    v = 0x2
.end annotation


# instance fields
.field final synthetic $config:Ldev/wiojelt/turksinema/common/WioSettingsConfig;

.field final synthetic $context:Landroid/content/Context;

.field final synthetic $scanBtn:Lcom/google/android/material/button/MaterialButton;

.field final synthetic $scanProgress:Landroid/widget/ProgressBar;

.field final synthetic $scanStatus:Landroid/widget/TextView;

.field label:I


# direct methods
.method constructor <init>(Landroid/widget/ProgressBar;Lcom/google/android/material/button/MaterialButton;Landroid/widget/TextView;Landroid/content/Context;Ldev/wiojelt/turksinema/common/WioSettingsConfig;Lkotlin/coroutines/Continuation;)V
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/ProgressBar;",
            "Lcom/google/android/material/button/MaterialButton;",
            "Landroid/widget/TextView;",
            "Landroid/content/Context;",
            "Ldev/wiojelt/turksinema/common/WioSettingsConfig;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1;->$scanProgress:Landroid/widget/ProgressBar;

    iput-object p2, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1;->$scanBtn:Lcom/google/android/material/button/MaterialButton;

    iput-object p3, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1;->$scanStatus:Landroid/widget/TextView;

    iput-object p4, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1;->$context:Landroid/content/Context;

    iput-object p5, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1;->$config:Ldev/wiojelt/turksinema/common/WioSettingsConfig;

    const/4 v0, 0x2

    invoke-direct {p0, v0, p6}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/Continuation;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .registers 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/Continuation<",
            "*>;)",
            "Lkotlin/coroutines/Continuation<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    new-instance v0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1;

    iget-object v1, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1;->$scanProgress:Landroid/widget/ProgressBar;

    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1;->$scanBtn:Lcom/google/android/material/button/MaterialButton;

    iget-object v3, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1;->$scanStatus:Landroid/widget/TextView;

    iget-object v4, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1;->$context:Landroid/content/Context;

    iget-object v5, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1;->$config:Ldev/wiojelt/turksinema/common/WioSettingsConfig;

    move-object v6, p2

    invoke-direct/range {v0 .. v6}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1;-><init>(Landroid/widget/ProgressBar;Lcom/google/android/material/button/MaterialButton;Landroid/widget/TextView;Landroid/content/Context;Ldev/wiojelt/turksinema/common/WioSettingsConfig;Lkotlin/coroutines/Continuation;)V

    check-cast v0, Lkotlin/coroutines/Continuation;

    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    check-cast p2, Lkotlin/coroutines/Continuation;

    invoke-virtual {p0, p1, p2}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1;->invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public final invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/CoroutineScope;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    invoke-virtual {p0, p1, p2}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    move-result-object v0

    check-cast v0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1;

    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    invoke-virtual {v0, v1}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 9
    .param p1, "$result"  # Ljava/lang/Object;

    invoke-static {}, Lkotlin/coroutines/intrinsics/IntrinsicsKt;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object v0

    .line 1121
    iget v1, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1;->label:I

    const/4 v2, 0x1

    packed-switch v1, :pswitch_data_8a

    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :pswitch_12  #0x1
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    move-object v1, p1

    goto :goto_38

    :pswitch_17  #0x0
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 1122
    invoke-static {}, Lkotlinx/coroutines/Dispatchers;->getIO()Lkotlinx/coroutines/CoroutineDispatcher;

    move-result-object v1

    check-cast v1, Lkotlin/coroutines/CoroutineContext;

    new-instance v3, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1$res$1;

    iget-object v4, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1;->$config:Ldev/wiojelt/turksinema/common/WioSettingsConfig;

    iget-object v5, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1;->$scanStatus:Landroid/widget/TextView;

    const/4 v6, 0x0

    invoke-direct {v3, v4, v5, v6}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1$res$1;-><init>(Ldev/wiojelt/turksinema/common/WioSettingsConfig;Landroid/widget/TextView;Lkotlin/coroutines/Continuation;)V

    check-cast v3, Lkotlin/jvm/functions/Function2;

    move-object v4, p0

    check-cast v4, Lkotlin/coroutines/Continuation;

    iput v2, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1;->label:I

    invoke-static {v1, v3, v4}, Lkotlinx/coroutines/BuildersKt;->withContext(Lkotlin/coroutines/CoroutineContext;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v1

    if-ne v1, v0, :cond_38

    .line 1121
    return-object v0

    :cond_38
    :goto_38
    move-object v0, v1

    check-cast v0, Lkotlin/Pair;

    .line 1129
    .local v0, "res":Lkotlin/Pair;
    iget-object v1, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1;->$scanProgress:Landroid/widget/ProgressBar;

    const/16 v3, 0x8

    invoke-virtual {v1, v3}, Landroid/widget/ProgressBar;->setVisibility(I)V

    .line 1130
    iget-object v1, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1;->$scanBtn:Lcom/google/android/material/button/MaterialButton;

    invoke-virtual {v1, v2}, Lcom/google/android/material/button/MaterialButton;->setEnabled(Z)V

    .line 1131
    iget-object v1, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1;->$scanStatus:Landroid/widget/TextView;

    invoke-virtual {v0}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v0}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    move-result-object v3

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "✓ "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, " kaynak erişilebilir · "

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " adres güncellendi"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    check-cast v2, Ljava/lang/CharSequence;

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1132
    iget-object v1, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1;->$context:Landroid/content/Context;

    const-string v2, "Tarama tamamlandı!"

    check-cast v2, Ljava/lang/CharSequence;

    const/4 v3, 0x0

    invoke-static {v1, v2, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    .line 1133
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v1

    :pswitch_data_8a
    .packed-switch 0x0
        :pswitch_17  #00000000
        :pswitch_12  #00000001
    .end packed-switch
.end method

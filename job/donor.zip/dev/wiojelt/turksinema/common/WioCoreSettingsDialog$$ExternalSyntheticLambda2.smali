.class public final synthetic Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x13
    versionHash = "7bbc1d7254613ffaa026de47d975f73968361ef3e5d7b818ce0a83a33039c6b8"
.end annotation


# instance fields
.field public final synthetic f$0:Lkotlin/jvm/internal/Ref$BooleanRef;

.field public final synthetic f$1:Lkotlin/jvm/functions/Function0;

.field public final synthetic f$2:Ldev/wiojelt/turksinema/common/WioSettingsConfig;

.field public final synthetic f$3:Ljava/util/Map;

.field public final synthetic f$4:Lkotlin/jvm/internal/Ref$ObjectRef;

.field public final synthetic f$5:Ljava/util/Map;


# direct methods
.method public synthetic constructor <init>(Lkotlin/jvm/internal/Ref$BooleanRef;Lkotlin/jvm/functions/Function0;Ldev/wiojelt/turksinema/common/WioSettingsConfig;Ljava/util/Map;Lkotlin/jvm/internal/Ref$ObjectRef;Ljava/util/Map;)V
    .registers 7

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda2;->f$0:Lkotlin/jvm/internal/Ref$BooleanRef;

    iput-object p2, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda2;->f$1:Lkotlin/jvm/functions/Function0;

    iput-object p3, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda2;->f$2:Ldev/wiojelt/turksinema/common/WioSettingsConfig;

    iput-object p4, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda2;->f$3:Ljava/util/Map;

    iput-object p5, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda2;->f$4:Lkotlin/jvm/internal/Ref$ObjectRef;

    iput-object p6, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda2;->f$5:Ljava/util/Map;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 9

    .line 0
    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda2;->f$0:Lkotlin/jvm/internal/Ref$BooleanRef;

    iget-object v1, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda2;->f$1:Lkotlin/jvm/functions/Function0;

    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda2;->f$2:Ldev/wiojelt/turksinema/common/WioSettingsConfig;

    iget-object v3, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda2;->f$3:Ljava/util/Map;

    iget-object v4, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda2;->f$4:Lkotlin/jvm/internal/Ref$ObjectRef;

    iget-object v5, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda2;->f$5:Ljava/util/Map;

    move-object v6, p1

    invoke-static/range {v0 .. v6}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->$r8$lambda$314usvR1xsplhTU4-DsZZXB8mL4(Lkotlin/jvm/internal/Ref$BooleanRef;Lkotlin/jvm/functions/Function0;Ldev/wiojelt/turksinema/common/WioSettingsConfig;Ljava/util/Map;Lkotlin/jvm/internal/Ref$ObjectRef;Ljava/util/Map;Landroid/view/View;)V

    return-void
.end method

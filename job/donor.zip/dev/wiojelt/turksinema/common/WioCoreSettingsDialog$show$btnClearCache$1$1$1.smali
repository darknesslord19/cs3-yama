.class final Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$btnClearCache$1$1$1;
.super Lkotlin/coroutines/jvm/internal/SuspendLambda;
.source "WioCoreSettingsDialog.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show(Landroid/content/Context;Ldev/wiojelt/turksinema/common/WioSettingsConfig;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/SuspendLambda;",
        "Lkotlin/jvm/functions/Function2<",
        "Lkotlinx/coroutines/CoroutineScope;",
        "Lkotlin/coroutines/Continuation<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"
    }
    d2 = {
        "<anonymous>",
        "",
        "Lkotlinx/coroutines/CoroutineScope;"
    }
    k = 0x3
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "dev.wiojelt.turksinema.common.WioCoreSettingsDialog$show$btnClearCache$1$1$1"
    f = "WioCoreSettingsDialog.kt"
    i = {}
    l = {
        0x1d6
    }
    m = "invokeSuspend"
    n = {}
    nl = {
        0x1d9
    }
    s = {}
    v = 0x2
.end annotation


# instance fields
.field final synthetic $config:Ldev/wiojelt/turksinema/common/WioSettingsConfig;

.field final synthetic $context:Landroid/content/Context;

.field label:I


# direct methods
.method constructor <init>(Ldev/wiojelt/turksinema/common/WioSettingsConfig;Landroid/content/Context;Lkotlin/coroutines/Continuation;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ldev/wiojelt/turksinema/common/WioSettingsConfig;",
            "Landroid/content/Context;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$btnClearCache$1$1$1;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$btnClearCache$1$1$1;->$config:Ldev/wiojelt/turksinema/common/WioSettingsConfig;

    iput-object p2, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$btnClearCache$1$1$1;->$context:Landroid/content/Context;

    const/4 v0, 0x2

    invoke-direct {p0, v0, p3}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/Continuation;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/Continuation<",
            "*>;)",
            "Lkotlin/coroutines/Continuation<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    new-instance v0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$btnClearCache$1$1$1;

    iget-object v1, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$btnClearCache$1$1$1;->$config:Ldev/wiojelt/turksinema/common/WioSettingsConfig;

    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$btnClearCache$1$1$1;->$context:Landroid/content/Context;

    invoke-direct {v0, v1, v2, p2}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$btnClearCache$1$1$1;-><init>(Ldev/wiojelt/turksinema/common/WioSettingsConfig;Landroid/content/Context;Lkotlin/coroutines/Continuation;)V

    check-cast v0, Lkotlin/coroutines/Continuation;

    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    check-cast p2, Lkotlin/coroutines/Continuation;

    invoke-virtual {p0, p1, p2}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$btnClearCache$1$1$1;->invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public final invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/CoroutineScope;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    invoke-virtual {p0, p1, p2}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$btnClearCache$1$1$1;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    move-result-object v0

    check-cast v0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$btnClearCache$1$1$1;

    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    invoke-virtual {v0, v1}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$btnClearCache$1$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 12
    .param p1, "$result"  # Ljava/lang/Object;

    invoke-static {}, Lkotlin/coroutines/intrinsics/IntrinsicsKt;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object v0

    .line 469
    iget v1, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$btnClearCache$1$1$1;->label:I

    const/4 v2, 0x1

    packed-switch v1, :pswitch_data_a0

    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :pswitch_12  #0x1
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    move-object v1, p1

    goto :goto_36

    :pswitch_17  #0x0
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 470
    invoke-static {}, Lkotlinx/coroutines/Dispatchers;->getIO()Lkotlinx/coroutines/CoroutineDispatcher;

    move-result-object v1

    check-cast v1, Lkotlin/coroutines/CoroutineContext;

    new-instance v3, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$btnClearCache$1$1$1$freedBytes$1;

    iget-object v4, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$btnClearCache$1$1$1;->$context:Landroid/content/Context;

    const/4 v5, 0x0

    invoke-direct {v3, v4, v5}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$btnClearCache$1$1$1$freedBytes$1;-><init>(Landroid/content/Context;Lkotlin/coroutines/Continuation;)V

    check-cast v3, Lkotlin/jvm/functions/Function2;

    move-object v4, p0

    check-cast v4, Lkotlin/coroutines/Continuation;

    iput v2, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$btnClearCache$1$1$1;->label:I

    invoke-static {v1, v3, v4}, Lkotlinx/coroutines/BuildersKt;->withContext(Lkotlin/coroutines/CoroutineContext;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v1

    if-ne v1, v0, :cond_36

    .line 469
    return-object v0

    .line 470
    :cond_36
    :goto_36
    check-cast v1, Ljava/lang/Number;

    invoke-virtual {v1}, Ljava/lang/Number;->longValue()J

    move-result-wide v0

    .line 473
    .local v0, "freedBytes":J
    long-to-double v3, v0

    const-wide/high16 v5, 0x4130000000000000L  # 1048576.0

    div-double/2addr v3, v5

    .line 474
    .local v3, "mb":D
    const-wide v5, 0x3fb999999999999aL  # 0.1

    cmpl-double v5, v3, v5

    .line 477
    iget-object v6, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$btnClearCache$1$1$1;->$config:Ldev/wiojelt/turksinema/common/WioSettingsConfig;

    .line 474
    const/4 v7, 0x0

    if-ltz v5, :cond_85

    .line 475
    invoke-virtual {v6}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getEnglishLabels()Z

    move-result v5

    const-string v6, "format(...)"

    if-eqz v5, :cond_6b

    sget-object v5, Lkotlin/jvm/internal/StringCompanionObject;->INSTANCE:Lkotlin/jvm/internal/StringCompanionObject;

    sget-object v5, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-static {v3, v4}, Lkotlin/coroutines/jvm/internal/Boxing;->boxDouble(D)Ljava/lang/Double;

    move-result-object v8

    new-array v9, v2, [Ljava/lang/Object;

    aput-object v8, v9, v7

    invoke-static {v9, v2}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v2

    const-string v8, "✓ %.1f MB cache cleared"

    invoke-static {v5, v8, v2}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    goto :goto_81

    :cond_6b
    sget-object v5, Lkotlin/jvm/internal/StringCompanionObject;->INSTANCE:Lkotlin/jvm/internal/StringCompanionObject;

    sget-object v5, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-static {v3, v4}, Lkotlin/coroutines/jvm/internal/Boxing;->boxDouble(D)Ljava/lang/Double;

    move-result-object v8

    new-array v9, v2, [Ljava/lang/Object;

    aput-object v8, v9, v7

    invoke-static {v9, v2}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v2

    const-string v8, "✓ %.1f MB önbellek temizlendi"

    invoke-static {v5, v8, v2}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    :goto_81
    invoke-static {v2, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    goto :goto_90

    .line 477
    :cond_85
    invoke-virtual {v6}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getEnglishLabels()Z

    move-result v2

    if-eqz v2, :cond_8e

    const-string v2, "✓ Cache is already clear"

    goto :goto_90

    :cond_8e
    const-string v2, "✓ Önbellek zaten temiz"

    .line 474
    :goto_90
    nop

    .line 479
    .local v2, "msg":Ljava/lang/String;
    iget-object v5, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$btnClearCache$1$1$1;->$context:Landroid/content/Context;

    move-object v6, v2

    check-cast v6, Ljava/lang/CharSequence;

    invoke-static {v5, v6, v7}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v5

    invoke-virtual {v5}, Landroid/widget/Toast;->show()V

    .line 480
    sget-object v5, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v5

    :pswitch_data_a0
    .packed-switch 0x0
        :pswitch_17  #00000000
        :pswitch_12  #00000001
    .end packed-switch
.end method

.class public final synthetic Ldev/wiojelt/turksinema/common/WioPollNotice$$ExternalSyntheticLambda4;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x13
    versionHash = "7bbc1d7254613ffaa026de47d975f73968361ef3e5d7b818ce0a83a33039c6b8"
.end annotation


# instance fields
.field public final synthetic f$0:Landroid/os/Handler;

.field public final synthetic f$1:Landroid/content/SharedPreferences;

.field public final synthetic f$2:Landroid/widget/TextView;

.field public final synthetic f$3:Landroid/widget/ProgressBar;

.field public final synthetic f$4:Lcom/google/android/material/button/MaterialButton;

.field public final synthetic f$5:Lcom/google/android/material/button/MaterialButton;


# direct methods
.method public synthetic constructor <init>(Landroid/os/Handler;Landroid/content/SharedPreferences;Landroid/widget/TextView;Landroid/widget/ProgressBar;Lcom/google/android/material/button/MaterialButton;Lcom/google/android/material/button/MaterialButton;)V
    .registers 7

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/wiojelt/turksinema/common/WioPollNotice$$ExternalSyntheticLambda4;->f$0:Landroid/os/Handler;

    iput-object p2, p0, Ldev/wiojelt/turksinema/common/WioPollNotice$$ExternalSyntheticLambda4;->f$1:Landroid/content/SharedPreferences;

    iput-object p3, p0, Ldev/wiojelt/turksinema/common/WioPollNotice$$ExternalSyntheticLambda4;->f$2:Landroid/widget/TextView;

    iput-object p4, p0, Ldev/wiojelt/turksinema/common/WioPollNotice$$ExternalSyntheticLambda4;->f$3:Landroid/widget/ProgressBar;

    iput-object p5, p0, Ldev/wiojelt/turksinema/common/WioPollNotice$$ExternalSyntheticLambda4;->f$4:Lcom/google/android/material/button/MaterialButton;

    iput-object p6, p0, Ldev/wiojelt/turksinema/common/WioPollNotice$$ExternalSyntheticLambda4;->f$5:Lcom/google/android/material/button/MaterialButton;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 9

    .line 0
    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioPollNotice$$ExternalSyntheticLambda4;->f$0:Landroid/os/Handler;

    iget-object v1, p0, Ldev/wiojelt/turksinema/common/WioPollNotice$$ExternalSyntheticLambda4;->f$1:Landroid/content/SharedPreferences;

    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioPollNotice$$ExternalSyntheticLambda4;->f$2:Landroid/widget/TextView;

    iget-object v3, p0, Ldev/wiojelt/turksinema/common/WioPollNotice$$ExternalSyntheticLambda4;->f$3:Landroid/widget/ProgressBar;

    iget-object v4, p0, Ldev/wiojelt/turksinema/common/WioPollNotice$$ExternalSyntheticLambda4;->f$4:Lcom/google/android/material/button/MaterialButton;

    iget-object v5, p0, Ldev/wiojelt/turksinema/common/WioPollNotice$$ExternalSyntheticLambda4;->f$5:Lcom/google/android/material/button/MaterialButton;

    move-object v6, p1

    invoke-static/range {v0 .. v6}, Ldev/wiojelt/turksinema/common/WioPollNotice;->showDialog$lambda$25(Landroid/os/Handler;Landroid/content/SharedPreferences;Landroid/widget/TextView;Landroid/widget/ProgressBar;Lcom/google/android/material/button/MaterialButton;Lcom/google/android/material/button/MaterialButton;Landroid/view/View;)V

    return-void
.end method

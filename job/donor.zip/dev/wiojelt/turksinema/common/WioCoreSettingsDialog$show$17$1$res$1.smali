.class final Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1$res$1;
.super Lkotlin/coroutines/jvm/internal/SuspendLambda;
.source "WioCoreSettingsDialog.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/SuspendLambda;",
        "Lkotlin/jvm/functions/Function2<",
        "Lkotlinx/coroutines/CoroutineScope;",
        "Lkotlin/coroutines/Continuation<",
        "-",
        "Lkotlin/Pair<",
        "+",
        "Ljava/lang/Integer;",
        "+",
        "Ljava/lang/Integer;",
        ">;>;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0002\u0018\u0002\u0010\u0000\u001a\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00020\u0001*\u00020\u0003H\n"
    }
    d2 = {
        "<anonymous>",
        "Lkotlin/Pair;",
        "",
        "Lkotlinx/coroutines/CoroutineScope;"
    }
    k = 0x3
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "dev.wiojelt.turksinema.common.WioCoreSettingsDialog$show$17$1$res$1"
    f = "WioCoreSettingsDialog.kt"
    i = {
        0x0,
        0x0
    }
    l = {
        0x464
    }
    m = "invokeSuspend"
    n = {
        "$this$withContext",
        "$this$invokeSuspend_u24lambda_u240"
    }
    nl = {
        0x466
    }
    s = {
        "L$0",
        "L$1"
    }
    v = 0x2
.end annotation


# instance fields
.field final synthetic $config:Ldev/wiojelt/turksinema/common/WioSettingsConfig;

.field final synthetic $scanStatus:Landroid/widget/TextView;

.field private synthetic L$0:Ljava/lang/Object;

.field L$1:Ljava/lang/Object;

.field label:I


# direct methods
.method public static synthetic $r8$lambda$GUHFRq8UaRLF1MKNjQb8i-zpzdY(Landroid/widget/TextView;Ljava/lang/String;)Lkotlin/Unit;
    .registers 2

    invoke-static {p0, p1}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1$res$1;->invokeSuspend$lambda$0$0(Landroid/widget/TextView;Ljava/lang/String;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method constructor <init>(Ldev/wiojelt/turksinema/common/WioSettingsConfig;Landroid/widget/TextView;Lkotlin/coroutines/Continuation;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ldev/wiojelt/turksinema/common/WioSettingsConfig;",
            "Landroid/widget/TextView;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1$res$1;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1$res$1;->$config:Ldev/wiojelt/turksinema/common/WioSettingsConfig;

    iput-object p2, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1$res$1;->$scanStatus:Landroid/widget/TextView;

    const/4 v0, 0x2

    invoke-direct {p0, v0, p3}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/Continuation;)V

    return-void
.end method

.method private static final invokeSuspend$lambda$0$0(Landroid/widget/TextView;Ljava/lang/String;)Lkotlin/Unit;
    .registers 3
    .param p0, "$scanStatus"  # Landroid/widget/TextView;
    .param p1, "msg"  # Ljava/lang/String;

    .line 1125
    move-object v0, p1

    check-cast v0, Ljava/lang/CharSequence;

    invoke-virtual {p0, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1126
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/Continuation<",
            "*>;)",
            "Lkotlin/coroutines/Continuation<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    new-instance v0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1$res$1;

    iget-object v1, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1$res$1;->$config:Ldev/wiojelt/turksinema/common/WioSettingsConfig;

    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1$res$1;->$scanStatus:Landroid/widget/TextView;

    invoke-direct {v0, v1, v2, p2}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1$res$1;-><init>(Ldev/wiojelt/turksinema/common/WioSettingsConfig;Landroid/widget/TextView;Lkotlin/coroutines/Continuation;)V

    iput-object p1, v0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1$res$1;->L$0:Ljava/lang/Object;

    check-cast v0, Lkotlin/coroutines/Continuation;

    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    check-cast p2, Lkotlin/coroutines/Continuation;

    invoke-virtual {p0, p1, p2}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1$res$1;->invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public final invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/CoroutineScope;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lkotlin/Pair<",
            "Ljava/lang/Integer;",
            "Ljava/lang/Integer;",
            ">;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    invoke-virtual {p0, p1, p2}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1$res$1;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    move-result-object v0

    check-cast v0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1$res$1;

    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    invoke-virtual {v0, v1}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1$res$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 9
    .param p1, "$result"  # Ljava/lang/Object;

    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1$res$1;->L$0:Ljava/lang/Object;

    check-cast v0, Lkotlinx/coroutines/CoroutineScope;

    .local v0, "$this$withContext":Lkotlinx/coroutines/CoroutineScope;
    invoke-static {}, Lkotlin/coroutines/intrinsics/IntrinsicsKt;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object v1

    .line 1122
    iget v2, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1$res$1;->label:I

    packed-switch v2, :pswitch_data_74

    new-instance v1, Ljava/lang/IllegalStateException;

    const-string v2, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1

    :pswitch_15  #0x1
    const/4 v1, 0x0

    .local v1, "$i$a$-runCatching-WioCoreSettingsDialog$show$17$1$res$1$1":I
    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1$res$1;->L$1:Ljava/lang/Object;

    check-cast v2, Lkotlinx/coroutines/CoroutineScope;

    .local v2, "$this$invokeSuspend_u24lambda_u240":Lkotlinx/coroutines/CoroutineScope;
    :try_start_1a
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V
    :try_end_1d
    .catchall {:try_start_1a .. :try_end_1d} :catchall_53

    move-object v4, v2

    move-object v2, p1

    goto :goto_4b

    .end local v1  # "$i$a$-runCatching-WioCoreSettingsDialog$show$17$1$res$1$1":I
    .end local v2  # "$this$invokeSuspend_u24lambda_u240":Lkotlinx/coroutines/CoroutineScope;
    :pswitch_20  #0x0
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 1123
    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1$res$1;->$config:Ldev/wiojelt/turksinema/common/WioSettingsConfig;

    iget-object v3, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1$res$1;->$scanStatus:Landroid/widget/TextView;

    :try_start_27
    sget-object v4, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v4, v0

    .local v4, "$this$invokeSuspend_u24lambda_u240":Lkotlinx/coroutines/CoroutineScope;
    const/4 v5, 0x0

    .line 1124
    .local v5, "$i$a$-runCatching-WioCoreSettingsDialog$show$17$1$res$1$1":I
    invoke-virtual {v2}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getOnAutoScanDomains()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    new-instance v6, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1$res$1$$ExternalSyntheticLambda0;

    invoke-direct {v6, v3}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1$res$1$$ExternalSyntheticLambda0;-><init>(Landroid/widget/TextView;)V

    invoke-static {v0}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    iput-object v3, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1$res$1;->L$0:Ljava/lang/Object;

    invoke-static {v4}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    iput-object v3, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1$res$1;->L$1:Ljava/lang/Object;

    const/4 v3, 0x1

    iput v3, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1$res$1;->label:I

    invoke-interface {v2, v6, p0}, Lkotlin/jvm/functions/Function2;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    if-ne v2, v1, :cond_4a

    .line 1122
    return-object v1

    .line 1124
    :cond_4a
    move v1, v5

    .line 1122
    .end local v5  # "$i$a$-runCatching-WioCoreSettingsDialog$show$17$1$res$1$1":I
    .restart local v1  # "$i$a$-runCatching-WioCoreSettingsDialog$show$17$1$res$1$1":I
    :goto_4b
    check-cast v2, Lkotlin/Pair;

    .line 1126
    nop

    .line 1123
    .end local v1  # "$i$a$-runCatching-WioCoreSettingsDialog$show$17$1$res$1$1":I
    .end local v4  # "$this$invokeSuspend_u24lambda_u240":Lkotlinx/coroutines/CoroutineScope;
    invoke-static {v2}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1
    :try_end_52
    .catchall {:try_start_27 .. :try_end_52} :catchall_53

    goto :goto_5e

    :catchall_53
    move-exception v1

    sget-object v2, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v1}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v1

    invoke-static {v1}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    .line 1127
    :goto_5e
    const/4 v2, 0x0

    invoke-static {v2}, Lkotlin/coroutines/jvm/internal/Boxing;->boxInt(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v2}, Lkotlin/coroutines/jvm/internal/Boxing;->boxInt(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-static {v3, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    invoke-static {v1}, Lkotlin/Result;->isFailure-impl(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_72

    move-object v1, v2

    :cond_72
    return-object v1

    nop

    :pswitch_data_74
    .packed-switch 0x0
        :pswitch_20  #00000000
        :pswitch_15  #00000001
    .end packed-switch
.end method

.class public final synthetic Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda8;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x13
    versionHash = "7bbc1d7254613ffaa026de47d975f73968361ef3e5d7b818ce0a83a33039c6b8"
.end annotation


# instance fields
.field public final synthetic f$0:Landroid/widget/LinearLayout;

.field public final synthetic f$1:Lcom/google/android/material/button/MaterialButton;

.field public final synthetic f$2:Ldev/wiojelt/turksinema/common/WioSettingsConfig;


# direct methods
.method public synthetic constructor <init>(Landroid/widget/LinearLayout;Lcom/google/android/material/button/MaterialButton;Ldev/wiojelt/turksinema/common/WioSettingsConfig;)V
    .registers 4

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda8;->f$0:Landroid/widget/LinearLayout;

    iput-object p2, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda8;->f$1:Lcom/google/android/material/button/MaterialButton;

    iput-object p3, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda8;->f$2:Ldev/wiojelt/turksinema/common/WioSettingsConfig;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 5

    .line 0
    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda8;->f$0:Landroid/widget/LinearLayout;

    iget-object v1, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda8;->f$1:Lcom/google/android/material/button/MaterialButton;

    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda8;->f$2:Ldev/wiojelt/turksinema/common/WioSettingsConfig;

    invoke-static {v0, v1, v2, p1}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->$r8$lambda$8SvpXLb_9yZI5o2cwUm59tO9DFU(Landroid/widget/LinearLayout;Lcom/google/android/material/button/MaterialButton;Ldev/wiojelt/turksinema/common/WioSettingsConfig;Landroid/view/View;)V

    return-void
.end method

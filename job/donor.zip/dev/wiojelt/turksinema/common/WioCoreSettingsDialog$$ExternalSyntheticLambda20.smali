.class public final synthetic Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda20;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x13
    versionHash = "7bbc1d7254613ffaa026de47d975f73968361ef3e5d7b818ce0a83a33039c6b8"
.end annotation


# instance fields
.field public final synthetic f$0:Ldev/wiojelt/turksinema/common/WioSettingsConfig;


# direct methods
.method public synthetic constructor <init>(Ldev/wiojelt/turksinema/common/WioSettingsConfig;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda20;->f$0:Ldev/wiojelt/turksinema/common/WioSettingsConfig;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 3

    .line 0
    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda20;->f$0:Ldev/wiojelt/turksinema/common/WioSettingsConfig;

    invoke-static {v0, p1}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->$r8$lambda$1QNC4oC3yoy2pOZOiksw51Tkui4(Ldev/wiojelt/turksinema/common/WioSettingsConfig;Landroid/view/View;)V

    return-void
.end method

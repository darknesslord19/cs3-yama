.class public final Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;
.super Ljava/lang/Object;
.source "WioCoreSettingsDialog.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nWioCoreSettingsDialog.kt\nKotlin\n*S Kotlin\n*F\n+ 1 WioCoreSettingsDialog.kt\ndev/wiojelt/turksinema/common/WioCoreSettingsDialog\n+ 2 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 4 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 5 _Maps.kt\nkotlin/collections/MapsKt___MapsKt\n*L\n1#1,1205:1\n15101#2,2:1206\n15101#2,2:1208\n15101#2,2:1210\n2077#3,3:1212\n2077#3,3:1216\n777#3:1219\n873#3,2:1220\n1814#3,3:1222\n2068#3,2:1225\n2068#3,2:1227\n1987#3,4:1231\n2068#3,2:1235\n2068#3,2:1237\n2068#3,2:1241\n2068#3,2:1243\n1#4:1215\n221#5,2:1229\n221#5,2:1239\n*S KotlinDebug\n*F\n+ 1 WioCoreSettingsDialog.kt\ndev/wiojelt/turksinema/common/WioCoreSettingsDialog\n*L\n118#1:1206,2\n121#1:1208,2\n125#1:1210,2\n761#1:1212,3\n953#1:1216,3\n730#1:1219\n730#1:1220,2\n730#1:1222,3\n731#1:1225,2\n776#1:1227,2\n826#1:1231,4\n857#1:1235,2\n858#1:1237,2\n915#1:1241,2\n916#1:1243,2\n779#1:1229,2\n885#1:1239,2\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000J\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0012\u0010\u0004\u001a\u00020\u00052\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007H\u0002J\u000e\u0010\b\u001a\u00020\u00052\u0006\u0010\t\u001a\u00020\nJ\u000e\u0010\u000b\u001a\u00020\f2\u0006\u0010\t\u001a\u00020\nJP\u0010\r\u001a\u00020\u000e2\u0006\u0010\t\u001a\u00020\n2\u0006\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u00102\b\b\u0002\u0010\u0012\u001a\u00020\f2\b\b\u0002\u0010\u0013\u001a\u00020\u00142\b\b\u0002\u0010\u0015\u001a\u00020\u00142\u0012\u0010\u0016\u001a\u000e\u0012\u0004\u0012\u00020\u0010\u0012\u0004\u0012\u00020\u000e0\u0017J\u0016\u0010\u0018\u001a\u00020\u000e2\u0006\u0010\t\u001a\u00020\n2\u0006\u0010\u0019\u001a\u00020\u001a¨\u0006\u001b"
    }
    d2 = {
        "Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;",
        "",
        "<init>",
        "()V",
        "deleteRecursive",
        "",
        "file",
        "Ljava/io/File;",
        "clearCache",
        "context",
        "Landroid/content/Context;",
        "isAutoDetectedTvOrLowRam",
        "",
        "showEditDomainDialog",
        "",
        "providerName",
        "",
        "currentUrl",
        "englishLabels",
        "brandColor",
        "",
        "brandColorBorder",
        "onSave",
        "Lkotlin/Function1;",
        "show",
        "config",
        "Ldev/wiojelt/turksinema/common/WioSettingsConfig;",
        "DiziMom"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation

.annotation build Lkotlin/jvm/internal/SourceDebugExtension;
    value = {
        "SMAP\nWioCoreSettingsDialog.kt\nKotlin\n*S Kotlin\n*F\n+ 1 WioCoreSettingsDialog.kt\ndev/wiojelt/turksinema/common/WioCoreSettingsDialog\n+ 2 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 4 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 5 _Maps.kt\nkotlin/collections/MapsKt___MapsKt\n*L\n1#1,1205:1\n15101#2,2:1206\n15101#2,2:1208\n15101#2,2:1210\n2077#3,3:1212\n2077#3,3:1216\n777#3:1219\n873#3,2:1220\n1814#3,3:1222\n2068#3,2:1225\n2068#3,2:1227\n1987#3,4:1231\n2068#3,2:1235\n2068#3,2:1237\n2068#3,2:1241\n2068#3,2:1243\n1#4:1215\n221#5,2:1229\n221#5,2:1239\n*S KotlinDebug\n*F\n+ 1 WioCoreSettingsDialog.kt\ndev/wiojelt/turksinema/common/WioCoreSettingsDialog\n*L\n118#1:1206,2\n121#1:1208,2\n125#1:1210,2\n761#1:1212,3\n953#1:1216,3\n730#1:1219\n730#1:1220,2\n730#1:1222,3\n731#1:1225,2\n776#1:1227,2\n826#1:1231,4\n857#1:1235,2\n858#1:1237,2\n915#1:1241,2\n916#1:1243,2\n779#1:1229,2\n885#1:1239,2\n*E\n"
    }
.end annotation


# static fields
.field public static final INSTANCE:Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field


# direct methods
.method public static synthetic $r8$lambda$-Ua9ytvJRyfeTV8DPwYy4b8mUro(Landroid/app/Dialog;Landroid/view/View;)V
    .registers 2

    invoke-static {p0, p1}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$lambda$12$0(Landroid/app/Dialog;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$-nEz8_xgLj7dwupzM8xqIPfDhLE(Landroid/app/Dialog;Lkotlin/jvm/functions/Function0;Landroid/view/View;)V
    .registers 3

    invoke-static {p0, p1, p2}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$lambda$16$0$1(Landroid/app/Dialog;Lkotlin/jvm/functions/Function0;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$1QNC4oC3yoy2pOZOiksw51Tkui4(Ldev/wiojelt/turksinema/common/WioSettingsConfig;Landroid/view/View;)V
    .registers 2

    invoke-static {p0, p1}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$lambda$29$1(Ldev/wiojelt/turksinema/common/WioSettingsConfig;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$314usvR1xsplhTU4-DsZZXB8mL4(Lkotlin/jvm/internal/Ref$BooleanRef;Lkotlin/jvm/functions/Function0;Ldev/wiojelt/turksinema/common/WioSettingsConfig;Ljava/util/Map;Lkotlin/jvm/internal/Ref$ObjectRef;Ljava/util/Map;Landroid/view/View;)V
    .registers 7

    invoke-static/range {p0 .. p6}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$lambda$48$0$1(Lkotlin/jvm/internal/Ref$BooleanRef;Lkotlin/jvm/functions/Function0;Ldev/wiojelt/turksinema/common/WioSettingsConfig;Ljava/util/Map;Lkotlin/jvm/internal/Ref$ObjectRef;Ljava/util/Map;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$5CiQsZwyVaDo0iBFZoLQ0Y4kTqI(Lkotlin/jvm/internal/Ref$BooleanRef;Ldev/wiojelt/turksinema/common/WioProviderSettingItem;Lkotlin/jvm/internal/Ref$ObjectRef;Ldev/wiojelt/turksinema/common/WioSettingsConfig;Ljava/util/Map;Landroid/widget/CompoundButton;Z)V
    .registers 7

    invoke-static/range {p0 .. p6}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$lambda$55$8(Lkotlin/jvm/internal/Ref$BooleanRef;Ldev/wiojelt/turksinema/common/WioProviderSettingItem;Lkotlin/jvm/internal/Ref$ObjectRef;Ldev/wiojelt/turksinema/common/WioSettingsConfig;Ljava/util/Map;Landroid/widget/CompoundButton;Z)V

    return-void
.end method

.method public static synthetic $r8$lambda$5tbXKuoAcRkqAcCeYyk6Yv7u2JA(Lcom/google/android/material/button/MaterialButton;Landroid/content/Context;Ljava/lang/String;Landroid/view/View;)V
    .registers 4

    invoke-static {p0, p1, p2, p3}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$lambda$65$0$1(Lcom/google/android/material/button/MaterialButton;Landroid/content/Context;Ljava/lang/String;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$8SvpXLb_9yZI5o2cwUm59tO9DFU(Landroid/widget/LinearLayout;Lcom/google/android/material/button/MaterialButton;Ldev/wiojelt/turksinema/common/WioSettingsConfig;Landroid/view/View;)V
    .registers 4

    invoke-static {p0, p1, p2, p3}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$lambda$56$0(Landroid/widget/LinearLayout;Lcom/google/android/material/button/MaterialButton;Ldev/wiojelt/turksinema/common/WioSettingsConfig;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$G_BUif1Q3rkzRtcGt_PN7EFFdM4(Lcom/google/android/material/switchmaterial/SwitchMaterial;Landroid/view/View;)V
    .registers 2

    invoke-static {p0, p1}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$lambda$55$7(Lcom/google/android/material/switchmaterial/SwitchMaterial;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$J3ReLetiULDauCX46poTmd50KDw(Landroid/content/Context;Ldev/wiojelt/turksinema/common/WioProviderSettingItem;Ldev/wiojelt/turksinema/common/WioSettingsConfig;Landroid/widget/TextView;Landroid/view/View;)V
    .registers 5

    invoke-static {p0, p1, p2, p3, p4}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$lambda$55$5$0(Landroid/content/Context;Ldev/wiojelt/turksinema/common/WioProviderSettingItem;Ldev/wiojelt/turksinema/common/WioSettingsConfig;Landroid/widget/TextView;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$Kf7Aep4XI5plwzVAGGxP8lHPmP0(Lkotlin/jvm/internal/Ref$BooleanRef;Lkotlin/jvm/functions/Function0;Ljava/util/Map;Lkotlin/jvm/internal/Ref$ObjectRef;Ldev/wiojelt/turksinema/common/WioSettingsConfig;Ljava/util/Map;Landroid/view/View;)V
    .registers 7

    invoke-static/range {p0 .. p6}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$lambda$49$0$1(Lkotlin/jvm/internal/Ref$BooleanRef;Lkotlin/jvm/functions/Function0;Ljava/util/Map;Lkotlin/jvm/internal/Ref$ObjectRef;Ldev/wiojelt/turksinema/common/WioSettingsConfig;Ljava/util/Map;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$OQW2pk-rgdQ86vUFgmDNoh_n6ss(Ldev/wiojelt/turksinema/common/WioSettingsConfig;Landroid/app/Dialog;Landroid/view/View;)V
    .registers 3

    invoke-static {p0, p1, p2}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$lambda$15$0(Ldev/wiojelt/turksinema/common/WioSettingsConfig;Landroid/app/Dialog;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$QIMY8gpWQO7ogqNlK8IbflvbMAc(Lcom/google/android/material/button/MaterialButton;Landroid/content/Context;Ljava/lang/String;Landroid/view/View;)V
    .registers 4

    invoke-static {p0, p1, p2, p3}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$lambda$66$0$0(Lcom/google/android/material/button/MaterialButton;Landroid/content/Context;Ljava/lang/String;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$aJh5iIEjiHQfLYiPhiDJR5L5hiY(Lkotlin/jvm/internal/Ref$BooleanRef;Ldev/wiojelt/turksinema/common/WioSettingsConfig;Ljava/util/Map;Ldev/wiojelt/turksinema/common/WioSelectionPreset;Lkotlin/jvm/internal/Ref$ObjectRef;Ljava/util/Map;Landroid/view/View;)V
    .registers 7

    invoke-static/range {p0 .. p6}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$lambda$41$0$0(Lkotlin/jvm/internal/Ref$BooleanRef;Ldev/wiojelt/turksinema/common/WioSettingsConfig;Ljava/util/Map;Ldev/wiojelt/turksinema/common/WioSelectionPreset;Lkotlin/jvm/internal/Ref$ObjectRef;Ljava/util/Map;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$e4UQCDw7r6glFQ-eTCcGlyQtBu8(Landroid/app/Dialog;Ldev/wiojelt/turksinema/common/WioSettingsConfig;Landroid/view/View;)V
    .registers 3

    invoke-static {p0, p1, p2}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$lambda$28$0(Landroid/app/Dialog;Ldev/wiojelt/turksinema/common/WioSettingsConfig;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$hTP0F1oNDM_YWwuaDeVdllTH4ok(Lkotlinx/coroutines/CoroutineScope;Ldev/wiojelt/turksinema/common/WioSettingsConfig;Landroid/content/Context;Landroid/view/View;)V
    .registers 4

    invoke-static {p0, p1, p2, p3}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$lambda$14$1(Lkotlinx/coroutines/CoroutineScope;Ldev/wiojelt/turksinema/common/WioSettingsConfig;Landroid/content/Context;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$jZIjPPjGr7YTfPxmPR0zAwVqj5w(Landroid/app/Dialog;Landroid/view/View;)V
    .registers 2

    invoke-static {p0, p1}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog$lambda$13$0(Landroid/app/Dialog;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$swFlOR6rSB793u2lN1P7mkvhNII(Ldev/wiojelt/turksinema/common/WioProviderSettingItem;Landroid/widget/TextView;Ljava/lang/String;)Lkotlin/Unit;
    .registers 3

    invoke-static {p0, p1, p2}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$lambda$55$5$0$0(Ldev/wiojelt/turksinema/common/WioProviderSettingItem;Landroid/widget/TextView;Ljava/lang/String;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$ubUm-7Rn_fhV2-6jf9Uz8cEkSWE(Landroid/widget/EditText;Landroid/content/Context;ZLcom/google/android/material/button/MaterialButton;Lkotlin/jvm/functions/Function1;Ljava/lang/String;Landroid/app/Dialog;Landroid/view/View;)V
    .registers 8

    invoke-static/range {p0 .. p7}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog$lambda$14$0(Landroid/widget/EditText;Landroid/content/Context;ZLcom/google/android/material/button/MaterialButton;Lkotlin/jvm/functions/Function1;Ljava/lang/String;Landroid/app/Dialog;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$udbt9-9xBVjx6g1jzvpOJOuISZ8(Lkotlin/jvm/internal/Ref$BooleanRef;Lkotlin/jvm/functions/Function0;Ldev/wiojelt/turksinema/common/WioSettingsConfig;Ljava/util/Map;Lkotlin/jvm/internal/Ref$ObjectRef;Ljava/util/Map;Landroid/view/View;)V
    .registers 7

    invoke-static/range {p0 .. p6}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$lambda$50$0$0(Lkotlin/jvm/internal/Ref$BooleanRef;Lkotlin/jvm/functions/Function0;Ldev/wiojelt/turksinema/common/WioSettingsConfig;Ljava/util/Map;Lkotlin/jvm/internal/Ref$ObjectRef;Ljava/util/Map;Landroid/view/View;)V

    return-void
.end method

.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;

    invoke-direct {v0}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;-><init>()V

    sput-object v0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->INSTANCE:Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 95
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static final synthetic access$show$refreshScanDurationUi(Ldev/wiojelt/turksinema/common/WioSettingsConfig;Lkotlin/jvm/internal/Ref$ObjectRef;Lkotlin/jvm/internal/Ref$ObjectRef;Z)V
    .registers 4
    .param p0, "$config"  # Ldev/wiojelt/turksinema/common/WioSettingsConfig;
    .param p1, "scanDurationLabel"  # Lkotlin/jvm/internal/Ref$ObjectRef;
    .param p2, "scanDurationSeekBar"  # Lkotlin/jvm/internal/Ref$ObjectRef;
    .param p3, "tvBoxActive"  # Z

    .line 95
    invoke-static {p0, p1, p2, p3}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$refreshScanDurationUi(Ldev/wiojelt/turksinema/common/WioSettingsConfig;Lkotlin/jvm/internal/Ref$ObjectRef;Lkotlin/jvm/internal/Ref$ObjectRef;Z)V

    return-void
.end method

.method public static final synthetic access$showEditDomainDialog$updateIncrementBtn(Landroid/widget/EditText;Lcom/google/android/material/button/MaterialButton;Z)V
    .registers 3
    .param p0, "input"  # Landroid/widget/EditText;
    .param p1, "btnIncrement"  # Lcom/google/android/material/button/MaterialButton;
    .param p2, "$englishLabels"  # Z

    .line 95
    invoke-static {p0, p1, p2}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog$updateIncrementBtn(Landroid/widget/EditText;Lcom/google/android/material/button/MaterialButton;Z)V

    return-void
.end method

.method private final deleteRecursive(Ljava/io/File;)J
    .registers 10
    .param p1, "file"  # Ljava/io/File;

    .line 98
    if-eqz p1, :cond_31

    invoke-virtual {p1}, Ljava/io/File;->exists()Z

    move-result v0

    if-nez v0, :cond_9

    goto :goto_31

    .line 99
    :cond_9
    const-wide/16 v0, 0x0

    .line 100
    .local v0, "bytes":J
    invoke-virtual {p1}, Ljava/io/File;->isDirectory()Z

    move-result v2

    if-eqz v2, :cond_25

    .line 101
    invoke-virtual {p1}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object v2

    .line 102
    .local v2, "children":[Ljava/io/File;
    if-eqz v2, :cond_25

    .line 103
    array-length v3, v2

    const/4 v4, 0x0

    :goto_19
    if-ge v4, v3, :cond_25

    aget-object v5, v2, v4

    .line 104
    .local v5, "child":Ljava/io/File;
    invoke-direct {p0, v5}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->deleteRecursive(Ljava/io/File;)J

    move-result-wide v6

    add-long/2addr v0, v6

    .line 103
    .end local v5  # "child":Ljava/io/File;
    add-int/lit8 v4, v4, 0x1

    goto :goto_19

    .line 108
    .end local v2  # "children":[Ljava/io/File;
    :cond_25
    invoke-virtual {p1}, Ljava/io/File;->length()J

    move-result-wide v2

    .line 109
    .local v2, "len":J
    invoke-virtual {p1}, Ljava/io/File;->delete()Z

    move-result v4

    if-eqz v4, :cond_30

    .line 110
    add-long/2addr v0, v2

    .line 112
    :cond_30
    return-wide v0

    .line 98
    .end local v0  # "bytes":J
    .end local v2  # "len":J
    :cond_31
    :goto_31
    const-wide/16 v0, 0x0

    return-wide v0
.end method

.method private static final show$dp(Landroid/content/Context;I)I
    .registers 4
    .param p0, "$context"  # Landroid/content/Context;
    .param p1, "value"  # I

    .line 339
    int-to-float v0, p1

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v1

    iget v1, v1, Landroid/util/DisplayMetrics;->density:F

    mul-float/2addr v0, v1

    float-to-int v0, v0

    return v0
.end method

.method private static final show$focusableGlassDrawable(Ldev/wiojelt/turksinema/common/WioSettingsConfig;Landroid/content/Context;IIIIF)Landroid/graphics/drawable/StateListDrawable;
    .registers 15
    .param p0, "$config"  # Ldev/wiojelt/turksinema/common/WioSettingsConfig;
    .param p1, "$context"  # Landroid/content/Context;
    .param p2, "normalBg"  # I
    .param p3, "normalBorder"  # I
    .param p4, "focusedBg"  # I
    .param p5, "focusedBorder"  # I
    .param p6, "radiusDp"  # F

    .line 348
    new-instance v0, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v0}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object v1, v0

    .local v1, "$this$show_u24focusableGlassDrawable_u24lambda_u240":Landroid/graphics/drawable/GradientDrawable;
    const/4 v2, 0x0

    .line 349
    .local v2, "$i$a$-apply-WioCoreSettingsDialog$show$focusableGlassDrawable$normal$1":I
    const/4 v3, 0x0

    invoke-virtual {v1, v3}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    .line 350
    float-to-int v4, p6

    invoke-static {p1, v4}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v4

    int-to-float v4, v4

    invoke-virtual {v1, v4}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 351
    invoke-virtual {v1, p2}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 352
    const/4 v4, 0x1

    invoke-static {p1, v4}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v4

    invoke-virtual {v1, v4, p3}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 353
    nop

    .line 348
    .end local v1  # "$this$show_u24focusableGlassDrawable_u24lambda_u240":Landroid/graphics/drawable/GradientDrawable;
    .end local v2  # "$i$a$-apply-WioCoreSettingsDialog$show$focusableGlassDrawable$normal$1":I
    nop

    .line 354
    .local v0, "normal":Landroid/graphics/drawable/GradientDrawable;
    new-instance v1, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v1}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object v2, v1

    .local v2, "$this$show_u24focusableGlassDrawable_u24lambda_u241":Landroid/graphics/drawable/GradientDrawable;
    const/4 v4, 0x0

    .line 355
    .local v4, "$i$a$-apply-WioCoreSettingsDialog$show$focusableGlassDrawable$focused$1":I
    invoke-virtual {v2, v3}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    .line 356
    float-to-int v5, p6

    invoke-static {p1, v5}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v5

    int-to-float v5, v5

    invoke-virtual {v2, v5}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 357
    invoke-virtual {v2, p4}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 358
    const/4 v5, 0x2

    invoke-static {p1, v5}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v5

    invoke-virtual {v2, v5, p5}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 359
    nop

    .line 354
    .end local v2  # "$this$show_u24focusableGlassDrawable_u24lambda_u241":Landroid/graphics/drawable/GradientDrawable;
    .end local v4  # "$i$a$-apply-WioCoreSettingsDialog$show$focusableGlassDrawable$focused$1":I
    nop

    .line 360
    .local v1, "focused":Landroid/graphics/drawable/GradientDrawable;
    new-instance v2, Landroid/graphics/drawable/StateListDrawable;

    invoke-direct {v2}, Landroid/graphics/drawable/StateListDrawable;-><init>()V

    move-object v4, v2

    .local v4, "$this$show_u24focusableGlassDrawable_u24lambda_u242":Landroid/graphics/drawable/StateListDrawable;
    const/4 v5, 0x0

    .line 361
    .local v5, "$i$a$-apply-WioCoreSettingsDialog$show$focusableGlassDrawable$1":I
    const v6, 0x101009c

    filled-new-array {v6}, [I

    move-result-object v6

    move-object v7, v1

    check-cast v7, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v4, v6, v7}, Landroid/graphics/drawable/StateListDrawable;->addState([ILandroid/graphics/drawable/Drawable;)V

    .line 362
    const v6, 0x10100a7

    filled-new-array {v6}, [I

    move-result-object v6

    move-object v7, v1

    check-cast v7, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v4, v6, v7}, Landroid/graphics/drawable/StateListDrawable;->addState([ILandroid/graphics/drawable/Drawable;)V

    .line 363
    new-array v3, v3, [I

    move-object v6, v0

    check-cast v6, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v4, v3, v6}, Landroid/graphics/drawable/StateListDrawable;->addState([ILandroid/graphics/drawable/Drawable;)V

    .line 364
    nop

    .line 360
    .end local v4  # "$this$show_u24focusableGlassDrawable_u24lambda_u242":Landroid/graphics/drawable/StateListDrawable;
    .end local v5  # "$i$a$-apply-WioCoreSettingsDialog$show$focusableGlassDrawable$1":I
    return-object v2
.end method

.method static synthetic show$focusableGlassDrawable$default(Ldev/wiojelt/turksinema/common/WioSettingsConfig;Landroid/content/Context;IIIIFILjava/lang/Object;)Landroid/graphics/drawable/StateListDrawable;
    .registers 16

    .line 341
    and-int/lit8 p8, p7, 0x4

    if-eqz p8, :cond_a

    .line 342
    invoke-virtual {p0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getCardBg()I

    move-result p2

    move v2, p2

    goto :goto_b

    .line 341
    :cond_a
    move v2, p2

    :goto_b
    and-int/lit8 p2, p7, 0x8

    if-eqz p2, :cond_17

    .line 343
    const-string p2, "#26FFFFFF"

    invoke-static {p2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result p3

    move v3, p3

    goto :goto_18

    .line 341
    :cond_17
    move v3, p3

    :goto_18
    and-int/lit8 p2, p7, 0x10

    if-eqz p2, :cond_24

    .line 344
    const-string p2, "#E6252936"

    invoke-static {p2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result p4

    move v4, p4

    goto :goto_25

    .line 341
    :cond_24
    move v4, p4

    :goto_25
    and-int/lit8 p2, p7, 0x20

    if-eqz p2, :cond_31

    .line 345
    const-string p2, "#80FFFFFF"

    invoke-static {p2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result p5

    move v5, p5

    goto :goto_32

    .line 341
    :cond_31
    move v5, p5

    :goto_32
    and-int/lit8 p2, p7, 0x40

    if-eqz p2, :cond_3a

    .line 346
    const/high16 p6, 0x41800000  # 16.0f

    move v6, p6

    goto :goto_3b

    .line 341
    :cond_3a
    move v6, p6

    :goto_3b
    move-object v0, p0

    move-object v1, p1

    invoke-static/range {v0 .. v6}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$focusableGlassDrawable(Ldev/wiojelt/turksinema/common/WioSettingsConfig;Landroid/content/Context;IIIIF)Landroid/graphics/drawable/StateListDrawable;

    move-result-object p0

    return-object p0
.end method

.method private static final show$lambda$12$0(Landroid/app/Dialog;Landroid/view/View;)V
    .registers 2
    .param p0, "$dialog"  # Landroid/app/Dialog;
    .param p1, "it"  # Landroid/view/View;

    .line 442
    invoke-virtual {p0}, Landroid/app/Dialog;->dismiss()V

    return-void
.end method

.method private static final show$lambda$14$1(Lkotlinx/coroutines/CoroutineScope;Ldev/wiojelt/turksinema/common/WioSettingsConfig;Landroid/content/Context;Landroid/view/View;)V
    .registers 12
    .param p0, "$scope"  # Lkotlinx/coroutines/CoroutineScope;
    .param p1, "$config"  # Ldev/wiojelt/turksinema/common/WioSettingsConfig;
    .param p2, "$context"  # Landroid/content/Context;
    .param p3, "it"  # Landroid/view/View;

    .line 469
    new-instance v0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$btnClearCache$1$1$1;

    const/4 v1, 0x0

    invoke-direct {v0, p1, p2, v1}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$btnClearCache$1$1$1;-><init>(Ldev/wiojelt/turksinema/common/WioSettingsConfig;Landroid/content/Context;Lkotlin/coroutines/Continuation;)V

    move-object v5, v0

    check-cast v5, Lkotlin/jvm/functions/Function2;

    const/4 v6, 0x3

    const/4 v7, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    move-object v2, p0

    .end local p0  # "$scope":Lkotlinx/coroutines/CoroutineScope;
    .local v2, "$scope":Lkotlinx/coroutines/CoroutineScope;
    invoke-static/range {v2 .. v7}, Lkotlinx/coroutines/BuildersKt;->launch$default(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/CoroutineContext;Lkotlinx/coroutines/CoroutineStart;Lkotlin/jvm/functions/Function2;ILjava/lang/Object;)Lkotlinx/coroutines/Job;

    .line 481
    return-void
.end method

.method private static final show$lambda$15$0(Ldev/wiojelt/turksinema/common/WioSettingsConfig;Landroid/app/Dialog;Landroid/view/View;)V
    .registers 4
    .param p0, "$config"  # Ldev/wiojelt/turksinema/common/WioSettingsConfig;
    .param p1, "$dialog"  # Landroid/app/Dialog;
    .param p2, "it"  # Landroid/view/View;

    .line 495
    invoke-virtual {p0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getOnSaveAndClose()Lkotlin/jvm/functions/Function0;

    move-result-object v0

    if-eqz v0, :cond_9

    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 496
    :cond_9
    invoke-virtual {p1}, Landroid/app/Dialog;->dismiss()V

    .line 497
    return-void
.end method

.method private static final show$lambda$16$0$1(Landroid/app/Dialog;Lkotlin/jvm/functions/Function0;Landroid/view/View;)V
    .registers 3
    .param p0, "$dialog"  # Landroid/app/Dialog;
    .param p1, "$onCustomList"  # Lkotlin/jvm/functions/Function0;
    .param p2, "it"  # Landroid/view/View;

    .line 518
    invoke-virtual {p0}, Landroid/app/Dialog;->dismiss()V

    .line 519
    invoke-interface {p1}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 520
    return-void
.end method

.method static final show$lambda$23(Lcom/google/android/material/switchmaterial/SwitchMaterial;Landroid/view/View;)V
    .registers 3
    .param p0, "$tvBoxSwitch"  # Lcom/google/android/material/switchmaterial/SwitchMaterial;
    .param p1, "it"  # Landroid/view/View;

    .line 592
    invoke-virtual {p0}, Lcom/google/android/material/switchmaterial/SwitchMaterial;->isChecked()Z

    move-result v0

    xor-int/lit8 v0, v0, 0x1

    invoke-virtual {p0, v0}, Lcom/google/android/material/switchmaterial/SwitchMaterial;->setChecked(Z)V

    .line 593
    return-void
.end method

.method static final show$lambda$24(Ldev/wiojelt/turksinema/common/WioSettingsConfig;Lkotlin/jvm/internal/Ref$ObjectRef;Lkotlin/jvm/internal/Ref$ObjectRef;Landroid/widget/CompoundButton;Z)V
    .registers 6
    .param p0, "$config"  # Ldev/wiojelt/turksinema/common/WioSettingsConfig;
    .param p1, "$scanDurationLabel"  # Lkotlin/jvm/internal/Ref$ObjectRef;
    .param p2, "$scanDurationSeekBar"  # Lkotlin/jvm/internal/Ref$ObjectRef;
    .param p4, "isChecked"  # Z

    .line 595
    invoke-virtual {p0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getOnTvBoxToggled()Lkotlin/jvm/functions/Function1;

    move-result-object p3

    invoke-static {p4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    invoke-interface {p3, v0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 596
    invoke-static {p0, p1, p2, p4}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$refreshScanDurationUi(Ldev/wiojelt/turksinema/common/WioSettingsConfig;Lkotlin/jvm/internal/Ref$ObjectRef;Lkotlin/jvm/internal/Ref$ObjectRef;Z)V

    .line 597
    return-void
.end method

.method private static final show$lambda$28$0(Landroid/app/Dialog;Ldev/wiojelt/turksinema/common/WioSettingsConfig;Landroid/view/View;)V
    .registers 4
    .param p0, "$dialog"  # Landroid/app/Dialog;
    .param p1, "$config"  # Ldev/wiojelt/turksinema/common/WioSettingsConfig;
    .param p2, "it"  # Landroid/view/View;

    .line 661
    invoke-virtual {p0}, Landroid/app/Dialog;->dismiss()V

    .line 662
    invoke-virtual {p1}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getOnWizardClick()Lkotlin/jvm/functions/Function0;

    move-result-object v0

    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 663
    return-void
.end method

.method private static final show$lambda$29$1(Ldev/wiojelt/turksinema/common/WioSettingsConfig;Landroid/view/View;)V
    .registers 3
    .param p0, "$config"  # Ldev/wiojelt/turksinema/common/WioSettingsConfig;
    .param p1, "it"  # Landroid/view/View;

    .line 681
    invoke-virtual {p0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getOnCustomListClick()Lkotlin/jvm/functions/Function0;

    move-result-object v0

    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 682
    return-void
.end method

.method static final show$lambda$35()Lkotlin/Unit;
    .registers 1

    .line 725
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final show$lambda$41$0$0(Lkotlin/jvm/internal/Ref$BooleanRef;Ldev/wiojelt/turksinema/common/WioSettingsConfig;Ljava/util/Map;Ldev/wiojelt/turksinema/common/WioSelectionPreset;Lkotlin/jvm/internal/Ref$ObjectRef;Ljava/util/Map;Landroid/view/View;)V
    .registers 16
    .param p0, "$isBulkUpdating"  # Lkotlin/jvm/internal/Ref$BooleanRef;
    .param p1, "$config"  # Ldev/wiojelt/turksinema/common/WioSettingsConfig;
    .param p2, "$switchMap"  # Ljava/util/Map;
    .param p3, "$preset"  # Ldev/wiojelt/turksinema/common/WioSelectionPreset;
    .param p4, "$updateCounterText"  # Lkotlin/jvm/internal/Ref$ObjectRef;
    .param p5, "$presetButtons"  # Ljava/util/Map;
    .param p6, "it"  # Landroid/view/View;

    .line 774
    const/4 v0, 0x1

    iput-boolean v0, p0, Lkotlin/jvm/internal/Ref$BooleanRef;->element:Z

    .line 775
    nop

    .line 776
    const/4 v0, 0x0

    :try_start_5
    invoke-virtual {p1}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getItems()Ljava/util/List;

    move-result-object v1

    check-cast v1, Ljava/lang/Iterable;

    .local v1, "$this$forEach$iv":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 1227
    .local v2, "$i$f$forEach":I
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_10
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_30

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    .local v4, "element$iv":Ljava/lang/Object;
    move-object v5, v4

    check-cast v5, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;

    .local v5, "item":Ldev/wiojelt/turksinema/common/WioProviderSettingItem;
    const/4 v6, 0x0

    .line 777
    .local v6, "$i$a$-forEach-WioCoreSettingsDialog$show$7$presetButton$1$1$1":I
    invoke-virtual {p3}, Ldev/wiojelt/turksinema/common/WioSelectionPreset;->getProviderIds()Ljava/util/Set;

    move-result-object v7

    invoke-virtual {v5}, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->getId()Ljava/lang/String;

    move-result-object v8

    invoke-interface {v7, v8}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v7

    invoke-virtual {v5, v7}, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->setEnabled(Z)V

    .line 778
    nop

    .line 1227
    .end local v5  # "item":Ldev/wiojelt/turksinema/common/WioProviderSettingItem;
    .end local v6  # "$i$a$-forEach-WioCoreSettingsDialog$show$7$presetButton$1$1$1":I
    nop

    .end local v4  # "element$iv":Ljava/lang/Object;
    goto :goto_10

    .line 1228
    :cond_30
    nop

    .line 779
    .end local v1  # "$this$forEach$iv":Ljava/lang/Iterable;
    .end local v2  # "$i$f$forEach":I
    move-object v1, p2

    .local v1, "$this$forEach$iv":Ljava/util/Map;
    const/4 v2, 0x0

    .line 1229
    .restart local v2  # "$i$f$forEach":I
    invoke-interface {v1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_3b
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_61

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/util/Map$Entry;

    .local v4, "element$iv":Ljava/util/Map$Entry;
    const/4 v5, 0x0

    .local v5, "$i$a$-forEach-WioCoreSettingsDialog$show$7$presetButton$1$1$2":I
    invoke-interface {v4}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    .local v6, "id":Ljava/lang/String;
    invoke-interface {v4}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lcom/google/android/material/switchmaterial/SwitchMaterial;

    .line 779
    .local v7, "sw":Lcom/google/android/material/switchmaterial/SwitchMaterial;
    invoke-virtual {p3}, Ldev/wiojelt/turksinema/common/WioSelectionPreset;->getProviderIds()Ljava/util/Set;

    move-result-object v8

    invoke-interface {v8, v6}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v8

    invoke-virtual {v7, v8}, Lcom/google/android/material/switchmaterial/SwitchMaterial;->setChecked(Z)V

    .line 1229
    .end local v5  # "$i$a$-forEach-WioCoreSettingsDialog$show$7$presetButton$1$1$2":I
    .end local v6  # "id":Ljava/lang/String;
    .end local v7  # "sw":Lcom/google/android/material/switchmaterial/SwitchMaterial;
    nop

    .end local v4  # "element$iv":Ljava/util/Map$Entry;
    goto :goto_3b

    .line 1230
    :cond_61
    nop

    .line 780
    .end local v1  # "$this$forEach$iv":Ljava/util/Map;
    .end local v2  # "$i$f$forEach":I
    invoke-virtual {p1}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getOnSelectionPreset()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    if-eqz v1, :cond_73

    invoke-virtual {p3}, Ldev/wiojelt/turksinema/common/WioSelectionPreset;->getId()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p3}, Ldev/wiojelt/turksinema/common/WioSelectionPreset;->getProviderIds()Ljava/util/Set;

    move-result-object v3

    invoke-interface {v1, v2, v3}, Lkotlin/jvm/functions/Function2;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 781
    :cond_73
    iget-object v1, p4, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    check-cast v1, Lkotlin/jvm/functions/Function0;

    invoke-interface {v1}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 782
    invoke-static {p1, p5}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$refreshPresetButtons(Ldev/wiojelt/turksinema/common/WioSettingsConfig;Ljava/util/Map;)V
    :try_end_7d
    .catchall {:try_start_5 .. :try_end_7d} :catchall_81

    .line 784
    iput-boolean v0, p0, Lkotlin/jvm/internal/Ref$BooleanRef;->element:Z

    .line 785
    nop

    .line 786
    return-void

    .line 784
    :catchall_81
    move-exception v1

    iput-boolean v0, p0, Lkotlin/jvm/internal/Ref$BooleanRef;->element:Z

    throw v1
.end method

.method static final show$lambda$46(Ldev/wiojelt/turksinema/common/WioSettingsConfig;Landroid/widget/TextView;)Lkotlin/Unit;
    .registers 9
    .param p0, "$config"  # Ldev/wiojelt/turksinema/common/WioSettingsConfig;
    .param p1, "$providersHeader"  # Landroid/widget/TextView;

    .line 826
    invoke-virtual {p0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getItems()Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$count$iv":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 1231
    .local v1, "$i$f$count":I
    instance-of v2, v0, Ljava/util/Collection;

    if-eqz v2, :cond_16

    move-object v2, v0

    check-cast v2, Ljava/util/Collection;

    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_16

    const/4 v2, 0x0

    goto :goto_38

    .line 1232
    :cond_16
    const/4 v2, 0x0

    .line 1233
    .local v2, "count$iv":I
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_1b
    :goto_1b
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_37

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    .local v4, "element$iv":Ljava/lang/Object;
    move-object v5, v4

    check-cast v5, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;

    .local v5, "it":Ldev/wiojelt/turksinema/common/WioProviderSettingItem;
    const/4 v6, 0x0

    .line 826
    .local v6, "$i$a$-count-WioCoreSettingsDialog$show$9$enabledCount$1":I
    invoke-virtual {v5}, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->isEnabled()Z

    move-result v5

    .line 1233
    .end local v5  # "it":Ldev/wiojelt/turksinema/common/WioProviderSettingItem;
    .end local v6  # "$i$a$-count-WioCoreSettingsDialog$show$9$enabledCount$1":I
    if-eqz v5, :cond_1b

    add-int/lit8 v2, v2, 0x1

    if-gez v2, :cond_1b

    invoke-static {}, Lkotlin/collections/CollectionsKt;->throwCountOverflow()V

    .end local v4  # "element$iv":Ljava/lang/Object;
    goto :goto_1b

    .line 1234
    :cond_37
    nop

    .line 826
    .end local v0  # "$this$count$iv":Ljava/lang/Iterable;
    .end local v1  # "$i$f$count":I
    .end local v2  # "count$iv":I
    :goto_38
    nop

    .line 827
    .local v2, "enabledCount":I
    invoke-virtual {p0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getEnglishLabels()Z

    move-result v0

    const-string v1, ")"

    const-string v3, "/"

    if-eqz v0, :cond_53

    invoke-virtual {p0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getItems()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "Providers ("

    goto :goto_62

    :cond_53
    invoke-virtual {p0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getItems()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "Sağlayıcılar ("

    :goto_62
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    check-cast v0, Ljava/lang/CharSequence;

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 828
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final show$lambda$48$0$1(Lkotlin/jvm/internal/Ref$BooleanRef;Lkotlin/jvm/functions/Function0;Ldev/wiojelt/turksinema/common/WioSettingsConfig;Ljava/util/Map;Lkotlin/jvm/internal/Ref$ObjectRef;Ljava/util/Map;Landroid/view/View;)V
    .registers 15
    .param p0, "$isBulkUpdating"  # Lkotlin/jvm/internal/Ref$BooleanRef;
    .param p1, "$onAll"  # Lkotlin/jvm/functions/Function0;
    .param p2, "$config"  # Ldev/wiojelt/turksinema/common/WioSettingsConfig;
    .param p3, "$switchMap"  # Ljava/util/Map;
    .param p4, "$updateCounterText"  # Lkotlin/jvm/internal/Ref$ObjectRef;
    .param p5, "$presetButtons"  # Ljava/util/Map;
    .param p6, "it"  # Landroid/view/View;

    .line 854
    const/4 v0, 0x1

    iput-boolean v0, p0, Lkotlin/jvm/internal/Ref$BooleanRef;->element:Z

    .line 855
    nop

    .line 856
    const/4 v1, 0x0

    :try_start_5
    invoke-interface {p1}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 857
    invoke-virtual {p2}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getItems()Ljava/util/List;

    move-result-object v2

    check-cast v2, Ljava/lang/Iterable;

    .local v2, "$this$forEach$iv":Ljava/lang/Iterable;
    const/4 v3, 0x0

    .line 1235
    .local v3, "$i$f$forEach":I
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_13
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_26

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    .local v5, "element$iv":Ljava/lang/Object;
    move-object v6, v5

    check-cast v6, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;

    .local v6, "it":Ldev/wiojelt/turksinema/common/WioProviderSettingItem;
    const/4 v7, 0x0

    .line 857
    .local v7, "$i$a$-forEach-WioCoreSettingsDialog$show$10$btnAll$1$1$1":I
    invoke-virtual {v6, v0}, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->setEnabled(Z)V

    .line 1235
    .end local v6  # "it":Ldev/wiojelt/turksinema/common/WioProviderSettingItem;
    .end local v7  # "$i$a$-forEach-WioCoreSettingsDialog$show$10$btnAll$1$1$1":I
    nop

    .end local v5  # "element$iv":Ljava/lang/Object;
    goto :goto_13

    .line 1236
    :cond_26
    nop

    .line 858
    .end local v2  # "$this$forEach$iv":Ljava/lang/Iterable;
    .end local v3  # "$i$f$forEach":I
    invoke-interface {p3}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v2

    check-cast v2, Ljava/lang/Iterable;

    .restart local v2  # "$this$forEach$iv":Ljava/lang/Iterable;
    const/4 v3, 0x0

    .line 1237
    .restart local v3  # "$i$f$forEach":I
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_32
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_45

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    .restart local v5  # "element$iv":Ljava/lang/Object;
    move-object v6, v5

    check-cast v6, Lcom/google/android/material/switchmaterial/SwitchMaterial;

    .local v6, "it":Lcom/google/android/material/switchmaterial/SwitchMaterial;
    const/4 v7, 0x0

    .line 858
    .local v7, "$i$a$-forEach-WioCoreSettingsDialog$show$10$btnAll$1$1$2":I
    invoke-virtual {v6, v0}, Lcom/google/android/material/switchmaterial/SwitchMaterial;->setChecked(Z)V

    .line 1237
    .end local v6  # "it":Lcom/google/android/material/switchmaterial/SwitchMaterial;
    .end local v7  # "$i$a$-forEach-WioCoreSettingsDialog$show$10$btnAll$1$1$2":I
    nop

    .end local v5  # "element$iv":Ljava/lang/Object;
    goto :goto_32

    .line 1238
    :cond_45
    nop

    .line 859
    .end local v2  # "$this$forEach$iv":Ljava/lang/Iterable;
    .end local v3  # "$i$f$forEach":I
    iget-object v0, p4, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    check-cast v0, Lkotlin/jvm/functions/Function0;

    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 860
    invoke-static {p2, p5}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$refreshPresetButtons(Ldev/wiojelt/turksinema/common/WioSettingsConfig;Ljava/util/Map;)V
    :try_end_50
    .catchall {:try_start_5 .. :try_end_50} :catchall_54

    .line 862
    iput-boolean v1, p0, Lkotlin/jvm/internal/Ref$BooleanRef;->element:Z

    .line 863
    nop

    .line 864
    return-void

    .line 862
    :catchall_54
    move-exception v0

    iput-boolean v1, p0, Lkotlin/jvm/internal/Ref$BooleanRef;->element:Z

    throw v0
.end method

.method private static final show$lambda$49$0$1(Lkotlin/jvm/internal/Ref$BooleanRef;Lkotlin/jvm/functions/Function0;Ljava/util/Map;Lkotlin/jvm/internal/Ref$ObjectRef;Ldev/wiojelt/turksinema/common/WioSettingsConfig;Ljava/util/Map;Landroid/view/View;)V
    .registers 20
    .param p0, "$isBulkUpdating"  # Lkotlin/jvm/internal/Ref$BooleanRef;
    .param p1, "$onRec"  # Lkotlin/jvm/functions/Function0;
    .param p2, "$switchMap"  # Ljava/util/Map;
    .param p3, "$updateCounterText"  # Lkotlin/jvm/internal/Ref$ObjectRef;
    .param p4, "$config"  # Ldev/wiojelt/turksinema/common/WioSettingsConfig;
    .param p5, "$presetButtons"  # Ljava/util/Map;
    .param p6, "it"  # Landroid/view/View;

    .line 882
    const/4 v0, 0x1

    iput-boolean v0, p0, Lkotlin/jvm/internal/Ref$BooleanRef;->element:Z

    .line 883
    nop

    .line 884
    const/4 v1, 0x0

    :try_start_5
    invoke-interface {p1}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 885
    move-object v0, p2

    .local v0, "$this$forEach$iv":Ljava/util/Map;
    const/4 v2, 0x0

    .line 1239
    .local v2, "$i$f$forEach":I
    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_12
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_5f

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/util/Map$Entry;

    .local v4, "element$iv":Ljava/util/Map$Entry;
    const/4 v5, 0x0

    .local v5, "$i$a$-forEach-WioCoreSettingsDialog$show$11$btnRec$1$1$1":I
    invoke-interface {v4}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    .local v6, "id":Ljava/lang/String;
    invoke-interface {v4}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lcom/google/android/material/switchmaterial/SwitchMaterial;

    .line 886
    .local v7, "sw":Lcom/google/android/material/switchmaterial/SwitchMaterial;
    invoke-virtual/range {p4 .. p4}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getItems()Ljava/util/List;

    move-result-object v8

    check-cast v8, Ljava/lang/Iterable;

    invoke-interface {v8}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :cond_35
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_4e

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    move-object v10, v9

    check-cast v10, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;

    .line 1215
    .local v10, "it":Ldev/wiojelt/turksinema/common/WioProviderSettingItem;
    const/4 v11, 0x0

    .line 886
    .local v11, "$i$a$-find-WioCoreSettingsDialog$show$11$btnRec$1$1$1$item$1":I
    invoke-virtual {v10}, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->getId()Ljava/lang/String;

    move-result-object v12

    invoke-static {v12, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v12

    .end local v10  # "it":Ldev/wiojelt/turksinema/common/WioProviderSettingItem;
    .end local v11  # "$i$a$-find-WioCoreSettingsDialog$show$11$btnRec$1$1$1$item$1":I
    if-eqz v12, :cond_35

    goto :goto_4f

    :cond_4e
    const/4 v9, 0x0

    :goto_4f
    check-cast v9, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;

    .line 887
    .local v9, "item":Ldev/wiojelt/turksinema/common/WioProviderSettingItem;
    if-eqz v9, :cond_58

    invoke-virtual {v9}, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->isEnabled()Z

    move-result v8

    goto :goto_59

    :cond_58
    move v8, v1

    :goto_59
    invoke-virtual {v7, v8}, Lcom/google/android/material/switchmaterial/SwitchMaterial;->setChecked(Z)V
    :try_end_5c
    .catchall {:try_start_5 .. :try_end_5c} :catchall_72

    .line 888
    .end local v9  # "item":Ldev/wiojelt/turksinema/common/WioProviderSettingItem;
    nop

    .line 1239
    .end local v5  # "$i$a$-forEach-WioCoreSettingsDialog$show$11$btnRec$1$1$1":I
    .end local v6  # "id":Ljava/lang/String;
    .end local v7  # "sw":Lcom/google/android/material/switchmaterial/SwitchMaterial;
    nop

    .end local v4  # "element$iv":Ljava/util/Map$Entry;
    goto :goto_12

    .line 1240
    :cond_5f
    nop

    .line 889
    .end local v0  # "$this$forEach$iv":Ljava/util/Map;
    .end local v2  # "$i$f$forEach":I
    move-object/from16 v2, p3

    :try_start_62
    iget-object v0, v2, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    check-cast v0, Lkotlin/jvm/functions/Function0;

    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 890
    invoke-static/range {p4 .. p5}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$refreshPresetButtons(Ldev/wiojelt/turksinema/common/WioSettingsConfig;Ljava/util/Map;)V
    :try_end_6c
    .catchall {:try_start_62 .. :try_end_6c} :catchall_70

    .line 892
    iput-boolean v1, p0, Lkotlin/jvm/internal/Ref$BooleanRef;->element:Z

    .line 893
    nop

    .line 894
    return-void

    .line 892
    :catchall_70
    move-exception v0

    goto :goto_75

    :catchall_72
    move-exception v0

    move-object/from16 v2, p3

    :goto_75
    iput-boolean v1, p0, Lkotlin/jvm/internal/Ref$BooleanRef;->element:Z

    throw v0
.end method

.method private static final show$lambda$50$0$0(Lkotlin/jvm/internal/Ref$BooleanRef;Lkotlin/jvm/functions/Function0;Ldev/wiojelt/turksinema/common/WioSettingsConfig;Ljava/util/Map;Lkotlin/jvm/internal/Ref$ObjectRef;Ljava/util/Map;Landroid/view/View;)V
    .registers 14
    .param p0, "$isBulkUpdating"  # Lkotlin/jvm/internal/Ref$BooleanRef;
    .param p1, "$onNone"  # Lkotlin/jvm/functions/Function0;
    .param p2, "$config"  # Ldev/wiojelt/turksinema/common/WioSettingsConfig;
    .param p3, "$switchMap"  # Ljava/util/Map;
    .param p4, "$updateCounterText"  # Lkotlin/jvm/internal/Ref$ObjectRef;
    .param p5, "$presetButtons"  # Ljava/util/Map;
    .param p6, "it"  # Landroid/view/View;

    .line 912
    const/4 v0, 0x1

    iput-boolean v0, p0, Lkotlin/jvm/internal/Ref$BooleanRef;->element:Z

    .line 913
    nop

    .line 914
    const/4 v0, 0x0

    :try_start_5
    invoke-interface {p1}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 915
    invoke-virtual {p2}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getItems()Ljava/util/List;

    move-result-object v1

    check-cast v1, Ljava/lang/Iterable;

    .local v1, "$this$forEach$iv":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 1241
    .local v2, "$i$f$forEach":I
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_13
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_26

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    .local v4, "element$iv":Ljava/lang/Object;
    move-object v5, v4

    check-cast v5, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;

    .local v5, "it":Ldev/wiojelt/turksinema/common/WioProviderSettingItem;
    const/4 v6, 0x0

    .line 915
    .local v6, "$i$a$-forEach-WioCoreSettingsDialog$show$12$btnNone$1$1$1":I
    invoke-virtual {v5, v0}, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->setEnabled(Z)V

    .line 1241
    .end local v5  # "it":Ldev/wiojelt/turksinema/common/WioProviderSettingItem;
    .end local v6  # "$i$a$-forEach-WioCoreSettingsDialog$show$12$btnNone$1$1$1":I
    nop

    .end local v4  # "element$iv":Ljava/lang/Object;
    goto :goto_13

    .line 1242
    :cond_26
    nop

    .line 916
    .end local v1  # "$this$forEach$iv":Ljava/lang/Iterable;
    .end local v2  # "$i$f$forEach":I
    invoke-interface {p3}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v1

    check-cast v1, Ljava/lang/Iterable;

    .restart local v1  # "$this$forEach$iv":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 1243
    .restart local v2  # "$i$f$forEach":I
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_32
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_45

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    .restart local v4  # "element$iv":Ljava/lang/Object;
    move-object v5, v4

    check-cast v5, Lcom/google/android/material/switchmaterial/SwitchMaterial;

    .local v5, "it":Lcom/google/android/material/switchmaterial/SwitchMaterial;
    const/4 v6, 0x0

    .line 916
    .local v6, "$i$a$-forEach-WioCoreSettingsDialog$show$12$btnNone$1$1$2":I
    invoke-virtual {v5, v0}, Lcom/google/android/material/switchmaterial/SwitchMaterial;->setChecked(Z)V

    .line 1243
    .end local v5  # "it":Lcom/google/android/material/switchmaterial/SwitchMaterial;
    .end local v6  # "$i$a$-forEach-WioCoreSettingsDialog$show$12$btnNone$1$1$2":I
    nop

    .end local v4  # "element$iv":Ljava/lang/Object;
    goto :goto_32

    .line 1244
    :cond_45
    nop

    .line 917
    .end local v1  # "$this$forEach$iv":Ljava/lang/Iterable;
    .end local v2  # "$i$f$forEach":I
    iget-object v1, p4, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    check-cast v1, Lkotlin/jvm/functions/Function0;

    invoke-interface {v1}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 918
    invoke-static {p2, p5}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$refreshPresetButtons(Ldev/wiojelt/turksinema/common/WioSettingsConfig;Ljava/util/Map;)V
    :try_end_50
    .catchall {:try_start_5 .. :try_end_50} :catchall_54

    .line 920
    iput-boolean v0, p0, Lkotlin/jvm/internal/Ref$BooleanRef;->element:Z

    .line 921
    nop

    .line 922
    return-void

    .line 920
    :catchall_54
    move-exception v1

    iput-boolean v0, p0, Lkotlin/jvm/internal/Ref$BooleanRef;->element:Z

    throw v1
.end method

.method private static final show$lambda$55$5$0(Landroid/content/Context;Ldev/wiojelt/turksinema/common/WioProviderSettingItem;Ldev/wiojelt/turksinema/common/WioSettingsConfig;Landroid/widget/TextView;Landroid/view/View;)V
    .registers 13
    .param p0, "$context"  # Landroid/content/Context;
    .param p1, "$item"  # Ldev/wiojelt/turksinema/common/WioProviderSettingItem;
    .param p2, "$config"  # Ldev/wiojelt/turksinema/common/WioSettingsConfig;
    .param p3, "$domainView"  # Landroid/widget/TextView;
    .param p4, "it"  # Landroid/view/View;

    .line 1007
    sget-object v0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->INSTANCE:Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;

    .line 1008
    nop

    .line 1009
    invoke-virtual {p1}, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->getDisplayName()Ljava/lang/String;

    move-result-object v2

    .line 1010
    invoke-virtual {p1}, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->getDomain()Ljava/lang/String;

    move-result-object v1

    if-nez v1, :cond_f

    const-string v1, ""

    :cond_f
    move-object v3, v1

    .line 1011
    invoke-virtual {p2}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getEnglishLabels()Z

    move-result v4

    .line 1012
    invoke-virtual {p2}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getBrandColor()I

    move-result v5

    .line 1013
    invoke-virtual {p2}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getBrandColorBorder()I

    move-result v6

    .line 1007
    new-instance v7, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda25;

    invoke-direct {v7, p1, p3}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda25;-><init>(Ldev/wiojelt/turksinema/common/WioProviderSettingItem;Landroid/widget/TextView;)V

    move-object v1, p0

    .end local p0  # "$context":Landroid/content/Context;
    .local v1, "$context":Landroid/content/Context;
    invoke-virtual/range {v0 .. v7}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;ZIILkotlin/jvm/functions/Function1;)V

    .line 1020
    return-void
.end method

.method private static final show$lambda$55$5$0$0(Ldev/wiojelt/turksinema/common/WioProviderSettingItem;Landroid/widget/TextView;Ljava/lang/String;)Lkotlin/Unit;
    .registers 5
    .param p0, "$item"  # Ldev/wiojelt/turksinema/common/WioProviderSettingItem;
    .param p1, "$domainView"  # Landroid/widget/TextView;
    .param p2, "newUrl"  # Ljava/lang/String;

    .line 1015
    invoke-virtual {p0, p2}, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->setDomain(Ljava/lang/String;)V

    .line 1016
    if-eqz p1, :cond_1d

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " ✎"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    check-cast v0, Ljava/lang/CharSequence;

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1017
    :cond_1d
    invoke-virtual {p0}, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->getOnDomainEdit()Lkotlin/jvm/functions/Function1;

    move-result-object v0

    invoke-interface {v0, p2}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1018
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final show$lambda$55$7(Lcom/google/android/material/switchmaterial/SwitchMaterial;Landroid/view/View;)V
    .registers 2
    .param p0, "$sw"  # Lcom/google/android/material/switchmaterial/SwitchMaterial;
    .param p1, "it"  # Landroid/view/View;

    .line 1035
    invoke-virtual {p0}, Lcom/google/android/material/switchmaterial/SwitchMaterial;->toggle()V

    .line 1036
    return-void
.end method

.method private static final show$lambda$55$8(Lkotlin/jvm/internal/Ref$BooleanRef;Ldev/wiojelt/turksinema/common/WioProviderSettingItem;Lkotlin/jvm/internal/Ref$ObjectRef;Ldev/wiojelt/turksinema/common/WioSettingsConfig;Ljava/util/Map;Landroid/widget/CompoundButton;Z)V
    .registers 8
    .param p0, "$isBulkUpdating"  # Lkotlin/jvm/internal/Ref$BooleanRef;
    .param p1, "$item"  # Ldev/wiojelt/turksinema/common/WioProviderSettingItem;
    .param p2, "$updateCounterText"  # Lkotlin/jvm/internal/Ref$ObjectRef;
    .param p3, "$config"  # Ldev/wiojelt/turksinema/common/WioSettingsConfig;
    .param p4, "$presetButtons"  # Ljava/util/Map;
    .param p6, "isChecked"  # Z

    .line 1039
    iget-boolean p5, p0, Lkotlin/jvm/internal/Ref$BooleanRef;->element:Z

    if-eqz p5, :cond_5

    return-void

    .line 1040
    :cond_5
    invoke-virtual {p1, p6}, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->setEnabled(Z)V

    .line 1041
    invoke-virtual {p1}, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->getOnToggle()Lkotlin/jvm/functions/Function1;

    move-result-object p5

    invoke-static {p6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    invoke-interface {p5, v0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1042
    iget-object p5, p2, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    check-cast p5, Lkotlin/jvm/functions/Function0;

    invoke-interface {p5}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 1043
    invoke-static {p3, p4}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$refreshPresetButtons(Ldev/wiojelt/turksinema/common/WioSettingsConfig;Ljava/util/Map;)V

    .line 1044
    return-void
.end method

.method private static final show$lambda$56$0(Landroid/widget/LinearLayout;Lcom/google/android/material/button/MaterialButton;Ldev/wiojelt/turksinema/common/WioSettingsConfig;Landroid/view/View;)V
    .registers 6
    .param p0, "$providerControlsContainer"  # Landroid/widget/LinearLayout;
    .param p1, "$this_apply"  # Lcom/google/android/material/button/MaterialButton;
    .param p2, "$config"  # Ldev/wiojelt/turksinema/common/WioSettingsConfig;
    .param p3, "it"  # Landroid/view/View;

    .line 1065
    invoke-virtual {p0}, Landroid/widget/LinearLayout;->getVisibility()I

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_9

    const/4 v0, 0x1

    goto :goto_a

    :cond_9
    move v0, v1

    .line 1066
    .local v0, "willOpen":Z
    :goto_a
    if-eqz v0, :cond_d

    goto :goto_f

    :cond_d
    const/16 v1, 0x8

    :goto_f
    invoke-virtual {p0, v1}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 1067
    if-eqz v0, :cond_22

    .line 1068
    invoke-virtual {p2}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getEnglishLabels()Z

    move-result v1

    if-eqz v1, :cond_1d

    const-string v1, "▲ Hide Provider Panel"

    goto :goto_1f

    :cond_1d
    const-string v1, "▲ Sağlayıcı Panelini Kapat"

    :goto_1f
    check-cast v1, Ljava/lang/CharSequence;

    goto :goto_2f

    .line 1070
    :cond_22
    invoke-virtual {p2}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getEnglishLabels()Z

    move-result v1

    if-eqz v1, :cond_2b

    const-string v1, "⚙ Choose Providers"

    goto :goto_2d

    :cond_2b
    const-string v1, "⚙ Sağlayıcıları Kendin Seç"

    :goto_2d
    check-cast v1, Ljava/lang/CharSequence;

    .line 1067
    :goto_2f
    invoke-virtual {p1, v1}, Lcom/google/android/material/button/MaterialButton;->setText(Ljava/lang/CharSequence;)V

    .line 1072
    return-void
.end method

.method static final show$lambda$63(Lcom/google/android/material/button/MaterialButton;Landroid/widget/ProgressBar;Landroid/widget/TextView;Lkotlinx/coroutines/CoroutineScope;Landroid/content/Context;Ldev/wiojelt/turksinema/common/WioSettingsConfig;Landroid/view/View;)V
    .registers 15
    .param p0, "$scanBtn"  # Lcom/google/android/material/button/MaterialButton;
    .param p1, "$scanProgress"  # Landroid/widget/ProgressBar;
    .param p2, "$scanStatus"  # Landroid/widget/TextView;
    .param p3, "$scope"  # Lkotlinx/coroutines/CoroutineScope;
    .param p4, "$context"  # Landroid/content/Context;
    .param p5, "$config"  # Ldev/wiojelt/turksinema/common/WioSettingsConfig;
    .param p6, "it"  # Landroid/view/View;

    .line 1118
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lcom/google/android/material/button/MaterialButton;->setEnabled(Z)V

    .line 1119
    invoke-virtual {p1, v0}, Landroid/widget/ProgressBar;->setVisibility(I)V

    .line 1120
    const-string v0, "Alan adları kontrol ediliyor..."

    check-cast v0, Ljava/lang/CharSequence;

    invoke-virtual {p2, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1121
    new-instance v1, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1;

    const/4 v7, 0x0

    move-object v3, p0

    move-object v2, p1

    move-object v4, p2

    move-object v5, p4

    move-object v6, p5

    .end local p0  # "$scanBtn":Lcom/google/android/material/button/MaterialButton;
    .end local p1  # "$scanProgress":Landroid/widget/ProgressBar;
    .end local p2  # "$scanStatus":Landroid/widget/TextView;
    .end local p4  # "$context":Landroid/content/Context;
    .end local p5  # "$config":Ldev/wiojelt/turksinema/common/WioSettingsConfig;
    .local v2, "$scanProgress":Landroid/widget/ProgressBar;
    .local v3, "$scanBtn":Lcom/google/android/material/button/MaterialButton;
    .local v4, "$scanStatus":Landroid/widget/TextView;
    .local v5, "$context":Landroid/content/Context;
    .local v6, "$config":Ldev/wiojelt/turksinema/common/WioSettingsConfig;
    invoke-direct/range {v1 .. v7}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$17$1;-><init>(Landroid/widget/ProgressBar;Lcom/google/android/material/button/MaterialButton;Landroid/widget/TextView;Landroid/content/Context;Ldev/wiojelt/turksinema/common/WioSettingsConfig;Lkotlin/coroutines/Continuation;)V

    check-cast v1, Lkotlin/jvm/functions/Function2;

    const/4 p4, 0x3

    const/4 p5, 0x0

    const/4 p1, 0x0

    const/4 p2, 0x0

    move-object p0, p3

    move-object p3, v1

    .end local p3  # "$scope":Lkotlinx/coroutines/CoroutineScope;
    .local p0, "$scope":Lkotlinx/coroutines/CoroutineScope;
    invoke-static/range {p0 .. p5}, Lkotlinx/coroutines/BuildersKt;->launch$default(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/CoroutineContext;Lkotlinx/coroutines/CoroutineStart;Lkotlin/jvm/functions/Function2;ILjava/lang/Object;)Lkotlinx/coroutines/Job;

    .line 1134
    return-void
.end method

.method private static final show$lambda$65$0$1(Lcom/google/android/material/button/MaterialButton;Landroid/content/Context;Ljava/lang/String;Landroid/view/View;)V
    .registers 9
    .param p0, "$this_apply"  # Lcom/google/android/material/button/MaterialButton;
    .param p1, "$context"  # Landroid/content/Context;
    .param p2, "$tg"  # Ljava/lang/String;
    .param p3, "it"  # Landroid/view/View;

    .line 1158
    :try_start_0
    sget-object v0, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v0, p0

    .local v0, "$this$show_u24lambda_u2465_u240_u241_u240":Lcom/google/android/material/button/MaterialButton;
    const/4 v1, 0x0

    .line 1159
    .local v1, "$i$a$-runCatching-WioCoreSettingsDialog$show$18$tgBtn$1$1$1":I
    new-instance v2, Landroid/content/Intent;

    const-string v3, "android.intent.action.VIEW"

    invoke-static {p2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v4

    invoke-direct {v2, v3, v4}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    const/high16 v3, 0x10000000

    invoke-virtual {v2, v3}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v2

    invoke-virtual {p1, v2}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 1160
    nop

    .end local v0  # "$this$show_u24lambda_u2465_u240_u241_u240":Lcom/google/android/material/button/MaterialButton;
    .end local v1  # "$i$a$-runCatching-WioCoreSettingsDialog$show$18$tgBtn$1$1$1":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 1158
    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1e
    .catchall {:try_start_0 .. :try_end_1e} :catchall_1f

    goto :goto_29

    :catchall_1f
    move-exception v0

    sget-object v1, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v0}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1161
    :goto_29
    return-void
.end method

.method private static final show$lambda$66$0$0(Lcom/google/android/material/button/MaterialButton;Landroid/content/Context;Ljava/lang/String;Landroid/view/View;)V
    .registers 9
    .param p0, "$this_apply"  # Lcom/google/android/material/button/MaterialButton;
    .param p1, "$context"  # Landroid/content/Context;
    .param p2, "$cf"  # Ljava/lang/String;
    .param p3, "it"  # Landroid/view/View;

    .line 1176
    :try_start_0
    sget-object v0, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v0, p0

    .local v0, "$this$show_u24lambda_u2466_u240_u240_u240":Lcom/google/android/material/button/MaterialButton;
    const/4 v1, 0x0

    .line 1177
    .local v1, "$i$a$-runCatching-WioCoreSettingsDialog$show$19$coffeeBtn$1$1$1":I
    new-instance v2, Landroid/content/Intent;

    const-string v3, "android.intent.action.VIEW"

    invoke-static {p2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v4

    invoke-direct {v2, v3, v4}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    const/high16 v3, 0x10000000

    invoke-virtual {v2, v3}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v2

    invoke-virtual {p1, v2}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 1178
    nop

    .end local v0  # "$this$show_u24lambda_u2466_u240_u240_u240":Lcom/google/android/material/button/MaterialButton;
    .end local v1  # "$i$a$-runCatching-WioCoreSettingsDialog$show$19$coffeeBtn$1$1$1":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 1176
    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1e
    .catchall {:try_start_0 .. :try_end_1e} :catchall_1f

    goto :goto_29

    :catchall_1f
    move-exception v0

    sget-object v1, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v0}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1179
    :goto_29
    return-void
.end method

.method static final show$lambda$68(Lkotlinx/coroutines/CoroutineScope;Landroid/content/DialogInterface;)V
    .registers 4
    .param p0, "$scope"  # Lkotlinx/coroutines/CoroutineScope;
    .param p1, "it"  # Landroid/content/DialogInterface;

    .line 1193
    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-static {p0, v0, v1, v0}, Lkotlinx/coroutines/CoroutineScopeKt;->cancel$default(Lkotlinx/coroutines/CoroutineScope;Ljava/util/concurrent/CancellationException;ILjava/lang/Object;)V

    return-void
.end method

.method static final show$lambda$69(Landroid/content/Context;Landroid/app/Dialog;Ldev/wiojelt/turksinema/common/WioSettingsConfig;Ljava/util/Map;Landroid/content/DialogInterface;)V
    .registers 10
    .param p0, "$context"  # Landroid/content/Context;
    .param p1, "$dialog"  # Landroid/app/Dialog;
    .param p2, "$config"  # Ldev/wiojelt/turksinema/common/WioSettingsConfig;
    .param p3, "$presetButtons"  # Ljava/util/Map;
    .param p4, "it"  # Landroid/content/DialogInterface;

    .line 1195
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    .line 1196
    .local v0, "metrics":Landroid/util/DisplayMetrics;
    invoke-virtual {p1}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v1

    if-eqz v1, :cond_2b

    .line 1197
    iget v2, v0, Landroid/util/DisplayMetrics;->widthPixels:I

    int-to-float v2, v2

    const v3, 0x3f70a3d7  # 0.94f

    mul-float/2addr v2, v3

    float-to-int v2, v2

    const/16 v3, 0x3d4

    invoke-static {p0, v3}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v3

    invoke-static {v2, v3}, Lkotlin/ranges/RangesKt;->coerceAtMost(II)I

    move-result v2

    .line 1198
    iget v3, v0, Landroid/util/DisplayMetrics;->heightPixels:I

    int-to-float v3, v3

    const v4, 0x3f666666  # 0.9f

    mul-float/2addr v3, v4

    float-to-int v3, v3

    .line 1196
    invoke-virtual {v1, v2, v3}, Landroid/view/Window;->setLayout(II)V

    .line 1200
    :cond_2b
    invoke-static {p2, p3}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$refreshPresetButtons(Ldev/wiojelt/turksinema/common/WioSettingsConfig;Ljava/util/Map;)V

    .line 1201
    return-void
.end method

.method private static final show$refreshPresetButtons(Ldev/wiojelt/turksinema/common/WioSettingsConfig;Ljava/util/Map;)V
    .registers 16
    .param p0, "$config"  # Ldev/wiojelt/turksinema/common/WioSettingsConfig;
    .param p1, "presetButtons"  # Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ldev/wiojelt/turksinema/common/WioSettingsConfig;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Lcom/google/android/material/button/MaterialButton;",
            ">;)V"
        }
    .end annotation

    .line 730
    invoke-virtual {p0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getItems()Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$filter$iv":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 1219
    .local v1, "$i$f$filter":I
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    check-cast v2, Ljava/util/Collection;

    .local v2, "destination$iv$iv":Ljava/util/Collection;
    move-object v3, v0

    .local v3, "$this$filterTo$iv$iv":Ljava/lang/Iterable;
    const/4 v4, 0x0

    .line 1220
    .local v4, "$i$f$filterTo":I
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :cond_14
    :goto_14
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_2c

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    .local v6, "element$iv$iv":Ljava/lang/Object;
    move-object v7, v6

    check-cast v7, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;

    .local v7, "it":Ldev/wiojelt/turksinema/common/WioProviderSettingItem;
    const/4 v8, 0x0

    .line 730
    .local v8, "$i$a$-filter-WioCoreSettingsDialog$show$refreshPresetButtons$activeIds$1":I
    invoke-virtual {v7}, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->isEnabled()Z

    move-result v7

    .line 1220
    .end local v7  # "it":Ldev/wiojelt/turksinema/common/WioProviderSettingItem;
    .end local v8  # "$i$a$-filter-WioCoreSettingsDialog$show$refreshPresetButtons$activeIds$1":I
    if-eqz v7, :cond_14

    invoke-interface {v2, v6}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_14

    .line 1221
    .end local v6  # "element$iv$iv":Ljava/lang/Object;
    :cond_2c
    nop

    .end local v2  # "destination$iv$iv":Ljava/util/Collection;
    .end local v3  # "$this$filterTo$iv$iv":Ljava/lang/Iterable;
    .end local v4  # "$i$f$filterTo":I
    check-cast v2, Ljava/util/List;

    .line 1219
    nop

    .end local v0  # "$this$filter$iv":Ljava/lang/Iterable;
    .end local v1  # "$i$f$filter":I
    check-cast v2, Ljava/lang/Iterable;

    .line 730
    new-instance v0, Ljava/util/LinkedHashSet;

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    check-cast v0, Ljava/util/Collection;

    .local v0, "destination$iv":Ljava/util/Collection;
    .local v2, "$this$mapTo$iv":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 1222
    .local v1, "$i$f$mapTo":I
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_3e
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_54

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    .line 1223
    .local v4, "item$iv":Ljava/lang/Object;
    move-object v5, v4

    check-cast v5, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;

    .local v5, "it":Ldev/wiojelt/turksinema/common/WioProviderSettingItem;
    const/4 v6, 0x0

    .line 730
    .local v6, "$i$a$-mapTo-WioCoreSettingsDialog$show$refreshPresetButtons$activeIds$2":I
    invoke-virtual {v5}, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->getId()Ljava/lang/String;

    move-result-object v5

    .line 1223
    .end local v5  # "it":Ldev/wiojelt/turksinema/common/WioProviderSettingItem;
    .end local v6  # "$i$a$-mapTo-WioCoreSettingsDialog$show$refreshPresetButtons$activeIds$2":I
    invoke-interface {v0, v5}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_3e

    .line 1224
    .end local v4  # "item$iv":Ljava/lang/Object;
    :cond_54
    nop

    .line 730
    .end local v0  # "destination$iv":Ljava/util/Collection;
    .end local v1  # "$i$f$mapTo":I
    .end local v2  # "$this$mapTo$iv":Ljava/lang/Iterable;
    check-cast v0, Ljava/util/LinkedHashSet;

    .line 731
    .local v0, "activeIds":Ljava/util/LinkedHashSet;
    invoke-virtual {p0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getSelectionPresets()Ljava/util/List;

    move-result-object v1

    check-cast v1, Ljava/lang/Iterable;

    .local v1, "$this$forEach$iv":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 1225
    .local v2, "$i$f$forEach":I
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_62
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_e6

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    .local v4, "element$iv":Ljava/lang/Object;
    move-object v5, v4

    check-cast v5, Ldev/wiojelt/turksinema/common/WioSelectionPreset;

    .local v5, "preset":Ldev/wiojelt/turksinema/common/WioSelectionPreset;
    const/4 v6, 0x0

    .line 732
    .local v6, "$i$a$-forEach-WioCoreSettingsDialog$show$refreshPresetButtons$1":I
    invoke-virtual {v5}, Ldev/wiojelt/turksinema/common/WioSelectionPreset;->getId()Ljava/lang/String;

    move-result-object v7

    invoke-interface {p1, v7}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lcom/google/android/material/button/MaterialButton;

    if-eqz v7, :cond_e2

    invoke-virtual {v5}, Ldev/wiojelt/turksinema/common/WioSelectionPreset;->getProviderIds()Ljava/util/Set;

    move-result-object v8

    invoke-static {v0, v8}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v8

    const-string v9, ")"

    const-string v10, " ("

    if-eqz v8, :cond_b8

    .line 733
    invoke-virtual {v5}, Ldev/wiojelt/turksinema/common/WioSelectionPreset;->getTitle()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v5}, Ldev/wiojelt/turksinema/common/WioSelectionPreset;->getProviderIds()Ljava/util/Set;

    move-result-object v11

    invoke-interface {v11}, Ljava/util/Set;->size()I

    move-result v11

    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    const-string v13, "✓ "

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    check-cast v8, Ljava/lang/CharSequence;

    goto :goto_df

    .line 735
    :cond_b8
    invoke-virtual {v5}, Ldev/wiojelt/turksinema/common/WioSelectionPreset;->getTitle()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v5}, Ldev/wiojelt/turksinema/common/WioSelectionPreset;->getProviderIds()Ljava/util/Set;

    move-result-object v11

    invoke-interface {v11}, Ljava/util/Set;->size()I

    move-result v11

    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v12, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    check-cast v8, Ljava/lang/CharSequence;

    .line 732
    :goto_df
    invoke-virtual {v7, v8}, Lcom/google/android/material/button/MaterialButton;->setText(Ljava/lang/CharSequence;)V

    .line 737
    :cond_e2
    nop

    .line 1225
    .end local v5  # "preset":Ldev/wiojelt/turksinema/common/WioSelectionPreset;
    .end local v6  # "$i$a$-forEach-WioCoreSettingsDialog$show$refreshPresetButtons$1":I
    nop

    .end local v4  # "element$iv":Ljava/lang/Object;
    goto/16 :goto_62

    .line 1226
    :cond_e6
    nop

    .line 738
    .end local v1  # "$this$forEach$iv":Ljava/lang/Iterable;
    .end local v2  # "$i$f$forEach":I
    return-void
.end method

.method private static final show$refreshScanDurationUi(Ldev/wiojelt/turksinema/common/WioSettingsConfig;Lkotlin/jvm/internal/Ref$ObjectRef;Lkotlin/jvm/internal/Ref$ObjectRef;Z)V
    .registers 8
    .param p0, "$config"  # Ldev/wiojelt/turksinema/common/WioSettingsConfig;
    .param p1, "scanDurationLabel"  # Lkotlin/jvm/internal/Ref$ObjectRef;
    .param p2, "scanDurationSeekBar"  # Lkotlin/jvm/internal/Ref$ObjectRef;
    .param p3, "tvBoxActive"  # Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ldev/wiojelt/turksinema/common/WioSettingsConfig;",
            "Lkotlin/jvm/internal/Ref$ObjectRef<",
            "Landroid/widget/TextView;",
            ">;",
            "Lkotlin/jvm/internal/Ref$ObjectRef<",
            "Landroid/widget/SeekBar;",
            ">;Z)V"
        }
    .end annotation

    .line 529
    invoke-virtual {p0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->isScanDurationSupported()Z

    move-result v0

    if-nez v0, :cond_7

    return-void

    .line 530
    :cond_7
    if-eqz p3, :cond_e

    .line 531
    invoke-virtual {p0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getTvBoxScanDurationSeconds()I

    move-result v0

    goto :goto_28

    .line 533
    :cond_e
    invoke-virtual {p0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getScanDurationSeconds()Lkotlin/jvm/functions/Function0;

    move-result-object v0

    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    move-result v0

    invoke-virtual {p0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getMinScanDurationSeconds()I

    move-result v1

    invoke-virtual {p0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getMaxScanDurationSeconds()I

    move-result v2

    invoke-static {v0, v1, v2}, Lkotlin/ranges/RangesKt;->coerceIn(III)I

    move-result v0

    .line 530
    :goto_28
    nop

    .line 535
    .local v0, "seconds":I
    iget-object v1, p1, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    check-cast v1, Landroid/widget/TextView;

    if-eqz v1, :cond_69

    const-string v2, "Kaynak arama süresi: "

    if-eqz p3, :cond_4d

    .line 536
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " sn · TV Box sabit"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    check-cast v2, Ljava/lang/CharSequence;

    goto :goto_66

    .line 538
    :cond_4d
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " sn"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    check-cast v2, Ljava/lang/CharSequence;

    .line 535
    :goto_66
    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 540
    :cond_69
    iget-object v1, p2, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    check-cast v1, Landroid/widget/SeekBar;

    if-eqz v1, :cond_8b

    .local v1, "$this$show_u24refreshScanDurationUi_u24lambda_u2417":Landroid/widget/SeekBar;
    const/4 v2, 0x0

    .line 541
    .local v2, "$i$a$-apply-WioCoreSettingsDialog$show$refreshScanDurationUi$1":I
    xor-int/lit8 v3, p3, 0x1

    invoke-virtual {v1, v3}, Landroid/widget/SeekBar;->setEnabled(Z)V

    .line 542
    if-eqz p3, :cond_7b

    const v3, 0x3ee66666  # 0.45f

    goto :goto_7d

    :cond_7b
    const/high16 v3, 0x3f800000  # 1.0f

    :goto_7d
    invoke-virtual {v1, v3}, Landroid/widget/SeekBar;->setAlpha(F)V

    .line 543
    invoke-virtual {p0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getMinScanDurationSeconds()I

    move-result v3

    sub-int v3, v0, v3

    invoke-virtual {v1, v3}, Landroid/widget/SeekBar;->setProgress(I)V

    .line 544
    nop

    .line 540
    .end local v1  # "$this$show_u24refreshScanDurationUi_u24lambda_u2417":Landroid/widget/SeekBar;
    .end local v2  # "$i$a$-apply-WioCoreSettingsDialog$show$refreshScanDurationUi$1":I
    nop

    .line 545
    :cond_8b
    return-void
.end method

.method public static synthetic showEditDomainDialog$default(Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;ZIILkotlin/jvm/functions/Function1;ILjava/lang/Object;)V
    .registers 18

    .line 142
    and-int/lit8 v0, p8, 0x8

    if-eqz v0, :cond_7

    .line 146
    const/4 p4, 0x0

    move v4, p4

    goto :goto_8

    .line 142
    :cond_7
    move v4, p4

    :goto_8
    and-int/lit8 p4, p8, 0x10

    if-eqz p4, :cond_14

    .line 147
    const-string p4, "#FFB703"

    invoke-static {p4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result p5

    move v5, p5

    goto :goto_15

    .line 142
    :cond_14
    move v5, p5

    :goto_15
    and-int/lit8 p4, p8, 0x20

    if-eqz p4, :cond_21

    .line 148
    const-string p4, "#66FFB703"

    invoke-static {p4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result p6

    move v6, p6

    goto :goto_22

    .line 142
    :cond_21
    move v6, p6

    :goto_22
    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v7, p7

    invoke-virtual/range {v0 .. v7}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;ZIILkotlin/jvm/functions/Function1;)V

    return-void
.end method

.method private static final showEditDomainDialog$dp(Landroid/content/Context;I)I
    .registers 4
    .param p0, "$context"  # Landroid/content/Context;
    .param p1, "v"  # I

    .line 151
    int-to-float v0, p1

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v1

    iget v1, v1, Landroid/util/DisplayMetrics;->density:F

    mul-float/2addr v0, v1

    float-to-int v0, v0

    return v0
.end method

.method private static final showEditDomainDialog$getIncrementedUrl(Ljava/lang/String;)Ljava/lang/String;
    .registers 8
    .param p0, "raw"  # Ljava/lang/String;

    .line 226
    move-object v0, p0

    check-cast v0, Ljava/lang/CharSequence;

    invoke-static {v0}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    .line 227
    .local v0, "text":Ljava/lang/String;
    move-object v1, v0

    check-cast v1, Ljava/lang/CharSequence;

    invoke-interface {v1}, Ljava/lang/CharSequence;->length()I

    move-result v1

    const/4 v2, 0x0

    if-nez v1, :cond_17

    const/4 v1, 0x1

    goto :goto_18

    :cond_17
    move v1, v2

    :goto_18
    const/4 v3, 0x0

    if-eqz v1, :cond_1c

    return-object v3

    .line 228
    :cond_1c
    new-instance v1, Lkotlin/text/Regex;

    const-string v4, "(\\d+)"

    invoke-direct {v1, v4}, Lkotlin/text/Regex;-><init>(Ljava/lang/String;)V

    move-object v4, v0

    check-cast v4, Ljava/lang/CharSequence;

    const/4 v5, 0x2

    invoke-static {v1, v4, v2, v5, v3}, Lkotlin/text/Regex;->findAll$default(Lkotlin/text/Regex;Ljava/lang/CharSequence;IILjava/lang/Object;)Lkotlin/sequences/Sequence;

    move-result-object v1

    invoke-static {v1}, Lkotlin/sequences/SequencesKt;->lastOrNull(Lkotlin/sequences/Sequence;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lkotlin/text/MatchResult;

    if-nez v1, :cond_34

    return-object v3

    .line 229
    .local v1, "match":Lkotlin/text/MatchResult;
    :cond_34
    invoke-interface {v1}, Lkotlin/text/MatchResult;->getValue()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lkotlin/text/StringsKt;->toLongOrNull(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v2

    if-eqz v2, :cond_5b

    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    move-result-wide v2

    .line 230
    .local v2, "num":J
    invoke-interface {v1}, Lkotlin/text/MatchResult;->getRange()Lkotlin/ranges/IntRange;

    move-result-object v4

    const-wide/16 v5, 0x1

    add-long/2addr v5, v2

    invoke-static {v5, v6}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v5

    check-cast v5, Ljava/lang/CharSequence;

    move-object v6, v0

    check-cast v6, Ljava/lang/CharSequence;

    invoke-static {v6, v4, v5}, Lkotlin/text/StringsKt;->replaceRange(Ljava/lang/CharSequence;Lkotlin/ranges/IntRange;Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v4

    return-object v4

    .line 229
    .end local v2  # "num":J
    :cond_5b
    return-object v3
.end method

.method private static final showEditDomainDialog$lambda$13$0(Landroid/app/Dialog;Landroid/view/View;)V
    .registers 2
    .param p0, "$editDialog"  # Landroid/app/Dialog;
    .param p1, "it"  # Landroid/view/View;

    .line 294
    invoke-virtual {p0}, Landroid/app/Dialog;->dismiss()V

    return-void
.end method

.method private static final showEditDomainDialog$lambda$14$0(Landroid/widget/EditText;Landroid/content/Context;ZLcom/google/android/material/button/MaterialButton;Lkotlin/jvm/functions/Function1;Ljava/lang/String;Landroid/app/Dialog;Landroid/view/View;)V
    .registers 16
    .param p0, "$input"  # Landroid/widget/EditText;
    .param p1, "$context"  # Landroid/content/Context;
    .param p2, "$englishLabels"  # Z
    .param p3, "$this_apply"  # Lcom/google/android/material/button/MaterialButton;
    .param p4, "$onSave"  # Lkotlin/jvm/functions/Function1;
    .param p5, "$providerName"  # Ljava/lang/String;
    .param p6, "$editDialog"  # Landroid/app/Dialog;
    .param p7, "it"  # Landroid/view/View;

    .line 307
    const/4 v0, 0x0

    .local v0, "raw":Ljava/lang/Object;
    invoke-virtual {p0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    check-cast v1, Ljava/lang/CharSequence;

    invoke-static {v1}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    .line 308
    move-object v1, v0

    check-cast v1, Ljava/lang/CharSequence;

    invoke-static {v1}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v2, 0x0

    if-eqz v1, :cond_2e

    .line 309
    if-eqz p2, :cond_22

    const-string v1, "Domain cannot be empty!"

    goto :goto_24

    :cond_22
    const-string v1, "Alan adı boş bırakılamaz!"

    :goto_24
    check-cast v1, Ljava/lang/CharSequence;

    invoke-static {p1, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    .line 310
    return-void

    .line 312
    :cond_2e
    const-string v1, "http://"

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {v0, v1, v2, v3, v4}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_51

    const-string v1, "https://"

    invoke-static {v0, v1, v2, v3, v4}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_51

    .line 313
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 315
    :cond_51
    :try_start_51
    sget-object v1, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v1, p3

    .local v1, "$this$showEditDomainDialog_u24lambda_u2414_u240_u240":Lcom/google/android/material/button/MaterialButton;
    const/4 v3, 0x0

    .line 316
    .local v3, "$i$a$-runCatching-WioCoreSettingsDialog$showEditDomainDialog$btnSave$1$1$1":I
    new-instance v4, Ljava/net/URI;

    invoke-direct {v4, v0}, Ljava/net/URI;-><init>(Ljava/lang/String;)V

    .line 317
    .local v4, "uri":Ljava/net/URI;
    invoke-virtual {v4}, Ljava/net/URI;->getHost()Ljava/lang/String;

    move-result-object v5

    check-cast v5, Ljava/lang/CharSequence;

    if-eqz v5, :cond_6b

    invoke-static {v5}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_69

    goto :goto_6b

    :cond_69
    move v5, v2

    goto :goto_6c

    :cond_6b
    :goto_6b
    const/4 v5, 0x1

    :goto_6c
    if-nez v5, :cond_d1

    .line 318
    invoke-virtual {v4}, Ljava/net/URI;->getScheme()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4}, Ljava/net/URI;->getAuthority()Ljava/lang/String;

    move-result-object v6

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v7, "://"

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    const-string v6, "/"

    check-cast v6, Ljava/lang/CharSequence;

    invoke-static {v5, v6}, Lkotlin/text/StringsKt;->removeSuffix(Ljava/lang/String;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v5

    .line 319
    .local v5, "validOrigin":Ljava/lang/String;
    invoke-interface {p4, v5}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 320
    if-eqz p2, :cond_aa

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, p5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " domain updated!"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    goto :goto_b9

    :cond_aa
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, p5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " adresi güncellendi!"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    :goto_b9
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    check-cast v6, Ljava/lang/CharSequence;

    invoke-static {p1, v6, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v6

    invoke-virtual {v6}, Landroid/widget/Toast;->show()V

    .line 321
    invoke-virtual {p6}, Landroid/app/Dialog;->dismiss()V

    .line 322
    nop

    .end local v1  # "$this$showEditDomainDialog_u24lambda_u2414_u240_u240":Lcom/google/android/material/button/MaterialButton;
    .end local v3  # "$i$a$-runCatching-WioCoreSettingsDialog$showEditDomainDialog$btnSave$1$1$1":I
    .end local v4  # "uri":Ljava/net/URI;
    .end local v5  # "validOrigin":Ljava/lang/String;
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 315
    invoke-static {v1}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    goto :goto_e4

    .line 317
    .restart local v1  # "$this$showEditDomainDialog_u24lambda_u2414_u240_u240":Lcom/google/android/material/button/MaterialButton;
    .restart local v3  # "$i$a$-runCatching-WioCoreSettingsDialog$showEditDomainDialog$btnSave$1$1$1":I
    .restart local v4  # "uri":Ljava/net/URI;
    :cond_d1
    new-instance v5, Ljava/lang/IllegalArgumentException;

    const-string v6, "Geçersiz host"

    invoke-direct {v5, v6}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .end local v0  # "raw":Ljava/lang/Object;
    .end local p0  # "$input":Landroid/widget/EditText;
    .end local p1  # "$context":Landroid/content/Context;
    .end local p2  # "$englishLabels":Z
    .end local p3  # "$this_apply":Lcom/google/android/material/button/MaterialButton;
    .end local p4  # "$onSave":Lkotlin/jvm/functions/Function1;
    .end local p5  # "$providerName":Ljava/lang/String;
    .end local p6  # "$editDialog":Landroid/app/Dialog;
    .end local p7  # "it":Landroid/view/View;
    throw v5
    :try_end_d9
    .catchall {:try_start_51 .. :try_end_d9} :catchall_d9

    .line 315
    .end local v1  # "$this$showEditDomainDialog_u24lambda_u2414_u240_u240":Lcom/google/android/material/button/MaterialButton;
    .end local v3  # "$i$a$-runCatching-WioCoreSettingsDialog$showEditDomainDialog$btnSave$1$1$1":I
    .end local v4  # "uri":Ljava/net/URI;
    .restart local v0  # "raw":Ljava/lang/Object;
    .restart local p0  # "$input":Landroid/widget/EditText;
    .restart local p1  # "$context":Landroid/content/Context;
    .restart local p2  # "$englishLabels":Z
    .restart local p3  # "$this_apply":Lcom/google/android/material/button/MaterialButton;
    .restart local p4  # "$onSave":Lkotlin/jvm/functions/Function1;
    .restart local p5  # "$providerName":Ljava/lang/String;
    .restart local p6  # "$editDialog":Landroid/app/Dialog;
    .restart local p7  # "it":Landroid/view/View;
    :catchall_d9
    move-exception v1

    sget-object v3, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v1}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v1

    invoke-static {v1}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    .line 322
    :goto_e4
    invoke-static {v1}, Lkotlin/Result;->exceptionOrNull-impl(Ljava/lang/Object;)Ljava/lang/Throwable;

    move-result-object v1

    if-eqz v1, :cond_fd

    .local v1, "it":Ljava/lang/Throwable;
    const/4 v3, 0x0

    .line 323
    .local v3, "$i$a$-onFailure-WioCoreSettingsDialog$showEditDomainDialog$btnSave$1$1$2":I
    if-eqz p2, :cond_f0

    const-string v4, "Invalid domain format!"

    goto :goto_f2

    :cond_f0
    const-string v4, "Geçersiz adres formatı!"

    :goto_f2
    check-cast v4, Ljava/lang/CharSequence;

    invoke-static {p1, v4, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/Toast;->show()V

    .line 324
    nop

    .line 322
    .end local v1  # "it":Ljava/lang/Throwable;
    .end local v3  # "$i$a$-onFailure-WioCoreSettingsDialog$showEditDomainDialog$btnSave$1$1$2":I
    nop

    .line 325
    :cond_fd
    return-void
.end method

.method private static final showEditDomainDialog$updateIncrementBtn(Landroid/widget/EditText;Lcom/google/android/material/button/MaterialButton;Z)V
    .registers 8
    .param p0, "input"  # Landroid/widget/EditText;
    .param p1, "btnIncrement"  # Lcom/google/android/material/button/MaterialButton;
    .param p2, "$englishLabels"  # Z

    .line 248
    invoke-virtual {p0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog$getIncrementedUrl(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 249
    .local v0, "next":Ljava/lang/String;
    if-eqz v0, :cond_72

    .line 250
    const/4 v1, 0x0

    invoke-virtual {p1, v1}, Lcom/google/android/material/button/MaterialButton;->setVisibility(I)V

    .line 251
    sget-object v1, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->INSTANCE:Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;

    :try_start_14
    sget-object v2, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    .line 1215
    .local v1, "$this$showEditDomainDialog_u24updateIncrementBtn_u24lambda_u249":Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;
    const/4 v2, 0x0

    .line 251
    .local v2, "$i$a$-runCatching-WioCoreSettingsDialog$showEditDomainDialog$updateIncrementBtn$hostOnly$1":I
    new-instance v3, Ljava/net/URI;

    invoke-direct {v3, v0}, Ljava/net/URI;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3}, Ljava/net/URI;->getHost()Ljava/lang/String;

    move-result-object v3

    .end local v1  # "$this$showEditDomainDialog_u24updateIncrementBtn_u24lambda_u249":Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;
    .end local v2  # "$i$a$-runCatching-WioCoreSettingsDialog$showEditDomainDialog$updateIncrementBtn$hostOnly$1":I
    invoke-static {v3}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1
    :try_end_24
    .catchall {:try_start_14 .. :try_end_24} :catchall_25

    goto :goto_30

    :catchall_25
    move-exception v1

    sget-object v2, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v1}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v1

    invoke-static {v1}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    :goto_30
    invoke-static {v1}, Lkotlin/Result;->isFailure-impl(Ljava/lang/Object;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_38

    move-object v1, v3

    :cond_38
    check-cast v1, Ljava/lang/String;

    if-nez v1, :cond_49

    const-string v1, "://"

    const/4 v2, 0x2

    invoke-static {v0, v1, v3, v2, v3}, Lkotlin/text/StringsKt;->substringAfter$default(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const-string v4, "/"

    invoke-static {v1, v4, v3, v2, v3}, Lkotlin/text/StringsKt;->substringBefore$default(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    .line 252
    .local v1, "hostOnly":Ljava/lang/String;
    :cond_49
    new-instance v2, Ljava/lang/StringBuilder;

    if-eqz p2, :cond_53

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "⚡ +1 Domain: "

    goto :goto_58

    :cond_53
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "⚡ +1 Adres: "

    :goto_58
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    check-cast v2, Ljava/lang/CharSequence;

    invoke-virtual {p1, v2}, Lcom/google/android/material/button/MaterialButton;->setText(Ljava/lang/CharSequence;)V

    .line 253
    new-instance v2, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda26;

    invoke-direct {v2, p0, v0, p1, p2}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda26;-><init>(Landroid/widget/EditText;Ljava/lang/String;Lcom/google/android/material/button/MaterialButton;Z)V

    invoke-virtual {p1, v2}, Lcom/google/android/material/button/MaterialButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .end local v1  # "hostOnly":Ljava/lang/String;
    goto :goto_77

    .line 259
    :cond_72
    const/16 v1, 0x8

    invoke-virtual {p1, v1}, Lcom/google/android/material/button/MaterialButton;->setVisibility(I)V

    .line 261
    :goto_77
    return-void
.end method

.method static final showEditDomainDialog$updateIncrementBtn$lambda$10(Landroid/widget/EditText;Ljava/lang/String;Lcom/google/android/material/button/MaterialButton;ZLandroid/view/View;)V
    .registers 6
    .param p0, "$input"  # Landroid/widget/EditText;
    .param p1, "$next"  # Ljava/lang/String;
    .param p2, "$btnIncrement"  # Lcom/google/android/material/button/MaterialButton;
    .param p3, "$englishLabels"  # Z
    .param p4, "it"  # Landroid/view/View;

    .line 254
    move-object v0, p1

    check-cast v0, Ljava/lang/CharSequence;

    invoke-virtual {p0, v0}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 255
    invoke-virtual {p0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-interface {v0}, Landroid/text/Editable;->length()I

    move-result v0

    invoke-virtual {p0, v0}, Landroid/widget/EditText;->setSelection(I)V

    .line 256
    invoke-static {p0, p2, p3}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog$updateIncrementBtn(Landroid/widget/EditText;Lcom/google/android/material/button/MaterialButton;Z)V

    .line 257
    return-void
.end method


# virtual methods
.method public final clearCache(Landroid/content/Context;)J
    .registers 16
    .param p1, "context"  # Landroid/content/Context;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param

    .line 116
    const-wide/16 v0, 0x0

    .line 117
    .local v0, "totalFreed":J
    :try_start_2
    sget-object v2, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v2, p0

    check-cast v2, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;

    .local v2, "$this$clearCache_u24lambda_u240":Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;
    const/4 v3, 0x0

    .line 118
    .local v3, "$i$a$-runCatching-WioCoreSettingsDialog$clearCache$1":I
    invoke-virtual {p1}, Landroid/content/Context;->getCacheDir()Ljava/io/File;

    move-result-object v4

    const/4 v5, 0x0

    if-eqz v4, :cond_29

    invoke-virtual {v4}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object v4

    if-eqz v4, :cond_29

    .local v4, "$this$forEach$iv":[Ljava/lang/Object;
    const/4 v6, 0x0

    .line 1206
    .local v6, "$i$f$forEach":I
    array-length v7, v4

    move v8, v5

    :goto_18
    if-ge v8, v7, :cond_28

    aget-object v9, v4, v8

    .local v9, "element$iv":Ljava/lang/Object;
    move-object v10, v9

    .local v10, "file":Ljava/io/File;
    const/4 v11, 0x0

    .line 119
    .local v11, "$i$a$-forEach-WioCoreSettingsDialog$clearCache$1$1":I
    invoke-direct {v2, v10}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->deleteRecursive(Ljava/io/File;)J

    move-result-wide v12

    add-long/2addr v0, v12

    .line 120
    nop

    .line 1206
    .end local v10  # "file":Ljava/io/File;
    .end local v11  # "$i$a$-forEach-WioCoreSettingsDialog$clearCache$1$1":I
    nop

    .end local v9  # "element$iv":Ljava/lang/Object;
    add-int/lit8 v8, v8, 0x1

    goto :goto_18

    .line 1207
    :cond_28
    nop

    .line 121
    .end local v4  # "$this$forEach$iv":[Ljava/lang/Object;
    .end local v6  # "$i$f$forEach":I
    :cond_29
    invoke-virtual {p1}, Landroid/content/Context;->getExternalCacheDir()Ljava/io/File;

    move-result-object v4

    if-eqz v4, :cond_49

    invoke-virtual {v4}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object v4

    if-eqz v4, :cond_49

    .restart local v4  # "$this$forEach$iv":[Ljava/lang/Object;
    const/4 v6, 0x0

    .line 1208
    .restart local v6  # "$i$f$forEach":I
    array-length v7, v4

    move v8, v5

    :goto_38
    if-ge v8, v7, :cond_48

    aget-object v9, v4, v8

    .restart local v9  # "element$iv":Ljava/lang/Object;
    move-object v10, v9

    .restart local v10  # "file":Ljava/io/File;
    const/4 v11, 0x0

    .line 122
    .local v11, "$i$a$-forEach-WioCoreSettingsDialog$clearCache$1$2":I
    invoke-direct {v2, v10}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->deleteRecursive(Ljava/io/File;)J

    move-result-wide v12

    add-long/2addr v0, v12

    .line 123
    nop

    .line 1208
    .end local v10  # "file":Ljava/io/File;
    .end local v11  # "$i$a$-forEach-WioCoreSettingsDialog$clearCache$1$2":I
    nop

    .end local v9  # "element$iv":Ljava/lang/Object;
    add-int/lit8 v8, v8, 0x1

    goto :goto_38

    .line 1209
    :cond_48
    nop

    .line 124
    .end local v4  # "$this$forEach$iv":[Ljava/lang/Object;
    .end local v6  # "$i$f$forEach":I
    :cond_49
    nop

    .line 125
    invoke-virtual {p1}, Landroid/content/Context;->getCodeCacheDir()Ljava/io/File;

    move-result-object v4

    if-eqz v4, :cond_69

    invoke-virtual {v4}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object v4

    if-eqz v4, :cond_69

    .restart local v4  # "$this$forEach$iv":[Ljava/lang/Object;
    const/4 v6, 0x0

    .line 1210
    .restart local v6  # "$i$f$forEach":I
    array-length v7, v4

    :goto_58
    if-ge v5, v7, :cond_68

    aget-object v8, v4, v5

    .local v8, "element$iv":Ljava/lang/Object;
    move-object v9, v8

    .local v9, "file":Ljava/io/File;
    const/4 v10, 0x0

    .line 126
    .local v10, "$i$a$-forEach-WioCoreSettingsDialog$clearCache$1$3":I
    invoke-direct {v2, v9}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->deleteRecursive(Ljava/io/File;)J

    move-result-wide v11

    add-long/2addr v0, v11

    .line 127
    nop

    .line 1210
    .end local v9  # "file":Ljava/io/File;
    .end local v10  # "$i$a$-forEach-WioCoreSettingsDialog$clearCache$1$3":I
    nop

    .end local v8  # "element$iv":Ljava/lang/Object;
    add-int/lit8 v5, v5, 0x1

    goto :goto_58

    .line 1211
    :cond_68
    nop

    .line 129
    .end local v4  # "$this$forEach$iv":[Ljava/lang/Object;
    .end local v6  # "$i$f$forEach":I
    :cond_69
    nop

    .end local v2  # "$this$clearCache_u24lambda_u240":Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;
    .end local v3  # "$i$a$-runCatching-WioCoreSettingsDialog$clearCache$1":I
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 117
    invoke-static {v2}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_6f
    .catchall {:try_start_2 .. :try_end_6f} :catchall_70

    goto :goto_7a

    :catchall_70
    move-exception v2

    sget-object v3, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v2}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v2

    invoke-static {v2}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    .line 130
    :goto_7a
    return-wide v0
.end method

.method public final isAutoDetectedTvOrLowRam(Landroid/content/Context;)Z
    .registers 12
    .param p1, "context"  # Landroid/content/Context;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param

    .line 134
    const-string v0, "TV"

    const/4 v1, 0x0

    :try_start_3
    sget-object v2, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v2, p0

    check-cast v2, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;

    .local v2, "$this$isAutoDetectedTvOrLowRam_u24lambda_u240":Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;
    const/4 v3, 0x0

    .line 135
    .local v3, "$i$a$-runCatching-WioCoreSettingsDialog$isAutoDetectedTvOrLowRam$1":I
    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v4

    const-string v5, "android.software.leanback"

    invoke-virtual {v4, v5}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    move-result v4

    const/4 v5, 0x1

    if-nez v4, :cond_41

    .line 136
    sget-object v4, Landroid/os/Build;->MODEL:Ljava/lang/String;

    check-cast v4, Ljava/lang/CharSequence;

    move-object v6, v0

    check-cast v6, Ljava/lang/CharSequence;

    invoke-static {v4, v6, v5}, Lkotlin/text/StringsKt;->contains(Ljava/lang/CharSequence;Ljava/lang/CharSequence;Z)Z

    move-result v4

    if-nez v4, :cond_41

    .line 137
    sget-object v4, Landroid/os/Build;->DEVICE:Ljava/lang/String;

    check-cast v4, Ljava/lang/CharSequence;

    check-cast v0, Ljava/lang/CharSequence;

    invoke-static {v4, v0, v5}, Lkotlin/text/StringsKt;->contains(Ljava/lang/CharSequence;Ljava/lang/CharSequence;Z)Z

    move-result v0

    if-nez v0, :cond_41

    .line 138
    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Runtime;->maxMemory()J

    move-result-wide v6

    const-wide/32 v8, 0xc000000

    cmp-long v0, v6, v8

    if-gez v0, :cond_3f

    goto :goto_41

    :cond_3f
    move v5, v1

    goto :goto_42

    :cond_41
    :goto_41
    nop

    .end local v2  # "$this$isAutoDetectedTvOrLowRam_u24lambda_u240":Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;
    .end local v3  # "$i$a$-runCatching-WioCoreSettingsDialog$isAutoDetectedTvOrLowRam$1":I
    :goto_42
    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    .line 134
    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0
    :try_end_4a
    .catchall {:try_start_3 .. :try_end_4a} :catchall_4b

    goto :goto_56

    :catchall_4b
    move-exception v0

    sget-object v2, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v0}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    .line 139
    :goto_56
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    invoke-static {v0}, Lkotlin/Result;->isFailure-impl(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_61

    move-object v0, v1

    :cond_61
    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 134
    return v0
.end method

.method public final show(Landroid/content/Context;Ldev/wiojelt/turksinema/common/WioSettingsConfig;)V
    .registers 67
    .param p1, "context"  # Landroid/content/Context;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p2, "config"  # Ldev/wiojelt/turksinema/common/WioSettingsConfig;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param

    .line 367
    move-object/from16 v1, p1

    move-object/from16 v0, p2

    new-instance v2, Landroid/app/Dialog;

    invoke-direct {v2, v1}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    move-object v3, v2

    .local v3, "$this$show_u24lambda_u243":Landroid/app/Dialog;
    const/4 v4, 0x0

    .line 368
    .local v4, "$i$a$-apply-WioCoreSettingsDialog$show$dialog$1":I
    const/4 v9, 0x1

    invoke-virtual {v3, v9}, Landroid/app/Dialog;->requestWindowFeature(I)Z

    .line 369
    invoke-virtual {v3}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v5

    const/4 v10, 0x0

    if-eqz v5, :cond_22

    new-instance v6, Landroid/graphics/drawable/ColorDrawable;

    invoke-direct {v6, v10}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    check-cast v6, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v5, v6}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    sget-object v5, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 370
    :cond_22
    invoke-virtual {v3, v10}, Landroid/app/Dialog;->setCanceledOnTouchOutside(Z)V

    .line 371
    nop

    .line 367
    .end local v3  # "$this$show_u24lambda_u243":Landroid/app/Dialog;
    .end local v4  # "$i$a$-apply-WioCoreSettingsDialog$show$dialog$1":I
    move-object v11, v2

    .line 372
    .local v11, "dialog":Landroid/app/Dialog;
    const/4 v12, 0x0

    invoke-static {v12, v9, v12}, Lkotlinx/coroutines/SupervisorKt;->SupervisorJob$default(Lkotlinx/coroutines/Job;ILjava/lang/Object;)Lkotlinx/coroutines/CompletableJob;

    move-result-object v2

    invoke-static {}, Lkotlinx/coroutines/Dispatchers;->getMain()Lkotlinx/coroutines/MainCoroutineDispatcher;

    move-result-object v3

    invoke-virtual {v3}, Lkotlinx/coroutines/MainCoroutineDispatcher;->getImmediate()Lkotlinx/coroutines/MainCoroutineDispatcher;

    move-result-object v3

    check-cast v3, Lkotlin/coroutines/CoroutineContext;

    invoke-interface {v2, v3}, Lkotlinx/coroutines/CompletableJob;->plus(Lkotlin/coroutines/CoroutineContext;)Lkotlin/coroutines/CoroutineContext;

    move-result-object v2

    invoke-static {v2}, Lkotlinx/coroutines/CoroutineScopeKt;->CoroutineScope(Lkotlin/coroutines/CoroutineContext;)Lkotlinx/coroutines/CoroutineScope;

    move-result-object v13

    .line 374
    .local v13, "scope":Lkotlinx/coroutines/CoroutineScope;
    new-instance v2, Landroid/widget/LinearLayout;

    invoke-direct {v2, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v3, v2

    .local v3, "$this$show_u24lambda_u244":Landroid/widget/LinearLayout;
    const/4 v4, 0x0

    .line 375
    .local v4, "$i$a$-apply-WioCoreSettingsDialog$show$root$1":I
    invoke-virtual {v3, v9}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 376
    const/16 v5, 0x14

    invoke-static {v1, v5}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v5

    const/16 v14, 0x10

    invoke-static {v1, v14}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v6

    const/16 v7, 0x14

    invoke-static {v1, v7}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v7

    const/16 v8, 0x18

    invoke-static {v1, v8}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v8

    invoke-virtual {v3, v5, v6, v7, v8}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 377
    new-instance v5, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v5}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object v6, v5

    .local v6, "$this$show_u24lambda_u244_u240":Landroid/graphics/drawable/GradientDrawable;
    const/4 v7, 0x0

    .line 378
    .local v7, "$i$a$-apply-WioCoreSettingsDialog$show$root$1$1":I
    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getSheetBg()I

    move-result v8

    invoke-virtual {v6, v8}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 379
    const/16 v8, 0x1c

    invoke-static {v1, v8}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v8

    int-to-float v8, v8

    invoke-virtual {v6, v8}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 380
    invoke-static {v1, v9}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v8

    const-string v15, "#33FFFFFF"

    invoke-static {v15}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v15

    invoke-virtual {v6, v8, v15}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 381
    nop

    .line 377
    .end local v6  # "$this$show_u24lambda_u244_u240":Landroid/graphics/drawable/GradientDrawable;
    .end local v7  # "$i$a$-apply-WioCoreSettingsDialog$show$root$1$1":I
    check-cast v5, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v3, v5}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 382
    nop

    .line 374
    .end local v3  # "$this$show_u24lambda_u244":Landroid/widget/LinearLayout;
    .end local v4  # "$i$a$-apply-WioCoreSettingsDialog$show$root$1":I
    move-object v15, v2

    .line 384
    .local v15, "root":Landroid/widget/LinearLayout;
    new-instance v2, Landroid/widget/LinearLayout;

    invoke-direct {v2, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v3, v2

    .local v3, "$this$show_u24lambda_u245":Landroid/widget/LinearLayout;
    const/4 v4, 0x0

    .line 385
    .local v4, "$i$a$-apply-WioCoreSettingsDialog$show$headerRow$1":I
    invoke-virtual {v3, v10}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 386
    invoke-virtual {v3, v14}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 387
    const/16 v5, 0xe

    invoke-static {v1, v5}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v6

    invoke-virtual {v3, v10, v10, v10, v6}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 388
    nop

    .line 384
    .end local v3  # "$this$show_u24lambda_u245":Landroid/widget/LinearLayout;
    .end local v4  # "$i$a$-apply-WioCoreSettingsDialog$show$headerRow$1":I
    nop

    .line 390
    .local v2, "headerRow":Landroid/widget/LinearLayout;
    new-instance v3, Landroid/widget/LinearLayout;

    invoke-direct {v3, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v4, v3

    .local v4, "$this$show_u24lambda_u246":Landroid/widget/LinearLayout;
    const/4 v6, 0x0

    .line 391
    .local v6, "$i$a$-apply-WioCoreSettingsDialog$show$titleCol$1":I
    invoke-virtual {v4, v9}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 392
    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v8, -0x2

    const/high16 v12, 0x3f800000  # 1.0f

    invoke-direct {v7, v10, v8, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    check-cast v7, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v4, v7}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 393
    nop

    .line 390
    .end local v4  # "$this$show_u24lambda_u246":Landroid/widget/LinearLayout;
    .end local v6  # "$i$a$-apply-WioCoreSettingsDialog$show$titleCol$1":I
    nop

    .line 395
    .local v3, "titleCol":Landroid/widget/LinearLayout;
    new-instance v4, Landroid/widget/LinearLayout;

    invoke-direct {v4, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v6, v4

    .local v6, "$this$show_u24lambda_u247":Landroid/widget/LinearLayout;
    const/4 v7, 0x0

    .line 396
    .local v7, "$i$a$-apply-WioCoreSettingsDialog$show$brandTitleRow$1":I
    invoke-virtual {v6, v10}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 397
    invoke-virtual {v6, v14}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 398
    nop

    .line 395
    .end local v6  # "$this$show_u24lambda_u247":Landroid/widget/LinearLayout;
    .end local v7  # "$i$a$-apply-WioCoreSettingsDialog$show$brandTitleRow$1":I
    nop

    .line 400
    .local v4, "brandTitleRow":Landroid/widget/LinearLayout;
    new-instance v6, Landroid/widget/TextView;

    invoke-direct {v6, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v7, v6

    .local v7, "$this$show_u24lambda_u248":Landroid/widget/TextView;
    const/16 v17, 0x0

    .line 401
    .local v17, "$i$a$-apply-WioCoreSettingsDialog$show$p1$1":I
    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getBrandPrefix()Ljava/lang/String;

    move-result-object v18

    move-object/from16 v14, v18

    check-cast v14, Ljava/lang/CharSequence;

    invoke-virtual {v7, v14}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 402
    const/high16 v14, 0x41a00000  # 20.0f

    invoke-virtual {v7, v14}, Landroid/widget/TextView;->setTextSize(F)V

    .line 403
    sget-object v14, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v7, v14}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 404
    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getBrandColor()I

    move-result v14

    invoke-virtual {v7, v14}, Landroid/widget/TextView;->setTextColor(I)V

    .line 405
    nop

    .line 400
    .end local v7  # "$this$show_u24lambda_u248":Landroid/widget/TextView;
    .end local v17  # "$i$a$-apply-WioCoreSettingsDialog$show$p1$1":I
    move-object v14, v6

    .line 406
    .local v14, "p1":Landroid/widget/TextView;
    new-instance v6, Landroid/widget/TextView;

    invoke-direct {v6, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v7, v6

    .local v7, "$this$show_u24lambda_u249":Landroid/widget/TextView;
    const/16 v17, 0x0

    .line 407
    .local v17, "$i$a$-apply-WioCoreSettingsDialog$show$p2$1":I
    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getBrandSuffix()Ljava/lang/String;

    move-result-object v18

    move-object/from16 v12, v18

    check-cast v12, Ljava/lang/CharSequence;

    invoke-virtual {v7, v12}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 408
    const/high16 v12, 0x41a00000  # 20.0f

    invoke-virtual {v7, v12}, Landroid/widget/TextView;->setTextSize(F)V

    .line 409
    sget-object v12, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v7, v12}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 410
    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getTextPrimary()I

    move-result v12

    invoke-virtual {v7, v12}, Landroid/widget/TextView;->setTextColor(I)V

    .line 411
    nop

    .line 406
    .end local v7  # "$this$show_u24lambda_u249":Landroid/widget/TextView;
    .end local v17  # "$i$a$-apply-WioCoreSettingsDialog$show$p2$1":I
    move-object v12, v6

    .line 412
    .local v12, "p2":Landroid/widget/TextView;
    new-instance v6, Landroid/widget/TextView;

    invoke-direct {v6, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v7, v6

    .local v7, "$this$show_u24lambda_u2410":Landroid/widget/TextView;
    const/16 v17, 0x0

    .line 413
    .local v17, "$i$a$-apply-WioCoreSettingsDialog$show$p3$1":I
    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getBrandTitleTag()Ljava/lang/String;

    move-result-object v5

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string v9, " "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    check-cast v5, Ljava/lang/CharSequence;

    invoke-virtual {v7, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 414
    const/high16 v5, 0x41800000  # 16.0f

    invoke-virtual {v7, v5}, Landroid/widget/TextView;->setTextSize(F)V

    .line 415
    sget-object v5, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v7, v5}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 416
    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getTextSecondary()I

    move-result v5

    invoke-virtual {v7, v5}, Landroid/widget/TextView;->setTextColor(I)V

    .line 417
    nop

    .line 412
    .end local v7  # "$this$show_u24lambda_u2410":Landroid/widget/TextView;
    .end local v17  # "$i$a$-apply-WioCoreSettingsDialog$show$p3$1":I
    move-object v9, v6

    .line 418
    .local v9, "p3":Landroid/widget/TextView;
    move-object v5, v14

    check-cast v5, Landroid/view/View;

    invoke-virtual {v4, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 419
    move-object v5, v12

    check-cast v5, Landroid/view/View;

    invoke-virtual {v4, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 420
    move-object v5, v9

    check-cast v5, Landroid/view/View;

    invoke-virtual {v4, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 421
    move-object v5, v4

    check-cast v5, Landroid/view/View;

    invoke-virtual {v3, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 423
    new-instance v5, Landroid/widget/TextView;

    invoke-direct {v5, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v6, v5

    .local v6, "$this$show_u24lambda_u2411":Landroid/widget/TextView;
    const/4 v7, 0x0

    .line 424
    .local v7, "$i$a$-apply-WioCoreSettingsDialog$show$summaryText$1":I
    const/high16 v8, 0x41400000  # 12.0f

    invoke-virtual {v6, v8}, Landroid/widget/TextView;->setTextSize(F)V

    .line 425
    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getTextSecondary()I

    move-result v8

    invoke-virtual {v6, v8}, Landroid/widget/TextView;->setTextColor(I)V

    .line 426
    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getSummarySubtitle()Ljava/lang/String;

    move-result-object v8

    if-eqz v8, :cond_185

    goto :goto_187

    :cond_185
    const-string v8, "Tüm kaynak ve optimizasyonlar tek merkezde"

    :goto_187
    check-cast v8, Ljava/lang/CharSequence;

    invoke-virtual {v6, v8}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 427
    const/4 v8, 0x2

    move-object/from16 v21, v4

    .end local v4  # "brandTitleRow":Landroid/widget/LinearLayout;
    .local v21, "brandTitleRow":Landroid/widget/LinearLayout;
    invoke-static {v1, v8}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v4

    invoke-virtual {v6, v10, v4, v10, v10}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 428
    nop

    .line 423
    .end local v6  # "$this$show_u24lambda_u2411":Landroid/widget/TextView;
    .end local v7  # "$i$a$-apply-WioCoreSettingsDialog$show$summaryText$1":I
    move-object/from16 v22, v5

    .line 429
    .local v22, "summaryText":Landroid/widget/TextView;
    move-object/from16 v4, v22

    check-cast v4, Landroid/view/View;

    invoke-virtual {v3, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 430
    move-object v4, v3

    check-cast v4, Landroid/view/View;

    invoke-virtual {v2, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 432
    new-instance v4, Lcom/google/android/material/button/MaterialButton;

    invoke-direct {v4, v1}, Lcom/google/android/material/button/MaterialButton;-><init>(Landroid/content/Context;)V

    move-object v5, v4

    .local v5, "$this$show_u24lambda_u2412":Lcom/google/android/material/button/MaterialButton;
    const/4 v6, 0x0

    .line 433
    .local v6, "$i$a$-apply-WioCoreSettingsDialog$show$closeBtn$1":I
    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getEnglishLabels()Z

    move-result v7

    if-eqz v7, :cond_1b6

    const-string v7, "✕ Close"

    goto :goto_1b8

    :cond_1b6
    const-string v7, "✕ Kapat"

    :goto_1b8
    check-cast v7, Ljava/lang/CharSequence;

    invoke-virtual {v5, v7}, Lcom/google/android/material/button/MaterialButton;->setText(Ljava/lang/CharSequence;)V

    .line 434
    const/high16 v7, 0x41400000  # 12.0f

    invoke-virtual {v5, v7}, Lcom/google/android/material/button/MaterialButton;->setTextSize(F)V

    .line 435
    const-string v7, "#9CA3AF"

    invoke-static {v7}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v7

    invoke-virtual {v5, v7}, Lcom/google/android/material/button/MaterialButton;->setTextColor(I)V

    .line 436
    const-string v7, "#16181D"

    invoke-static {v7}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v7

    invoke-static {v7}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v7

    invoke-virtual {v5, v7}, Lcom/google/android/material/button/MaterialButton;->setBackgroundTintList(Landroid/content/res/ColorStateList;)V

    .line 437
    const-string v7, "#292D38"

    invoke-static {v7}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v7

    invoke-static {v7}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v7

    invoke-virtual {v5, v7}, Lcom/google/android/material/button/MaterialButton;->setStrokeColor(Landroid/content/res/ColorStateList;)V

    .line 438
    const/4 v7, 0x1

    invoke-static {v1, v7}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v8

    invoke-virtual {v5, v8}, Lcom/google/android/material/button/MaterialButton;->setStrokeWidth(I)V

    .line 439
    const/16 v7, 0x64

    invoke-static {v1, v7}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v8

    invoke-virtual {v5, v8}, Lcom/google/android/material/button/MaterialButton;->setCornerRadius(I)V

    .line 440
    invoke-virtual {v5, v10}, Lcom/google/android/material/button/MaterialButton;->setAllCaps(Z)V

    .line 441
    const/16 v8, 0xc

    invoke-static {v1, v8}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v7

    move-object/from16 v25, v3

    .end local v3  # "titleCol":Landroid/widget/LinearLayout;
    .local v25, "titleCol":Landroid/widget/LinearLayout;
    const/4 v3, 0x4

    invoke-static {v1, v3}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v10

    move-object/from16 v26, v4

    invoke-static {v1, v8}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v4

    invoke-static {v1, v3}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v8

    invoke-virtual {v5, v7, v10, v4, v8}, Lcom/google/android/material/button/MaterialButton;->setPadding(IIII)V

    .line 442
    new-instance v4, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda0;

    invoke-direct {v4, v11}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda0;-><init>(Landroid/app/Dialog;)V

    invoke-virtual {v5, v4}, Lcom/google/android/material/button/MaterialButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 443
    nop

    .line 432
    .end local v5  # "$this$show_u24lambda_u2412":Lcom/google/android/material/button/MaterialButton;
    .end local v6  # "$i$a$-apply-WioCoreSettingsDialog$show$closeBtn$1":I
    nop

    .line 444
    .local v26, "closeBtn":Lcom/google/android/material/button/MaterialButton;
    move-object/from16 v4, v26

    check-cast v4, Landroid/view/View;

    invoke-virtual {v2, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 445
    move-object v4, v2

    check-cast v4, Landroid/view/View;

    invoke-virtual {v15, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 447
    new-instance v4, Landroid/widget/LinearLayout;

    invoke-direct {v4, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v5, v4

    .local v5, "$this$show_u24lambda_u2413":Landroid/widget/LinearLayout;
    const/4 v6, 0x0

    .line 448
    .local v6, "$i$a$-apply-WioCoreSettingsDialog$show$topActionRow$1":I
    const/4 v7, 0x0

    invoke-virtual {v5, v7}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 449
    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v10, -0x1

    const/4 v8, -0x2

    invoke-direct {v7, v10, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object/from16 v20, v7

    .local v20, "$this$show_u24lambda_u2413_u240":Landroid/widget/LinearLayout$LayoutParams;
    const/16 v28, 0x0

    .line 450
    .local v28, "$i$a$-apply-WioCoreSettingsDialog$show$topActionRow$1$lp$1":I
    const/16 v3, 0xc

    invoke-static {v1, v3}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v8

    move-object/from16 v3, v20

    .end local v20  # "$this$show_u24lambda_u2413_u240":Landroid/widget/LinearLayout$LayoutParams;
    .local v3, "$this$show_u24lambda_u2413_u240":Landroid/widget/LinearLayout$LayoutParams;
    iput v8, v3, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 451
    nop

    .line 449
    .end local v3  # "$this$show_u24lambda_u2413_u240":Landroid/widget/LinearLayout$LayoutParams;
    .end local v28  # "$i$a$-apply-WioCoreSettingsDialog$show$topActionRow$1$lp$1":I
    nop

    .line 452
    .local v7, "lp":Landroid/widget/LinearLayout$LayoutParams;
    move-object v3, v7

    check-cast v3, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v5, v3}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 453
    nop

    .line 447
    .end local v5  # "$this$show_u24lambda_u2413":Landroid/widget/LinearLayout;
    .end local v6  # "$i$a$-apply-WioCoreSettingsDialog$show$topActionRow$1":I
    .end local v7  # "lp":Landroid/widget/LinearLayout$LayoutParams;
    move-object v3, v4

    .line 455
    .local v3, "topActionRow":Landroid/widget/LinearLayout;
    new-instance v4, Lcom/google/android/material/button/MaterialButton;

    invoke-direct {v4, v1}, Lcom/google/android/material/button/MaterialButton;-><init>(Landroid/content/Context;)V

    move-object v5, v4

    .local v5, "$this$show_u24lambda_u2414":Lcom/google/android/material/button/MaterialButton;
    const/4 v6, 0x0

    .line 456
    .local v6, "$i$a$-apply-WioCoreSettingsDialog$show$btnClearCache$1":I
    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getEnglishLabels()Z

    move-result v7

    if-eqz v7, :cond_264

    const-string v7, "\ud83e\uddf9 Clear Cache"

    goto :goto_266

    :cond_264
    const-string v7, "\ud83e\uddf9 Önbelleği Temizle"

    :goto_266
    check-cast v7, Ljava/lang/CharSequence;

    invoke-virtual {v5, v7}, Lcom/google/android/material/button/MaterialButton;->setText(Ljava/lang/CharSequence;)V

    .line 457
    const/high16 v7, 0x41400000  # 12.0f

    invoke-virtual {v5, v7}, Lcom/google/android/material/button/MaterialButton;->setTextSize(F)V

    .line 458
    invoke-virtual {v5, v10}, Lcom/google/android/material/button/MaterialButton;->setTextColor(I)V

    .line 459
    const-string v8, "#16181D"

    invoke-static {v8}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v8

    invoke-static {v8}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v8

    invoke-virtual {v5, v8}, Lcom/google/android/material/button/MaterialButton;->setBackgroundTintList(Landroid/content/res/ColorStateList;)V

    .line 460
    const-string v8, "#292D38"

    invoke-static {v8}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v8

    invoke-static {v8}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v8

    invoke-virtual {v5, v8}, Lcom/google/android/material/button/MaterialButton;->setStrokeColor(Landroid/content/res/ColorStateList;)V

    .line 461
    const/4 v8, 0x1

    invoke-static {v1, v8}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v7

    invoke-virtual {v5, v7}, Lcom/google/android/material/button/MaterialButton;->setStrokeWidth(I)V

    .line 462
    const/16 v7, 0xe

    invoke-static {v1, v7}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v8

    invoke-virtual {v5, v8}, Lcom/google/android/material/button/MaterialButton;->setCornerRadius(I)V

    .line 463
    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v8, 0x2c

    invoke-static {v1, v8}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v10

    move-object/from16 v30, v2

    const/4 v2, 0x0

    const/high16 v8, 0x3f800000  # 1.0f

    .end local v2  # "headerRow":Landroid/widget/LinearLayout;
    .local v30, "headerRow":Landroid/widget/LinearLayout;
    invoke-direct {v7, v2, v10, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    move-object v2, v7

    .local v2, "$this$show_u24lambda_u2414_u240":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v8, 0x0

    .line 464
    .local v8, "$i$a$-apply-WioCoreSettingsDialog$show$btnClearCache$1$lp$1":I
    const/16 v10, 0x8

    move-object/from16 v31, v4

    invoke-static {v1, v10}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v4

    invoke-virtual {v2, v4}, Landroid/widget/LinearLayout$LayoutParams;->setMarginEnd(I)V

    .line 465
    nop

    .line 463
    .end local v2  # "$this$show_u24lambda_u2414_u240":Landroid/widget/LinearLayout$LayoutParams;
    .end local v8  # "$i$a$-apply-WioCoreSettingsDialog$show$btnClearCache$1$lp$1":I
    nop

    .line 466
    .restart local v7  # "lp":Landroid/widget/LinearLayout$LayoutParams;
    move-object v2, v7

    check-cast v2, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v5, v2}, Lcom/google/android/material/button/MaterialButton;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 467
    const/4 v2, 0x0

    invoke-virtual {v5, v2}, Lcom/google/android/material/button/MaterialButton;->setAllCaps(Z)V

    .line 468
    new-instance v2, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda11;

    invoke-direct {v2, v13, v0, v1}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda11;-><init>(Lkotlinx/coroutines/CoroutineScope;Ldev/wiojelt/turksinema/common/WioSettingsConfig;Landroid/content/Context;)V

    invoke-virtual {v5, v2}, Lcom/google/android/material/button/MaterialButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 482
    nop

    .line 455
    .end local v5  # "$this$show_u24lambda_u2414":Lcom/google/android/material/button/MaterialButton;
    .end local v6  # "$i$a$-apply-WioCoreSettingsDialog$show$btnClearCache$1":I
    .end local v7  # "lp":Landroid/widget/LinearLayout$LayoutParams;
    nop

    .line 484
    .local v31, "btnClearCache":Lcom/google/android/material/button/MaterialButton;
    new-instance v2, Lcom/google/android/material/button/MaterialButton;

    invoke-direct {v2, v1}, Lcom/google/android/material/button/MaterialButton;-><init>(Landroid/content/Context;)V

    move-object v4, v2

    .local v4, "$this$show_u24lambda_u2415":Lcom/google/android/material/button/MaterialButton;
    const/4 v5, 0x0

    .line 485
    .local v5, "$i$a$-apply-WioCoreSettingsDialog$show$btnSaveClose$1":I
    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getEnglishLabels()Z

    move-result v6

    if-eqz v6, :cond_2e1

    const-string v6, "✓ Save and Close"

    goto :goto_2e3

    :cond_2e1
    const-string v6, "✓ Kaydet ve Kapat"

    :goto_2e3
    check-cast v6, Ljava/lang/CharSequence;

    invoke-virtual {v4, v6}, Lcom/google/android/material/button/MaterialButton;->setText(Ljava/lang/CharSequence;)V

    .line 486
    const/high16 v6, 0x41500000  # 13.0f

    invoke-virtual {v4, v6}, Lcom/google/android/material/button/MaterialButton;->setTextSize(F)V

    .line 487
    sget-object v6, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v4, v6}, Lcom/google/android/material/button/MaterialButton;->setTypeface(Landroid/graphics/Typeface;)V

    .line 488
    const/high16 v6, -0x1000000

    invoke-virtual {v4, v6}, Lcom/google/android/material/button/MaterialButton;->setTextColor(I)V

    .line 489
    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getBrandColor()I

    move-result v6

    invoke-static {v6}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v6

    invoke-virtual {v4, v6}, Lcom/google/android/material/button/MaterialButton;->setBackgroundTintList(Landroid/content/res/ColorStateList;)V

    .line 490
    const/16 v7, 0xe

    invoke-static {v1, v7}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v6

    invoke-virtual {v4, v6}, Lcom/google/android/material/button/MaterialButton;->setCornerRadius(I)V

    .line 491
    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v7, 0x2c

    invoke-static {v1, v7}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v8

    const v7, 0x3f99999a  # 1.2f

    const/4 v10, 0x0

    invoke-direct {v6, v10, v8, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    .line 492
    .local v6, "lp":Landroid/widget/LinearLayout$LayoutParams;
    move-object v7, v6

    check-cast v7, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v4, v7}, Lcom/google/android/material/button/MaterialButton;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 493
    invoke-virtual {v4, v10}, Lcom/google/android/material/button/MaterialButton;->setAllCaps(Z)V

    .line 494
    new-instance v7, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda15;

    invoke-direct {v7, v0, v11}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda15;-><init>(Ldev/wiojelt/turksinema/common/WioSettingsConfig;Landroid/app/Dialog;)V

    invoke-virtual {v4, v7}, Lcom/google/android/material/button/MaterialButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 498
    nop

    .line 484
    .end local v4  # "$this$show_u24lambda_u2415":Lcom/google/android/material/button/MaterialButton;
    .end local v5  # "$i$a$-apply-WioCoreSettingsDialog$show$btnSaveClose$1":I
    .end local v6  # "lp":Landroid/widget/LinearLayout$LayoutParams;
    move-object v10, v2

    .line 500
    .local v10, "btnSaveClose":Lcom/google/android/material/button/MaterialButton;
    move-object/from16 v2, v31

    check-cast v2, Landroid/view/View;

    invoke-virtual {v3, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 501
    move-object v2, v10

    check-cast v2, Landroid/view/View;

    invoke-virtual {v3, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 502
    move-object v2, v3

    check-cast v2, Landroid/view/View;

    invoke-virtual {v15, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 504
    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getOnCustomListClick()Lkotlin/jvm/functions/Function0;

    move-result-object v2

    const/high16 v5, 0x41480000  # 12.5f

    if-eqz v2, :cond_3be

    .local v2, "onCustomList":Lkotlin/jvm/functions/Function0;
    const/4 v6, 0x0

    .line 505
    .local v6, "$i$a$-let-WioCoreSettingsDialog$show$1":I
    new-instance v7, Lcom/google/android/material/button/MaterialButton;

    invoke-direct {v7, v1}, Lcom/google/android/material/button/MaterialButton;-><init>(Landroid/content/Context;)V

    move-object v8, v7

    .local v8, "$this$show_u24lambda_u2416_u240":Lcom/google/android/material/button/MaterialButton;
    const/16 v32, 0x0

    .line 506
    .local v32, "$i$a$-apply-WioCoreSettingsDialog$show$1$customListBtn$1":I
    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getCustomListSummary()Ljava/lang/String;

    move-result-object v33

    if-eqz v33, :cond_358

    goto :goto_35a

    :cond_358
    const-string v33, "\ud83d\udccb Özel M3U / IPTV Listelerim (Ekle / Kaldır)"

    :goto_35a
    check-cast v33, Ljava/lang/CharSequence;

    move-object/from16 v4, v33

    invoke-virtual {v8, v4}, Lcom/google/android/material/button/MaterialButton;->setText(Ljava/lang/CharSequence;)V

    .line 507
    invoke-virtual {v8, v5}, Lcom/google/android/material/button/MaterialButton;->setTextSize(F)V

    .line 508
    sget-object v4, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v8, v4}, Lcom/google/android/material/button/MaterialButton;->setTypeface(Landroid/graphics/Typeface;)V

    .line 509
    const/high16 v4, -0x1000000

    invoke-virtual {v8, v4}, Lcom/google/android/material/button/MaterialButton;->setTextColor(I)V

    .line 510
    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getBrandColor()I

    move-result v4

    invoke-static {v4}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v4

    invoke-virtual {v8, v4}, Lcom/google/android/material/button/MaterialButton;->setBackgroundTintList(Landroid/content/res/ColorStateList;)V

    .line 511
    const/16 v4, 0x64

    invoke-static {v1, v4}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v5

    invoke-virtual {v8, v5}, Lcom/google/android/material/button/MaterialButton;->setCornerRadius(I)V

    .line 512
    const/4 v5, 0x0

    invoke-virtual {v8, v5}, Lcom/google/android/material/button/MaterialButton;->setAllCaps(Z)V

    .line 513
    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v4, 0x2a

    invoke-static {v1, v4}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v0

    const/4 v4, -0x1

    invoke-direct {v5, v4, v0}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object v0, v5

    .local v0, "$this$show_u24lambda_u2416_u240_u240":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v4, 0x0

    .line 514
    .local v4, "$i$a$-apply-WioCoreSettingsDialog$show$1$customListBtn$1$lp$1":I
    move-object/from16 v34, v3

    move/from16 v35, v4

    const/16 v3, 0xc

    .end local v3  # "topActionRow":Landroid/widget/LinearLayout;
    .end local v4  # "$i$a$-apply-WioCoreSettingsDialog$show$1$customListBtn$1$lp$1":I
    .local v34, "topActionRow":Landroid/widget/LinearLayout;
    .local v35, "$i$a$-apply-WioCoreSettingsDialog$show$1$customListBtn$1$lp$1":I
    invoke-static {v1, v3}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v4

    iput v4, v0, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 515
    nop

    .line 513
    .end local v0  # "$this$show_u24lambda_u2416_u240_u240":Landroid/widget/LinearLayout$LayoutParams;
    .end local v35  # "$i$a$-apply-WioCoreSettingsDialog$show$1$customListBtn$1$lp$1":I
    nop

    .line 516
    .local v5, "lp":Landroid/widget/LinearLayout$LayoutParams;
    move-object v0, v5

    check-cast v0, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v8, v0}, Lcom/google/android/material/button/MaterialButton;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 517
    new-instance v0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda16;

    invoke-direct {v0, v11, v2}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda16;-><init>(Landroid/app/Dialog;Lkotlin/jvm/functions/Function0;)V

    invoke-virtual {v8, v0}, Lcom/google/android/material/button/MaterialButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 521
    nop

    .line 505
    .end local v5  # "lp":Landroid/widget/LinearLayout$LayoutParams;
    .end local v8  # "$this$show_u24lambda_u2416_u240":Lcom/google/android/material/button/MaterialButton;
    .end local v32  # "$i$a$-apply-WioCoreSettingsDialog$show$1$customListBtn$1":I
    nop

    .line 522
    .local v7, "customListBtn":Lcom/google/android/material/button/MaterialButton;
    move-object v0, v7

    check-cast v0, Landroid/view/View;

    invoke-virtual {v15, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 523
    nop

    .end local v2  # "onCustomList":Lkotlin/jvm/functions/Function0;
    .end local v6  # "$i$a$-let-WioCoreSettingsDialog$show$1":I
    .end local v7  # "customListBtn":Lcom/google/android/material/button/MaterialButton;
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 504
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    goto :goto_3c0

    .end local v34  # "topActionRow":Landroid/widget/LinearLayout;
    .restart local v3  # "topActionRow":Landroid/widget/LinearLayout;
    :cond_3be
    move-object/from16 v34, v3

    .line 525
    .end local v3  # "topActionRow":Landroid/widget/LinearLayout;
    .restart local v34  # "topActionRow":Landroid/widget/LinearLayout;
    :goto_3c0
    new-instance v0, Lkotlin/jvm/internal/Ref$ObjectRef;

    invoke-direct {v0}, Lkotlin/jvm/internal/Ref$ObjectRef;-><init>()V

    .line 526
    .local v0, "scanDurationLabel":Lkotlin/jvm/internal/Ref$ObjectRef;
    new-instance v2, Lkotlin/jvm/internal/Ref$ObjectRef;

    invoke-direct {v2}, Lkotlin/jvm/internal/Ref$ObjectRef;-><init>()V

    .line 547
    .local v2, "scanDurationSeekBar":Lkotlin/jvm/internal/Ref$ObjectRef;
    invoke-virtual/range {p2 .. p2}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->isTvBoxSupported()Z

    move-result v3

    if-eqz v3, :cond_539

    .line 548
    invoke-virtual/range {p0 .. p1}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->isAutoDetectedTvOrLowRam(Landroid/content/Context;)Z

    move-result v32

    .line 549
    .local v32, "isTv":Z
    new-instance v3, Landroid/widget/LinearLayout;

    invoke-direct {v3, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v5, v3

    .local v5, "$this$show_u24lambda_u2418":Landroid/widget/LinearLayout;
    const/16 v35, 0x0

    .line 550
    .local v35, "$i$a$-apply-WioCoreSettingsDialog$show$tvBoxCard$1":I
    const/4 v7, 0x0

    invoke-virtual {v5, v7}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 551
    const/16 v6, 0x10

    invoke-virtual {v5, v6}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 552
    invoke-static {v1, v6}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v7

    const/16 v8, 0xc

    invoke-static {v1, v8}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v4

    move-object/from16 v36, v0

    .end local v0  # "scanDurationLabel":Lkotlin/jvm/internal/Ref$ObjectRef;
    .local v36, "scanDurationLabel":Lkotlin/jvm/internal/Ref$ObjectRef;
    invoke-static {v1, v6}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v0

    invoke-static {v1, v8}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v6

    invoke-virtual {v5, v7, v4, v0, v6}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 553
    const/16 v7, 0x7c

    move v0, v8

    const/4 v8, 0x0

    move-object v4, v2

    .end local v2  # "scanDurationSeekBar":Lkotlin/jvm/internal/Ref$ObjectRef;
    .local v4, "scanDurationSeekBar":Lkotlin/jvm/internal/Ref$ObjectRef;
    const/4 v2, 0x0

    move-object v6, v3

    const/4 v3, 0x0

    move-object/from16 v37, v4

    .end local v4  # "scanDurationSeekBar":Lkotlin/jvm/internal/Ref$ObjectRef;
    .local v37, "scanDurationSeekBar":Lkotlin/jvm/internal/Ref$ObjectRef;
    const/4 v4, 0x0

    move-object/from16 v38, v5

    .end local v5  # "$this$show_u24lambda_u2418":Landroid/widget/LinearLayout;
    .local v38, "$this$show_u24lambda_u2418":Landroid/widget/LinearLayout;
    const/4 v5, 0x0

    move-object/from16 v39, v6

    const/4 v6, 0x0

    move-object/from16 v0, p2

    move-object/from16 v17, v9

    move-object/from16 v23, v10

    move-object/from16 v24, v12

    move-object/from16 v27, v13

    move-object/from16 v9, v36

    move-object/from16 v10, v37

    move-object/from16 v12, v38

    move-object/from16 v38, v39

    const/4 v13, -0x2

    .end local v13  # "scope":Lkotlinx/coroutines/CoroutineScope;
    .end local v36  # "scanDurationLabel":Lkotlin/jvm/internal/Ref$ObjectRef;
    .end local v37  # "scanDurationSeekBar":Lkotlin/jvm/internal/Ref$ObjectRef;
    .end local v38  # "$this$show_u24lambda_u2418":Landroid/widget/LinearLayout;
    .local v9, "scanDurationLabel":Lkotlin/jvm/internal/Ref$ObjectRef;
    .local v10, "scanDurationSeekBar":Lkotlin/jvm/internal/Ref$ObjectRef;
    .local v12, "$this$show_u24lambda_u2418":Landroid/widget/LinearLayout;
    .local v17, "p3":Landroid/widget/TextView;
    .local v23, "btnSaveClose":Lcom/google/android/material/button/MaterialButton;
    .local v24, "p2":Landroid/widget/TextView;
    .local v27, "scope":Lkotlinx/coroutines/CoroutineScope;
    invoke-static/range {v0 .. v8}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$focusableGlassDrawable$default(Ldev/wiojelt/turksinema/common/WioSettingsConfig;Landroid/content/Context;IIIIFILjava/lang/Object;)Landroid/graphics/drawable/StateListDrawable;

    move-result-object v2

    check-cast v2, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v12, v2}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 554
    const/4 v7, 0x1

    invoke-virtual {v12, v7}, Landroid/widget/LinearLayout;->setFocusable(Z)V

    .line 555
    invoke-virtual {v12, v7}, Landroid/widget/LinearLayout;->setClickable(Z)V

    .line 556
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v4, -0x1

    invoke-direct {v2, v4, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 557
    .local v2, "lp":Landroid/widget/LinearLayout$LayoutParams;
    const/16 v3, 0xc

    invoke-static {v1, v3}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v4

    iput v4, v2, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 558
    move-object v3, v2

    check-cast v3, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v12, v3}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 559
    nop

    .line 549
    .end local v2  # "lp":Landroid/widget/LinearLayout$LayoutParams;
    .end local v12  # "$this$show_u24lambda_u2418":Landroid/widget/LinearLayout;
    .end local v35  # "$i$a$-apply-WioCoreSettingsDialog$show$tvBoxCard$1":I
    move-object/from16 v2, v38

    .line 561
    .local v2, "tvBoxCard":Landroid/widget/LinearLayout;
    new-instance v3, Landroid/widget/LinearLayout;

    invoke-direct {v3, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v4, v3

    .local v4, "$this$show_u24lambda_u2419":Landroid/widget/LinearLayout;
    const/4 v5, 0x0

    .line 562
    .local v5, "$i$a$-apply-WioCoreSettingsDialog$show$tvBoxInfo$1":I
    const/4 v7, 0x1

    invoke-virtual {v4, v7}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 563
    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v7, 0x0

    const/high16 v8, 0x3f800000  # 1.0f

    invoke-direct {v6, v7, v13, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    check-cast v6, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v4, v6}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 564
    nop

    .line 561
    .end local v4  # "$this$show_u24lambda_u2419":Landroid/widget/LinearLayout;
    .end local v5  # "$i$a$-apply-WioCoreSettingsDialog$show$tvBoxInfo$1":I
    nop

    .line 566
    .local v3, "tvBoxInfo":Landroid/widget/LinearLayout;
    new-instance v4, Landroid/widget/TextView;

    invoke-direct {v4, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v5, v4

    .local v5, "$this$show_u24lambda_u2420":Landroid/widget/TextView;
    const/4 v6, 0x0

    .line 567
    .local v6, "$i$a$-apply-WioCoreSettingsDialog$show$tvBoxTitle$1":I
    const-string v7, "\ud83d\udcfa TV Box / Düşük Bellek Modu"

    check-cast v7, Ljava/lang/CharSequence;

    invoke-virtual {v5, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 568
    const/high16 v7, 0x41680000  # 14.5f

    invoke-virtual {v5, v7}, Landroid/widget/TextView;->setTextSize(F)V

    .line 569
    sget-object v7, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v5, v7}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 570
    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getTextPrimary()I

    move-result v7

    invoke-virtual {v5, v7}, Landroid/widget/TextView;->setTextColor(I)V

    .line 571
    nop

    .line 566
    .end local v5  # "$this$show_u24lambda_u2420":Landroid/widget/TextView;
    .end local v6  # "$i$a$-apply-WioCoreSettingsDialog$show$tvBoxTitle$1":I
    nop

    .line 573
    .local v4, "tvBoxTitle":Landroid/widget/TextView;
    new-instance v5, Landroid/widget/TextView;

    invoke-direct {v5, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v6, v5

    .local v6, "$this$show_u24lambda_u2421":Landroid/widget/TextView;
    const/4 v7, 0x0

    .line 574
    .local v7, "$i$a$-apply-WioCoreSettingsDialog$show$tvBoxDesc$1":I
    const/high16 v8, 0x41300000  # 11.0f

    invoke-virtual {v6, v8}, Landroid/widget/TextView;->setTextSize(F)V

    .line 575
    if-eqz v32, :cond_497

    const-string v8, "#00E676"

    invoke-static {v8}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v8

    goto :goto_49b

    :cond_497
    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getTextSecondary()I

    move-result v8

    :goto_49b
    invoke-virtual {v6, v8}, Landroid/widget/TextView;->setTextColor(I)V

    .line 576
    if-eqz v32, :cond_4a5

    const-string v8, "✓ TV / Kısıtlı RAM tespit edildi · Eşzamanlı taramayı sınırlar"

    check-cast v8, Ljava/lang/CharSequence;

    goto :goto_4a9

    .line 577
    :cond_4a5
    const-string v8, "Eşzamanlı kaynak taramasını sınırlandırır (Düşük RAM donmalarını önler)"

    check-cast v8, Ljava/lang/CharSequence;

    .line 576
    :goto_4a9
    invoke-virtual {v6, v8}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 578
    const/4 v8, 0x3

    invoke-static {v1, v8}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v8

    const/4 v12, 0x0

    invoke-virtual {v6, v12, v8, v12, v12}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 579
    nop

    .line 573
    .end local v6  # "$this$show_u24lambda_u2421":Landroid/widget/TextView;
    .end local v7  # "$i$a$-apply-WioCoreSettingsDialog$show$tvBoxDesc$1":I
    nop

    .line 581
    .local v5, "tvBoxDesc":Landroid/widget/TextView;
    move-object v6, v4

    check-cast v6, Landroid/view/View;

    invoke-virtual {v3, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 582
    move-object v6, v5

    check-cast v6, Landroid/view/View;

    invoke-virtual {v3, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 584
    new-instance v6, Lcom/google/android/material/switchmaterial/SwitchMaterial;

    invoke-direct {v6, v1}, Lcom/google/android/material/switchmaterial/SwitchMaterial;-><init>(Landroid/content/Context;)V

    move-object v7, v6

    .local v7, "$this$show_u24lambda_u2422":Lcom/google/android/material/switchmaterial/SwitchMaterial;
    const/4 v8, 0x0

    .line 585
    .local v8, "$i$a$-apply-WioCoreSettingsDialog$show$tvBoxSwitch$1":I
    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->isTvBoxActive()Lkotlin/jvm/functions/Function0;

    move-result-object v12

    invoke-interface {v12}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ljava/lang/Boolean;

    invoke-virtual {v12}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v12

    invoke-virtual {v7, v12}, Lcom/google/android/material/switchmaterial/SwitchMaterial;->setChecked(Z)V

    .line 586
    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getBrandColor()I

    move-result v12

    invoke-static {v12}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v12

    invoke-virtual {v7, v12}, Lcom/google/android/material/switchmaterial/SwitchMaterial;->setThumbTintList(Landroid/content/res/ColorStateList;)V

    .line 587
    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getBrandColor()I

    move-result v12

    invoke-static {v12}, Landroid/graphics/Color;->red(I)I

    move-result v12

    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getBrandColor()I

    move-result v33

    invoke-static/range {v33 .. v33}, Landroid/graphics/Color;->green(I)I

    move-result v13

    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getBrandColor()I

    move-result v33

    move-object/from16 v36, v3

    .end local v3  # "tvBoxInfo":Landroid/widget/LinearLayout;
    .local v36, "tvBoxInfo":Landroid/widget/LinearLayout;
    invoke-static/range {v33 .. v33}, Landroid/graphics/Color;->blue(I)I

    move-result v3

    move-object/from16 v33, v4

    .end local v4  # "tvBoxTitle":Landroid/widget/TextView;
    .local v33, "tvBoxTitle":Landroid/widget/TextView;
    const/16 v4, 0x50

    invoke-static {v4, v12, v13, v3}, Landroid/graphics/Color;->argb(IIII)I

    move-result v3

    invoke-static {v3}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v3

    invoke-virtual {v7, v3}, Lcom/google/android/material/switchmaterial/SwitchMaterial;->setTrackTintList(Landroid/content/res/ColorStateList;)V

    .line 588
    const/4 v12, 0x0

    invoke-virtual {v7, v12}, Lcom/google/android/material/switchmaterial/SwitchMaterial;->setFocusable(Z)V

    .line 589
    nop

    .line 584
    .end local v7  # "$this$show_u24lambda_u2422":Lcom/google/android/material/switchmaterial/SwitchMaterial;
    .end local v8  # "$i$a$-apply-WioCoreSettingsDialog$show$tvBoxSwitch$1":I
    nop

    .line 591
    .local v6, "tvBoxSwitch":Lcom/google/android/material/switchmaterial/SwitchMaterial;
    new-instance v3, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda17;

    invoke-direct {v3, v6}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda17;-><init>(Lcom/google/android/material/switchmaterial/SwitchMaterial;)V

    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 594
    new-instance v3, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda18;

    invoke-direct {v3, v0, v9, v10}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda18;-><init>(Ldev/wiojelt/turksinema/common/WioSettingsConfig;Lkotlin/jvm/internal/Ref$ObjectRef;Lkotlin/jvm/internal/Ref$ObjectRef;)V

    invoke-virtual {v6, v3}, Lcom/google/android/material/switchmaterial/SwitchMaterial;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    .line 599
    move-object/from16 v3, v36

    check-cast v3, Landroid/view/View;

    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 600
    move-object v3, v6

    check-cast v3, Landroid/view/View;

    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 601
    move-object v3, v2

    check-cast v3, Landroid/view/View;

    invoke-virtual {v15, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    goto :goto_545

    .line 547
    .end local v5  # "tvBoxDesc":Landroid/widget/TextView;
    .end local v6  # "tvBoxSwitch":Lcom/google/android/material/switchmaterial/SwitchMaterial;
    .end local v17  # "p3":Landroid/widget/TextView;
    .end local v23  # "btnSaveClose":Lcom/google/android/material/button/MaterialButton;
    .end local v24  # "p2":Landroid/widget/TextView;
    .end local v27  # "scope":Lkotlinx/coroutines/CoroutineScope;
    .end local v32  # "isTv":Z
    .end local v33  # "tvBoxTitle":Landroid/widget/TextView;
    .end local v36  # "tvBoxInfo":Landroid/widget/LinearLayout;
    .restart local v0  # "scanDurationLabel":Lkotlin/jvm/internal/Ref$ObjectRef;
    .local v2, "scanDurationSeekBar":Lkotlin/jvm/internal/Ref$ObjectRef;
    .local v9, "p3":Landroid/widget/TextView;
    .local v10, "btnSaveClose":Lcom/google/android/material/button/MaterialButton;
    .local v12, "p2":Landroid/widget/TextView;
    .restart local v13  # "scope":Lkotlinx/coroutines/CoroutineScope;
    :cond_539
    move-object/from16 v17, v9

    move-object/from16 v23, v10

    move-object/from16 v24, v12

    move-object/from16 v27, v13

    move-object v9, v0

    move-object v10, v2

    move-object/from16 v0, p2

    .line 604
    .end local v0  # "scanDurationLabel":Lkotlin/jvm/internal/Ref$ObjectRef;
    .end local v2  # "scanDurationSeekBar":Lkotlin/jvm/internal/Ref$ObjectRef;
    .end local v12  # "p2":Landroid/widget/TextView;
    .end local v13  # "scope":Lkotlinx/coroutines/CoroutineScope;
    .local v9, "scanDurationLabel":Lkotlin/jvm/internal/Ref$ObjectRef;
    .local v10, "scanDurationSeekBar":Lkotlin/jvm/internal/Ref$ObjectRef;
    .restart local v17  # "p3":Landroid/widget/TextView;
    .restart local v23  # "btnSaveClose":Lcom/google/android/material/button/MaterialButton;
    .restart local v24  # "p2":Landroid/widget/TextView;
    .restart local v27  # "scope":Lkotlinx/coroutines/CoroutineScope;
    :goto_545
    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->isScanDurationSupported()Z

    move-result v2

    const/16 v12, 0xa

    if-eqz v2, :cond_643

    .line 605
    new-instance v13, Landroid/widget/LinearLayout;

    invoke-direct {v13, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v2, v13

    .local v2, "$this$show_u24lambda_u2425":Landroid/widget/LinearLayout;
    const/16 v32, 0x0

    .line 606
    .local v32, "$i$a$-apply-WioCoreSettingsDialog$show$durationCard$1":I
    const/4 v7, 0x1

    invoke-virtual {v2, v7}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 607
    const/16 v6, 0x10

    invoke-static {v1, v6}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v3

    invoke-static {v1, v12}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v4

    invoke-static {v1, v6}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v5

    const/16 v6, 0x8

    invoke-static {v1, v6}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v7

    invoke-virtual {v2, v3, v4, v5, v7}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 608
    move-object v3, v2

    .end local v2  # "$this$show_u24lambda_u2425":Landroid/widget/LinearLayout;
    .local v3, "$this$show_u24lambda_u2425":Landroid/widget/LinearLayout;
    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getCardBgSubtle()I

    move-result v2

    const-string v4, "#20FFFFFF"

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    const/16 v7, 0x30

    const/4 v8, 0x0

    move-object v5, v3

    move v3, v4

    .end local v3  # "$this$show_u24lambda_u2425":Landroid/widget/LinearLayout;
    .local v5, "$this$show_u24lambda_u2425":Landroid/widget/LinearLayout;
    const/4 v4, 0x0

    move-object v6, v5

    .end local v5  # "$this$show_u24lambda_u2425":Landroid/widget/LinearLayout;
    .local v6, "$this$show_u24lambda_u2425":Landroid/widget/LinearLayout;
    const/4 v5, 0x0

    move-object/from16 v33, v6

    .end local v6  # "$this$show_u24lambda_u2425":Landroid/widget/LinearLayout;
    .local v33, "$this$show_u24lambda_u2425":Landroid/widget/LinearLayout;
    const/high16 v6, 0x41600000  # 14.0f

    move-object/from16 v12, v33

    .end local v33  # "$this$show_u24lambda_u2425":Landroid/widget/LinearLayout;
    .local v12, "$this$show_u24lambda_u2425":Landroid/widget/LinearLayout;
    invoke-static/range {v0 .. v8}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$focusableGlassDrawable$default(Ldev/wiojelt/turksinema/common/WioSettingsConfig;Landroid/content/Context;IIIIFILjava/lang/Object;)Landroid/graphics/drawable/StateListDrawable;

    move-result-object v2

    check-cast v2, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v12, v2}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 609
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v4, -0x1

    const/4 v8, -0x2

    invoke-direct {v2, v4, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object v3, v2

    .local v3, "$this$show_u24lambda_u2425_u240":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v4, 0x0

    .line 610
    .local v4, "$i$a$-apply-WioCoreSettingsDialog$show$durationCard$1$1":I
    const/16 v5, 0xa

    invoke-static {v1, v5}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v6

    iput v6, v3, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 611
    nop

    .line 609
    .end local v3  # "$this$show_u24lambda_u2425_u240":Landroid/widget/LinearLayout$LayoutParams;
    .end local v4  # "$i$a$-apply-WioCoreSettingsDialog$show$durationCard$1$1":I
    check-cast v2, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v12, v2}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 612
    nop

    .line 605
    .end local v12  # "$this$show_u24lambda_u2425":Landroid/widget/LinearLayout;
    .end local v32  # "$i$a$-apply-WioCoreSettingsDialog$show$durationCard$1":I
    nop

    .line 614
    .local v13, "durationCard":Landroid/widget/LinearLayout;
    new-instance v2, Landroid/widget/TextView;

    invoke-direct {v2, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v3, v2

    .local v3, "$this$show_u24lambda_u2426":Landroid/widget/TextView;
    const/4 v4, 0x0

    .line 615
    .local v4, "$i$a$-apply-WioCoreSettingsDialog$show$4":I
    const/high16 v5, 0x41480000  # 12.5f

    invoke-virtual {v3, v5}, Landroid/widget/TextView;->setTextSize(F)V

    .line 616
    sget-object v5, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v3, v5}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 617
    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getTextPrimary()I

    move-result v5

    invoke-virtual {v3, v5}, Landroid/widget/TextView;->setTextColor(I)V

    .line 618
    nop

    .end local v3  # "$this$show_u24lambda_u2426":Landroid/widget/TextView;
    .end local v4  # "$i$a$-apply-WioCoreSettingsDialog$show$4":I
    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 614
    iput-object v2, v9, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    .line 619
    iget-object v2, v9, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    check-cast v2, Landroid/view/View;

    invoke-virtual {v13, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 621
    new-instance v2, Landroid/widget/SeekBar;

    invoke-direct {v2, v1}, Landroid/widget/SeekBar;-><init>(Landroid/content/Context;)V

    move-object v3, v2

    .local v3, "$this$show_u24lambda_u2427":Landroid/widget/SeekBar;
    const/4 v4, 0x0

    .line 622
    .local v4, "$i$a$-apply-WioCoreSettingsDialog$show$5":I
    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getMaxScanDurationSeconds()I

    move-result v5

    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getMinScanDurationSeconds()I

    move-result v6

    sub-int/2addr v5, v6

    const/4 v7, 0x0

    invoke-static {v5, v7}, Lkotlin/ranges/RangesKt;->coerceAtLeast(II)I

    move-result v5

    invoke-virtual {v3, v5}, Landroid/widget/SeekBar;->setMax(I)V

    .line 623
    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getBrandColor()I

    move-result v5

    invoke-static {v5}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v5

    invoke-virtual {v3, v5}, Landroid/widget/SeekBar;->setProgressTintList(Landroid/content/res/ColorStateList;)V

    .line 624
    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getBrandColor()I

    move-result v5

    invoke-static {v5}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v5

    invoke-virtual {v3, v5}, Landroid/widget/SeekBar;->setThumbTintList(Landroid/content/res/ColorStateList;)V

    .line 625
    new-instance v5, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$5$1;

    invoke-direct {v5, v0, v9, v10}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$5$1;-><init>(Ldev/wiojelt/turksinema/common/WioSettingsConfig;Lkotlin/jvm/internal/Ref$ObjectRef;Lkotlin/jvm/internal/Ref$ObjectRef;)V

    check-cast v5, Landroid/widget/SeekBar$OnSeekBarChangeListener;

    invoke-virtual {v3, v5}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    .line 641
    nop

    .end local v3  # "$this$show_u24lambda_u2427":Landroid/widget/SeekBar;
    .end local v4  # "$i$a$-apply-WioCoreSettingsDialog$show$5":I
    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 621
    iput-object v2, v10, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    .line 642
    iget-object v2, v10, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    check-cast v2, Landroid/view/View;

    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v4, 0x22

    invoke-static {v1, v4}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v4

    const/4 v5, -0x1

    invoke-direct {v3, v5, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    check-cast v3, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v13, v2, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 643
    move-object v2, v13

    check-cast v2, Landroid/view/View;

    invoke-virtual {v15, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 644
    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->isTvBoxSupported()Z

    move-result v2

    if-eqz v2, :cond_63f

    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->isTvBoxActive()Lkotlin/jvm/functions/Function0;

    move-result-object v2

    invoke-interface {v2}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Boolean;

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-eqz v2, :cond_63f

    const/4 v2, 0x1

    goto :goto_640

    :cond_63f
    const/4 v2, 0x0

    :goto_640
    invoke-static {v0, v9, v10, v2}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$refreshScanDurationUi(Ldev/wiojelt/turksinema/common/WioSettingsConfig;Lkotlin/jvm/internal/Ref$ObjectRef;Lkotlin/jvm/internal/Ref$ObjectRef;Z)V

    .line 647
    .end local v13  # "durationCard":Landroid/widget/LinearLayout;
    :cond_643
    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getOnWizardClick()Lkotlin/jvm/functions/Function0;

    move-result-object v2

    if-eqz v2, :cond_6bf

    .line 648
    new-instance v2, Lcom/google/android/material/button/MaterialButton;

    invoke-direct {v2, v1}, Lcom/google/android/material/button/MaterialButton;-><init>(Landroid/content/Context;)V

    move-object v3, v2

    .local v3, "$this$show_u24lambda_u2428":Lcom/google/android/material/button/MaterialButton;
    const/4 v4, 0x0

    .line 649
    .local v4, "$i$a$-apply-WioCoreSettingsDialog$show$wizardBtn$1":I
    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getEnglishLabels()Z

    move-result v5

    if-eqz v5, :cond_659

    const-string v5, "\ud83e\ude84 Setup Wizard & Mode Selection"

    goto :goto_65b

    :cond_659
    const-string v5, "\ud83e\ude84 Mod Seçimi & Kurulum Sihirbazı"

    :goto_65b
    check-cast v5, Ljava/lang/CharSequence;

    invoke-virtual {v3, v5}, Lcom/google/android/material/button/MaterialButton;->setText(Ljava/lang/CharSequence;)V

    .line 650
    const/high16 v12, 0x41400000  # 12.0f

    invoke-virtual {v3, v12}, Lcom/google/android/material/button/MaterialButton;->setTextSize(F)V

    .line 651
    const/4 v5, -0x1

    invoke-virtual {v3, v5}, Lcom/google/android/material/button/MaterialButton;->setTextColor(I)V

    .line 652
    const-string v5, "#1B222A"

    invoke-static {v5}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v5

    invoke-static {v5}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v5

    invoke-virtual {v3, v5}, Lcom/google/android/material/button/MaterialButton;->setBackgroundTintList(Landroid/content/res/ColorStateList;)V

    .line 653
    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getBrandColorBorder()I

    move-result v5

    invoke-static {v5}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v5

    invoke-virtual {v3, v5}, Lcom/google/android/material/button/MaterialButton;->setStrokeColor(Landroid/content/res/ColorStateList;)V

    .line 654
    const/4 v7, 0x1

    invoke-static {v1, v7}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v5

    invoke-virtual {v3, v5}, Lcom/google/android/material/button/MaterialButton;->setStrokeWidth(I)V

    .line 655
    const/16 v5, 0xa

    invoke-static {v1, v5}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v6

    invoke-virtual {v3, v6}, Lcom/google/android/material/button/MaterialButton;->setCornerRadius(I)V

    .line 656
    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v7, 0x28

    invoke-static {v1, v7}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v7

    const/4 v8, -0x1

    invoke-direct {v6, v8, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 657
    .local v6, "lp":Landroid/widget/LinearLayout$LayoutParams;
    invoke-static {v1, v5}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v7

    iput v7, v6, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 658
    move-object v5, v6

    check-cast v5, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v3, v5}, Lcom/google/android/material/button/MaterialButton;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 659
    const/4 v7, 0x0

    invoke-virtual {v3, v7}, Lcom/google/android/material/button/MaterialButton;->setAllCaps(Z)V

    .line 660
    new-instance v5, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda19;

    invoke-direct {v5, v11, v0}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda19;-><init>(Landroid/app/Dialog;Ldev/wiojelt/turksinema/common/WioSettingsConfig;)V

    invoke-virtual {v3, v5}, Lcom/google/android/material/button/MaterialButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 664
    nop

    .line 648
    .end local v3  # "$this$show_u24lambda_u2428":Lcom/google/android/material/button/MaterialButton;
    .end local v4  # "$i$a$-apply-WioCoreSettingsDialog$show$wizardBtn$1":I
    .end local v6  # "lp":Landroid/widget/LinearLayout$LayoutParams;
    nop

    .line 665
    .local v2, "wizardBtn":Lcom/google/android/material/button/MaterialButton;
    move-object v3, v2

    check-cast v3, Landroid/view/View;

    invoke-virtual {v15, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    goto :goto_6c1

    .line 647
    .end local v2  # "wizardBtn":Lcom/google/android/material/button/MaterialButton;
    :cond_6bf
    const/high16 v12, 0x41400000  # 12.0f

    .line 668
    :goto_6c1
    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getOnCustomListClick()Lkotlin/jvm/functions/Function0;

    move-result-object v2

    if-eqz v2, :cond_7fd

    .line 669
    new-instance v2, Landroid/widget/LinearLayout;

    invoke-direct {v2, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v3, v2

    .local v3, "$this$show_u24lambda_u2429":Landroid/widget/LinearLayout;
    const/16 v32, 0x0

    .line 670
    .local v32, "$i$a$-apply-WioCoreSettingsDialog$show$customListCard$1":I
    const/4 v7, 0x0

    invoke-virtual {v3, v7}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 671
    const/16 v6, 0x10

    invoke-virtual {v3, v6}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 672
    invoke-static {v1, v6}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v4

    const/16 v8, 0xc

    invoke-static {v1, v8}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v5

    invoke-static {v1, v6}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v7

    invoke-static {v1, v8}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v6

    invoke-virtual {v3, v4, v5, v7, v6}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 673
    const/16 v7, 0x7c

    const/4 v8, 0x0

    move-object v4, v2

    const/4 v2, 0x0

    move-object v5, v3

    .end local v3  # "$this$show_u24lambda_u2429":Landroid/widget/LinearLayout;
    .local v5, "$this$show_u24lambda_u2429":Landroid/widget/LinearLayout;
    const/4 v3, 0x0

    move-object v6, v4

    const/4 v4, 0x0

    move-object/from16 v33, v5

    .end local v5  # "$this$show_u24lambda_u2429":Landroid/widget/LinearLayout;
    .local v33, "$this$show_u24lambda_u2429":Landroid/widget/LinearLayout;
    const/4 v5, 0x0

    move-object/from16 v37, v6

    const/4 v6, 0x0

    move-object/from16 v12, v33

    move-object/from16 v33, v37

    .end local v33  # "$this$show_u24lambda_u2429":Landroid/widget/LinearLayout;
    .local v12, "$this$show_u24lambda_u2429":Landroid/widget/LinearLayout;
    invoke-static/range {v0 .. v8}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$focusableGlassDrawable$default(Ldev/wiojelt/turksinema/common/WioSettingsConfig;Landroid/content/Context;IIIIFILjava/lang/Object;)Landroid/graphics/drawable/StateListDrawable;

    move-result-object v2

    move-object v7, v1

    check-cast v2, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v12, v2}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 674
    const/4 v8, 0x1

    invoke-virtual {v12, v8}, Landroid/widget/LinearLayout;->setFocusable(Z)V

    .line 675
    invoke-virtual {v12, v8}, Landroid/widget/LinearLayout;->setClickable(Z)V

    .line 676
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v4, -0x1

    const/4 v8, -0x2

    invoke-direct {v1, v4, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object v2, v1

    .local v2, "$this$show_u24lambda_u2429_u240":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v3, 0x0

    .line 677
    .local v3, "$i$a$-apply-WioCoreSettingsDialog$show$customListCard$1$lp$1":I
    const/16 v5, 0xa

    invoke-static {v7, v5}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v4

    iput v4, v2, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 678
    nop

    .line 676
    .end local v2  # "$this$show_u24lambda_u2429_u240":Landroid/widget/LinearLayout$LayoutParams;
    .end local v3  # "$i$a$-apply-WioCoreSettingsDialog$show$customListCard$1$lp$1":I
    nop

    .line 679
    .local v1, "lp":Landroid/widget/LinearLayout$LayoutParams;
    move-object v2, v1

    check-cast v2, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v12, v2}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 680
    new-instance v2, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda20;

    invoke-direct {v2, v0}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda20;-><init>(Ldev/wiojelt/turksinema/common/WioSettingsConfig;)V

    invoke-virtual {v12, v2}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 683
    nop

    .line 669
    .end local v1  # "lp":Landroid/widget/LinearLayout$LayoutParams;
    .end local v12  # "$this$show_u24lambda_u2429":Landroid/widget/LinearLayout;
    .end local v32  # "$i$a$-apply-WioCoreSettingsDialog$show$customListCard$1":I
    move-object/from16 v1, v33

    .line 685
    .local v1, "customListCard":Landroid/widget/LinearLayout;
    new-instance v2, Landroid/widget/TextView;

    invoke-direct {v2, v7}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v3, v2

    .local v3, "$this$show_u24lambda_u2430":Landroid/widget/TextView;
    const/4 v4, 0x0

    .line 686
    .local v4, "$i$a$-apply-WioCoreSettingsDialog$show$iconText$1":I
    const-string v5, "\ud83d\udccb"

    check-cast v5, Ljava/lang/CharSequence;

    invoke-virtual {v3, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 687
    const/high16 v5, 0x41900000  # 18.0f

    invoke-virtual {v3, v5}, Landroid/widget/TextView;->setTextSize(F)V

    .line 688
    const/16 v8, 0xc

    invoke-static {v7, v8}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v5

    const/4 v12, 0x0

    invoke-virtual {v3, v12, v12, v5, v12}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 689
    nop

    .line 685
    .end local v3  # "$this$show_u24lambda_u2430":Landroid/widget/TextView;
    .end local v4  # "$i$a$-apply-WioCoreSettingsDialog$show$iconText$1":I
    nop

    .line 690
    .local v2, "iconText":Landroid/widget/TextView;
    move-object v3, v2

    check-cast v3, Landroid/view/View;

    invoke-virtual {v1, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 692
    new-instance v3, Landroid/widget/LinearLayout;

    invoke-direct {v3, v7}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v4, v3

    .local v4, "$this$show_u24lambda_u2431":Landroid/widget/LinearLayout;
    const/4 v5, 0x0

    .line 693
    .local v5, "$i$a$-apply-WioCoreSettingsDialog$show$textCol$1":I
    const/4 v8, 0x1

    invoke-virtual {v4, v8}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 694
    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v8, 0x3f800000  # 1.0f

    const/4 v12, -0x2

    const/4 v13, 0x0

    invoke-direct {v6, v13, v12, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    check-cast v6, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v4, v6}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 695
    nop

    .line 692
    .end local v4  # "$this$show_u24lambda_u2431":Landroid/widget/LinearLayout;
    .end local v5  # "$i$a$-apply-WioCoreSettingsDialog$show$textCol$1":I
    nop

    .line 697
    .local v3, "textCol":Landroid/widget/LinearLayout;
    new-instance v4, Landroid/widget/TextView;

    invoke-direct {v4, v7}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v5, v4

    .local v5, "$this$show_u24lambda_u2432":Landroid/widget/TextView;
    const/4 v6, 0x0

    .line 698
    .local v6, "$i$a$-apply-WioCoreSettingsDialog$show$titleView$1":I
    const-string v8, "Özel M3U / IPTV Listelerim"

    check-cast v8, Ljava/lang/CharSequence;

    invoke-virtual {v5, v8}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 699
    const/high16 v8, 0x41600000  # 14.0f

    invoke-virtual {v5, v8}, Landroid/widget/TextView;->setTextSize(F)V

    .line 700
    sget-object v8, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v5, v8}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 701
    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getTextPrimary()I

    move-result v8

    invoke-virtual {v5, v8}, Landroid/widget/TextView;->setTextColor(I)V

    .line 702
    nop

    .line 697
    .end local v5  # "$this$show_u24lambda_u2432":Landroid/widget/TextView;
    .end local v6  # "$i$a$-apply-WioCoreSettingsDialog$show$titleView$1":I
    nop

    .line 703
    .local v4, "titleView":Landroid/widget/TextView;
    new-instance v5, Landroid/widget/TextView;

    invoke-direct {v5, v7}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v6, v5

    .local v6, "$this$show_u24lambda_u2433":Landroid/widget/TextView;
    const/4 v8, 0x0

    .line 704
    .local v8, "$i$a$-apply-WioCoreSettingsDialog$show$descView$1":I
    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getCustomListSummary()Ljava/lang/String;

    move-result-object v12

    if-eqz v12, :cond_7a4

    goto :goto_7a6

    :cond_7a4
    const-string v12, "M3U listesi ekle, yönet veya kaldır"

    :goto_7a6
    check-cast v12, Ljava/lang/CharSequence;

    invoke-virtual {v6, v12}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 705
    const/high16 v12, 0x41300000  # 11.0f

    invoke-virtual {v6, v12}, Landroid/widget/TextView;->setTextSize(F)V

    .line 706
    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getBrandColor()I

    move-result v12

    invoke-virtual {v6, v12}, Landroid/widget/TextView;->setTextColor(I)V

    .line 707
    const/4 v12, 0x2

    invoke-static {v7, v12}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v13

    const/4 v12, 0x0

    invoke-virtual {v6, v12, v13, v12, v12}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 708
    nop

    .line 703
    .end local v6  # "$this$show_u24lambda_u2433":Landroid/widget/TextView;
    .end local v8  # "$i$a$-apply-WioCoreSettingsDialog$show$descView$1":I
    nop

    .line 709
    .local v5, "descView":Landroid/widget/TextView;
    move-object v6, v4

    check-cast v6, Landroid/view/View;

    invoke-virtual {v3, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 710
    move-object v6, v5

    check-cast v6, Landroid/view/View;

    invoke-virtual {v3, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 711
    move-object v6, v3

    check-cast v6, Landroid/view/View;

    invoke-virtual {v1, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 713
    new-instance v6, Landroid/widget/TextView;

    invoke-direct {v6, v7}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v8, v6

    .local v8, "$this$show_u24lambda_u2434":Landroid/widget/TextView;
    const/4 v12, 0x0

    .line 714
    .local v12, "$i$a$-apply-WioCoreSettingsDialog$show$arrowView$1":I
    const-string v13, "➔"

    check-cast v13, Ljava/lang/CharSequence;

    invoke-virtual {v8, v13}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 715
    const/high16 v13, 0x41600000  # 14.0f

    invoke-virtual {v8, v13}, Landroid/widget/TextView;->setTextSize(F)V

    .line 716
    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getTextSecondary()I

    move-result v13

    invoke-virtual {v8, v13}, Landroid/widget/TextView;->setTextColor(I)V

    .line 717
    nop

    .line 713
    .end local v8  # "$this$show_u24lambda_u2434":Landroid/widget/TextView;
    .end local v12  # "$i$a$-apply-WioCoreSettingsDialog$show$arrowView$1":I
    nop

    .line 718
    .local v6, "arrowView":Landroid/widget/TextView;
    move-object v8, v6

    check-cast v8, Landroid/view/View;

    invoke-virtual {v1, v8}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 720
    move-object v8, v1

    check-cast v8, Landroid/view/View;

    invoke-virtual {v15, v8}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    goto :goto_7fe

    .line 668
    .end local v1  # "customListCard":Landroid/widget/LinearLayout;
    .end local v2  # "iconText":Landroid/widget/TextView;
    .end local v3  # "textCol":Landroid/widget/LinearLayout;
    .end local v4  # "titleView":Landroid/widget/TextView;
    .end local v5  # "descView":Landroid/widget/TextView;
    .end local v6  # "arrowView":Landroid/widget/TextView;
    :cond_7fd
    move-object v7, v1

    .line 723
    :goto_7fe
    new-instance v1, Ljava/util/LinkedHashMap;

    invoke-direct {v1}, Ljava/util/LinkedHashMap;-><init>()V

    move-object v3, v1

    check-cast v3, Ljava/util/Map;

    .line 724
    .local v3, "switchMap":Ljava/util/Map;
    new-instance v1, Lkotlin/jvm/internal/Ref$BooleanRef;

    invoke-direct {v1}, Lkotlin/jvm/internal/Ref$BooleanRef;-><init>()V

    .line 725
    .local v1, "isBulkUpdating":Lkotlin/jvm/internal/Ref$BooleanRef;
    new-instance v5, Lkotlin/jvm/internal/Ref$ObjectRef;

    invoke-direct {v5}, Lkotlin/jvm/internal/Ref$ObjectRef;-><init>()V

    .local v5, "updateCounterText":Lkotlin/jvm/internal/Ref$ObjectRef;
    new-instance v2, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda21;

    invoke-direct {v2}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda21;-><init>()V

    iput-object v2, v5, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    .line 727
    new-instance v2, Ljava/util/LinkedHashMap;

    invoke-direct {v2}, Ljava/util/LinkedHashMap;-><init>()V

    move-object v6, v2

    check-cast v6, Ljava/util/Map;

    .line 740
    .local v6, "presetButtons":Ljava/util/Map;
    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getSelectionPresets()Ljava/util/List;

    move-result-object v2

    check-cast v2, Ljava/util/Collection;

    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_a37

    .line 741
    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getSelectionTitle()Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_87c

    .local v2, "title":Ljava/lang/String;
    const/4 v4, 0x0

    .line 742
    .local v4, "$i$a$-let-WioCoreSettingsDialog$show$6":I
    new-instance v8, Landroid/widget/TextView;

    invoke-direct {v8, v7}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v13, v8

    .local v13, "$this$show_u24lambda_u2439_u240":Landroid/widget/TextView;
    const/16 v33, 0x0

    .line 743
    .local v33, "$i$a$-apply-WioCoreSettingsDialog$show$6$presetTitle$1":I
    move-object v12, v2

    check-cast v12, Ljava/lang/CharSequence;

    invoke-virtual {v13, v12}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 744
    const/high16 v12, 0x41600000  # 14.0f

    invoke-virtual {v13, v12}, Landroid/widget/TextView;->setTextSize(F)V

    .line 745
    sget-object v12, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v13, v12}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 746
    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getBrandColor()I

    move-result v12

    invoke-virtual {v13, v12}, Landroid/widget/TextView;->setTextColor(I)V

    .line 747
    const/4 v12, 0x2

    invoke-static {v7, v12}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v0

    move-object/from16 v39, v1

    move-object/from16 v38, v8

    const/4 v8, 0x4

    .end local v1  # "isBulkUpdating":Lkotlin/jvm/internal/Ref$BooleanRef;
    .local v39, "isBulkUpdating":Lkotlin/jvm/internal/Ref$BooleanRef;
    invoke-static {v7, v8}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v1

    invoke-static {v7, v12}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v8

    move-object/from16 v43, v2

    const/4 v12, 0x6

    .end local v2  # "title":Ljava/lang/String;
    .local v43, "title":Ljava/lang/String;
    invoke-static {v7, v12}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v2

    invoke-virtual {v13, v0, v1, v8, v2}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 748
    nop

    .line 742
    .end local v13  # "$this$show_u24lambda_u2439_u240":Landroid/widget/TextView;
    .end local v33  # "$i$a$-apply-WioCoreSettingsDialog$show$6$presetTitle$1":I
    nop

    .line 749
    .local v38, "presetTitle":Landroid/widget/TextView;
    move-object/from16 v0, v38

    check-cast v0, Landroid/view/View;

    invoke-virtual {v15, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 750
    nop

    .end local v4  # "$i$a$-let-WioCoreSettingsDialog$show$6":I
    .end local v38  # "presetTitle":Landroid/widget/TextView;
    .end local v43  # "title":Ljava/lang/String;
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 741
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    goto :goto_87e

    .end local v39  # "isBulkUpdating":Lkotlin/jvm/internal/Ref$BooleanRef;
    .restart local v1  # "isBulkUpdating":Lkotlin/jvm/internal/Ref$BooleanRef;
    :cond_87c
    move-object/from16 v39, v1

    .line 752
    .end local v1  # "isBulkUpdating":Lkotlin/jvm/internal/Ref$BooleanRef;
    .restart local v39  # "isBulkUpdating":Lkotlin/jvm/internal/Ref$BooleanRef;
    :goto_87e
    invoke-virtual/range {p2 .. p2}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getCompactSelectionPresets()Z

    move-result v0

    if-eqz v0, :cond_8ac

    .line 753
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, v7}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v1, v0

    .local v1, "$this$show_u24lambda_u2440":Landroid/widget/LinearLayout;
    const/4 v2, 0x0

    .line 754
    .local v2, "$i$a$-apply-WioCoreSettingsDialog$show$compactPresetRow$1":I
    const/4 v12, 0x0

    invoke-virtual {v1, v12}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 755
    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v8, -0x2

    const/4 v12, -0x1

    invoke-direct {v4, v12, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object v8, v4

    .local v8, "$this$show_u24lambda_u2440_u240":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v12, 0x0

    .line 756
    .local v12, "$i$a$-apply-WioCoreSettingsDialog$show$compactPresetRow$1$1":I
    move-object/from16 v33, v0

    const/16 v13, 0xa

    invoke-static {v7, v13}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v0

    iput v0, v8, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 757
    nop

    .line 755
    .end local v8  # "$this$show_u24lambda_u2440_u240":Landroid/widget/LinearLayout$LayoutParams;
    .end local v12  # "$i$a$-apply-WioCoreSettingsDialog$show$compactPresetRow$1$1":I
    check-cast v4, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v1, v4}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 758
    nop

    .line 753
    .end local v1  # "$this$show_u24lambda_u2440":Landroid/widget/LinearLayout;
    .end local v2  # "$i$a$-apply-WioCoreSettingsDialog$show$compactPresetRow$1":I
    move-object/from16 v0, v33

    goto :goto_8ad

    .line 759
    :cond_8ac
    const/4 v0, 0x0

    .line 752
    :goto_8ad
    move-object v8, v0

    .line 761
    .local v8, "compactPresetRow":Landroid/widget/LinearLayout;
    invoke-virtual/range {p2 .. p2}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getSelectionPresets()Ljava/util/List;

    move-result-object v0

    move-object v12, v0

    check-cast v12, Ljava/lang/Iterable;

    .local v12, "$this$forEachIndexed$iv":Ljava/lang/Iterable;
    const/4 v13, 0x0

    .line 1212
    .local v13, "$i$f$forEachIndexed":I
    const/4 v0, 0x0

    .line 1213
    .local v0, "index$iv":I
    invoke-interface {v12}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v33

    :goto_8bb
    invoke-interface/range {v33 .. v33}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_a1d

    invoke-interface/range {v33 .. v33}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v38

    .local v38, "item$iv":Ljava/lang/Object;
    add-int/lit8 v43, v0, 0x1

    .end local v0  # "index$iv":I
    .local v43, "index$iv":I
    if-gez v0, :cond_8cc

    invoke-static {}, Lkotlin/collections/CollectionsKt;->throwIndexOverflow()V

    :cond_8cc
    move-object/from16 v4, v38

    check-cast v4, Ldev/wiojelt/turksinema/common/WioSelectionPreset;

    .local v0, "index":I
    .local v4, "preset":Ldev/wiojelt/turksinema/common/WioSelectionPreset;
    const/16 v44, 0x0

    .line 762
    .local v44, "$i$a$-forEachIndexed-WioCoreSettingsDialog$show$7":I
    new-instance v1, Lcom/google/android/material/button/MaterialButton;

    invoke-direct {v1, v7}, Lcom/google/android/material/button/MaterialButton;-><init>(Landroid/content/Context;)V

    move-object v2, v1

    .local v2, "$this$show_u24lambda_u2441_u240":Lcom/google/android/material/button/MaterialButton;
    const/16 v45, 0x0

    .line 763
    .local v45, "$i$a$-apply-WioCoreSettingsDialog$show$7$presetButton$1":I
    move-object/from16 v46, v9

    const/high16 v9, 0x41400000  # 12.0f

    .end local v9  # "scanDurationLabel":Lkotlin/jvm/internal/Ref$ObjectRef;
    .local v46, "scanDurationLabel":Lkotlin/jvm/internal/Ref$ObjectRef;
    invoke-virtual {v2, v9}, Lcom/google/android/material/button/MaterialButton;->setTextSize(F)V

    .line 764
    sget-object v9, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v2, v9}, Lcom/google/android/material/button/MaterialButton;->setTypeface(Landroid/graphics/Typeface;)V

    .line 765
    const/4 v9, -0x1

    invoke-virtual {v2, v9}, Lcom/google/android/material/button/MaterialButton;->setTextColor(I)V

    .line 766
    const-string v9, "#1B222A"

    invoke-static {v9}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v9

    invoke-static {v9}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v9

    invoke-virtual {v2, v9}, Lcom/google/android/material/button/MaterialButton;->setBackgroundTintList(Landroid/content/res/ColorStateList;)V

    .line 767
    invoke-virtual/range {p2 .. p2}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getBrandColorBorder()I

    move-result v9

    invoke-static {v9}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v9

    invoke-virtual {v2, v9}, Lcom/google/android/material/button/MaterialButton;->setStrokeColor(Landroid/content/res/ColorStateList;)V

    .line 768
    move/from16 v47, v0

    const/4 v9, 0x1

    .end local v0  # "index":I
    .local v47, "index":I
    invoke-static {v7, v9}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v0

    invoke-virtual {v2, v0}, Lcom/google/android/material/button/MaterialButton;->setStrokeWidth(I)V

    .line 769
    const/16 v0, 0xc

    invoke-static {v7, v0}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v9

    invoke-virtual {v2, v9}, Lcom/google/android/material/button/MaterialButton;->setCornerRadius(I)V

    .line 770
    const/4 v0, 0x0

    invoke-virtual {v2, v0}, Lcom/google/android/material/button/MaterialButton;->setAllCaps(Z)V

    .line 771
    const v0, 0x800013

    invoke-virtual {v2, v0}, Lcom/google/android/material/button/MaterialButton;->setGravity(I)V

    .line 772
    invoke-virtual {v4}, Ldev/wiojelt/turksinema/common/WioSelectionPreset;->getTitle()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4}, Ldev/wiojelt/turksinema/common/WioSelectionPreset;->getDescription()Ljava/lang/String;

    move-result-object v9

    move-object/from16 v48, v1

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ". "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    check-cast v0, Ljava/lang/CharSequence;

    invoke-virtual {v2, v0}, Lcom/google/android/material/button/MaterialButton;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 773
    new-instance v0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda22;

    move-object/from16 v1, v39

    move/from16 v9, v47

    move-object/from16 v39, v10

    move-object v10, v2

    move-object/from16 v2, p2

    .end local v2  # "$this$show_u24lambda_u2441_u240":Lcom/google/android/material/button/MaterialButton;
    .end local v47  # "index":I
    .local v1, "isBulkUpdating":Lkotlin/jvm/internal/Ref$BooleanRef;
    .local v9, "index":I
    .local v10, "$this$show_u24lambda_u2441_u240":Lcom/google/android/material/button/MaterialButton;
    .local v39, "scanDurationSeekBar":Lkotlin/jvm/internal/Ref$ObjectRef;
    invoke-direct/range {v0 .. v6}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda22;-><init>(Lkotlin/jvm/internal/Ref$BooleanRef;Ldev/wiojelt/turksinema/common/WioSettingsConfig;Ljava/util/Map;Ldev/wiojelt/turksinema/common/WioSelectionPreset;Lkotlin/jvm/internal/Ref$ObjectRef;Ljava/util/Map;)V

    move-object/from16 v63, v2

    move-object v2, v0

    move-object v0, v4

    move-object v4, v3

    move-object/from16 v3, v63

    .end local v3  # "switchMap":Ljava/util/Map;
    .local v0, "preset":Ldev/wiojelt/turksinema/common/WioSelectionPreset;
    .local v4, "switchMap":Ljava/util/Map;
    invoke-virtual {v10, v2}, Lcom/google/android/material/button/MaterialButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 787
    nop

    .line 762
    .end local v10  # "$this$show_u24lambda_u2441_u240":Lcom/google/android/material/button/MaterialButton;
    .end local v45  # "$i$a$-apply-WioCoreSettingsDialog$show$7$presetButton$1":I
    move-object/from16 v2, v48

    .line 788
    .local v2, "presetButton":Lcom/google/android/material/button/MaterialButton;
    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSelectionPreset;->getId()Ljava/lang/String;

    move-result-object v10

    invoke-interface {v6, v10, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 789
    if-eqz v8, :cond_9a7

    .line 790
    move-object v10, v2

    check-cast v10, Landroid/view/View;

    move-object/from16 v45, v0

    .end local v0  # "preset":Ldev/wiojelt/turksinema/common/WioSelectionPreset;
    .local v45, "preset":Ldev/wiojelt/turksinema/common/WioSelectionPreset;
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v40, v1

    move-object/from16 v47, v12

    const/16 v12, 0x2c

    .end local v1  # "isBulkUpdating":Lkotlin/jvm/internal/Ref$BooleanRef;
    .end local v12  # "$this$forEachIndexed$iv":Ljava/lang/Iterable;
    .local v40, "isBulkUpdating":Lkotlin/jvm/internal/Ref$BooleanRef;
    .local v47, "$this$forEachIndexed$iv":Ljava/lang/Iterable;
    invoke-static {v7, v12}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v1

    move-object/from16 v49, v2

    const/4 v2, 0x0

    const/high16 v12, 0x3f800000  # 1.0f

    .end local v2  # "presetButton":Lcom/google/android/material/button/MaterialButton;
    .local v49, "presetButton":Lcom/google/android/material/button/MaterialButton;
    invoke-direct {v0, v2, v1, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    move-object v1, v0

    .local v1, "$this$show_u24lambda_u2441_u241":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v2, 0x0

    .line 791
    .local v2, "$i$a$-apply-WioCoreSettingsDialog$show$7$1":I
    invoke-virtual {v3}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getSelectionPresets()Ljava/util/List;

    move-result-object v12

    invoke-static {v12}, Lkotlin/collections/CollectionsKt;->getLastIndex(Ljava/util/List;)I

    move-result v12

    if-ge v9, v12, :cond_99a

    move-object/from16 v50, v0

    const/16 v12, 0x8

    invoke-static {v7, v12}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v0

    invoke-virtual {v1, v0}, Landroid/widget/LinearLayout$LayoutParams;->setMarginEnd(I)V

    goto :goto_99c

    :cond_99a
    move-object/from16 v50, v0

    .line 792
    :goto_99c
    nop

    .end local v1  # "$this$show_u24lambda_u2441_u241":Landroid/widget/LinearLayout$LayoutParams;
    .end local v2  # "$i$a$-apply-WioCoreSettingsDialog$show$7$1":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 790
    move-object/from16 v0, v50

    check-cast v0, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v8, v10, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    goto :goto_a0f

    .line 794
    .end local v40  # "isBulkUpdating":Lkotlin/jvm/internal/Ref$BooleanRef;
    .end local v45  # "preset":Ldev/wiojelt/turksinema/common/WioSelectionPreset;
    .end local v47  # "$this$forEachIndexed$iv":Ljava/lang/Iterable;
    .end local v49  # "presetButton":Lcom/google/android/material/button/MaterialButton;
    .restart local v0  # "preset":Ldev/wiojelt/turksinema/common/WioSelectionPreset;
    .local v1, "isBulkUpdating":Lkotlin/jvm/internal/Ref$BooleanRef;
    .local v2, "presetButton":Lcom/google/android/material/button/MaterialButton;
    .restart local v12  # "$this$forEachIndexed$iv":Ljava/lang/Iterable;
    :cond_9a7
    move-object/from16 v45, v0

    move-object/from16 v40, v1

    move-object/from16 v49, v2

    move-object/from16 v47, v12

    .end local v0  # "preset":Ldev/wiojelt/turksinema/common/WioSelectionPreset;
    .end local v1  # "isBulkUpdating":Lkotlin/jvm/internal/Ref$BooleanRef;
    .end local v2  # "presetButton":Lcom/google/android/material/button/MaterialButton;
    .end local v12  # "$this$forEachIndexed$iv":Ljava/lang/Iterable;
    .restart local v40  # "isBulkUpdating":Lkotlin/jvm/internal/Ref$BooleanRef;
    .restart local v45  # "preset":Ldev/wiojelt/turksinema/common/WioSelectionPreset;
    .restart local v47  # "$this$forEachIndexed$iv":Ljava/lang/Iterable;
    .restart local v49  # "presetButton":Lcom/google/android/material/button/MaterialButton;
    move-object/from16 v0, v49

    check-cast v0, Landroid/view/View;

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v12, 0x2c

    invoke-static {v7, v12}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v2

    const/4 v12, -0x1

    invoke-direct {v1, v12, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object v2, v1

    .local v2, "$this$show_u24lambda_u2441_u242":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v10, 0x0

    .line 795
    .local v10, "$i$a$-apply-WioCoreSettingsDialog$show$7$2":I
    move-object/from16 v50, v1

    const/4 v12, 0x6

    invoke-static {v7, v12}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v1

    iput v1, v2, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 796
    nop

    .end local v2  # "$this$show_u24lambda_u2441_u242":Landroid/widget/LinearLayout$LayoutParams;
    .end local v10  # "$i$a$-apply-WioCoreSettingsDialog$show$7$2":I
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 794
    move-object/from16 v1, v50

    check-cast v1, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v15, v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 797
    new-instance v0, Landroid/widget/TextView;

    invoke-direct {v0, v7}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v1, v0

    .local v1, "$this$show_u24lambda_u2441_u243":Landroid/widget/TextView;
    const/4 v2, 0x0

    .line 798
    .local v2, "$i$a$-apply-WioCoreSettingsDialog$show$7$3":I
    invoke-virtual/range {v45 .. v45}, Ldev/wiojelt/turksinema/common/WioSelectionPreset;->getDescription()Ljava/lang/String;

    move-result-object v10

    check-cast v10, Ljava/lang/CharSequence;

    invoke-virtual {v1, v10}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 799
    const/high16 v10, 0x41280000  # 10.5f

    invoke-virtual {v1, v10}, Landroid/widget/TextView;->setTextSize(F)V

    .line 800
    invoke-virtual {v3}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getTextSecondary()I

    move-result v10

    invoke-virtual {v1, v10}, Landroid/widget/TextView;->setTextColor(I)V

    .line 801
    const/16 v12, 0x8

    invoke-static {v7, v12}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v10

    move-object/from16 v50, v0

    invoke-static {v7, v12}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v0

    move/from16 v51, v2

    const/4 v12, 0x6

    .end local v2  # "$i$a$-apply-WioCoreSettingsDialog$show$7$3":I
    .local v51, "$i$a$-apply-WioCoreSettingsDialog$show$7$3":I
    invoke-static {v7, v12}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v2

    const/4 v12, 0x0

    invoke-virtual {v1, v10, v12, v0, v2}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 802
    nop

    .line 797
    .end local v1  # "$this$show_u24lambda_u2441_u243":Landroid/widget/TextView;
    .end local v51  # "$i$a$-apply-WioCoreSettingsDialog$show$7$3":I
    move-object/from16 v0, v50

    check-cast v0, Landroid/view/View;

    invoke-virtual {v15, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 804
    :goto_a0f
    nop

    .line 1213
    .end local v9  # "index":I
    .end local v44  # "$i$a$-forEachIndexed-WioCoreSettingsDialog$show$7":I
    .end local v45  # "preset":Ldev/wiojelt/turksinema/common/WioSelectionPreset;
    .end local v49  # "presetButton":Lcom/google/android/material/button/MaterialButton;
    move-object v3, v4

    move-object/from16 v10, v39

    move-object/from16 v39, v40

    move/from16 v0, v43

    move-object/from16 v9, v46

    move-object/from16 v12, v47

    .end local v38  # "item$iv":Ljava/lang/Object;
    goto/16 :goto_8bb

    .line 1214
    .end local v4  # "switchMap":Ljava/util/Map;
    .end local v40  # "isBulkUpdating":Lkotlin/jvm/internal/Ref$BooleanRef;
    .end local v43  # "index$iv":I
    .end local v46  # "scanDurationLabel":Lkotlin/jvm/internal/Ref$ObjectRef;
    .end local v47  # "$this$forEachIndexed$iv":Ljava/lang/Iterable;
    .local v0, "index$iv":I
    .restart local v3  # "switchMap":Ljava/util/Map;
    .local v9, "scanDurationLabel":Lkotlin/jvm/internal/Ref$ObjectRef;
    .local v10, "scanDurationSeekBar":Lkotlin/jvm/internal/Ref$ObjectRef;
    .restart local v12  # "$this$forEachIndexed$iv":Ljava/lang/Iterable;
    .local v39, "isBulkUpdating":Lkotlin/jvm/internal/Ref$BooleanRef;
    :cond_a1d
    move-object v4, v3

    move-object/from16 v46, v9

    move-object/from16 v47, v12

    move-object/from16 v40, v39

    move-object/from16 v3, p2

    move-object/from16 v39, v10

    .line 805
    .end local v0  # "index$iv":I
    .end local v3  # "switchMap":Ljava/util/Map;
    .end local v9  # "scanDurationLabel":Lkotlin/jvm/internal/Ref$ObjectRef;
    .end local v10  # "scanDurationSeekBar":Lkotlin/jvm/internal/Ref$ObjectRef;
    .end local v12  # "$this$forEachIndexed$iv":Ljava/lang/Iterable;
    .end local v13  # "$i$f$forEachIndexed":I
    .restart local v4  # "switchMap":Ljava/util/Map;
    .local v39, "scanDurationSeekBar":Lkotlin/jvm/internal/Ref$ObjectRef;
    .restart local v40  # "isBulkUpdating":Lkotlin/jvm/internal/Ref$BooleanRef;
    .restart local v46  # "scanDurationLabel":Lkotlin/jvm/internal/Ref$ObjectRef;
    if-eqz v8, :cond_a3f

    move-object v0, v8

    .line 1215
    .local v0, "it":Landroid/widget/LinearLayout;
    const/4 v1, 0x0

    .line 805
    .local v1, "$i$a$-let-WioCoreSettingsDialog$show$8":I
    move-object v2, v0

    check-cast v2, Landroid/view/View;

    invoke-virtual {v15, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .end local v0  # "it":Landroid/widget/LinearLayout;
    .end local v1  # "$i$a$-let-WioCoreSettingsDialog$show$8":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    goto :goto_a3f

    .line 740
    .end local v4  # "switchMap":Ljava/util/Map;
    .end local v8  # "compactPresetRow":Landroid/widget/LinearLayout;
    .end local v39  # "scanDurationSeekBar":Lkotlin/jvm/internal/Ref$ObjectRef;
    .end local v40  # "isBulkUpdating":Lkotlin/jvm/internal/Ref$BooleanRef;
    .end local v46  # "scanDurationLabel":Lkotlin/jvm/internal/Ref$ObjectRef;
    .local v1, "isBulkUpdating":Lkotlin/jvm/internal/Ref$BooleanRef;
    .restart local v3  # "switchMap":Ljava/util/Map;
    .restart local v9  # "scanDurationLabel":Lkotlin/jvm/internal/Ref$ObjectRef;
    .restart local v10  # "scanDurationSeekBar":Lkotlin/jvm/internal/Ref$ObjectRef;
    :cond_a37
    move-object/from16 v40, v1

    move-object v4, v3

    move-object/from16 v46, v9

    move-object/from16 v39, v10

    move-object v3, v0

    .line 808
    .end local v1  # "isBulkUpdating":Lkotlin/jvm/internal/Ref$BooleanRef;
    .end local v3  # "switchMap":Ljava/util/Map;
    .end local v9  # "scanDurationLabel":Lkotlin/jvm/internal/Ref$ObjectRef;
    .end local v10  # "scanDurationSeekBar":Lkotlin/jvm/internal/Ref$ObjectRef;
    .restart local v4  # "switchMap":Ljava/util/Map;
    .restart local v39  # "scanDurationSeekBar":Lkotlin/jvm/internal/Ref$ObjectRef;
    .restart local v40  # "isBulkUpdating":Lkotlin/jvm/internal/Ref$BooleanRef;
    .restart local v46  # "scanDurationLabel":Lkotlin/jvm/internal/Ref$ObjectRef;
    :cond_a3f
    :goto_a3f
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, v7}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v1, v0

    .local v1, "$this$show_u24lambda_u2443":Landroid/widget/LinearLayout;
    const/4 v2, 0x0

    .line 809
    .local v2, "$i$a$-apply-WioCoreSettingsDialog$show$providerControlsContainer$1":I
    const/4 v8, 0x1

    invoke-virtual {v1, v8}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 810
    nop

    .line 808
    .end local v1  # "$this$show_u24lambda_u2443":Landroid/widget/LinearLayout;
    .end local v2  # "$i$a$-apply-WioCoreSettingsDialog$show$providerControlsContainer$1":I
    move-object v9, v0

    .line 812
    .local v9, "providerControlsContainer":Landroid/widget/LinearLayout;
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, v7}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v1, v0

    .local v1, "$this$show_u24lambda_u2444":Landroid/widget/LinearLayout;
    const/4 v2, 0x0

    .line 813
    .local v2, "$i$a$-apply-WioCoreSettingsDialog$show$providersHeaderRow$1":I
    const/4 v12, 0x0

    invoke-virtual {v1, v12}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 814
    const/16 v8, 0x10

    invoke-virtual {v1, v8}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 815
    const/4 v12, 0x2

    invoke-static {v7, v12}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v8

    const/4 v10, 0x4

    invoke-static {v7, v10}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v13

    invoke-static {v7, v12}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v10

    move-object/from16 v33, v0

    const/4 v12, 0x6

    invoke-static {v7, v12}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v0

    invoke-virtual {v1, v8, v13, v10, v0}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 816
    nop

    .line 812
    .end local v1  # "$this$show_u24lambda_u2444":Landroid/widget/LinearLayout;
    .end local v2  # "$i$a$-apply-WioCoreSettingsDialog$show$providersHeaderRow$1":I
    move-object/from16 v10, v33

    .line 818
    .local v10, "providersHeaderRow":Landroid/widget/LinearLayout;
    new-instance v0, Landroid/widget/TextView;

    invoke-direct {v0, v7}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v1, v0

    .local v1, "$this$show_u24lambda_u2445":Landroid/widget/TextView;
    const/4 v2, 0x0

    .line 819
    .local v2, "$i$a$-apply-WioCoreSettingsDialog$show$providersHeader$1":I
    const/high16 v13, 0x41600000  # 14.0f

    invoke-virtual {v1, v13}, Landroid/widget/TextView;->setTextSize(F)V

    .line 820
    sget-object v8, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v1, v8}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 821
    invoke-virtual {v3}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getBrandColor()I

    move-result v8

    invoke-virtual {v1, v8}, Landroid/widget/TextView;->setTextColor(I)V

    .line 822
    new-instance v8, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v32, v0

    const/4 v0, 0x0

    const/high16 v12, 0x3f800000  # 1.0f

    const/4 v13, -0x2

    invoke-direct {v8, v0, v13, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    check-cast v8, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v1, v8}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 823
    nop

    .line 818
    .end local v1  # "$this$show_u24lambda_u2445":Landroid/widget/TextView;
    .end local v2  # "$i$a$-apply-WioCoreSettingsDialog$show$providersHeader$1":I
    move-object/from16 v12, v32

    .line 825
    .local v12, "providersHeader":Landroid/widget/TextView;
    new-instance v0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda1;

    invoke-direct {v0, v3, v12}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda1;-><init>(Ldev/wiojelt/turksinema/common/WioSettingsConfig;Landroid/widget/TextView;)V

    iput-object v0, v5, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    .line 829
    iget-object v0, v5, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    check-cast v0, Lkotlin/jvm/functions/Function0;

    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 830
    move-object v0, v12

    check-cast v0, Landroid/view/View;

    invoke-virtual {v10, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 831
    move-object v0, v10

    check-cast v0, Landroid/view/View;

    invoke-virtual {v9, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 833
    invoke-virtual {v3}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getOnSelectAll()Lkotlin/jvm/functions/Function0;

    move-result-object v0

    const-string v13, "#161820"

    if-nez v0, :cond_add

    invoke-virtual {v3}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getOnSelectRecommended()Lkotlin/jvm/functions/Function0;

    move-result-object v0

    if-nez v0, :cond_add

    invoke-virtual {v3}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getOnSelectNone()Lkotlin/jvm/functions/Function0;

    move-result-object v0

    if-eqz v0, :cond_ad1

    goto :goto_add

    :cond_ad1
    move-object/from16 v33, v5

    move-object/from16 v43, v6

    move-object/from16 v38, v10

    move-object/from16 v42, v40

    move-object/from16 v40, v12

    goto/16 :goto_cf6

    .line 834
    :cond_add
    :goto_add
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, v7}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v1, v0

    .local v1, "$this$show_u24lambda_u2447":Landroid/widget/LinearLayout;
    const/4 v2, 0x0

    .line 835
    .local v2, "$i$a$-apply-WioCoreSettingsDialog$show$batchRow$1":I
    const/4 v8, 0x0

    invoke-virtual {v1, v8}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 836
    new-instance v8, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v32, v0

    move/from16 v33, v2

    const/4 v0, -0x2

    const/4 v2, -0x1

    .end local v2  # "$i$a$-apply-WioCoreSettingsDialog$show$batchRow$1":I
    .local v33, "$i$a$-apply-WioCoreSettingsDialog$show$batchRow$1":I
    invoke-direct {v8, v2, v0}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 837
    .local v8, "lp":Landroid/widget/LinearLayout$LayoutParams;
    const/16 v0, 0xa

    invoke-static {v7, v0}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v2

    iput v2, v8, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 838
    move-object v0, v8

    check-cast v0, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v1, v0}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 839
    nop

    .line 834
    .end local v1  # "$this$show_u24lambda_u2447":Landroid/widget/LinearLayout;
    .end local v8  # "lp":Landroid/widget/LinearLayout$LayoutParams;
    .end local v33  # "$i$a$-apply-WioCoreSettingsDialog$show$batchRow$1":I
    move-object/from16 v8, v32

    .line 841
    .local v8, "batchRow":Landroid/widget/LinearLayout;
    invoke-virtual {v3}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getOnSelectAll()Lkotlin/jvm/functions/Function0;

    move-result-object v2

    if-eqz v2, :cond_ba9

    .local v2, "onAll":Lkotlin/jvm/functions/Function0;
    const/16 v32, 0x0

    .line 842
    .local v32, "$i$a$-let-WioCoreSettingsDialog$show$10":I
    new-instance v0, Lcom/google/android/material/button/MaterialButton;

    invoke-direct {v0, v7}, Lcom/google/android/material/button/MaterialButton;-><init>(Landroid/content/Context;)V

    move-object v1, v0

    .local v1, "$this$show_u24lambda_u2448_u240":Lcom/google/android/material/button/MaterialButton;
    const/16 v33, 0x0

    .line 843
    .local v33, "$i$a$-apply-WioCoreSettingsDialog$show$10$btnAll$1":I
    invoke-virtual {v3}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getEnglishLabels()Z

    move-result v38

    if-eqz v38, :cond_b1d

    const-string v38, "Enable All"

    goto :goto_b1f

    :cond_b1d
    const-string v38, "Tümünü Aç"

    :goto_b1f
    check-cast v38, Ljava/lang/CharSequence;

    move-object/from16 v42, v0

    move-object/from16 v0, v38

    invoke-virtual {v1, v0}, Lcom/google/android/material/button/MaterialButton;->setText(Ljava/lang/CharSequence;)V

    .line 844
    const/high16 v0, 0x41300000  # 11.0f

    invoke-virtual {v1, v0}, Lcom/google/android/material/button/MaterialButton;->setTextSize(F)V

    .line 845
    const/4 v0, -0x1

    invoke-virtual {v1, v0}, Lcom/google/android/material/button/MaterialButton;->setTextColor(I)V

    .line 846
    invoke-static {v13}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    invoke-static {v0}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v0

    invoke-virtual {v1, v0}, Lcom/google/android/material/button/MaterialButton;->setBackgroundTintList(Landroid/content/res/ColorStateList;)V

    .line 847
    const-string v0, "#26FFFFFF"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    invoke-static {v0}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v0

    invoke-virtual {v1, v0}, Lcom/google/android/material/button/MaterialButton;->setStrokeColor(Landroid/content/res/ColorStateList;)V

    .line 848
    move-object/from16 v38, v2

    const/4 v0, 0x1

    .end local v2  # "onAll":Lkotlin/jvm/functions/Function0;
    .local v38, "onAll":Lkotlin/jvm/functions/Function0;
    invoke-static {v7, v0}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v2

    invoke-virtual {v1, v2}, Lcom/google/android/material/button/MaterialButton;->setStrokeWidth(I)V

    .line 849
    const/16 v0, 0x64

    invoke-static {v7, v0}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v2

    invoke-virtual {v1, v2}, Lcom/google/android/material/button/MaterialButton;->setCornerRadius(I)V

    .line 850
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v0, 0x24

    invoke-static {v7, v0}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v0

    move-object/from16 v43, v4

    const/high16 v3, 0x3f800000  # 1.0f

    const/4 v4, 0x0

    .end local v4  # "switchMap":Ljava/util/Map;
    .local v43, "switchMap":Ljava/util/Map;
    invoke-direct {v2, v4, v0, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    move-object v0, v2

    .line 1215
    .local v0, "$this$show_u24lambda_u2448_u240_u240":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v3, 0x0

    .line 850
    .local v3, "$i$a$-apply-WioCoreSettingsDialog$show$10$btnAll$1$lp$1":I
    move-object/from16 v44, v2

    const/4 v4, 0x6

    invoke-static {v7, v4}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout$LayoutParams;->setMarginEnd(I)V

    .line 851
    .end local v0  # "$this$show_u24lambda_u2448_u240_u240":Landroid/widget/LinearLayout$LayoutParams;
    .end local v3  # "$i$a$-apply-WioCoreSettingsDialog$show$10$btnAll$1$lp$1":I
    .local v44, "lp":Landroid/widget/LinearLayout$LayoutParams;
    move-object/from16 v0, v44

    check-cast v0, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v1, v0}, Lcom/google/android/material/button/MaterialButton;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 852
    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Lcom/google/android/material/button/MaterialButton;->setAllCaps(Z)V

    .line 853
    new-instance v0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda2;

    move-object/from16 v3, p2

    move-object/from16 v2, v38

    move-object/from16 v4, v43

    move-object/from16 v38, v10

    move-object v10, v1

    move-object/from16 v1, v40

    move-object/from16 v40, v12

    const/16 v12, 0x64

    .end local v12  # "providersHeader":Landroid/widget/TextView;
    .end local v43  # "switchMap":Ljava/util/Map;
    .local v1, "isBulkUpdating":Lkotlin/jvm/internal/Ref$BooleanRef;
    .restart local v2  # "onAll":Lkotlin/jvm/functions/Function0;
    .restart local v4  # "switchMap":Ljava/util/Map;
    .local v10, "$this$show_u24lambda_u2448_u240":Lcom/google/android/material/button/MaterialButton;
    .local v38, "providersHeaderRow":Landroid/widget/LinearLayout;
    .local v40, "providersHeader":Landroid/widget/TextView;
    invoke-direct/range {v0 .. v6}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda2;-><init>(Lkotlin/jvm/internal/Ref$BooleanRef;Lkotlin/jvm/functions/Function0;Ldev/wiojelt/turksinema/common/WioSettingsConfig;Ljava/util/Map;Lkotlin/jvm/internal/Ref$ObjectRef;Ljava/util/Map;)V

    invoke-virtual {v10, v0}, Lcom/google/android/material/button/MaterialButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 865
    nop

    .line 842
    .end local v10  # "$this$show_u24lambda_u2448_u240":Lcom/google/android/material/button/MaterialButton;
    .end local v33  # "$i$a$-apply-WioCoreSettingsDialog$show$10$btnAll$1":I
    .end local v44  # "lp":Landroid/widget/LinearLayout$LayoutParams;
    nop

    .line 866
    .local v42, "btnAll":Lcom/google/android/material/button/MaterialButton;
    move-object/from16 v0, v42

    check-cast v0, Landroid/view/View;

    invoke-virtual {v8, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 867
    nop

    .end local v2  # "onAll":Lkotlin/jvm/functions/Function0;
    .end local v32  # "$i$a$-let-WioCoreSettingsDialog$show$10":I
    .end local v42  # "btnAll":Lcom/google/android/material/button/MaterialButton;
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 841
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    goto :goto_bb1

    .end local v1  # "isBulkUpdating":Lkotlin/jvm/internal/Ref$BooleanRef;
    .end local v38  # "providersHeaderRow":Landroid/widget/LinearLayout;
    .local v10, "providersHeaderRow":Landroid/widget/LinearLayout;
    .restart local v12  # "providersHeader":Landroid/widget/TextView;
    .local v40, "isBulkUpdating":Lkotlin/jvm/internal/Ref$BooleanRef;
    :cond_ba9
    move-object/from16 v38, v10

    move-object/from16 v1, v40

    move-object/from16 v40, v12

    const/16 v12, 0x64

    .line 869
    .end local v10  # "providersHeaderRow":Landroid/widget/LinearLayout;
    .end local v12  # "providersHeader":Landroid/widget/TextView;
    .restart local v1  # "isBulkUpdating":Lkotlin/jvm/internal/Ref$BooleanRef;
    .restart local v38  # "providersHeaderRow":Landroid/widget/LinearLayout;
    .local v40, "providersHeader":Landroid/widget/TextView;
    :goto_bb1
    invoke-virtual/range {p2 .. p2}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getOnSelectRecommended()Lkotlin/jvm/functions/Function0;

    move-result-object v2

    if-eqz v2, :cond_c50

    .local v2, "onRec":Lkotlin/jvm/functions/Function0;
    const/4 v10, 0x0

    .line 870
    .local v10, "$i$a$-let-WioCoreSettingsDialog$show$11":I
    new-instance v0, Lcom/google/android/material/button/MaterialButton;

    invoke-direct {v0, v7}, Lcom/google/android/material/button/MaterialButton;-><init>(Landroid/content/Context;)V

    move-object v3, v0

    .local v3, "$this$show_u24lambda_u2449_u240":Lcom/google/android/material/button/MaterialButton;
    const/16 v32, 0x0

    .line 871
    .local v32, "$i$a$-apply-WioCoreSettingsDialog$show$11$btnRec$1":I
    invoke-virtual/range {p2 .. p2}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getEnglishLabels()Z

    move-result v33

    if-eqz v33, :cond_bc9

    const-string v33, "Recommended"

    goto :goto_bcb

    :cond_bc9
    const-string v33, "Önerilenler"

    :goto_bcb
    check-cast v33, Ljava/lang/CharSequence;

    move-object/from16 v12, v33

    invoke-virtual {v3, v12}, Lcom/google/android/material/button/MaterialButton;->setText(Ljava/lang/CharSequence;)V

    .line 872
    const/high16 v12, 0x41300000  # 11.0f

    invoke-virtual {v3, v12}, Lcom/google/android/material/button/MaterialButton;->setTextSize(F)V

    .line 873
    const/4 v12, -0x1

    invoke-virtual {v3, v12}, Lcom/google/android/material/button/MaterialButton;->setTextColor(I)V

    .line 874
    invoke-static {v13}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v12

    invoke-static {v12}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v12

    invoke-virtual {v3, v12}, Lcom/google/android/material/button/MaterialButton;->setBackgroundTintList(Landroid/content/res/ColorStateList;)V

    .line 875
    const-string v12, "#26FFFFFF"

    invoke-static {v12}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v12

    invoke-static {v12}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v12

    invoke-virtual {v3, v12}, Lcom/google/android/material/button/MaterialButton;->setStrokeColor(Landroid/content/res/ColorStateList;)V

    .line 876
    move-object/from16 v33, v0

    const/4 v12, 0x1

    invoke-static {v7, v12}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v0

    invoke-virtual {v3, v0}, Lcom/google/android/material/button/MaterialButton;->setStrokeWidth(I)V

    .line 877
    const/16 v0, 0x64

    invoke-static {v7, v0}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v12

    invoke-virtual {v3, v12}, Lcom/google/android/material/button/MaterialButton;->setCornerRadius(I)V

    .line 878
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v12, 0x24

    invoke-static {v7, v12}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v12

    move-object/from16 v42, v1

    move-object/from16 v43, v2

    const/high16 v1, 0x3f800000  # 1.0f

    const/4 v2, 0x0

    .end local v1  # "isBulkUpdating":Lkotlin/jvm/internal/Ref$BooleanRef;
    .end local v2  # "onRec":Lkotlin/jvm/functions/Function0;
    .local v42, "isBulkUpdating":Lkotlin/jvm/internal/Ref$BooleanRef;
    .local v43, "onRec":Lkotlin/jvm/functions/Function0;
    invoke-direct {v0, v2, v12, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    move-object v1, v0

    .line 1215
    .local v1, "$this$show_u24lambda_u2449_u240_u240":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v2, 0x0

    .line 878
    .local v2, "$i$a$-apply-WioCoreSettingsDialog$show$11$btnRec$1$lp$1":I
    move-object/from16 v44, v0

    const/4 v12, 0x6

    invoke-static {v7, v12}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v0

    invoke-virtual {v1, v0}, Landroid/widget/LinearLayout$LayoutParams;->setMarginEnd(I)V

    .line 879
    .end local v1  # "$this$show_u24lambda_u2449_u240_u240":Landroid/widget/LinearLayout$LayoutParams;
    .end local v2  # "$i$a$-apply-WioCoreSettingsDialog$show$11$btnRec$1$lp$1":I
    .restart local v44  # "lp":Landroid/widget/LinearLayout$LayoutParams;
    move-object/from16 v0, v44

    check-cast v0, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v3, v0}, Lcom/google/android/material/button/MaterialButton;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 880
    const/4 v12, 0x0

    invoke-virtual {v3, v12}, Lcom/google/android/material/button/MaterialButton;->setAllCaps(Z)V

    .line 881
    new-instance v0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda3;

    move-object v12, v3

    move-object v3, v4

    move-object v4, v5

    move-object/from16 v1, v42

    move-object/from16 v2, v43

    move-object/from16 v5, p2

    .end local v5  # "updateCounterText":Lkotlin/jvm/internal/Ref$ObjectRef;
    .end local v42  # "isBulkUpdating":Lkotlin/jvm/internal/Ref$BooleanRef;
    .end local v43  # "onRec":Lkotlin/jvm/functions/Function0;
    .local v1, "isBulkUpdating":Lkotlin/jvm/internal/Ref$BooleanRef;
    .local v2, "onRec":Lkotlin/jvm/functions/Function0;
    .local v3, "switchMap":Ljava/util/Map;
    .local v4, "updateCounterText":Lkotlin/jvm/internal/Ref$ObjectRef;
    .local v12, "$this$show_u24lambda_u2449_u240":Lcom/google/android/material/button/MaterialButton;
    invoke-direct/range {v0 .. v6}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda3;-><init>(Lkotlin/jvm/internal/Ref$BooleanRef;Lkotlin/jvm/functions/Function0;Ljava/util/Map;Lkotlin/jvm/internal/Ref$ObjectRef;Ldev/wiojelt/turksinema/common/WioSettingsConfig;Ljava/util/Map;)V

    move-object v5, v4

    move-object v4, v3

    .end local v3  # "switchMap":Ljava/util/Map;
    .local v4, "switchMap":Ljava/util/Map;
    .restart local v5  # "updateCounterText":Lkotlin/jvm/internal/Ref$ObjectRef;
    invoke-virtual {v12, v0}, Lcom/google/android/material/button/MaterialButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 895
    nop

    .line 870
    .end local v12  # "$this$show_u24lambda_u2449_u240":Lcom/google/android/material/button/MaterialButton;
    .end local v32  # "$i$a$-apply-WioCoreSettingsDialog$show$11$btnRec$1":I
    .end local v44  # "lp":Landroid/widget/LinearLayout$LayoutParams;
    nop

    .line 896
    .local v33, "btnRec":Lcom/google/android/material/button/MaterialButton;
    move-object/from16 v0, v33

    check-cast v0, Landroid/view/View;

    invoke-virtual {v8, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 897
    nop

    .end local v2  # "onRec":Lkotlin/jvm/functions/Function0;
    .end local v10  # "$i$a$-let-WioCoreSettingsDialog$show$11":I
    .end local v33  # "btnRec":Lcom/google/android/material/button/MaterialButton;
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 869
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 899
    :cond_c50
    invoke-virtual/range {p2 .. p2}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getOnSelectNone()Lkotlin/jvm/functions/Function0;

    move-result-object v2

    if-eqz v2, :cond_cea

    .local v2, "onNone":Lkotlin/jvm/functions/Function0;
    const/4 v10, 0x0

    .line 900
    .local v10, "$i$a$-let-WioCoreSettingsDialog$show$12":I
    new-instance v12, Lcom/google/android/material/button/MaterialButton;

    invoke-direct {v12, v7}, Lcom/google/android/material/button/MaterialButton;-><init>(Landroid/content/Context;)V

    move-object v0, v12

    .local v0, "$this$show_u24lambda_u2450_u240":Lcom/google/android/material/button/MaterialButton;
    const/16 v32, 0x0

    .line 901
    .local v32, "$i$a$-apply-WioCoreSettingsDialog$show$12$btnNone$1":I
    invoke-virtual/range {p2 .. p2}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getEnglishLabels()Z

    move-result v3

    if-eqz v3, :cond_c68

    const-string v3, "Disable All"

    goto :goto_c6a

    :cond_c68
    const-string v3, "Tümünü Kapat"

    :goto_c6a
    check-cast v3, Ljava/lang/CharSequence;

    invoke-virtual {v0, v3}, Lcom/google/android/material/button/MaterialButton;->setText(Ljava/lang/CharSequence;)V

    .line 902
    const/high16 v3, 0x41300000  # 11.0f

    invoke-virtual {v0, v3}, Lcom/google/android/material/button/MaterialButton;->setTextSize(F)V

    .line 903
    invoke-virtual/range {p2 .. p2}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getTextSecondary()I

    move-result v3

    invoke-virtual {v0, v3}, Lcom/google/android/material/button/MaterialButton;->setTextColor(I)V

    .line 904
    invoke-static {v13}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v3

    invoke-static {v3}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v3

    invoke-virtual {v0, v3}, Lcom/google/android/material/button/MaterialButton;->setBackgroundTintList(Landroid/content/res/ColorStateList;)V

    .line 905
    const-string v3, "#26FFFFFF"

    invoke-static {v3}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v3

    invoke-static {v3}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v3

    invoke-virtual {v0, v3}, Lcom/google/android/material/button/MaterialButton;->setStrokeColor(Landroid/content/res/ColorStateList;)V

    .line 906
    move-object/from16 v42, v1

    const/4 v3, 0x1

    .end local v1  # "isBulkUpdating":Lkotlin/jvm/internal/Ref$BooleanRef;
    .restart local v42  # "isBulkUpdating":Lkotlin/jvm/internal/Ref$BooleanRef;
    invoke-static {v7, v3}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v1

    invoke-virtual {v0, v1}, Lcom/google/android/material/button/MaterialButton;->setStrokeWidth(I)V

    .line 907
    const/16 v1, 0x64

    invoke-static {v7, v1}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v3

    invoke-virtual {v0, v3}, Lcom/google/android/material/button/MaterialButton;->setCornerRadius(I)V

    .line 908
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v3, 0x24

    invoke-static {v7, v3}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v3

    move-object/from16 v33, v2

    move-object/from16 v43, v4

    const/high16 v2, 0x3f800000  # 1.0f

    const/4 v4, 0x0

    .end local v2  # "onNone":Lkotlin/jvm/functions/Function0;
    .end local v4  # "switchMap":Ljava/util/Map;
    .local v33, "onNone":Lkotlin/jvm/functions/Function0;
    .local v43, "switchMap":Ljava/util/Map;
    invoke-direct {v1, v4, v3, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    move-object/from16 v44, v1

    .line 909
    .restart local v44  # "lp":Landroid/widget/LinearLayout$LayoutParams;
    move-object/from16 v1, v44

    check-cast v1, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v0, v1}, Lcom/google/android/material/button/MaterialButton;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 910
    invoke-virtual {v0, v4}, Lcom/google/android/material/button/MaterialButton;->setAllCaps(Z)V

    .line 911
    move-object v1, v0

    .end local v0  # "$this$show_u24lambda_u2450_u240":Lcom/google/android/material/button/MaterialButton;
    .local v1, "$this$show_u24lambda_u2450_u240":Lcom/google/android/material/button/MaterialButton;
    new-instance v0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda4;

    move-object/from16 v3, p2

    move/from16 v45, v10

    move-object/from16 v2, v33

    move-object/from16 v4, v43

    move-object v10, v1

    move-object/from16 v1, v42

    .end local v33  # "onNone":Lkotlin/jvm/functions/Function0;
    .end local v42  # "isBulkUpdating":Lkotlin/jvm/internal/Ref$BooleanRef;
    .end local v43  # "switchMap":Ljava/util/Map;
    .local v1, "isBulkUpdating":Lkotlin/jvm/internal/Ref$BooleanRef;
    .restart local v2  # "onNone":Lkotlin/jvm/functions/Function0;
    .restart local v4  # "switchMap":Ljava/util/Map;
    .local v10, "$this$show_u24lambda_u2450_u240":Lcom/google/android/material/button/MaterialButton;
    .local v45, "$i$a$-let-WioCoreSettingsDialog$show$12":I
    invoke-direct/range {v0 .. v6}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda4;-><init>(Lkotlin/jvm/internal/Ref$BooleanRef;Lkotlin/jvm/functions/Function0;Ldev/wiojelt/turksinema/common/WioSettingsConfig;Ljava/util/Map;Lkotlin/jvm/internal/Ref$ObjectRef;Ljava/util/Map;)V

    move-object/from16 v33, v5

    move-object/from16 v43, v6

    .end local v1  # "isBulkUpdating":Lkotlin/jvm/internal/Ref$BooleanRef;
    .end local v5  # "updateCounterText":Lkotlin/jvm/internal/Ref$ObjectRef;
    .end local v6  # "presetButtons":Ljava/util/Map;
    .local v33, "updateCounterText":Lkotlin/jvm/internal/Ref$ObjectRef;
    .restart local v42  # "isBulkUpdating":Lkotlin/jvm/internal/Ref$BooleanRef;
    .local v43, "presetButtons":Ljava/util/Map;
    invoke-virtual {v10, v0}, Lcom/google/android/material/button/MaterialButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 923
    nop

    .line 900
    .end local v10  # "$this$show_u24lambda_u2450_u240":Lcom/google/android/material/button/MaterialButton;
    .end local v32  # "$i$a$-apply-WioCoreSettingsDialog$show$12$btnNone$1":I
    .end local v44  # "lp":Landroid/widget/LinearLayout$LayoutParams;
    nop

    .line 924
    .local v12, "btnNone":Lcom/google/android/material/button/MaterialButton;
    move-object v0, v12

    check-cast v0, Landroid/view/View;

    invoke-virtual {v8, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 925
    nop

    .end local v2  # "onNone":Lkotlin/jvm/functions/Function0;
    .end local v12  # "btnNone":Lcom/google/android/material/button/MaterialButton;
    .end local v45  # "$i$a$-let-WioCoreSettingsDialog$show$12":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 899
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    goto :goto_cf0

    .end local v33  # "updateCounterText":Lkotlin/jvm/internal/Ref$ObjectRef;
    .end local v42  # "isBulkUpdating":Lkotlin/jvm/internal/Ref$BooleanRef;
    .end local v43  # "presetButtons":Ljava/util/Map;
    .restart local v1  # "isBulkUpdating":Lkotlin/jvm/internal/Ref$BooleanRef;
    .restart local v5  # "updateCounterText":Lkotlin/jvm/internal/Ref$ObjectRef;
    .restart local v6  # "presetButtons":Ljava/util/Map;
    :cond_cea
    move-object/from16 v42, v1

    move-object/from16 v33, v5

    move-object/from16 v43, v6

    .line 927
    .end local v1  # "isBulkUpdating":Lkotlin/jvm/internal/Ref$BooleanRef;
    .end local v5  # "updateCounterText":Lkotlin/jvm/internal/Ref$ObjectRef;
    .end local v6  # "presetButtons":Ljava/util/Map;
    .restart local v33  # "updateCounterText":Lkotlin/jvm/internal/Ref$ObjectRef;
    .restart local v42  # "isBulkUpdating":Lkotlin/jvm/internal/Ref$BooleanRef;
    .restart local v43  # "presetButtons":Ljava/util/Map;
    :goto_cf0
    move-object v0, v8

    check-cast v0, Landroid/view/View;

    invoke-virtual {v9, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 930
    .end local v8  # "batchRow":Landroid/widget/LinearLayout;
    :goto_cf6
    invoke-virtual {v7}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->widthPixels:I

    const/16 v1, 0x244

    invoke-static {v7, v1}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v1

    if-le v0, v1, :cond_d0a

    const/4 v0, 0x1

    goto :goto_d0b

    :cond_d0a
    const/4 v0, 0x0

    :goto_d0b
    move v10, v0

    .line 931
    .local v10, "isWide":Z
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, v7}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v1, v0

    .local v1, "$this$show_u24lambda_u2451":Landroid/widget/LinearLayout;
    const/4 v2, 0x0

    .line 932
    .local v2, "$i$a$-apply-WioCoreSettingsDialog$show$columnsContainer$1":I
    if-eqz v10, :cond_d17

    const/4 v3, 0x0

    goto :goto_d18

    :cond_d17
    const/4 v3, 0x1

    :goto_d18
    invoke-virtual {v1, v3}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 933
    nop

    .line 931
    .end local v1  # "$this$show_u24lambda_u2451":Landroid/widget/LinearLayout;
    .end local v2  # "$i$a$-apply-WioCoreSettingsDialog$show$columnsContainer$1":I
    move-object v12, v0

    .line 935
    .local v12, "columnsContainer":Landroid/widget/LinearLayout;
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, v7}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v1, v0

    .local v1, "$this$show_u24lambda_u2452":Landroid/widget/LinearLayout;
    const/4 v2, 0x0

    .line 936
    .local v2, "$i$a$-apply-WioCoreSettingsDialog$show$col1$1":I
    const/4 v8, 0x1

    invoke-virtual {v1, v8}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 937
    if-eqz v10, :cond_d47

    .line 938
    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v5, -0x2

    const/4 v6, 0x0

    const/high16 v8, 0x3f800000  # 1.0f

    invoke-direct {v3, v6, v5, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    move-object v5, v3

    .local v5, "$this$show_u24lambda_u2452_u240":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v6, 0x0

    .line 939
    .local v6, "$i$a$-apply-WioCoreSettingsDialog$show$col1$1$1":I
    move-object/from16 v32, v0

    const/16 v8, 0x8

    invoke-static {v7, v8}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v0

    invoke-virtual {v5, v0}, Landroid/widget/LinearLayout$LayoutParams;->setMarginEnd(I)V

    .line 940
    nop

    .line 938
    .end local v5  # "$this$show_u24lambda_u2452_u240":Landroid/widget/LinearLayout$LayoutParams;
    .end local v6  # "$i$a$-apply-WioCoreSettingsDialog$show$col1$1$1":I
    check-cast v3, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v1, v3}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    goto :goto_d49

    .line 937
    :cond_d47
    move-object/from16 v32, v0

    .line 942
    :goto_d49
    nop

    .line 935
    .end local v1  # "$this$show_u24lambda_u2452":Landroid/widget/LinearLayout;
    .end local v2  # "$i$a$-apply-WioCoreSettingsDialog$show$col1$1":I
    nop

    .line 943
    .local v32, "col1":Landroid/widget/LinearLayout;
    if-eqz v10, :cond_d68

    .line 944
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, v7}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v1, v0

    .local v1, "$this$show_u24lambda_u2453":Landroid/widget/LinearLayout;
    const/4 v2, 0x0

    .line 945
    .local v2, "$i$a$-apply-WioCoreSettingsDialog$show$col2$1":I
    const/4 v8, 0x1

    invoke-virtual {v1, v8}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 946
    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v5, -0x2

    const/4 v6, 0x0

    const/high16 v8, 0x3f800000  # 1.0f

    invoke-direct {v3, v6, v5, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    check-cast v3, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v1, v3}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 947
    nop

    .line 944
    .end local v1  # "$this$show_u24lambda_u2453":Landroid/widget/LinearLayout;
    .end local v2  # "$i$a$-apply-WioCoreSettingsDialog$show$col2$1":I
    goto :goto_d69

    .line 948
    :cond_d68
    const/4 v0, 0x0

    .line 943
    :goto_d69
    move-object/from16 v44, v0

    .line 950
    .local v44, "col2":Landroid/widget/LinearLayout;
    move-object/from16 v0, v32

    check-cast v0, Landroid/view/View;

    invoke-virtual {v12, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 951
    if-eqz v44, :cond_d81

    move-object/from16 v0, v44

    .line 1215
    .local v0, "it":Landroid/widget/LinearLayout;
    const/4 v1, 0x0

    .line 951
    .local v1, "$i$a$-let-WioCoreSettingsDialog$show$13":I
    move-object v2, v0

    check-cast v2, Landroid/view/View;

    invoke-virtual {v12, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .end local v0  # "it":Landroid/widget/LinearLayout;
    .end local v1  # "$i$a$-let-WioCoreSettingsDialog$show$13":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 953
    :cond_d81
    invoke-virtual/range {p2 .. p2}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getItems()Ljava/util/List;

    move-result-object v0

    move-object/from16 v45, v0

    check-cast v45, Ljava/lang/Iterable;

    .local v45, "$this$forEachIndexed$iv":Ljava/lang/Iterable;
    const/16 v47, 0x0

    .line 1216
    .local v47, "$i$f$forEachIndexed":I
    const/4 v0, 0x0

    .line 1217
    .local v0, "index$iv":I
    invoke-interface/range {v45 .. v45}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v49

    :goto_d90
    invoke-interface/range {v49 .. v49}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_102a

    invoke-interface/range {v49 .. v49}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v50

    .local v50, "item$iv":Ljava/lang/Object;
    add-int/lit8 v51, v0, 0x1

    .end local v0  # "index$iv":I
    .local v51, "index$iv":I
    if-gez v0, :cond_da1

    invoke-static {}, Lkotlin/collections/CollectionsKt;->throwIndexOverflow()V

    :cond_da1
    move-object/from16 v2, v50

    check-cast v2, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;

    .local v2, "item":Ldev/wiojelt/turksinema/common/WioProviderSettingItem;
    move/from16 v52, v0

    .local v52, "idx":I
    const/16 v53, 0x0

    .line 954
    .local v53, "$i$a$-forEachIndexed-WioCoreSettingsDialog$show$14":I
    if-eqz v10, :cond_db5

    rem-int/lit8 v0, v52, 0x2

    if-eqz v0, :cond_db5

    if-nez v44, :cond_db2

    goto :goto_db5

    :cond_db2
    move-object/from16 v0, v44

    goto :goto_db7

    :cond_db5
    :goto_db5
    move-object/from16 v0, v32

    .line 956
    .local v0, "targetCol":Landroid/widget/LinearLayout;
    :goto_db7
    new-instance v1, Landroid/widget/LinearLayout;

    invoke-direct {v1, v7}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v3, v1

    .local v3, "$this$show_u24lambda_u2455_u240":Landroid/widget/LinearLayout;
    const/16 v54, 0x0

    .line 957
    .local v54, "$i$a$-apply-WioCoreSettingsDialog$show$14$card$1":I
    const/4 v6, 0x0

    invoke-virtual {v3, v6}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 958
    const/16 v5, 0x10

    invoke-virtual {v3, v5}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 959
    const/16 v8, 0xc

    invoke-static {v7, v8}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v6

    move-object/from16 v55, v0

    const/16 v5, 0x8

    .end local v0  # "targetCol":Landroid/widget/LinearLayout;
    .local v55, "targetCol":Landroid/widget/LinearLayout;
    invoke-static {v7, v5}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v0

    move-object/from16 v56, v1

    invoke-static {v7, v8}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v1

    invoke-static {v7, v5}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v8

    invoke-virtual {v3, v6, v0, v1, v8}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 960
    move-object v0, v2

    .end local v2  # "item":Ldev/wiojelt/turksinema/common/WioProviderSettingItem;
    .local v0, "item":Ldev/wiojelt/turksinema/common/WioProviderSettingItem;
    invoke-virtual/range {p2 .. p2}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getCardBgSubtle()I

    move-result v2

    invoke-virtual/range {p2 .. p2}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getBrandColor()I

    move-result v1

    invoke-static {v1}, Landroid/graphics/Color;->red(I)I

    move-result v1

    invoke-virtual/range {p2 .. p2}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getBrandColor()I

    move-result v5

    invoke-static {v5}, Landroid/graphics/Color;->green(I)I

    move-result v5

    invoke-virtual/range {p2 .. p2}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getBrandColor()I

    move-result v6

    invoke-static {v6}, Landroid/graphics/Color;->blue(I)I

    move-result v6

    const/16 v8, 0x28

    invoke-static {v8, v1, v5, v6}, Landroid/graphics/Color;->argb(IIII)I

    move-result v1

    const/16 v7, 0x30

    const/4 v8, 0x0

    move-object v5, v4

    .end local v4  # "switchMap":Ljava/util/Map;
    .local v5, "switchMap":Ljava/util/Map;
    const/4 v4, 0x0

    move-object v6, v5

    .end local v5  # "switchMap":Ljava/util/Map;
    .local v6, "switchMap":Ljava/util/Map;
    const/4 v5, 0x0

    move-object/from16 v57, v6

    .end local v6  # "switchMap":Ljava/util/Map;
    .local v57, "switchMap":Ljava/util/Map;
    const/high16 v6, 0x41400000  # 12.0f

    move-object/from16 v19, v0

    move/from16 v58, v10

    move-object/from16 v41, v12

    move-object/from16 v12, v55

    move-object/from16 v10, v57

    const/16 v59, 0x10

    move-object/from16 v0, p2

    move-object/from16 v55, v13

    move-object/from16 v57, v14

    const/4 v14, 0x4

    move-object v13, v3

    move v3, v1

    move-object/from16 v1, p1

    .end local v0  # "item":Ldev/wiojelt/turksinema/common/WioProviderSettingItem;
    .end local v3  # "$this$show_u24lambda_u2455_u240":Landroid/widget/LinearLayout;
    .end local v14  # "p1":Landroid/widget/TextView;
    .end local v55  # "targetCol":Landroid/widget/LinearLayout;
    .local v10, "switchMap":Ljava/util/Map;
    .local v12, "targetCol":Landroid/widget/LinearLayout;
    .local v13, "$this$show_u24lambda_u2455_u240":Landroid/widget/LinearLayout;
    .local v19, "item":Ldev/wiojelt/turksinema/common/WioProviderSettingItem;
    .local v41, "columnsContainer":Landroid/widget/LinearLayout;
    .local v57, "p1":Landroid/widget/TextView;
    .local v58, "isWide":Z
    invoke-static/range {v0 .. v8}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$focusableGlassDrawable$default(Ldev/wiojelt/turksinema/common/WioSettingsConfig;Landroid/content/Context;IIIIFILjava/lang/Object;)Landroid/graphics/drawable/StateListDrawable;

    move-result-object v2

    move-object v7, v1

    check-cast v2, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v13, v2}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 961
    const/4 v8, 0x1

    invoke-virtual {v13, v8}, Landroid/widget/LinearLayout;->setFocusable(Z)V

    .line 962
    invoke-virtual {v13, v8}, Landroid/widget/LinearLayout;->setClickable(Z)V

    .line 963
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v4, -0x1

    const/4 v8, -0x2

    invoke-direct {v1, v4, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object v2, v1

    .local v2, "$this$show_u24lambda_u2455_u240_u240":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v3, 0x0

    .line 964
    .local v3, "$i$a$-apply-WioCoreSettingsDialog$show$14$card$1$lp$1":I
    const/4 v4, 0x6

    invoke-static {v7, v4}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v5

    iput v5, v2, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 965
    nop

    .line 963
    .end local v2  # "$this$show_u24lambda_u2455_u240_u240":Landroid/widget/LinearLayout$LayoutParams;
    .end local v3  # "$i$a$-apply-WioCoreSettingsDialog$show$14$card$1$lp$1":I
    nop

    .line 966
    .local v1, "lp":Landroid/widget/LinearLayout$LayoutParams;
    move-object v2, v1

    check-cast v2, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v13, v2}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 967
    nop

    .line 956
    .end local v1  # "lp":Landroid/widget/LinearLayout$LayoutParams;
    .end local v13  # "$this$show_u24lambda_u2455_u240":Landroid/widget/LinearLayout;
    .end local v54  # "$i$a$-apply-WioCoreSettingsDialog$show$14$card$1":I
    move-object/from16 v6, v56

    .line 969
    .local v6, "card":Landroid/widget/LinearLayout;
    new-instance v1, Landroid/widget/LinearLayout;

    invoke-direct {v1, v7}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v2, v1

    .local v2, "$this$show_u24lambda_u2455_u241":Landroid/widget/LinearLayout;
    const/4 v3, 0x0

    .line 970
    .local v3, "$i$a$-apply-WioCoreSettingsDialog$show$14$textCol$1":I
    const/4 v8, 0x1

    invoke-virtual {v2, v8}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 971
    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v5, 0x0

    const/high16 v8, 0x3f800000  # 1.0f

    const/4 v13, -0x2

    invoke-direct {v4, v5, v13, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    check-cast v4, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v2, v4}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 972
    nop

    .line 969
    .end local v2  # "$this$show_u24lambda_u2455_u241":Landroid/widget/LinearLayout;
    .end local v3  # "$i$a$-apply-WioCoreSettingsDialog$show$14$textCol$1":I
    move-object v8, v1

    .line 974
    .local v8, "textCol":Landroid/widget/LinearLayout;
    new-instance v1, Landroid/widget/TextView;

    invoke-direct {v1, v7}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v2, v1

    .local v2, "$this$show_u24lambda_u2455_u242":Landroid/widget/TextView;
    const/4 v3, 0x0

    .line 975
    .local v3, "$i$a$-apply-WioCoreSettingsDialog$show$14$nameView$1":I
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    move-object v5, v4

    .local v5, "$this$show_u24lambda_u2455_u242_u240":Ljava/lang/StringBuilder;
    const/4 v13, 0x0

    .line 976
    .local v13, "$i$a$-buildString-WioCoreSettingsDialog$show$14$nameView$1$1":I
    invoke-virtual/range {v19 .. v19}, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->getDisplayName()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v5, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 977
    invoke-virtual/range {v19 .. v19}, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->isForeign()Z

    move-result v14

    if-eqz v14, :cond_e8f

    const-string v14, "  \ud83c\udf10"

    invoke-virtual {v5, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 978
    :cond_e8f
    invoke-virtual/range {v19 .. v19}, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->getCapabilityBadges()Ljava/lang/String;

    move-result-object v14

    if-eqz v14, :cond_eb9

    move-object/from16 v56, v14

    .line 1215
    .local v56, "it":Ljava/lang/String;
    const/16 v60, 0x0

    .line 978
    .local v60, "$i$a$-takeIf-WioCoreSettingsDialog$show$14$nameView$1$1$1":I
    move-object/from16 v61, v56

    check-cast v61, Ljava/lang/CharSequence;

    invoke-static/range {v61 .. v61}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v61

    .end local v56  # "it":Ljava/lang/String;
    .end local v60  # "$i$a$-takeIf-WioCoreSettingsDialog$show$14$nameView$1$1$1":I
    if-nez v61, :cond_ea4

    goto :goto_ea5

    :cond_ea4
    const/4 v14, 0x0

    :goto_ea5
    if-eqz v14, :cond_eb9

    .line 1215
    .local v14, "it":Ljava/lang/String;
    const/16 v56, 0x0

    .line 978
    .local v56, "$i$a$-let-WioCoreSettingsDialog$show$14$nameView$1$1$2":I
    move-object/from16 v60, v1

    const-string v1, "  "

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .end local v14  # "it":Ljava/lang/String;
    .end local v56  # "$i$a$-let-WioCoreSettingsDialog$show$14$nameView$1$1$2":I
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    goto :goto_ebb

    :cond_eb9
    move-object/from16 v60, v1

    .line 979
    :goto_ebb
    nop

    .line 975
    .end local v5  # "$this$show_u24lambda_u2455_u242_u240":Ljava/lang/StringBuilder;
    .end local v13  # "$i$a$-buildString-WioCoreSettingsDialog$show$14$nameView$1$1":I
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    check-cast v1, Ljava/lang/CharSequence;

    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 980
    const/high16 v1, 0x41580000  # 13.5f

    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setTextSize(F)V

    .line 981
    sget-object v1, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 982
    invoke-virtual/range {v19 .. v19}, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->isForeign()Z

    move-result v1

    if-eqz v1, :cond_eda

    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getTextSecondary()I

    move-result v1

    goto :goto_ede

    :cond_eda
    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getTextPrimary()I

    move-result v1

    :goto_ede
    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 983
    nop

    .line 974
    .end local v2  # "$this$show_u24lambda_u2455_u242":Landroid/widget/TextView;
    .end local v3  # "$i$a$-apply-WioCoreSettingsDialog$show$14$nameView$1":I
    nop

    .line 984
    .local v60, "nameView":Landroid/widget/TextView;
    move-object/from16 v1, v60

    check-cast v1, Landroid/view/View;

    invoke-virtual {v8, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 986
    invoke-virtual/range {v19 .. v19}, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->getDomain()Ljava/lang/String;

    move-result-object v13

    .line 987
    .local v13, "domainText":Ljava/lang/String;
    if-eqz v13, :cond_f26

    .line 988
    new-instance v1, Landroid/widget/TextView;

    invoke-direct {v1, v7}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v2, v1

    .local v2, "$this$show_u24lambda_u2455_u243":Landroid/widget/TextView;
    const/4 v3, 0x0

    .line 989
    .local v3, "$i$a$-apply-WioCoreSettingsDialog$show$14$domainView$1":I
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, " ✎"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    check-cast v4, Ljava/lang/CharSequence;

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 990
    const/high16 v4, 0x41300000  # 11.0f

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setTextSize(F)V

    .line 991
    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getTextSecondary()I

    move-result v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setTextColor(I)V

    .line 992
    const/4 v14, 0x2

    invoke-static {v7, v14}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v4

    const/4 v5, 0x0

    invoke-virtual {v2, v5, v4, v5, v5}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 993
    nop

    .line 988
    .end local v2  # "$this$show_u24lambda_u2455_u243":Landroid/widget/TextView;
    .end local v3  # "$i$a$-apply-WioCoreSettingsDialog$show$14$domainView$1":I
    goto :goto_f28

    .line 994
    :cond_f26
    const/4 v14, 0x2

    const/4 v1, 0x0

    .line 987
    :goto_f28
    nop

    .line 995
    .local v1, "domainView":Landroid/widget/TextView;
    if-eqz v1, :cond_f37

    move-object v2, v1

    .line 1215
    .local v2, "it":Landroid/widget/TextView;
    const/4 v3, 0x0

    .line 995
    .local v3, "$i$a$-let-WioCoreSettingsDialog$show$14$1":I
    move-object v4, v2

    check-cast v4, Landroid/view/View;

    invoke-virtual {v8, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .end local v2  # "it":Landroid/widget/TextView;
    .end local v3  # "$i$a$-let-WioCoreSettingsDialog$show$14$1":I
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 997
    :cond_f37
    move-object v2, v8

    check-cast v2, Landroid/view/View;

    invoke-virtual {v6, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 999
    invoke-virtual/range {v19 .. v19}, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->getOnDomainEdit()Lkotlin/jvm/functions/Function1;

    move-result-object v2

    if-eqz v2, :cond_f9a

    .line 1000
    new-instance v2, Landroid/widget/TextView;

    invoke-direct {v2, v7}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v3, v2

    .local v3, "$this$show_u24lambda_u2455_u245":Landroid/widget/TextView;
    const/4 v4, 0x0

    .line 1001
    .local v4, "$i$a$-apply-WioCoreSettingsDialog$show$14$editBtn$1":I
    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getEnglishLabels()Z

    move-result v5

    if-eqz v5, :cond_f53

    const-string v5, "Edit ✎"

    goto :goto_f55

    :cond_f53
    const-string v5, "Düzenle ✎"

    :goto_f55
    check-cast v5, Ljava/lang/CharSequence;

    invoke-virtual {v3, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1002
    const/high16 v5, 0x41300000  # 11.0f

    invoke-virtual {v3, v5}, Landroid/widget/TextView;->setTextSize(F)V

    .line 1003
    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getBrandColor()I

    move-result v5

    invoke-virtual {v3, v5}, Landroid/widget/TextView;->setTextColor(I)V

    .line 1004
    const/16 v5, 0x8

    invoke-static {v7, v5}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v14

    move-object/from16 v56, v2

    move/from16 v61, v4

    const/4 v2, 0x6

    .end local v4  # "$i$a$-apply-WioCoreSettingsDialog$show$14$editBtn$1":I
    .local v61, "$i$a$-apply-WioCoreSettingsDialog$show$14$editBtn$1":I
    invoke-static {v7, v2}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v4

    move-object/from16 v62, v8

    .end local v8  # "textCol":Landroid/widget/LinearLayout;
    .local v62, "textCol":Landroid/widget/LinearLayout;
    invoke-static {v7, v5}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v8

    invoke-static {v7, v2}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v5

    invoke-virtual {v3, v14, v4, v8, v5}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 1005
    const/4 v8, 0x1

    invoke-virtual {v3, v8}, Landroid/widget/TextView;->setClickable(Z)V

    .line 1006
    new-instance v2, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda5;

    move-object/from16 v4, v19

    .end local v19  # "item":Ldev/wiojelt/turksinema/common/WioProviderSettingItem;
    .local v4, "item":Ldev/wiojelt/turksinema/common/WioProviderSettingItem;
    invoke-direct {v2, v7, v4, v0, v1}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda5;-><init>(Landroid/content/Context;Ldev/wiojelt/turksinema/common/WioProviderSettingItem;Ldev/wiojelt/turksinema/common/WioSettingsConfig;Landroid/widget/TextView;)V

    invoke-virtual {v3, v2}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1021
    nop

    .line 1000
    .end local v3  # "$this$show_u24lambda_u2455_u245":Landroid/widget/TextView;
    .end local v61  # "$i$a$-apply-WioCoreSettingsDialog$show$14$editBtn$1":I
    nop

    .line 1022
    .local v56, "editBtn":Landroid/widget/TextView;
    move-object/from16 v2, v56

    check-cast v2, Landroid/view/View;

    invoke-virtual {v6, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    goto :goto_f9e

    .line 999
    .end local v4  # "item":Ldev/wiojelt/turksinema/common/WioProviderSettingItem;
    .end local v56  # "editBtn":Landroid/widget/TextView;
    .end local v62  # "textCol":Landroid/widget/LinearLayout;
    .restart local v8  # "textCol":Landroid/widget/LinearLayout;
    .restart local v19  # "item":Ldev/wiojelt/turksinema/common/WioProviderSettingItem;
    :cond_f9a
    move-object/from16 v62, v8

    move-object/from16 v4, v19

    .line 1025
    .end local v8  # "textCol":Landroid/widget/LinearLayout;
    .end local v19  # "item":Ldev/wiojelt/turksinema/common/WioProviderSettingItem;
    .restart local v4  # "item":Ldev/wiojelt/turksinema/common/WioProviderSettingItem;
    .restart local v62  # "textCol":Landroid/widget/LinearLayout;
    :goto_f9e
    new-instance v2, Lcom/google/android/material/switchmaterial/SwitchMaterial;

    invoke-direct {v2, v7}, Lcom/google/android/material/switchmaterial/SwitchMaterial;-><init>(Landroid/content/Context;)V

    move-object v3, v2

    .local v3, "$this$show_u24lambda_u2455_u246":Lcom/google/android/material/switchmaterial/SwitchMaterial;
    const/4 v5, 0x0

    .line 1026
    .local v5, "$i$a$-apply-WioCoreSettingsDialog$show$14$sw$1":I
    invoke-virtual {v4}, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->isEnabled()Z

    move-result v8

    invoke-virtual {v3, v8}, Lcom/google/android/material/switchmaterial/SwitchMaterial;->setChecked(Z)V

    .line 1027
    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getBrandColor()I

    move-result v8

    invoke-static {v8}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v8

    invoke-virtual {v3, v8}, Lcom/google/android/material/switchmaterial/SwitchMaterial;->setThumbTintList(Landroid/content/res/ColorStateList;)V

    .line 1028
    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getBrandColor()I

    move-result v8

    invoke-static {v8}, Landroid/graphics/Color;->red(I)I

    move-result v8

    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getBrandColor()I

    move-result v14

    invoke-static {v14}, Landroid/graphics/Color;->green(I)I

    move-result v14

    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getBrandColor()I

    move-result v19

    invoke-static/range {v19 .. v19}, Landroid/graphics/Color;->blue(I)I

    move-result v0

    move-object/from16 v19, v1

    .end local v1  # "domainView":Landroid/widget/TextView;
    .local v19, "domainView":Landroid/widget/TextView;
    const/16 v1, 0x50

    invoke-static {v1, v8, v14, v0}, Landroid/graphics/Color;->argb(IIII)I

    move-result v0

    invoke-static {v0}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v0

    invoke-virtual {v3, v0}, Lcom/google/android/material/switchmaterial/SwitchMaterial;->setTrackTintList(Landroid/content/res/ColorStateList;)V

    .line 1029
    const/4 v0, 0x0

    invoke-virtual {v3, v0}, Lcom/google/android/material/switchmaterial/SwitchMaterial;->setFocusable(Z)V

    .line 1030
    const/4 v8, 0x1

    invoke-virtual {v3, v8}, Lcom/google/android/material/switchmaterial/SwitchMaterial;->setClickable(Z)V

    .line 1031
    nop

    .line 1025
    .end local v3  # "$this$show_u24lambda_u2455_u246":Lcom/google/android/material/switchmaterial/SwitchMaterial;
    .end local v5  # "$i$a$-apply-WioCoreSettingsDialog$show$14$sw$1":I
    move-object v8, v2

    .line 1032
    .local v8, "sw":Lcom/google/android/material/switchmaterial/SwitchMaterial;
    invoke-virtual {v4}, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->getId()Ljava/lang/String;

    move-result-object v0

    invoke-interface {v10, v0, v8}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1034
    new-instance v0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda6;

    invoke-direct {v0, v8}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda6;-><init>(Lcom/google/android/material/switchmaterial/SwitchMaterial;)V

    invoke-virtual {v6, v0}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1038
    new-instance v0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda7;

    move-object v2, v4

    move-object/from16 v3, v33

    move-object/from16 v1, v42

    move-object/from16 v5, v43

    const/high16 v29, 0x41300000  # 11.0f

    move-object/from16 v4, p2

    .end local v4  # "item":Ldev/wiojelt/turksinema/common/WioProviderSettingItem;
    .end local v33  # "updateCounterText":Lkotlin/jvm/internal/Ref$ObjectRef;
    .end local v42  # "isBulkUpdating":Lkotlin/jvm/internal/Ref$BooleanRef;
    .end local v43  # "presetButtons":Ljava/util/Map;
    .local v1, "isBulkUpdating":Lkotlin/jvm/internal/Ref$BooleanRef;
    .local v2, "item":Ldev/wiojelt/turksinema/common/WioProviderSettingItem;
    .local v3, "updateCounterText":Lkotlin/jvm/internal/Ref$ObjectRef;
    .local v5, "presetButtons":Ljava/util/Map;
    invoke-direct/range {v0 .. v5}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda7;-><init>(Lkotlin/jvm/internal/Ref$BooleanRef;Ldev/wiojelt/turksinema/common/WioProviderSettingItem;Lkotlin/jvm/internal/Ref$ObjectRef;Ldev/wiojelt/turksinema/common/WioSettingsConfig;Ljava/util/Map;)V

    move-object v3, v4

    move-object v14, v5

    move-object v1, v0

    move-object v0, v2

    .end local v1  # "isBulkUpdating":Lkotlin/jvm/internal/Ref$BooleanRef;
    .end local v2  # "item":Ldev/wiojelt/turksinema/common/WioProviderSettingItem;
    .end local v3  # "updateCounterText":Lkotlin/jvm/internal/Ref$ObjectRef;
    .end local v5  # "presetButtons":Ljava/util/Map;
    .restart local v0  # "item":Ldev/wiojelt/turksinema/common/WioProviderSettingItem;
    .local v14, "presetButtons":Ljava/util/Map;
    .restart local v33  # "updateCounterText":Lkotlin/jvm/internal/Ref$ObjectRef;
    .restart local v42  # "isBulkUpdating":Lkotlin/jvm/internal/Ref$BooleanRef;
    invoke-virtual {v8, v1}, Lcom/google/android/material/switchmaterial/SwitchMaterial;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    .line 1046
    move-object v1, v8

    check-cast v1, Landroid/view/View;

    invoke-virtual {v6, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1047
    move-object v1, v6

    check-cast v1, Landroid/view/View;

    invoke-virtual {v12, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1048
    nop

    .line 1217
    .end local v0  # "item":Ldev/wiojelt/turksinema/common/WioProviderSettingItem;
    .end local v6  # "card":Landroid/widget/LinearLayout;
    .end local v8  # "sw":Lcom/google/android/material/switchmaterial/SwitchMaterial;
    .end local v12  # "targetCol":Landroid/widget/LinearLayout;
    .end local v13  # "domainText":Ljava/lang/String;
    .end local v19  # "domainView":Landroid/widget/TextView;
    .end local v52  # "idx":I
    .end local v53  # "$i$a$-forEachIndexed-WioCoreSettingsDialog$show$14":I
    .end local v60  # "nameView":Landroid/widget/TextView;
    .end local v62  # "textCol":Landroid/widget/LinearLayout;
    move-object v4, v10

    move-object/from16 v43, v14

    move-object/from16 v12, v41

    move/from16 v0, v51

    move-object/from16 v13, v55

    move-object/from16 v14, v57

    move/from16 v10, v58

    .end local v50  # "item$iv":Ljava/lang/Object;
    goto/16 :goto_d90

    .line 1218
    .end local v41  # "columnsContainer":Landroid/widget/LinearLayout;
    .end local v51  # "index$iv":I
    .end local v57  # "p1":Landroid/widget/TextView;
    .end local v58  # "isWide":Z
    .local v0, "index$iv":I
    .local v4, "switchMap":Ljava/util/Map;
    .local v10, "isWide":Z
    .local v12, "columnsContainer":Landroid/widget/LinearLayout;
    .local v14, "p1":Landroid/widget/TextView;
    .restart local v43  # "presetButtons":Ljava/util/Map;
    :cond_102a
    move-object/from16 v3, p2

    move/from16 v58, v10

    move-object/from16 v41, v12

    move-object/from16 v55, v13

    move-object/from16 v57, v14

    move-object/from16 v14, v43

    move-object v10, v4

    .line 1050
    .end local v0  # "index$iv":I
    .end local v4  # "switchMap":Ljava/util/Map;
    .end local v12  # "columnsContainer":Landroid/widget/LinearLayout;
    .end local v43  # "presetButtons":Ljava/util/Map;
    .end local v45  # "$this$forEachIndexed$iv":Ljava/lang/Iterable;
    .end local v47  # "$i$f$forEachIndexed":I
    .local v10, "switchMap":Ljava/util/Map;
    .local v14, "presetButtons":Ljava/util/Map;
    .restart local v41  # "columnsContainer":Landroid/widget/LinearLayout;
    .restart local v57  # "p1":Landroid/widget/TextView;
    .restart local v58  # "isWide":Z
    move-object/from16 v0, v41

    check-cast v0, Landroid/view/View;

    invoke-virtual {v9, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1052
    invoke-virtual {v3}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getProvidersCollapsible()Z

    move-result v0

    if-eqz v0, :cond_10c9

    .line 1053
    const/16 v5, 0x8

    invoke-virtual {v9, v5}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 1054
    new-instance v0, Lcom/google/android/material/button/MaterialButton;

    invoke-direct {v0, v7}, Lcom/google/android/material/button/MaterialButton;-><init>(Landroid/content/Context;)V

    move-object v1, v0

    .local v1, "$this$show_u24lambda_u2456":Lcom/google/android/material/button/MaterialButton;
    const/4 v2, 0x0

    .line 1055
    .local v2, "$i$a$-apply-WioCoreSettingsDialog$show$providerToggle$1":I
    invoke-virtual {v3}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getEnglishLabels()Z

    move-result v4

    if-eqz v4, :cond_1059

    const-string v4, "⚙ Choose Providers"

    goto :goto_105b

    :cond_1059
    const-string v4, "⚙ Sağlayıcıları Kendin Seç"

    :goto_105b
    check-cast v4, Ljava/lang/CharSequence;

    invoke-virtual {v1, v4}, Lcom/google/android/material/button/MaterialButton;->setText(Ljava/lang/CharSequence;)V

    .line 1056
    const/high16 v5, 0x41480000  # 12.5f

    invoke-virtual {v1, v5}, Lcom/google/android/material/button/MaterialButton;->setTextSize(F)V

    .line 1057
    sget-object v4, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v1, v4}, Lcom/google/android/material/button/MaterialButton;->setTypeface(Landroid/graphics/Typeface;)V

    .line 1058
    invoke-virtual {v3}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getTextPrimary()I

    move-result v4

    invoke-virtual {v1, v4}, Lcom/google/android/material/button/MaterialButton;->setTextColor(I)V

    .line 1059
    const-string v4, "#1B222A"

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    invoke-static {v4}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v4

    invoke-virtual {v1, v4}, Lcom/google/android/material/button/MaterialButton;->setBackgroundTintList(Landroid/content/res/ColorStateList;)V

    .line 1060
    invoke-virtual {v3}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getBrandColorBorder()I

    move-result v4

    invoke-static {v4}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v4

    invoke-virtual {v1, v4}, Lcom/google/android/material/button/MaterialButton;->setStrokeColor(Landroid/content/res/ColorStateList;)V

    .line 1061
    const/4 v8, 0x1

    invoke-static {v7, v8}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v4

    invoke-virtual {v1, v4}, Lcom/google/android/material/button/MaterialButton;->setStrokeWidth(I)V

    .line 1062
    const/16 v8, 0xc

    invoke-static {v7, v8}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v4

    invoke-virtual {v1, v4}, Lcom/google/android/material/button/MaterialButton;->setCornerRadius(I)V

    .line 1063
    const/4 v12, 0x0

    invoke-virtual {v1, v12}, Lcom/google/android/material/button/MaterialButton;->setAllCaps(Z)V

    .line 1064
    new-instance v4, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda8;

    invoke-direct {v4, v9, v1, v3}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda8;-><init>(Landroid/widget/LinearLayout;Lcom/google/android/material/button/MaterialButton;Ldev/wiojelt/turksinema/common/WioSettingsConfig;)V

    invoke-virtual {v1, v4}, Lcom/google/android/material/button/MaterialButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1073
    nop

    .line 1054
    .end local v1  # "$this$show_u24lambda_u2456":Lcom/google/android/material/button/MaterialButton;
    .end local v2  # "$i$a$-apply-WioCoreSettingsDialog$show$providerToggle$1":I
    nop

    .line 1074
    .local v0, "providerToggle":Lcom/google/android/material/button/MaterialButton;
    move-object v1, v0

    check-cast v1, Landroid/view/View;

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v12, 0x2c

    invoke-static {v7, v12}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v4

    const/4 v12, -0x1

    invoke-direct {v2, v12, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object v4, v2

    .local v4, "$this$show_u24lambda_u2457":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v5, 0x0

    .line 1075
    .local v5, "$i$a$-apply-WioCoreSettingsDialog$show$15":I
    const/16 v12, 0x8

    invoke-static {v7, v12}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v6

    iput v6, v4, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 1076
    nop

    .end local v4  # "$this$show_u24lambda_u2457":Landroid/widget/LinearLayout$LayoutParams;
    .end local v5  # "$i$a$-apply-WioCoreSettingsDialog$show$15":I
    sget-object v4, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 1074
    check-cast v2, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v15, v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1078
    .end local v0  # "providerToggle":Lcom/google/android/material/button/MaterialButton;
    :cond_10c9
    move-object v0, v9

    check-cast v0, Landroid/view/View;

    invoke-virtual {v15, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1080
    invoke-virtual {v3}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getOnAutoScanDomains()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    if-eqz v0, :cond_11d0

    .line 1081
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, v7}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v1, v0

    .local v1, "$this$show_u24lambda_u2458":Landroid/widget/LinearLayout;
    const/4 v2, 0x0

    .line 1082
    .local v2, "$i$a$-apply-WioCoreSettingsDialog$show$scanSection$1":I
    const/4 v8, 0x1

    invoke-virtual {v1, v8}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 1083
    const/4 v12, 0x6

    invoke-static {v7, v12}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v4

    invoke-static {v7, v12}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v5

    const/4 v12, 0x0

    invoke-virtual {v1, v12, v4, v12, v5}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 1084
    nop

    .line 1081
    .end local v1  # "$this$show_u24lambda_u2458":Landroid/widget/LinearLayout;
    .end local v2  # "$i$a$-apply-WioCoreSettingsDialog$show$scanSection$1":I
    move-object v8, v0

    .line 1086
    .local v8, "scanSection":Landroid/widget/LinearLayout;
    new-instance v0, Landroid/widget/TextView;

    invoke-direct {v0, v7}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v1, v0

    .local v1, "$this$show_u24lambda_u2459":Landroid/widget/TextView;
    const/4 v2, 0x0

    .line 1087
    .local v2, "$i$a$-apply-WioCoreSettingsDialog$show$scanStatus$1":I
    const/high16 v4, 0x41380000  # 11.5f

    invoke-virtual {v1, v4}, Landroid/widget/TextView;->setTextSize(F)V

    .line 1088
    invoke-virtual {v3}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getTextSecondary()I

    move-result v4

    invoke-virtual {v1, v4}, Landroid/widget/TextView;->setTextColor(I)V

    .line 1089
    const-string v4, "Alan adlarını test edip en güncel adreslere geçmek için tarayın."

    check-cast v4, Ljava/lang/CharSequence;

    invoke-virtual {v1, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1090
    const/4 v12, 0x6

    invoke-static {v7, v12}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v4

    const/4 v12, 0x0

    invoke-virtual {v1, v12, v12, v12, v4}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 1091
    nop

    .line 1086
    .end local v1  # "$this$show_u24lambda_u2459":Landroid/widget/TextView;
    .end local v2  # "$i$a$-apply-WioCoreSettingsDialog$show$scanStatus$1":I
    nop

    .line 1092
    .local v0, "scanStatus":Landroid/widget/TextView;
    move-object v1, v0

    check-cast v1, Landroid/view/View;

    invoke-virtual {v8, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1094
    new-instance v2, Landroid/widget/ProgressBar;

    invoke-direct {v2, v7}, Landroid/widget/ProgressBar;-><init>(Landroid/content/Context;)V

    move-object v1, v2

    .local v1, "$this$show_u24lambda_u2460":Landroid/widget/ProgressBar;
    const/4 v4, 0x0

    .line 1095
    .local v4, "$i$a$-apply-WioCoreSettingsDialog$show$scanProgress$1":I
    const/4 v12, 0x1

    invoke-virtual {v1, v12}, Landroid/widget/ProgressBar;->setIndeterminate(Z)V

    .line 1096
    const/16 v5, 0x8

    invoke-virtual {v1, v5}, Landroid/widget/ProgressBar;->setVisibility(I)V

    .line 1097
    nop

    .line 1094
    .end local v1  # "$this$show_u24lambda_u2460":Landroid/widget/ProgressBar;
    .end local v4  # "$i$a$-apply-WioCoreSettingsDialog$show$scanProgress$1":I
    nop

    .line 1098
    .local v2, "scanProgress":Landroid/widget/ProgressBar;
    move-object v1, v2

    check-cast v1, Landroid/view/View;

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v5, 0x4

    invoke-static {v7, v5}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v5

    const/4 v12, -0x1

    invoke-direct {v4, v12, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object v5, v4

    .local v5, "$this$show_u24lambda_u2461":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v6, 0x0

    .line 1099
    .local v6, "$i$a$-apply-WioCoreSettingsDialog$show$16":I
    const/4 v12, 0x6

    invoke-static {v7, v12}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v12

    iput v12, v5, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 1100
    nop

    .end local v5  # "$this$show_u24lambda_u2461":Landroid/widget/LinearLayout$LayoutParams;
    .end local v6  # "$i$a$-apply-WioCoreSettingsDialog$show$16":I
    sget-object v5, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 1098
    check-cast v4, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v8, v1, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1102
    new-instance v1, Lcom/google/android/material/button/MaterialButton;

    invoke-direct {v1, v7}, Lcom/google/android/material/button/MaterialButton;-><init>(Landroid/content/Context;)V

    move-object v4, v1

    .local v4, "$this$show_u24lambda_u2462":Lcom/google/android/material/button/MaterialButton;
    const/4 v5, 0x0

    .line 1103
    .local v5, "$i$a$-apply-WioCoreSettingsDialog$show$scanBtn$1":I
    const-string v6, "⚡ Otomatik Tara ve Güncelle"

    check-cast v6, Ljava/lang/CharSequence;

    invoke-virtual {v4, v6}, Lcom/google/android/material/button/MaterialButton;->setText(Ljava/lang/CharSequence;)V

    .line 1104
    const/high16 v6, 0x41480000  # 12.5f

    invoke-virtual {v4, v6}, Lcom/google/android/material/button/MaterialButton;->setTextSize(F)V

    .line 1105
    const/4 v12, -0x1

    invoke-virtual {v4, v12}, Lcom/google/android/material/button/MaterialButton;->setTextColor(I)V

    .line 1106
    invoke-static/range {v55 .. v55}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v6

    invoke-static {v6}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v6

    invoke-virtual {v4, v6}, Lcom/google/android/material/button/MaterialButton;->setBackgroundTintList(Landroid/content/res/ColorStateList;)V

    .line 1107
    const-string v6, "#33FFFFFF"

    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v6

    invoke-static {v6}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v6

    invoke-virtual {v4, v6}, Lcom/google/android/material/button/MaterialButton;->setStrokeColor(Landroid/content/res/ColorStateList;)V

    .line 1108
    const/4 v12, 0x1

    invoke-static {v7, v12}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v6

    invoke-virtual {v4, v6}, Lcom/google/android/material/button/MaterialButton;->setStrokeWidth(I)V

    .line 1109
    const/16 v12, 0x64

    invoke-static {v7, v12}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v6

    invoke-virtual {v4, v6}, Lcom/google/android/material/button/MaterialButton;->setCornerRadius(I)V

    .line 1110
    const/4 v12, 0x0

    invoke-virtual {v4, v12}, Lcom/google/android/material/button/MaterialButton;->setAllCaps(Z)V

    .line 1111
    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v12, 0x2a

    invoke-static {v7, v12}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v13

    const/4 v12, -0x1

    invoke-direct {v6, v12, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object v12, v6

    .local v12, "$this$show_u24lambda_u2462_u240":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v13, 0x0

    .line 1112
    .local v13, "$i$a$-apply-WioCoreSettingsDialog$show$scanBtn$1$lp$1":I
    move-object/from16 v16, v0

    const/16 v0, 0xa

    .end local v0  # "scanStatus":Landroid/widget/TextView;
    .local v16, "scanStatus":Landroid/widget/TextView;
    invoke-static {v7, v0}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v0

    iput v0, v12, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 1113
    nop

    .line 1111
    .end local v12  # "$this$show_u24lambda_u2462_u240":Landroid/widget/LinearLayout$LayoutParams;
    .end local v13  # "$i$a$-apply-WioCoreSettingsDialog$show$scanBtn$1$lp$1":I
    nop

    .line 1114
    .local v6, "lp":Landroid/widget/LinearLayout$LayoutParams;
    move-object v0, v6

    check-cast v0, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v4, v0}, Lcom/google/android/material/button/MaterialButton;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1115
    nop

    .line 1102
    .end local v4  # "$this$show_u24lambda_u2462":Lcom/google/android/material/button/MaterialButton;
    .end local v5  # "$i$a$-apply-WioCoreSettingsDialog$show$scanBtn$1":I
    .end local v6  # "lp":Landroid/widget/LinearLayout$LayoutParams;
    nop

    .line 1117
    .local v1, "scanBtn":Lcom/google/android/material/button/MaterialButton;
    new-instance v0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda9;

    move-object v6, v3

    move-object v5, v7

    move-object/from16 v3, v16

    move-object/from16 v4, v27

    .end local v16  # "scanStatus":Landroid/widget/TextView;
    .end local v27  # "scope":Lkotlinx/coroutines/CoroutineScope;
    .local v3, "scanStatus":Landroid/widget/TextView;
    .local v4, "scope":Lkotlinx/coroutines/CoroutineScope;
    invoke-direct/range {v0 .. v6}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda9;-><init>(Lcom/google/android/material/button/MaterialButton;Landroid/widget/ProgressBar;Landroid/widget/TextView;Lkotlinx/coroutines/CoroutineScope;Landroid/content/Context;Ldev/wiojelt/turksinema/common/WioSettingsConfig;)V

    move-object v3, v1

    move-object v1, v5

    move-object v5, v0

    move-object v0, v6

    .end local v1  # "scanBtn":Lcom/google/android/material/button/MaterialButton;
    .local v3, "scanBtn":Lcom/google/android/material/button/MaterialButton;
    .restart local v16  # "scanStatus":Landroid/widget/TextView;
    invoke-virtual {v3, v5}, Lcom/google/android/material/button/MaterialButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1136
    move-object v5, v3

    check-cast v5, Landroid/view/View;

    invoke-virtual {v8, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1137
    move-object v5, v8

    check-cast v5, Landroid/view/View;

    invoke-virtual {v15, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    goto :goto_11d4

    .line 1080
    .end local v2  # "scanProgress":Landroid/widget/ProgressBar;
    .end local v3  # "scanBtn":Lcom/google/android/material/button/MaterialButton;
    .end local v4  # "scope":Lkotlinx/coroutines/CoroutineScope;
    .end local v8  # "scanSection":Landroid/widget/LinearLayout;
    .end local v16  # "scanStatus":Landroid/widget/TextView;
    .restart local v27  # "scope":Lkotlinx/coroutines/CoroutineScope;
    :cond_11d0
    move-object v0, v3

    move-object v1, v7

    move-object/from16 v4, v27

    .line 1141
    .end local v27  # "scope":Lkotlinx/coroutines/CoroutineScope;
    .restart local v4  # "scope":Lkotlinx/coroutines/CoroutineScope;
    :goto_11d4
    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getTelegramUrl()Ljava/lang/String;

    move-result-object v2

    if-nez v2, :cond_11e0

    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getCoffeeUrl()Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_12c5

    .line 1142
    :cond_11e0
    new-instance v2, Landroid/widget/LinearLayout;

    invoke-direct {v2, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v3, v2

    .local v3, "$this$show_u24lambda_u2464":Landroid/widget/LinearLayout;
    const/4 v5, 0x0

    .line 1143
    .local v5, "$i$a$-apply-WioCoreSettingsDialog$show$linkRow$1":I
    const/4 v12, 0x0

    invoke-virtual {v3, v12}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 1144
    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v8, -0x2

    const/4 v12, -0x1

    invoke-direct {v6, v12, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 1145
    .restart local v6  # "lp":Landroid/widget/LinearLayout$LayoutParams;
    move-object v7, v6

    check-cast v7, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v3, v7}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1146
    nop

    .line 1142
    .end local v3  # "$this$show_u24lambda_u2464":Landroid/widget/LinearLayout;
    .end local v5  # "$i$a$-apply-WioCoreSettingsDialog$show$linkRow$1":I
    .end local v6  # "lp":Landroid/widget/LinearLayout$LayoutParams;
    nop

    .line 1148
    .local v2, "linkRow":Landroid/widget/LinearLayout;
    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getTelegramUrl()Ljava/lang/String;

    move-result-object v3

    if-eqz v3, :cond_1262

    .local v3, "tg":Ljava/lang/String;
    const/4 v5, 0x0

    .line 1149
    .local v5, "$i$a$-let-WioCoreSettingsDialog$show$18":I
    new-instance v6, Lcom/google/android/material/button/MaterialButton;

    invoke-direct {v6, v1}, Lcom/google/android/material/button/MaterialButton;-><init>(Landroid/content/Context;)V

    move-object v7, v6

    .local v7, "$this$show_u24lambda_u2465_u240":Lcom/google/android/material/button/MaterialButton;
    const/4 v8, 0x0

    .line 1150
    .local v8, "$i$a$-apply-WioCoreSettingsDialog$show$18$tgBtn$1":I
    const-string v12, "Telegram ↗"

    check-cast v12, Ljava/lang/CharSequence;

    invoke-virtual {v7, v12}, Lcom/google/android/material/button/MaterialButton;->setText(Ljava/lang/CharSequence;)V

    .line 1151
    const/4 v12, -0x1

    invoke-virtual {v7, v12}, Lcom/google/android/material/button/MaterialButton;->setTextColor(I)V

    .line 1152
    const-string v12, "#2AABEE"

    invoke-static {v12}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v12

    invoke-virtual {v7, v12}, Lcom/google/android/material/button/MaterialButton;->setBackgroundColor(I)V

    .line 1153
    const/16 v12, 0x64

    invoke-static {v1, v12}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v13

    invoke-virtual {v7, v13}, Lcom/google/android/material/button/MaterialButton;->setCornerRadius(I)V

    .line 1154
    new-instance v12, Landroid/widget/LinearLayout$LayoutParams;

    move/from16 v16, v5

    const/16 v13, 0x2a

    .end local v5  # "$i$a$-let-WioCoreSettingsDialog$show$18":I
    .local v16, "$i$a$-let-WioCoreSettingsDialog$show$18":I
    invoke-static {v1, v13}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v5

    move-object/from16 v19, v6

    const/4 v6, 0x0

    const/high16 v13, 0x3f800000  # 1.0f

    invoke-direct {v12, v6, v5, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    move-object v5, v12

    .line 1215
    .local v5, "$this$show_u24lambda_u2465_u240_u240":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v6, 0x0

    .line 1154
    .local v6, "$i$a$-apply-WioCoreSettingsDialog$show$18$tgBtn$1$lp$1":I
    const/16 v13, 0x8

    invoke-static {v1, v13}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v13

    invoke-virtual {v5, v13}, Landroid/widget/LinearLayout$LayoutParams;->setMarginEnd(I)V

    .line 1155
    .end local v5  # "$this$show_u24lambda_u2465_u240_u240":Landroid/widget/LinearLayout$LayoutParams;
    .end local v6  # "$i$a$-apply-WioCoreSettingsDialog$show$18$tgBtn$1$lp$1":I
    .local v12, "lp":Landroid/widget/LinearLayout$LayoutParams;
    move-object v5, v12

    check-cast v5, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v7, v5}, Lcom/google/android/material/button/MaterialButton;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1156
    const/4 v6, 0x0

    invoke-virtual {v7, v6}, Lcom/google/android/material/button/MaterialButton;->setAllCaps(Z)V

    .line 1157
    new-instance v5, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda10;

    invoke-direct {v5, v7, v1, v3}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda10;-><init>(Lcom/google/android/material/button/MaterialButton;Landroid/content/Context;Ljava/lang/String;)V

    invoke-virtual {v7, v5}, Lcom/google/android/material/button/MaterialButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1162
    nop

    .line 1149
    .end local v7  # "$this$show_u24lambda_u2465_u240":Lcom/google/android/material/button/MaterialButton;
    .end local v8  # "$i$a$-apply-WioCoreSettingsDialog$show$18$tgBtn$1":I
    .end local v12  # "lp":Landroid/widget/LinearLayout$LayoutParams;
    nop

    .line 1163
    .local v19, "tgBtn":Lcom/google/android/material/button/MaterialButton;
    move-object/from16 v5, v19

    check-cast v5, Landroid/view/View;

    invoke-virtual {v2, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1164
    nop

    .end local v3  # "tg":Ljava/lang/String;
    .end local v16  # "$i$a$-let-WioCoreSettingsDialog$show$18":I
    .end local v19  # "tgBtn":Lcom/google/android/material/button/MaterialButton;
    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 1148
    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 1166
    :cond_1262
    invoke-virtual {v0}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->getCoffeeUrl()Ljava/lang/String;

    move-result-object v3

    if-eqz v3, :cond_12bf

    .local v3, "cf":Ljava/lang/String;
    const/4 v5, 0x0

    .line 1167
    .local v5, "$i$a$-let-WioCoreSettingsDialog$show$19":I
    new-instance v6, Lcom/google/android/material/button/MaterialButton;

    invoke-direct {v6, v1}, Lcom/google/android/material/button/MaterialButton;-><init>(Landroid/content/Context;)V

    move-object v7, v6

    .local v7, "$this$show_u24lambda_u2466_u240":Lcom/google/android/material/button/MaterialButton;
    const/4 v8, 0x0

    .line 1168
    .local v8, "$i$a$-apply-WioCoreSettingsDialog$show$19$coffeeBtn$1":I
    const-string v12, "Destek ol ☕"

    check-cast v12, Ljava/lang/CharSequence;

    invoke-virtual {v7, v12}, Lcom/google/android/material/button/MaterialButton;->setText(Ljava/lang/CharSequence;)V

    .line 1169
    const/high16 v12, -0x1000000

    invoke-virtual {v7, v12}, Lcom/google/android/material/button/MaterialButton;->setTextColor(I)V

    .line 1170
    const-string v12, "#FFDD00"

    invoke-static {v12}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v12

    invoke-virtual {v7, v12}, Lcom/google/android/material/button/MaterialButton;->setBackgroundColor(I)V

    .line 1171
    const/16 v12, 0x64

    invoke-static {v1, v12}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v12

    invoke-virtual {v7, v12}, Lcom/google/android/material/button/MaterialButton;->setCornerRadius(I)V

    .line 1172
    new-instance v12, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v13, 0x2a

    invoke-static {v1, v13}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$dp(Landroid/content/Context;I)I

    move-result v13

    move/from16 v16, v5

    move-object/from16 v18, v6

    const/high16 v5, 0x3f800000  # 1.0f

    const/4 v6, 0x0

    .end local v5  # "$i$a$-let-WioCoreSettingsDialog$show$19":I
    .local v16, "$i$a$-let-WioCoreSettingsDialog$show$19":I
    invoke-direct {v12, v6, v13, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    .line 1173
    .restart local v12  # "lp":Landroid/widget/LinearLayout$LayoutParams;
    move-object v5, v12

    check-cast v5, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v7, v5}, Lcom/google/android/material/button/MaterialButton;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1174
    invoke-virtual {v7, v6}, Lcom/google/android/material/button/MaterialButton;->setAllCaps(Z)V

    .line 1175
    new-instance v5, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda12;

    invoke-direct {v5, v7, v1, v3}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda12;-><init>(Lcom/google/android/material/button/MaterialButton;Landroid/content/Context;Ljava/lang/String;)V

    invoke-virtual {v7, v5}, Lcom/google/android/material/button/MaterialButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1180
    nop

    .line 1167
    .end local v7  # "$this$show_u24lambda_u2466_u240":Lcom/google/android/material/button/MaterialButton;
    .end local v8  # "$i$a$-apply-WioCoreSettingsDialog$show$19$coffeeBtn$1":I
    .end local v12  # "lp":Landroid/widget/LinearLayout$LayoutParams;
    nop

    .line 1181
    .local v18, "coffeeBtn":Lcom/google/android/material/button/MaterialButton;
    move-object/from16 v5, v18

    check-cast v5, Landroid/view/View;

    invoke-virtual {v2, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1182
    nop

    .end local v3  # "cf":Ljava/lang/String;
    .end local v16  # "$i$a$-let-WioCoreSettingsDialog$show$19":I
    .end local v18  # "coffeeBtn":Lcom/google/android/material/button/MaterialButton;
    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 1166
    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 1184
    :cond_12bf
    move-object v3, v2

    check-cast v3, Landroid/view/View;

    invoke-virtual {v15, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1187
    .end local v2  # "linkRow":Landroid/widget/LinearLayout;
    :cond_12c5
    new-instance v2, Landroidx/core/widget/NestedScrollView;

    invoke-direct {v2, v1}, Landroidx/core/widget/NestedScrollView;-><init>(Landroid/content/Context;)V

    move-object v3, v2

    .local v3, "$this$show_u24lambda_u2467":Landroidx/core/widget/NestedScrollView;
    const/4 v5, 0x0

    .line 1188
    .local v5, "$i$a$-apply-WioCoreSettingsDialog$show$scroll$1":I
    move-object v6, v15

    check-cast v6, Landroid/view/View;

    invoke-virtual {v3, v6}, Landroidx/core/widget/NestedScrollView;->addView(Landroid/view/View;)V

    .line 1189
    const/4 v12, 0x0

    invoke-virtual {v3, v12}, Landroidx/core/widget/NestedScrollView;->setVerticalScrollBarEnabled(Z)V

    .line 1190
    nop

    .line 1187
    .end local v3  # "$this$show_u24lambda_u2467":Landroidx/core/widget/NestedScrollView;
    .end local v5  # "$i$a$-apply-WioCoreSettingsDialog$show$scroll$1":I
    nop

    .line 1192
    .local v2, "scroll":Landroidx/core/widget/NestedScrollView;
    move-object v3, v2

    check-cast v3, Landroid/view/View;

    invoke-virtual {v11, v3}, Landroid/app/Dialog;->setContentView(Landroid/view/View;)V

    .line 1193
    new-instance v3, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda13;

    invoke-direct {v3, v4}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda13;-><init>(Lkotlinx/coroutines/CoroutineScope;)V

    invoke-virtual {v11, v3}, Landroid/app/Dialog;->setOnDismissListener(Landroid/content/DialogInterface$OnDismissListener;)V

    .line 1194
    new-instance v3, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda14;

    invoke-direct {v3, v1, v11, v0, v14}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda14;-><init>(Landroid/content/Context;Landroid/app/Dialog;Ldev/wiojelt/turksinema/common/WioSettingsConfig;Ljava/util/Map;)V

    invoke-virtual {v11, v3}, Landroid/app/Dialog;->setOnShowListener(Landroid/content/DialogInterface$OnShowListener;)V

    .line 1202
    invoke-virtual {v11}, Landroid/app/Dialog;->show()V

    .line 1203
    return-void
.end method

.method public final showEditDomainDialog(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;ZIILkotlin/jvm/functions/Function1;)V
    .registers 32
    .param p1, "context"  # Landroid/content/Context;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p2, "providerName"  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p3, "currentUrl"  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p4, "englishLabels"  # Z
    .param p5, "brandColor"  # I
    .param p6, "brandColorBorder"  # I
    .param p7, "onSave"  # Lkotlin/jvm/functions/Function1;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "ZII",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 153
    move-object/from16 v2, p1

    move-object/from16 v6, p2

    move/from16 v3, p4

    new-instance v7, Landroid/app/Dialog;

    invoke-direct {v7, v2}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    move-object v0, v7

    .local v0, "$this$showEditDomainDialog_u24lambda_u240":Landroid/app/Dialog;
    const/4 v1, 0x0

    .line 154
    .local v1, "$i$a$-apply-WioCoreSettingsDialog$showEditDomainDialog$editDialog$1":I
    const/4 v4, 0x1

    invoke-virtual {v0, v4}, Landroid/app/Dialog;->requestWindowFeature(I)Z

    .line 155
    invoke-virtual {v0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v5

    const/4 v8, 0x0

    if-eqz v5, :cond_22

    new-instance v9, Landroid/graphics/drawable/ColorDrawable;

    invoke-direct {v9, v8}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    check-cast v9, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v5, v9}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 156
    :cond_22
    nop

    .line 153
    .end local v0  # "$this$showEditDomainDialog_u24lambda_u240":Landroid/app/Dialog;
    .end local v1  # "$i$a$-apply-WioCoreSettingsDialog$showEditDomainDialog$editDialog$1":I
    nop

    .line 158
    .local v7, "editDialog":Landroid/app/Dialog;
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, v2}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v1, v0

    .local v1, "$this$showEditDomainDialog_u24lambda_u241":Landroid/widget/LinearLayout;
    const/4 v5, 0x0

    .line 159
    .local v5, "$i$a$-apply-WioCoreSettingsDialog$showEditDomainDialog$container$1":I
    invoke-virtual {v1, v4}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 160
    const/16 v9, 0x16

    invoke-static {v2, v9}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog$dp(Landroid/content/Context;I)I

    move-result v10

    const/16 v11, 0x14

    invoke-static {v2, v11}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog$dp(Landroid/content/Context;I)I

    move-result v12

    invoke-static {v2, v9}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog$dp(Landroid/content/Context;I)I

    move-result v9

    invoke-static {v2, v11}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog$dp(Landroid/content/Context;I)I

    move-result v13

    invoke-virtual {v1, v10, v12, v9, v13}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 161
    new-instance v9, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v9}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object v10, v9

    .local v10, "$this$showEditDomainDialog_u24lambda_u241_u240":Landroid/graphics/drawable/GradientDrawable;
    const/4 v12, 0x0

    .line 162
    .local v12, "$i$a$-apply-WioCoreSettingsDialog$showEditDomainDialog$container$1$1":I
    invoke-virtual {v10, v8}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    .line 163
    const/16 v13, 0x1c

    invoke-static {v2, v13}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog$dp(Landroid/content/Context;I)I

    move-result v13

    int-to-float v13, v13

    invoke-virtual {v10, v13}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 164
    const-string v13, "#F20D0E12"

    invoke-static {v13}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v13

    invoke-virtual {v10, v13}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 165
    invoke-static {v2, v4}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog$dp(Landroid/content/Context;I)I

    move-result v13

    const-string v14, "#33FFFFFF"

    invoke-static {v14}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v14

    invoke-virtual {v10, v13, v14}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 166
    nop

    .line 161
    .end local v10  # "$this$showEditDomainDialog_u24lambda_u241_u240":Landroid/graphics/drawable/GradientDrawable;
    .end local v12  # "$i$a$-apply-WioCoreSettingsDialog$showEditDomainDialog$container$1$1":I
    check-cast v9, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v1, v9}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 167
    nop

    .line 158
    .end local v1  # "$this$showEditDomainDialog_u24lambda_u241":Landroid/widget/LinearLayout;
    .end local v5  # "$i$a$-apply-WioCoreSettingsDialog$showEditDomainDialog$container$1":I
    move-object v9, v0

    .line 169
    .local v9, "container":Landroid/widget/LinearLayout;
    new-instance v0, Landroid/widget/TextView;

    invoke-direct {v0, v2}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v1, v0

    .local v1, "$this$showEditDomainDialog_u24lambda_u242":Landroid/widget/TextView;
    const/4 v5, 0x0

    .line 170
    .local v5, "$i$a$-apply-WioCoreSettingsDialog$showEditDomainDialog$headerTag$1":I
    if-eqz v3, :cond_83

    const-string v10, "● UPDATE DOMAIN"

    goto :goto_85

    :cond_83
    const-string v10, "● ALAN ADI GÜNCELLEME"

    :goto_85
    check-cast v10, Ljava/lang/CharSequence;

    invoke-virtual {v1, v10}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 171
    const/high16 v10, 0x41200000  # 10.0f

    invoke-virtual {v1, v10}, Landroid/widget/TextView;->setTextSize(F)V

    .line 172
    sget-object v10, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v1, v10}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 173
    const-string v10, "#D71921"

    invoke-static {v10}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v10

    invoke-virtual {v1, v10}, Landroid/widget/TextView;->setTextColor(I)V

    .line 174
    const/16 v10, 0xa

    invoke-static {v2, v10}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog$dp(Landroid/content/Context;I)I

    move-result v12

    const/4 v13, 0x4

    invoke-static {v2, v13}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog$dp(Landroid/content/Context;I)I

    move-result v14

    invoke-static {v2, v10}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog$dp(Landroid/content/Context;I)I

    move-result v15

    invoke-static {v2, v13}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog$dp(Landroid/content/Context;I)I

    move-result v11

    invoke-virtual {v1, v12, v14, v15, v11}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 175
    new-instance v11, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v11}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object v12, v11

    .local v12, "$this$showEditDomainDialog_u24lambda_u242_u240":Landroid/graphics/drawable/GradientDrawable;
    const/4 v14, 0x0

    .line 176
    .local v14, "$i$a$-apply-WioCoreSettingsDialog$showEditDomainDialog$headerTag$1$1":I
    invoke-virtual {v12, v8}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    .line 177
    const/16 v15, 0x64

    invoke-static {v2, v15}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog$dp(Landroid/content/Context;I)I

    move-result v13

    int-to-float v13, v13

    invoke-virtual {v12, v13}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 178
    const-string v13, "#26D71921"

    invoke-static {v13}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v13

    invoke-virtual {v12, v13}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 179
    invoke-static {v2, v4}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog$dp(Landroid/content/Context;I)I

    move-result v13

    const-string v17, "#40D71921"

    invoke-static/range {v17 .. v17}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v15

    invoke-virtual {v12, v13, v15}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 180
    nop

    .line 175
    .end local v12  # "$this$showEditDomainDialog_u24lambda_u242_u240":Landroid/graphics/drawable/GradientDrawable;
    .end local v14  # "$i$a$-apply-WioCoreSettingsDialog$showEditDomainDialog$headerTag$1$1":I
    check-cast v11, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v1, v11}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 181
    nop

    .line 169
    .end local v1  # "$this$showEditDomainDialog_u24lambda_u242":Landroid/widget/TextView;
    .end local v5  # "$i$a$-apply-WioCoreSettingsDialog$showEditDomainDialog$headerTag$1":I
    move-object v11, v0

    .line 182
    .local v11, "headerTag":Landroid/widget/TextView;
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, v2}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v1, v0

    .local v1, "$this$showEditDomainDialog_u24lambda_u243":Landroid/widget/LinearLayout;
    const/4 v5, 0x0

    .line 183
    .local v5, "$i$a$-apply-WioCoreSettingsDialog$showEditDomainDialog$headerTagWrapper$1":I
    invoke-virtual {v1, v8}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 184
    move-object v12, v11

    check-cast v12, Landroid/view/View;

    invoke-virtual {v1, v12}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 185
    nop

    .line 182
    .end local v1  # "$this$showEditDomainDialog_u24lambda_u243":Landroid/widget/LinearLayout;
    .end local v5  # "$i$a$-apply-WioCoreSettingsDialog$showEditDomainDialog$headerTagWrapper$1":I
    move-object v12, v0

    .line 186
    .local v12, "headerTagWrapper":Landroid/widget/LinearLayout;
    move-object v0, v12

    check-cast v0, Landroid/view/View;

    invoke-virtual {v9, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 188
    new-instance v0, Landroid/widget/TextView;

    invoke-direct {v0, v2}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v1, v0

    .local v1, "$this$showEditDomainDialog_u24lambda_u244":Landroid/widget/TextView;
    const/4 v5, 0x0

    .line 189
    .local v5, "$i$a$-apply-WioCoreSettingsDialog$showEditDomainDialog$titleView$1":I
    new-instance v13, Ljava/lang/StringBuilder;

    if-eqz v3, :cond_112

    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v13, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v13

    const-string v14, " Domain"

    goto :goto_11b

    :cond_112
    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v13, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v13

    const-string v14, " Alan Adı"

    :goto_11b
    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v13

    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v13

    check-cast v13, Ljava/lang/CharSequence;

    invoke-virtual {v1, v13}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 190
    const/high16 v13, 0x41900000  # 18.0f

    invoke-virtual {v1, v13}, Landroid/widget/TextView;->setTextSize(F)V

    .line 191
    sget-object v13, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v1, v13}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 192
    const/4 v13, -0x1

    invoke-virtual {v1, v13}, Landroid/widget/TextView;->setTextColor(I)V

    .line 193
    const/16 v14, 0x8

    invoke-static {v2, v14}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog$dp(Landroid/content/Context;I)I

    move-result v14

    const/4 v15, 0x2

    invoke-static {v2, v15}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog$dp(Landroid/content/Context;I)I

    move-result v15

    invoke-virtual {v1, v8, v14, v8, v15}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 194
    nop

    .line 188
    .end local v1  # "$this$showEditDomainDialog_u24lambda_u244":Landroid/widget/TextView;
    .end local v5  # "$i$a$-apply-WioCoreSettingsDialog$showEditDomainDialog$titleView$1":I
    move-object v14, v0

    .line 195
    .local v14, "titleView":Landroid/widget/TextView;
    move-object v0, v14

    check-cast v0, Landroid/view/View;

    invoke-virtual {v9, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 197
    new-instance v0, Landroid/widget/TextView;

    invoke-direct {v0, v2}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v1, v0

    .local v1, "$this$showEditDomainDialog_u24lambda_u245":Landroid/widget/TextView;
    const/4 v5, 0x0

    .line 198
    .local v5, "$i$a$-apply-WioCoreSettingsDialog$showEditDomainDialog$subtitleView$1":I
    if-eqz v3, :cond_158

    const-string v15, "Enter the new working domain:"

    goto :goto_15a

    :cond_158
    const-string v15, "Yeni çalışan alan adını girin:"

    :goto_15a
    check-cast v15, Ljava/lang/CharSequence;

    invoke-virtual {v1, v15}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 199
    const/high16 v15, 0x41400000  # 12.0f

    invoke-virtual {v1, v15}, Landroid/widget/TextView;->setTextSize(F)V

    .line 200
    const-string v15, "#8E95A5"

    invoke-static {v15}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v10

    invoke-virtual {v1, v10}, Landroid/widget/TextView;->setTextColor(I)V

    .line 201
    const/16 v10, 0xe

    invoke-static {v2, v10}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog$dp(Landroid/content/Context;I)I

    move-result v4

    invoke-virtual {v1, v8, v8, v8, v4}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 202
    nop

    .line 197
    .end local v1  # "$this$showEditDomainDialog_u24lambda_u245":Landroid/widget/TextView;
    .end local v5  # "$i$a$-apply-WioCoreSettingsDialog$showEditDomainDialog$subtitleView$1":I
    move-object/from16 v18, v0

    .line 203
    .local v18, "subtitleView":Landroid/widget/TextView;
    move-object/from16 v0, v18

    check-cast v0, Landroid/view/View;

    invoke-virtual {v9, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 205
    new-instance v1, Landroid/widget/EditText;

    invoke-direct {v1, v2}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    move-object v0, v1

    .local v0, "$this$showEditDomainDialog_u24lambda_u246":Landroid/widget/EditText;
    const/4 v4, 0x0

    .line 206
    .local v4, "$i$a$-apply-WioCoreSettingsDialog$showEditDomainDialog$input$1":I
    move-object/from16 v5, p3

    check-cast v5, Ljava/lang/CharSequence;

    invoke-virtual {v0, v5}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 207
    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v5

    invoke-interface {v5}, Landroid/text/Editable;->length()I

    move-result v5

    invoke-virtual {v0, v5}, Landroid/widget/EditText;->setSelection(I)V

    .line 208
    const/high16 v5, 0x41600000  # 14.0f

    invoke-virtual {v0, v5}, Landroid/widget/EditText;->setTextSize(F)V

    .line 209
    invoke-virtual {v0, v13}, Landroid/widget/EditText;->setTextColor(I)V

    .line 210
    const-string v5, "#6E7681"

    invoke-static {v5}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {v0, v5}, Landroid/widget/EditText;->setHintTextColor(I)V

    .line 211
    if-eqz v3, :cond_1af

    const-string v5, "https://example.com"

    goto :goto_1b1

    :cond_1af
    const-string v5, "https://ornekadres.com"

    :goto_1b1
    check-cast v5, Ljava/lang/CharSequence;

    invoke-virtual {v0, v5}, Landroid/widget/EditText;->setHint(Ljava/lang/CharSequence;)V

    .line 212
    invoke-static {v2, v10}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog$dp(Landroid/content/Context;I)I

    move-result v5

    const/16 v13, 0xc

    invoke-static {v2, v13}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog$dp(Landroid/content/Context;I)I

    move-result v8

    move-object/from16 v20, v1

    invoke-static {v2, v10}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog$dp(Landroid/content/Context;I)I

    move-result v1

    invoke-static {v2, v13}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog$dp(Landroid/content/Context;I)I

    move-result v10

    invoke-virtual {v0, v5, v8, v1, v10}, Landroid/widget/EditText;->setPadding(IIII)V

    .line 213
    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setSingleLine(Z)V

    .line 214
    new-instance v1, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v1}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object v5, v1

    .local v5, "$this$showEditDomainDialog_u24lambda_u246_u240":Landroid/graphics/drawable/GradientDrawable;
    const/4 v8, 0x0

    .line 215
    .local v8, "$i$a$-apply-WioCoreSettingsDialog$showEditDomainDialog$input$1$1":I
    const/4 v10, 0x0

    invoke-virtual {v5, v10}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    .line 216
    const/16 v10, 0xe

    invoke-static {v2, v10}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog$dp(Landroid/content/Context;I)I

    move-result v10

    int-to-float v10, v10

    invoke-virtual {v5, v10}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 217
    const-string v10, "#E6161820"

    invoke-static {v10}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v10

    invoke-virtual {v5, v10}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 218
    const/4 v10, 0x1

    invoke-static {v2, v10}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog$dp(Landroid/content/Context;I)I

    move-result v13

    const-string v10, "#26FFFFFF"

    move-object/from16 v22, v1

    invoke-static {v10}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v5, v13, v1}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 219
    nop

    .line 214
    .end local v5  # "$this$showEditDomainDialog_u24lambda_u246_u240":Landroid/graphics/drawable/GradientDrawable;
    .end local v8  # "$i$a$-apply-WioCoreSettingsDialog$showEditDomainDialog$input$1$1":I
    move-object/from16 v1, v22

    check-cast v1, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 220
    nop

    .line 205
    .end local v0  # "$this$showEditDomainDialog_u24lambda_u246":Landroid/widget/EditText;
    .end local v4  # "$i$a$-apply-WioCoreSettingsDialog$showEditDomainDialog$input$1":I
    move-object/from16 v1, v20

    .line 221
    .local v1, "input":Landroid/widget/EditText;
    move-object v0, v1

    check-cast v0, Landroid/view/View;

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v8, -0x2

    const/4 v5, -0x1

    invoke-direct {v4, v5, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object v5, v4

    .local v5, "$this$showEditDomainDialog_u24lambda_u247":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v13, 0x0

    .line 222
    .local v13, "$i$a$-apply-WioCoreSettingsDialog$showEditDomainDialog$1":I
    move-object/from16 v22, v4

    const/16 v8, 0xa

    invoke-static {v2, v8}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog$dp(Landroid/content/Context;I)I

    move-result v4

    iput v4, v5, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 223
    nop

    .end local v5  # "$this$showEditDomainDialog_u24lambda_u247":Landroid/widget/LinearLayout$LayoutParams;
    .end local v13  # "$i$a$-apply-WioCoreSettingsDialog$showEditDomainDialog$1":I
    sget-object v4, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 221
    move-object/from16 v4, v22

    check-cast v4, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v9, v0, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 233
    new-instance v0, Lcom/google/android/material/button/MaterialButton;

    invoke-direct {v0, v2}, Lcom/google/android/material/button/MaterialButton;-><init>(Landroid/content/Context;)V

    move-object v4, v0

    .local v4, "$this$showEditDomainDialog_u24lambda_u248":Lcom/google/android/material/button/MaterialButton;
    const/4 v5, 0x0

    .line 234
    .local v5, "$i$a$-apply-WioCoreSettingsDialog$showEditDomainDialog$btnIncrement$1":I
    const/high16 v8, 0x41380000  # 11.5f

    invoke-virtual {v4, v8}, Lcom/google/android/material/button/MaterialButton;->setTextSize(F)V

    .line 235
    sget-object v8, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v4, v8}, Lcom/google/android/material/button/MaterialButton;->setTypeface(Landroid/graphics/Typeface;)V

    .line 236
    const-string v8, "#4ADE80"

    invoke-static {v8}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v8

    invoke-virtual {v4, v8}, Lcom/google/android/material/button/MaterialButton;->setTextColor(I)V

    .line 237
    const-string v8, "#142B1E"

    invoke-static {v8}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v8

    invoke-static {v8}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v8

    invoke-virtual {v4, v8}, Lcom/google/android/material/button/MaterialButton;->setBackgroundTintList(Landroid/content/res/ColorStateList;)V

    .line 238
    const-string v8, "#16A34A"

    invoke-static {v8}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v8

    invoke-static {v8}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v8

    invoke-virtual {v4, v8}, Lcom/google/android/material/button/MaterialButton;->setStrokeColor(Landroid/content/res/ColorStateList;)V

    .line 239
    const/4 v8, 0x1

    invoke-static {v2, v8}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog$dp(Landroid/content/Context;I)I

    move-result v13

    invoke-virtual {v4, v13}, Lcom/google/android/material/button/MaterialButton;->setStrokeWidth(I)V

    .line 240
    const/16 v8, 0x64

    invoke-static {v2, v8}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog$dp(Landroid/content/Context;I)I

    move-result v13

    invoke-virtual {v4, v13}, Lcom/google/android/material/button/MaterialButton;->setCornerRadius(I)V

    .line 241
    const/4 v8, 0x0

    invoke-virtual {v4, v8}, Lcom/google/android/material/button/MaterialButton;->setAllCaps(Z)V

    .line 242
    invoke-virtual {v4, v8}, Lcom/google/android/material/button/MaterialButton;->setInsetTop(I)V

    .line 243
    invoke-virtual {v4, v8}, Lcom/google/android/material/button/MaterialButton;->setInsetBottom(I)V

    .line 244
    const/16 v8, 0xc

    invoke-static {v2, v8}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog$dp(Landroid/content/Context;I)I

    move-result v13

    move-object/from16 v21, v0

    move/from16 v16, v5

    const/4 v0, 0x4

    .end local v5  # "$i$a$-apply-WioCoreSettingsDialog$showEditDomainDialog$btnIncrement$1":I
    .local v16, "$i$a$-apply-WioCoreSettingsDialog$showEditDomainDialog$btnIncrement$1":I
    invoke-static {v2, v0}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog$dp(Landroid/content/Context;I)I

    move-result v5

    invoke-static {v2, v8}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog$dp(Landroid/content/Context;I)I

    move-result v8

    invoke-static {v2, v0}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog$dp(Landroid/content/Context;I)I

    move-result v0

    invoke-virtual {v4, v13, v5, v8, v0}, Lcom/google/android/material/button/MaterialButton;->setPadding(IIII)V

    .line 245
    nop

    .line 233
    .end local v4  # "$this$showEditDomainDialog_u24lambda_u248":Lcom/google/android/material/button/MaterialButton;
    .end local v16  # "$i$a$-apply-WioCoreSettingsDialog$showEditDomainDialog$btnIncrement$1":I
    move-object/from16 v8, v21

    .line 262
    .local v8, "btnIncrement":Lcom/google/android/material/button/MaterialButton;
    invoke-static {v1, v8, v3}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog$updateIncrementBtn(Landroid/widget/EditText;Lcom/google/android/material/button/MaterialButton;Z)V

    .line 264
    new-instance v0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$showEditDomainDialog$2;

    invoke-direct {v0, v1, v8, v3}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$showEditDomainDialog$2;-><init>(Landroid/widget/EditText;Lcom/google/android/material/button/MaterialButton;Z)V

    check-cast v0, Landroid/text/TextWatcher;

    invoke-virtual {v1, v0}, Landroid/widget/EditText;->addTextChangedListener(Landroid/text/TextWatcher;)V

    .line 270
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, v2}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v4, v0

    .local v4, "$this$showEditDomainDialog_u24lambda_u2411":Landroid/widget/LinearLayout;
    const/4 v5, 0x0

    .line 271
    .local v5, "$i$a$-apply-WioCoreSettingsDialog$showEditDomainDialog$incrementRow$1":I
    const/4 v13, 0x0

    invoke-virtual {v4, v13}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 272
    move-object v13, v8

    check-cast v13, Landroid/view/View;

    invoke-virtual {v4, v13}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 273
    new-instance v13, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v16, v0

    move-object/from16 v21, v1

    const/4 v0, -0x2

    const/4 v1, -0x1

    .end local v1  # "input":Landroid/widget/EditText;
    .local v21, "input":Landroid/widget/EditText;
    invoke-direct {v13, v1, v0}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object v0, v13

    .local v0, "$this$showEditDomainDialog_u24lambda_u2411_u240":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v1, 0x0

    .line 274
    .local v1, "$i$a$-apply-WioCoreSettingsDialog$showEditDomainDialog$incrementRow$1$1":I
    move/from16 v22, v1

    .end local v1  # "$i$a$-apply-WioCoreSettingsDialog$showEditDomainDialog$incrementRow$1$1":I
    .local v22, "$i$a$-apply-WioCoreSettingsDialog$showEditDomainDialog$incrementRow$1$1":I
    const/16 v1, 0x10

    invoke-static {v2, v1}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog$dp(Landroid/content/Context;I)I

    move-result v3

    iput v3, v0, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 275
    nop

    .line 273
    .end local v0  # "$this$showEditDomainDialog_u24lambda_u2411_u240":Landroid/widget/LinearLayout$LayoutParams;
    .end local v22  # "$i$a$-apply-WioCoreSettingsDialog$showEditDomainDialog$incrementRow$1$1":I
    check-cast v13, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v4, v13}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 276
    nop

    .line 270
    .end local v4  # "$this$showEditDomainDialog_u24lambda_u2411":Landroid/widget/LinearLayout;
    .end local v5  # "$i$a$-apply-WioCoreSettingsDialog$showEditDomainDialog$incrementRow$1":I
    nop

    .line 277
    .local v16, "incrementRow":Landroid/widget/LinearLayout;
    move-object/from16 v0, v16

    check-cast v0, Landroid/view/View;

    invoke-virtual {v9, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 279
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, v2}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v3, v0

    .local v3, "$this$showEditDomainDialog_u24lambda_u2412":Landroid/widget/LinearLayout;
    const/4 v4, 0x0

    .line 280
    .local v4, "$i$a$-apply-WioCoreSettingsDialog$showEditDomainDialog$btnRow$1":I
    const/4 v13, 0x0

    invoke-virtual {v3, v13}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 281
    const v5, 0x800005

    invoke-virtual {v3, v5}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 282
    nop

    .line 279
    .end local v3  # "$this$showEditDomainDialog_u24lambda_u2412":Landroid/widget/LinearLayout;
    .end local v4  # "$i$a$-apply-WioCoreSettingsDialog$showEditDomainDialog$btnRow$1":I
    move-object v13, v0

    .line 284
    .local v13, "btnRow":Landroid/widget/LinearLayout;
    new-instance v0, Lcom/google/android/material/button/MaterialButton;

    invoke-direct {v0, v2}, Lcom/google/android/material/button/MaterialButton;-><init>(Landroid/content/Context;)V

    move-object v3, v0

    .local v3, "$this$showEditDomainDialog_u24lambda_u2413":Lcom/google/android/material/button/MaterialButton;
    const/4 v4, 0x0

    .line 285
    .local v4, "$i$a$-apply-WioCoreSettingsDialog$showEditDomainDialog$btnCancel$1":I
    if-eqz p4, :cond_2f9

    const-string v5, "Cancel"

    goto :goto_2fb

    :cond_2f9
    const-string v5, "İptal"

    :goto_2fb
    check-cast v5, Ljava/lang/CharSequence;

    invoke-virtual {v3, v5}, Lcom/google/android/material/button/MaterialButton;->setText(Ljava/lang/CharSequence;)V

    .line 286
    const/high16 v5, 0x41480000  # 12.5f

    invoke-virtual {v3, v5}, Lcom/google/android/material/button/MaterialButton;->setTextSize(F)V

    .line 287
    invoke-static {v15}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v15

    invoke-virtual {v3, v15}, Lcom/google/android/material/button/MaterialButton;->setTextColor(I)V

    .line 288
    const-string v15, "#161820"

    invoke-static {v15}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v15

    invoke-static {v15}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v15

    invoke-virtual {v3, v15}, Lcom/google/android/material/button/MaterialButton;->setBackgroundTintList(Landroid/content/res/ColorStateList;)V

    .line 289
    invoke-static {v10}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v10

    invoke-static {v10}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v10

    invoke-virtual {v3, v10}, Lcom/google/android/material/button/MaterialButton;->setStrokeColor(Landroid/content/res/ColorStateList;)V

    .line 290
    const/4 v10, 0x1

    invoke-static {v2, v10}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog$dp(Landroid/content/Context;I)I

    move-result v10

    invoke-virtual {v3, v10}, Lcom/google/android/material/button/MaterialButton;->setStrokeWidth(I)V

    .line 291
    const/16 v10, 0x64

    invoke-static {v2, v10}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog$dp(Landroid/content/Context;I)I

    move-result v15

    invoke-virtual {v3, v15}, Lcom/google/android/material/button/MaterialButton;->setCornerRadius(I)V

    .line 292
    const/4 v10, 0x0

    invoke-virtual {v3, v10}, Lcom/google/android/material/button/MaterialButton;->setAllCaps(Z)V

    .line 293
    invoke-static {v2, v1}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog$dp(Landroid/content/Context;I)I

    move-result v10

    const/4 v15, 0x6

    invoke-static {v2, v15}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog$dp(Landroid/content/Context;I)I

    move-result v5

    invoke-static {v2, v1}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog$dp(Landroid/content/Context;I)I

    move-result v1

    move-object/from16 v22, v0

    invoke-static {v2, v15}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog$dp(Landroid/content/Context;I)I

    move-result v0

    invoke-virtual {v3, v10, v5, v1, v0}, Lcom/google/android/material/button/MaterialButton;->setPadding(IIII)V

    .line 294
    new-instance v0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda23;

    invoke-direct {v0, v7}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda23;-><init>(Landroid/app/Dialog;)V

    invoke-virtual {v3, v0}, Lcom/google/android/material/button/MaterialButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 295
    nop

    .line 284
    .end local v3  # "$this$showEditDomainDialog_u24lambda_u2413":Lcom/google/android/material/button/MaterialButton;
    .end local v4  # "$i$a$-apply-WioCoreSettingsDialog$showEditDomainDialog$btnCancel$1":I
    nop

    .line 297
    .local v22, "btnCancel":Lcom/google/android/material/button/MaterialButton;
    new-instance v10, Lcom/google/android/material/button/MaterialButton;

    invoke-direct {v10, v2}, Lcom/google/android/material/button/MaterialButton;-><init>(Landroid/content/Context;)V

    move-object v4, v10

    .local v4, "$this$showEditDomainDialog_u24lambda_u2414":Lcom/google/android/material/button/MaterialButton;
    const/16 v23, 0x0

    .line 298
    .local v23, "$i$a$-apply-WioCoreSettingsDialog$showEditDomainDialog$btnSave$1":I
    if-eqz p4, :cond_366

    const-string v0, "✓ Save"

    goto :goto_368

    :cond_366
    const-string v0, "✓ Kaydet"

    :goto_368
    check-cast v0, Ljava/lang/CharSequence;

    invoke-virtual {v4, v0}, Lcom/google/android/material/button/MaterialButton;->setText(Ljava/lang/CharSequence;)V

    .line 299
    const/high16 v0, 0x41480000  # 12.5f

    invoke-virtual {v4, v0}, Lcom/google/android/material/button/MaterialButton;->setTextSize(F)V

    .line 300
    sget-object v0, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v4, v0}, Lcom/google/android/material/button/MaterialButton;->setTypeface(Landroid/graphics/Typeface;)V

    .line 301
    const/high16 v0, -0x1000000

    invoke-virtual {v4, v0}, Lcom/google/android/material/button/MaterialButton;->setTextColor(I)V

    .line 302
    const/16 v19, -0x1

    invoke-static/range {v19 .. v19}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v0

    invoke-virtual {v4, v0}, Lcom/google/android/material/button/MaterialButton;->setBackgroundTintList(Landroid/content/res/ColorStateList;)V

    .line 303
    const/16 v0, 0x64

    invoke-static {v2, v0}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog$dp(Landroid/content/Context;I)I

    move-result v0

    invoke-virtual {v4, v0}, Lcom/google/android/material/button/MaterialButton;->setCornerRadius(I)V

    .line 304
    const/4 v0, 0x0

    invoke-virtual {v4, v0}, Lcom/google/android/material/button/MaterialButton;->setAllCaps(Z)V

    .line 305
    const/16 v0, 0x14

    invoke-static {v2, v0}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog$dp(Landroid/content/Context;I)I

    move-result v1

    invoke-static {v2, v15}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog$dp(Landroid/content/Context;I)I

    move-result v3

    invoke-static {v2, v0}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog$dp(Landroid/content/Context;I)I

    move-result v0

    invoke-static {v2, v15}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog$dp(Landroid/content/Context;I)I

    move-result v5

    invoke-virtual {v4, v1, v3, v0, v5}, Lcom/google/android/material/button/MaterialButton;->setPadding(IIII)V

    .line 306
    new-instance v0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda24;

    move/from16 v3, p4

    move-object/from16 v5, p7

    move-object/from16 v1, v21

    .end local v21  # "input":Landroid/widget/EditText;
    .local v1, "input":Landroid/widget/EditText;
    invoke-direct/range {v0 .. v7}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda24;-><init>(Landroid/widget/EditText;Landroid/content/Context;ZLcom/google/android/material/button/MaterialButton;Lkotlin/jvm/functions/Function1;Ljava/lang/String;Landroid/app/Dialog;)V

    .end local v1  # "input":Landroid/widget/EditText;
    .restart local v21  # "input":Landroid/widget/EditText;
    invoke-virtual {v4, v0}, Lcom/google/android/material/button/MaterialButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 326
    nop

    .line 297
    .end local v4  # "$this$showEditDomainDialog_u24lambda_u2414":Lcom/google/android/material/button/MaterialButton;
    .end local v23  # "$i$a$-apply-WioCoreSettingsDialog$showEditDomainDialog$btnSave$1":I
    nop

    .line 328
    .local v10, "btnSave":Lcom/google/android/material/button/MaterialButton;
    move-object/from16 v0, v22

    check-cast v0, Landroid/view/View;

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v3, 0x28

    invoke-static {v2, v3}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog$dp(Landroid/content/Context;I)I

    move-result v4

    const/4 v5, -0x2

    invoke-direct {v1, v5, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object v4, v1

    .local v4, "$this$showEditDomainDialog_u24lambda_u2415":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v5, 0x0

    .line 329
    .local v5, "$i$a$-apply-WioCoreSettingsDialog$showEditDomainDialog$3":I
    const/16 v6, 0xa

    invoke-static {v2, v6}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog$dp(Landroid/content/Context;I)I

    move-result v6

    invoke-virtual {v4, v6}, Landroid/widget/LinearLayout$LayoutParams;->setMarginEnd(I)V

    .line 330
    nop

    .end local v4  # "$this$showEditDomainDialog_u24lambda_u2415":Landroid/widget/LinearLayout$LayoutParams;
    .end local v5  # "$i$a$-apply-WioCoreSettingsDialog$showEditDomainDialog$3":I
    sget-object v4, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 328
    check-cast v1, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v13, v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 331
    move-object v0, v10

    check-cast v0, Landroid/view/View;

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    invoke-static {v2, v3}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog$dp(Landroid/content/Context;I)I

    move-result v3

    const/4 v5, -0x2

    invoke-direct {v1, v5, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    check-cast v1, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v13, v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 332
    move-object v0, v13

    check-cast v0, Landroid/view/View;

    invoke-virtual {v9, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 334
    move-object v0, v9

    check-cast v0, Landroid/view/View;

    invoke-virtual {v7, v0}, Landroid/app/Dialog;->setContentView(Landroid/view/View;)V

    .line 335
    invoke-virtual {v7}, Landroid/app/Dialog;->show()V

    .line 336
    return-void
.end method

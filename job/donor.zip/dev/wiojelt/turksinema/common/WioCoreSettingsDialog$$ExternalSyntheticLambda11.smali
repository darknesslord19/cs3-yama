.class public final synthetic Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda11;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x13
    versionHash = "7bbc1d7254613ffaa026de47d975f73968361ef3e5d7b818ce0a83a33039c6b8"
.end annotation


# instance fields
.field public final synthetic f$0:Lkotlinx/coroutines/CoroutineScope;

.field public final synthetic f$1:Ldev/wiojelt/turksinema/common/WioSettingsConfig;

.field public final synthetic f$2:Landroid/content/Context;


# direct methods
.method public synthetic constructor <init>(Lkotlinx/coroutines/CoroutineScope;Ldev/wiojelt/turksinema/common/WioSettingsConfig;Landroid/content/Context;)V
    .registers 4

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda11;->f$0:Lkotlinx/coroutines/CoroutineScope;

    iput-object p2, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda11;->f$1:Ldev/wiojelt/turksinema/common/WioSettingsConfig;

    iput-object p3, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda11;->f$2:Landroid/content/Context;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 5

    .line 0
    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda11;->f$0:Lkotlinx/coroutines/CoroutineScope;

    iget-object v1, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda11;->f$1:Ldev/wiojelt/turksinema/common/WioSettingsConfig;

    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda11;->f$2:Landroid/content/Context;

    invoke-static {v0, v1, v2, p1}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->$r8$lambda$hTP0F1oNDM_YWwuaDeVdllTH4ok(Lkotlinx/coroutines/CoroutineScope;Ldev/wiojelt/turksinema/common/WioSettingsConfig;Landroid/content/Context;Landroid/view/View;)V

    return-void
.end method

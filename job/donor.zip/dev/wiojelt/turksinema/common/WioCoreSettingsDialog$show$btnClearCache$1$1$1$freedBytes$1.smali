.class final Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$btnClearCache$1$1$1$freedBytes$1;
.super Lkotlin/coroutines/jvm/internal/SuspendLambda;
.source "WioCoreSettingsDialog.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$btnClearCache$1$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/SuspendLambda;",
        "Lkotlin/jvm/functions/Function2<",
        "Lkotlinx/coroutines/CoroutineScope;",
        "Lkotlin/coroutines/Continuation<",
        "-",
        "Ljava/lang/Long;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\n\n\u0000\n\u0002\u0010\t\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"
    }
    d2 = {
        "<anonymous>",
        "",
        "Lkotlinx/coroutines/CoroutineScope;"
    }
    k = 0x3
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "dev.wiojelt.turksinema.common.WioCoreSettingsDialog$show$btnClearCache$1$1$1$freedBytes$1"
    f = "WioCoreSettingsDialog.kt"
    i = {}
    l = {}
    m = "invokeSuspend"
    n = {}
    nl = {}
    s = {}
    v = 0x2
.end annotation


# instance fields
.field final synthetic $context:Landroid/content/Context;

.field label:I


# direct methods
.method constructor <init>(Landroid/content/Context;Lkotlin/coroutines/Continuation;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$btnClearCache$1$1$1$freedBytes$1;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$btnClearCache$1$1$1$freedBytes$1;->$context:Landroid/content/Context;

    const/4 v0, 0x2

    invoke-direct {p0, v0, p2}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/Continuation;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/Continuation<",
            "*>;)",
            "Lkotlin/coroutines/Continuation<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    new-instance v0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$btnClearCache$1$1$1$freedBytes$1;

    iget-object v1, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$btnClearCache$1$1$1$freedBytes$1;->$context:Landroid/content/Context;

    invoke-direct {v0, v1, p2}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$btnClearCache$1$1$1$freedBytes$1;-><init>(Landroid/content/Context;Lkotlin/coroutines/Continuation;)V

    check-cast v0, Lkotlin/coroutines/Continuation;

    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    check-cast p2, Lkotlin/coroutines/Continuation;

    invoke-virtual {p0, p1, p2}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$btnClearCache$1$1$1$freedBytes$1;->invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public final invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/CoroutineScope;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Ljava/lang/Long;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    invoke-virtual {p0, p1, p2}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$btnClearCache$1$1$1$freedBytes$1;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    move-result-object v0

    check-cast v0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$btnClearCache$1$1$1$freedBytes$1;

    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    invoke-virtual {v0, v1}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$btnClearCache$1$1$1$freedBytes$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4
    .param p1, "$result"  # Ljava/lang/Object;

    invoke-static {}, Lkotlin/coroutines/intrinsics/IntrinsicsKt;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    .line 470
    iget v0, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$btnClearCache$1$1$1$freedBytes$1;->label:I

    packed-switch v0, :pswitch_data_20

    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :pswitch_10  #0x0
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 471
    sget-object v0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->INSTANCE:Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;

    iget-object v1, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$show$btnClearCache$1$1$1$freedBytes$1;->$context:Landroid/content/Context;

    invoke-virtual {v0, v1}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->clearCache(Landroid/content/Context;)J

    move-result-wide v0

    invoke-static {v0, v1}, Lkotlin/coroutines/jvm/internal/Boxing;->boxLong(J)Ljava/lang/Long;

    move-result-object v0

    return-object v0

    :pswitch_data_20
    .packed-switch 0x0
        :pswitch_10  #00000000
    .end packed-switch
.end method

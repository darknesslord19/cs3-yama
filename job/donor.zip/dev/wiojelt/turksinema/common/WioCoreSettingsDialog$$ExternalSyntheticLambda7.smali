.class public final synthetic Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda7;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/widget/CompoundButton$OnCheckedChangeListener;


# annotations
.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x13
    versionHash = "7bbc1d7254613ffaa026de47d975f73968361ef3e5d7b818ce0a83a33039c6b8"
.end annotation


# instance fields
.field public final synthetic f$0:Lkotlin/jvm/internal/Ref$BooleanRef;

.field public final synthetic f$1:Ldev/wiojelt/turksinema/common/WioProviderSettingItem;

.field public final synthetic f$2:Lkotlin/jvm/internal/Ref$ObjectRef;

.field public final synthetic f$3:Ldev/wiojelt/turksinema/common/WioSettingsConfig;

.field public final synthetic f$4:Ljava/util/Map;


# direct methods
.method public synthetic constructor <init>(Lkotlin/jvm/internal/Ref$BooleanRef;Ldev/wiojelt/turksinema/common/WioProviderSettingItem;Lkotlin/jvm/internal/Ref$ObjectRef;Ldev/wiojelt/turksinema/common/WioSettingsConfig;Ljava/util/Map;)V
    .registers 6

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda7;->f$0:Lkotlin/jvm/internal/Ref$BooleanRef;

    iput-object p2, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda7;->f$1:Ldev/wiojelt/turksinema/common/WioProviderSettingItem;

    iput-object p3, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda7;->f$2:Lkotlin/jvm/internal/Ref$ObjectRef;

    iput-object p4, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda7;->f$3:Ldev/wiojelt/turksinema/common/WioSettingsConfig;

    iput-object p5, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda7;->f$4:Ljava/util/Map;

    return-void
.end method


# virtual methods
.method public final onCheckedChanged(Landroid/widget/CompoundButton;Z)V
    .registers 10

    .line 0
    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda7;->f$0:Lkotlin/jvm/internal/Ref$BooleanRef;

    iget-object v1, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda7;->f$1:Ldev/wiojelt/turksinema/common/WioProviderSettingItem;

    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda7;->f$2:Lkotlin/jvm/internal/Ref$ObjectRef;

    iget-object v3, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda7;->f$3:Ldev/wiojelt/turksinema/common/WioSettingsConfig;

    iget-object v4, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda7;->f$4:Ljava/util/Map;

    move-object v5, p1

    move v6, p2

    invoke-static/range {v0 .. v6}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->$r8$lambda$5CiQsZwyVaDo0iBFZoLQ0Y4kTqI(Lkotlin/jvm/internal/Ref$BooleanRef;Ldev/wiojelt/turksinema/common/WioProviderSettingItem;Lkotlin/jvm/internal/Ref$ObjectRef;Ldev/wiojelt/turksinema/common/WioSettingsConfig;Ljava/util/Map;Landroid/widget/CompoundButton;Z)V

    return-void
.end method

.class public final Ldev/wiojelt/turksinema/common/WioProviderSettingItem;
.super Ljava/lang/Object;
.source "WioCoreSettingsDialog.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u00004\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u001e\n\u0002\u0010\b\n\u0002\b\u0002\b\u0086\b\u0018\u00002\u00020\u0001B\u008a\u0001\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0005\u001a\u00020\u0006\u0012\n\b\u0002\u0010\u0007\u001a\u0004\u0018\u00010\u0003\u0012\b\b\u0002\u0010\b\u001a\u00020\u0006\u0012\b\b\u0002\u0010\t\u001a\u00020\u0006\u0012\n\b\u0002\u0010\n\u001a\u0004\u0018\u00010\u0003\u0012\u0014\b\u0002\u0010\u000b\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\r0\f\u0012%\b\u0002\u0010\u000e\u001a\u001f\u0012\u0013\u0012\u00110\u0003¢\u0006\f\b\u000f\u0012\b\b\u0010\u0012\u0004\b\b(\u0011\u0012\u0004\u0012\u00020\r\u0018\u00010\f¢\u0006\u0004\b\u0012\u0010\u0013J\t\u0010!\u001a\u00020\u0003HÆ\u0003J\t\u0010\"\u001a\u00020\u0003HÆ\u0003J\t\u0010#\u001a\u00020\u0006HÆ\u0003J\u000b\u0010$\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\t\u0010%\u001a\u00020\u0006HÆ\u0003J\t\u0010&\u001a\u00020\u0006HÆ\u0003J\u000b\u0010\'\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\u0015\u0010(\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\r0\fHÆ\u0003J&\u0010)\u001a\u001f\u0012\u0013\u0012\u00110\u0003¢\u0006\f\b\u000f\u0012\b\b\u0010\u0012\u0004\b\b(\u0011\u0012\u0004\u0012\u00020\r\u0018\u00010\fHÆ\u0003J\u0090\u0001\u0010*\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00062\n\b\u0002\u0010\u0007\u001a\u0004\u0018\u00010\u00032\b\b\u0002\u0010\b\u001a\u00020\u00062\b\b\u0002\u0010\t\u001a\u00020\u00062\n\b\u0002\u0010\n\u001a\u0004\u0018\u00010\u00032\u0014\b\u0002\u0010\u000b\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\r0\f2%\b\u0002\u0010\u000e\u001a\u001f\u0012\u0013\u0012\u00110\u0003¢\u0006\f\b\u000f\u0012\b\b\u0010\u0012\u0004\b\b(\u0011\u0012\u0004\u0012\u00020\r\u0018\u00010\fHÆ\u0001J\u0014\u0010+\u001a\u00020\u00062\b\u0010,\u001a\u0004\u0018\u00010\u0001HÖ\u0083\u0004J\n\u0010-\u001a\u00020.HÖ\u0081\u0004J\n\u0010/\u001a\u00020\u0003HÖ\u0081\u0004R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0015R\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0015R\u0011\u0010\u0005\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0017R\u001c\u0010\u0007\u001a\u0004\u0018\u00010\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0018\u0010\u0015\"\u0004\b\u0019\u0010\u001aR\u001a\u0010\b\u001a\u00020\u0006X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\b\u0010\u0017\"\u0004\b\u001b\u0010\u001cR\u0011\u0010\t\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\u0017R\u0013\u0010\n\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001d\u0010\u0015R\u001d\u0010\u000b\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\r0\f¢\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u001fR.\u0010\u000e\u001a\u001f\u0012\u0013\u0012\u00110\u0003¢\u0006\f\b\u000f\u0012\b\b\u0010\u0012\u0004\b\b(\u0011\u0012\u0004\u0012\u00020\r\u0018\u00010\f¢\u0006\b\n\u0000\u001a\u0004\b \u0010\u001f¨\u00060"
    }
    d2 = {
        "Ldev/wiojelt/turksinema/common/WioProviderSettingItem;",
        "",
        "id",
        "",
        "displayName",
        "isDirectTmdb",
        "",
        "domain",
        "isEnabled",
        "isForeign",
        "capabilityBadges",
        "onToggle",
        "Lkotlin/Function1;",
        "",
        "onDomainEdit",
        "Lkotlin/ParameterName;",
        "name",
        "newDomain",
        "<init>",
        "(Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;ZZLjava/lang/String;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;)V",
        "getId",
        "()Ljava/lang/String;",
        "getDisplayName",
        "()Z",
        "getDomain",
        "setDomain",
        "(Ljava/lang/String;)V",
        "setEnabled",
        "(Z)V",
        "getCapabilityBadges",
        "getOnToggle",
        "()Lkotlin/jvm/functions/Function1;",
        "getOnDomainEdit",
        "component1",
        "component2",
        "component3",
        "component4",
        "component5",
        "component6",
        "component7",
        "component8",
        "component9",
        "copy",
        "equals",
        "other",
        "hashCode",
        "",
        "toString",
        "DiziMom"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final capabilityBadges:Ljava/lang/String;
    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation
.end field

.field private final displayName:Ljava/lang/String;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field private domain:Ljava/lang/String;
    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation
.end field

.field private final id:Ljava/lang/String;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field private final isDirectTmdb:Z

.field private isEnabled:Z

.field private final isForeign:Z

.field private final onDomainEdit:Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function1<",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation
.end field

.field private final onToggle:Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function1<",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;ZZLjava/lang/String;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;)V
    .registers 10
    .param p1, "id"  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p2, "displayName"  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p3, "isDirectTmdb"  # Z
    .param p4, "domain"  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/Nullable;
        .end annotation
    .end param
    .param p5, "isEnabled"  # Z
    .param p6, "isForeign"  # Z
    .param p7, "capabilityBadges"  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/Nullable;
        .end annotation
    .end param
    .param p8, "onToggle"  # Lkotlin/jvm/functions/Function1;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p9, "onDomainEdit"  # Lkotlin/jvm/functions/Function1;
        .annotation build Lorg/jetbrains/annotations/Nullable;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Z",
            "Ljava/lang/String;",
            "ZZ",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 34
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 35
    iput-object p1, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->id:Ljava/lang/String;

    .line 36
    iput-object p2, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->displayName:Ljava/lang/String;

    .line 37
    iput-boolean p3, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->isDirectTmdb:Z

    .line 38
    iput-object p4, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->domain:Ljava/lang/String;

    .line 39
    iput-boolean p5, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->isEnabled:Z

    .line 40
    iput-boolean p6, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->isForeign:Z

    .line 41
    iput-object p7, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->capabilityBadges:Ljava/lang/String;

    .line 42
    iput-object p8, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->onToggle:Lkotlin/jvm/functions/Function1;

    .line 43
    iput-object p9, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->onDomainEdit:Lkotlin/jvm/functions/Function1;

    .line 34
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;ZZLjava/lang/String;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;ILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .registers 14

    .line 34
    and-int/lit8 p11, p10, 0x4

    const/4 v0, 0x0

    if-eqz p11, :cond_6

    .line 37
    move p3, v0

    .line 34
    :cond_6
    and-int/lit8 p11, p10, 0x8

    const/4 v1, 0x0

    if-eqz p11, :cond_c

    .line 38
    move-object p4, v1

    .line 34
    :cond_c
    and-int/lit8 p11, p10, 0x10

    if-eqz p11, :cond_11

    .line 39
    const/4 p5, 0x1

    .line 34
    :cond_11
    and-int/lit8 p11, p10, 0x20

    if-eqz p11, :cond_16

    .line 40
    move p6, v0

    .line 34
    :cond_16
    and-int/lit8 p11, p10, 0x40

    if-eqz p11, :cond_1b

    .line 41
    move-object p7, v1

    .line 34
    :cond_1b
    and-int/lit16 p11, p10, 0x80

    if-eqz p11, :cond_24

    .line 42
    new-instance p8, Ldev/wiojelt/turksinema/common/WioProviderSettingItem$$ExternalSyntheticLambda1;

    invoke-direct {p8}, Ldev/wiojelt/turksinema/common/WioProviderSettingItem$$ExternalSyntheticLambda1;-><init>()V

    .line 34
    :cond_24
    and-int/lit16 p10, p10, 0x100

    if-eqz p10, :cond_2a

    .line 43
    move-object p10, v1

    goto :goto_2b

    .line 34
    :cond_2a
    move-object p10, p9

    :goto_2b
    move-object p9, p8

    move-object p8, p7

    move p7, p6

    move p6, p5

    move-object p5, p4

    move p4, p3

    move-object p3, p2

    move-object p2, p1

    move-object p1, p0

    invoke-direct/range {p1 .. p10}, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;-><init>(Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;ZZLjava/lang/String;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;)V

    .line 44
    return-void
.end method

.method static final _init_$lambda$0(Z)Lkotlin/Unit;
    .registers 2
    .param p0, "it"  # Z

    .line 42
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public static synthetic copy$default(Ldev/wiojelt/turksinema/common/WioProviderSettingItem;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;ZZLjava/lang/String;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ldev/wiojelt/turksinema/common/WioProviderSettingItem;
    .registers 12

    and-int/lit8 p11, p10, 0x1

    if-eqz p11, :cond_6

    iget-object p1, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->id:Ljava/lang/String;

    :cond_6
    and-int/lit8 p11, p10, 0x2

    if-eqz p11, :cond_c

    iget-object p2, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->displayName:Ljava/lang/String;

    :cond_c
    and-int/lit8 p11, p10, 0x4

    if-eqz p11, :cond_12

    iget-boolean p3, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->isDirectTmdb:Z

    :cond_12
    and-int/lit8 p11, p10, 0x8

    if-eqz p11, :cond_18

    iget-object p4, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->domain:Ljava/lang/String;

    :cond_18
    and-int/lit8 p11, p10, 0x10

    if-eqz p11, :cond_1e

    iget-boolean p5, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->isEnabled:Z

    :cond_1e
    and-int/lit8 p11, p10, 0x20

    if-eqz p11, :cond_24

    iget-boolean p6, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->isForeign:Z

    :cond_24
    and-int/lit8 p11, p10, 0x40

    if-eqz p11, :cond_2a

    iget-object p7, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->capabilityBadges:Ljava/lang/String;

    :cond_2a
    and-int/lit16 p11, p10, 0x80

    if-eqz p11, :cond_30

    iget-object p8, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->onToggle:Lkotlin/jvm/functions/Function1;

    :cond_30
    and-int/lit16 p10, p10, 0x100

    if-eqz p10, :cond_36

    iget-object p9, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->onDomainEdit:Lkotlin/jvm/functions/Function1;

    :cond_36
    move-object p10, p8

    move-object p11, p9

    move p8, p6

    move-object p9, p7

    move-object p6, p4

    move p7, p5

    move-object p4, p2

    move p5, p3

    move-object p2, p0

    move-object p3, p1

    invoke-virtual/range {p2 .. p11}, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->copy(Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;ZZLjava/lang/String;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;)Ldev/wiojelt/turksinema/common/WioProviderSettingItem;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .registers 2
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->id:Ljava/lang/String;

    return-object v0
.end method

.method public final component2()Ljava/lang/String;
    .registers 2
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->displayName:Ljava/lang/String;

    return-object v0
.end method

.method public final component3()Z
    .registers 2

    iget-boolean v0, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->isDirectTmdb:Z

    return v0
.end method

.method public final component4()Ljava/lang/String;
    .registers 2
    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation

    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->domain:Ljava/lang/String;

    return-object v0
.end method

.method public final component5()Z
    .registers 2

    iget-boolean v0, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->isEnabled:Z

    return v0
.end method

.method public final component6()Z
    .registers 2

    iget-boolean v0, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->isForeign:Z

    return v0
.end method

.method public final component7()Ljava/lang/String;
    .registers 2
    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation

    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->capabilityBadges:Ljava/lang/String;

    return-object v0
.end method

.method public final component8()Lkotlin/jvm/functions/Function1;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function1<",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->onToggle:Lkotlin/jvm/functions/Function1;

    return-object v0
.end method

.method public final component9()Lkotlin/jvm/functions/Function1;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function1<",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation

    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->onDomainEdit:Lkotlin/jvm/functions/Function1;

    return-object v0
.end method

.method public final copy(Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;ZZLjava/lang/String;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;)Ldev/wiojelt/turksinema/common/WioProviderSettingItem;
    .registers 20
    .param p1  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p2  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p4  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/Nullable;
        .end annotation
    .end param
    .param p7  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/Nullable;
        .end annotation
    .end param
    .param p8  # Lkotlin/jvm/functions/Function1;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p9  # Lkotlin/jvm/functions/Function1;
        .annotation build Lorg/jetbrains/annotations/Nullable;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Z",
            "Ljava/lang/String;",
            "ZZ",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;)",
            "Ldev/wiojelt/turksinema/common/WioProviderSettingItem;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    new-instance v0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;

    move-object v1, p1

    move-object v2, p2

    move v3, p3

    move-object v4, p4

    move v5, p5

    move/from16 v6, p6

    move-object/from16 v7, p7

    move-object/from16 v8, p8

    move-object/from16 v9, p9

    invoke-direct/range {v0 .. v9}, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;-><init>(Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;ZZLjava/lang/String;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;)V

    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 7
    .param p1  # Ljava/lang/Object;
        .annotation build Lorg/jetbrains/annotations/Nullable;
        .end annotation
    .end param

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    move-object v1, p1

    check-cast v1, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;

    iget-object v3, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->id:Ljava/lang/String;

    iget-object v4, v1, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->id:Ljava/lang/String;

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_18

    return v2

    :cond_18
    iget-object v3, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->displayName:Ljava/lang/String;

    iget-object v4, v1, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->displayName:Ljava/lang/String;

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_23

    return v2

    :cond_23
    iget-boolean v3, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->isDirectTmdb:Z

    iget-boolean v4, v1, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->isDirectTmdb:Z

    if-eq v3, v4, :cond_2a

    return v2

    :cond_2a
    iget-object v3, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->domain:Ljava/lang/String;

    iget-object v4, v1, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->domain:Ljava/lang/String;

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_35

    return v2

    :cond_35
    iget-boolean v3, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->isEnabled:Z

    iget-boolean v4, v1, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->isEnabled:Z

    if-eq v3, v4, :cond_3c

    return v2

    :cond_3c
    iget-boolean v3, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->isForeign:Z

    iget-boolean v4, v1, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->isForeign:Z

    if-eq v3, v4, :cond_43

    return v2

    :cond_43
    iget-object v3, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->capabilityBadges:Ljava/lang/String;

    iget-object v4, v1, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->capabilityBadges:Ljava/lang/String;

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4e

    return v2

    :cond_4e
    iget-object v3, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->onToggle:Lkotlin/jvm/functions/Function1;

    iget-object v4, v1, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->onToggle:Lkotlin/jvm/functions/Function1;

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_59

    return v2

    :cond_59
    iget-object v3, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->onDomainEdit:Lkotlin/jvm/functions/Function1;

    iget-object v1, v1, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->onDomainEdit:Lkotlin/jvm/functions/Function1;

    invoke-static {v3, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_64

    return v2

    :cond_64
    return v0
.end method

.method public final getCapabilityBadges()Ljava/lang/String;
    .registers 2
    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation

    .line 41
    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->capabilityBadges:Ljava/lang/String;

    return-object v0
.end method

.method public final getDisplayName()Ljava/lang/String;
    .registers 2
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 36
    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->displayName:Ljava/lang/String;

    return-object v0
.end method

.method public final getDomain()Ljava/lang/String;
    .registers 2
    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation

    .line 38
    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->domain:Ljava/lang/String;

    return-object v0
.end method

.method public final getId()Ljava/lang/String;
    .registers 2
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 35
    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->id:Ljava/lang/String;

    return-object v0
.end method

.method public final getOnDomainEdit()Lkotlin/jvm/functions/Function1;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function1<",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation

    .line 43
    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->onDomainEdit:Lkotlin/jvm/functions/Function1;

    return-object v0
.end method

.method public final getOnToggle()Lkotlin/jvm/functions/Function1;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function1<",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 42
    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->onToggle:Lkotlin/jvm/functions/Function1;

    return-object v0
.end method

.method public hashCode()I
    .registers 5

    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->id:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    mul-int/lit8 v1, v0, 0x1f

    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->displayName:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v2

    add-int/2addr v1, v2

    mul-int/lit8 v0, v1, 0x1f

    iget-boolean v2, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->isDirectTmdb:Z

    invoke-static {v2}, Ldev/wiojelt/turksinema/common/WioProviderSettingItem$$ExternalSyntheticBackport0;->m(Z)I

    move-result v2

    add-int/2addr v0, v2

    mul-int/lit8 v1, v0, 0x1f

    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->domain:Ljava/lang/String;

    const/4 v3, 0x0

    if-nez v2, :cond_21

    move v2, v3

    goto :goto_27

    :cond_21
    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->domain:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v2

    :goto_27
    add-int/2addr v1, v2

    mul-int/lit8 v0, v1, 0x1f

    iget-boolean v2, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->isEnabled:Z

    invoke-static {v2}, Ldev/wiojelt/turksinema/common/WioProviderSettingItem$$ExternalSyntheticBackport0;->m(Z)I

    move-result v2

    add-int/2addr v0, v2

    mul-int/lit8 v1, v0, 0x1f

    iget-boolean v2, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->isForeign:Z

    invoke-static {v2}, Ldev/wiojelt/turksinema/common/WioProviderSettingItem$$ExternalSyntheticBackport0;->m(Z)I

    move-result v2

    add-int/2addr v1, v2

    mul-int/lit8 v0, v1, 0x1f

    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->capabilityBadges:Ljava/lang/String;

    if-nez v2, :cond_42

    move v2, v3

    goto :goto_48

    :cond_42
    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->capabilityBadges:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v2

    :goto_48
    add-int/2addr v0, v2

    mul-int/lit8 v1, v0, 0x1f

    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->onToggle:Lkotlin/jvm/functions/Function1;

    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    add-int/2addr v1, v2

    mul-int/lit8 v0, v1, 0x1f

    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->onDomainEdit:Lkotlin/jvm/functions/Function1;

    if-nez v2, :cond_59

    goto :goto_5f

    :cond_59
    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->onDomainEdit:Lkotlin/jvm/functions/Function1;

    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v3

    :goto_5f
    add-int/2addr v0, v3

    return v0
.end method

.method public final isDirectTmdb()Z
    .registers 2

    .line 37
    iget-boolean v0, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->isDirectTmdb:Z

    return v0
.end method

.method public final isEnabled()Z
    .registers 2

    .line 39
    iget-boolean v0, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->isEnabled:Z

    return v0
.end method

.method public final isForeign()Z
    .registers 2

    .line 40
    iget-boolean v0, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->isForeign:Z

    return v0
.end method

.method public final setDomain(Ljava/lang/String;)V
    .registers 2
    .param p1, "<set-?>"  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/Nullable;
        .end annotation
    .end param

    .line 38
    iput-object p1, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->domain:Ljava/lang/String;

    return-void
.end method

.method public final setEnabled(Z)V
    .registers 2
    .param p1, "<set-?>"  # Z

    .line 39
    iput-boolean p1, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->isEnabled:Z

    return-void
.end method

.method public toString()Ljava/lang/String;
    .registers 12
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->id:Ljava/lang/String;

    iget-object v1, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->displayName:Ljava/lang/String;

    iget-boolean v2, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->isDirectTmdb:Z

    iget-object v3, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->domain:Ljava/lang/String;

    iget-boolean v4, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->isEnabled:Z

    iget-boolean v5, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->isForeign:Z

    iget-object v6, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->capabilityBadges:Ljava/lang/String;

    iget-object v7, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->onToggle:Lkotlin/jvm/functions/Function1;

    iget-object v8, p0, Ldev/wiojelt/turksinema/common/WioProviderSettingItem;->onDomainEdit:Lkotlin/jvm/functions/Function1;

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "WioProviderSettingItem(id="

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v9, ", displayName="

    invoke-virtual {v0, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", isDirectTmdb="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", domain="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", isEnabled="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", isForeign="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", capabilityBadges="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", onToggle="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", onDomainEdit="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ")"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

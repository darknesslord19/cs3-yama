.class public final synthetic Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda13;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/content/DialogInterface$OnDismissListener;


# annotations
.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x13
    versionHash = "7bbc1d7254613ffaa026de47d975f73968361ef3e5d7b818ce0a83a33039c6b8"
.end annotation


# instance fields
.field public final synthetic f$0:Lkotlinx/coroutines/CoroutineScope;


# direct methods
.method public synthetic constructor <init>(Lkotlinx/coroutines/CoroutineScope;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda13;->f$0:Lkotlinx/coroutines/CoroutineScope;

    return-void
.end method


# virtual methods
.method public final onDismiss(Landroid/content/DialogInterface;)V
    .registers 3

    .line 0
    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda13;->f$0:Lkotlinx/coroutines/CoroutineScope;

    invoke-static {v0, p1}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$lambda$68(Lkotlinx/coroutines/CoroutineScope;Landroid/content/DialogInterface;)V

    return-void
.end method

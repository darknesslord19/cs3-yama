.class public final synthetic Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda26;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x13
    versionHash = "7bbc1d7254613ffaa026de47d975f73968361ef3e5d7b818ce0a83a33039c6b8"
.end annotation


# instance fields
.field public final synthetic f$0:Landroid/widget/EditText;

.field public final synthetic f$1:Ljava/lang/String;

.field public final synthetic f$2:Lcom/google/android/material/button/MaterialButton;

.field public final synthetic f$3:Z


# direct methods
.method public synthetic constructor <init>(Landroid/widget/EditText;Ljava/lang/String;Lcom/google/android/material/button/MaterialButton;Z)V
    .registers 5

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda26;->f$0:Landroid/widget/EditText;

    iput-object p2, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda26;->f$1:Ljava/lang/String;

    iput-object p3, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda26;->f$2:Lcom/google/android/material/button/MaterialButton;

    iput-boolean p4, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda26;->f$3:Z

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 6

    .line 0
    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda26;->f$0:Landroid/widget/EditText;

    iget-object v1, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda26;->f$1:Ljava/lang/String;

    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda26;->f$2:Lcom/google/android/material/button/MaterialButton;

    iget-boolean v3, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda26;->f$3:Z

    invoke-static {v0, v1, v2, v3, p1}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->showEditDomainDialog$updateIncrementBtn$lambda$10(Landroid/widget/EditText;Ljava/lang/String;Lcom/google/android/material/button/MaterialButton;ZLandroid/view/View;)V

    return-void
.end method

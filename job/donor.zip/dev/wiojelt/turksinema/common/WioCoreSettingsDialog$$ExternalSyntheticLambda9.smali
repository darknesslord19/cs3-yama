.class public final synthetic Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda9;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x13
    versionHash = "7bbc1d7254613ffaa026de47d975f73968361ef3e5d7b818ce0a83a33039c6b8"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/google/android/material/button/MaterialButton;

.field public final synthetic f$1:Landroid/widget/ProgressBar;

.field public final synthetic f$2:Landroid/widget/TextView;

.field public final synthetic f$3:Lkotlinx/coroutines/CoroutineScope;

.field public final synthetic f$4:Landroid/content/Context;

.field public final synthetic f$5:Ldev/wiojelt/turksinema/common/WioSettingsConfig;


# direct methods
.method public synthetic constructor <init>(Lcom/google/android/material/button/MaterialButton;Landroid/widget/ProgressBar;Landroid/widget/TextView;Lkotlinx/coroutines/CoroutineScope;Landroid/content/Context;Ldev/wiojelt/turksinema/common/WioSettingsConfig;)V
    .registers 7

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda9;->f$0:Lcom/google/android/material/button/MaterialButton;

    iput-object p2, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda9;->f$1:Landroid/widget/ProgressBar;

    iput-object p3, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda9;->f$2:Landroid/widget/TextView;

    iput-object p4, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda9;->f$3:Lkotlinx/coroutines/CoroutineScope;

    iput-object p5, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda9;->f$4:Landroid/content/Context;

    iput-object p6, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda9;->f$5:Ldev/wiojelt/turksinema/common/WioSettingsConfig;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 9

    .line 0
    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda9;->f$0:Lcom/google/android/material/button/MaterialButton;

    iget-object v1, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda9;->f$1:Landroid/widget/ProgressBar;

    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda9;->f$2:Landroid/widget/TextView;

    iget-object v3, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda9;->f$3:Lkotlinx/coroutines/CoroutineScope;

    iget-object v4, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda9;->f$4:Landroid/content/Context;

    iget-object v5, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda9;->f$5:Ldev/wiojelt/turksinema/common/WioSettingsConfig;

    move-object v6, p1

    invoke-static/range {v0 .. v6}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->show$lambda$63(Lcom/google/android/material/button/MaterialButton;Landroid/widget/ProgressBar;Landroid/widget/TextView;Lkotlinx/coroutines/CoroutineScope;Landroid/content/Context;Ldev/wiojelt/turksinema/common/WioSettingsConfig;Landroid/view/View;)V

    return-void
.end method

.class public final synthetic Ldev/wiojelt/turksinema/common/DomainUpdateUi$$ExternalSyntheticLambda5;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x13
    versionHash = "7bbc1d7254613ffaa026de47d975f73968361ef3e5d7b818ce0a83a33039c6b8"
.end annotation


# instance fields
.field public final synthetic f$0:Landroid/content/Context;


# direct methods
.method public synthetic constructor <init>(Landroid/content/Context;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/wiojelt/turksinema/common/DomainUpdateUi$$ExternalSyntheticLambda5;->f$0:Landroid/content/Context;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 2

    .line 0
    iget-object v0, p0, Ldev/wiojelt/turksinema/common/DomainUpdateUi$$ExternalSyntheticLambda5;->f$0:Landroid/content/Context;

    invoke-static {v0}, Ldev/wiojelt/turksinema/common/DomainUpdateUi;->show$lambda$3(Landroid/content/Context;)Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

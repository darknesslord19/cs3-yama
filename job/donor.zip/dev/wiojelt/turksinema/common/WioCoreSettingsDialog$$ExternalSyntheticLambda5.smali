.class public final synthetic Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda5;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x13
    versionHash = "7bbc1d7254613ffaa026de47d975f73968361ef3e5d7b818ce0a83a33039c6b8"
.end annotation


# instance fields
.field public final synthetic f$0:Landroid/content/Context;

.field public final synthetic f$1:Ldev/wiojelt/turksinema/common/WioProviderSettingItem;

.field public final synthetic f$2:Ldev/wiojelt/turksinema/common/WioSettingsConfig;

.field public final synthetic f$3:Landroid/widget/TextView;


# direct methods
.method public synthetic constructor <init>(Landroid/content/Context;Ldev/wiojelt/turksinema/common/WioProviderSettingItem;Ldev/wiojelt/turksinema/common/WioSettingsConfig;Landroid/widget/TextView;)V
    .registers 5

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda5;->f$0:Landroid/content/Context;

    iput-object p2, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda5;->f$1:Ldev/wiojelt/turksinema/common/WioProviderSettingItem;

    iput-object p3, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda5;->f$2:Ldev/wiojelt/turksinema/common/WioSettingsConfig;

    iput-object p4, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda5;->f$3:Landroid/widget/TextView;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 6

    .line 0
    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda5;->f$0:Landroid/content/Context;

    iget-object v1, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda5;->f$1:Ldev/wiojelt/turksinema/common/WioProviderSettingItem;

    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda5;->f$2:Ldev/wiojelt/turksinema/common/WioSettingsConfig;

    iget-object v3, p0, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog$$ExternalSyntheticLambda5;->f$3:Landroid/widget/TextView;

    invoke-static {v0, v1, v2, v3, p1}, Ldev/wiojelt/turksinema/common/WioCoreSettingsDialog;->$r8$lambda$J3ReLetiULDauCX46poTmd50KDw(Landroid/content/Context;Ldev/wiojelt/turksinema/common/WioProviderSettingItem;Ldev/wiojelt/turksinema/common/WioSettingsConfig;Landroid/widget/TextView;Landroid/view/View;)V

    return-void
.end method

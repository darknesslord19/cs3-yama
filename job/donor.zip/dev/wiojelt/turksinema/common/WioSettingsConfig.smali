.class public final Ldev/wiojelt/turksinema/common/WioSettingsConfig;
.super Ljava/lang/Object;
.source "WioCoreSettingsDialog.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\b\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0007\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\"\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b^\b\u0086\b\u0018\u00002\u00020\u0001Bê\u0004\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0005\u001a\u00020\u0003\u0012\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u0003\u0012\b\b\u0002\u0010\u0007\u001a\u00020\b\u0012\b\b\u0002\u0010\t\u001a\u00020\b\u0012\b\b\u0002\u0010\n\u001a\u00020\b\u0012\b\b\u0002\u0010\u000b\u001a\u00020\b\u0012\b\b\u0002\u0010\f\u001a\u00020\b\u0012\b\b\u0002\u0010\r\u001a\u00020\b\u0012\b\b\u0002\u0010\u000e\u001a\u00020\b\u0012\b\b\u0002\u0010\u000f\u001a\u00020\b\u0012\b\b\u0002\u0010\u0010\u001a\u00020\u0011\u0012\b\b\u0002\u0010\u0012\u001a\u00020\u0011\u0012\u000e\b\u0002\u0010\u0013\u001a\b\u0012\u0004\u0012\u00020\u00110\u0014\u0012\u0014\b\u0002\u0010\u0015\u001a\u000e\u0012\u0004\u0012\u00020\u0011\u0012\u0004\u0012\u00020\u00170\u0016\u0012\b\b\u0002\u0010\u0018\u001a\u00020\u0011\u0012\u000e\b\u0002\u0010\u0019\u001a\b\u0012\u0004\u0012\u00020\b0\u0014\u0012\u0014\b\u0002\u0010\u001a\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\u00170\u0016\u0012\b\b\u0002\u0010\u001b\u001a\u00020\b\u0012\b\b\u0002\u0010\u001c\u001a\u00020\b\u0012\b\b\u0002\u0010\u001d\u001a\u00020\b\u0012\u000e\b\u0002\u0010\u001e\u001a\b\u0012\u0004\u0012\u00020 0\u001f\u0012\n\b\u0002\u0010!\u001a\u0004\u0018\u00010\u0003\u0012\b\b\u0002\u0010\"\u001a\u00020\u0011\u0012\u000e\b\u0002\u0010#\u001a\b\u0012\u0004\u0012\u00020$0\u001f\u0012@\b\u0002\u0010%\u001a:\u0012\u0013\u0012\u00110\u0003¢\u0006\f\b\'\u0012\b\b(\u0012\u0004\b\b()\u0012\u0019\u0012\u0017\u0012\u0004\u0012\u00020\u00030*¢\u0006\f\b\'\u0012\b\b(\u0012\u0004\b\b(+\u0012\u0004\u0012\u00020\u0017\u0018\u00010&\u0012\u0010\b\u0002\u0010,\u001a\n\u0012\u0004\u0012\u00020\u0017\u0018\u00010\u0014\u0012\u0010\b\u0002\u0010-\u001a\n\u0012\u0004\u0012\u00020\u0017\u0018\u00010\u0014\u0012\u0010\b\u0002\u0010.\u001a\n\u0012\u0004\u0012\u00020\u0017\u0018\u00010\u0014\u0012\u0010\b\u0002\u0010/\u001a\n\u0012\u0004\u0012\u00020\u0017\u0018\u00010\u0014\u0012\u0010\b\u0002\u00100\u001a\n\u0012\u0004\u0012\u00020\u0017\u0018\u00010\u0014\u0012\n\b\u0002\u00101\u001a\u0004\u0018\u00010\u0003\u0012M\b\u0002\u00102\u001aG\b\u0001\u0012\u001f\u0012\u001d\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00170\u0016¢\u0006\f\b\'\u0012\b\b(\u0012\u0004\b\b(3\u0012\u0016\u0012\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\b0504\u0012\u0006\u0012\u0004\u0018\u00010\u0001\u0018\u00010&\u0012\u0010\b\u0002\u00106\u001a\n\u0012\u0004\u0012\u00020\u0017\u0018\u00010\u0014\u0012\b\b\u0002\u00107\u001a\u00020\u0011\u0012\n\b\u0002\u00108\u001a\u0004\u0018\u00010\u0003\u0012\n\b\u0002\u00109\u001a\u0004\u0018\u00010\u0003¢\u0006\u0004\b:\u0010;J\t\u0010g\u001a\u00020\u0003HÆ\u0003J\t\u0010h\u001a\u00020\u0003HÆ\u0003J\t\u0010i\u001a\u00020\u0003HÆ\u0003J\u000b\u0010j\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\t\u0010k\u001a\u00020\bHÆ\u0003J\t\u0010l\u001a\u00020\bHÆ\u0003J\t\u0010m\u001a\u00020\bHÆ\u0003J\t\u0010n\u001a\u00020\bHÆ\u0003J\t\u0010o\u001a\u00020\bHÆ\u0003J\t\u0010p\u001a\u00020\bHÆ\u0003J\t\u0010q\u001a\u00020\bHÆ\u0003J\t\u0010r\u001a\u00020\bHÆ\u0003J\t\u0010s\u001a\u00020\u0011HÆ\u0003J\t\u0010t\u001a\u00020\u0011HÆ\u0003J\u000f\u0010u\u001a\b\u0012\u0004\u0012\u00020\u00110\u0014HÆ\u0003J\u0015\u0010v\u001a\u000e\u0012\u0004\u0012\u00020\u0011\u0012\u0004\u0012\u00020\u00170\u0016HÆ\u0003J\t\u0010w\u001a\u00020\u0011HÆ\u0003J\u000f\u0010x\u001a\b\u0012\u0004\u0012\u00020\b0\u0014HÆ\u0003J\u0015\u0010y\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\u00170\u0016HÆ\u0003J\t\u0010z\u001a\u00020\bHÆ\u0003J\t\u0010{\u001a\u00020\bHÆ\u0003J\t\u0010|\u001a\u00020\bHÆ\u0003J\u000f\u0010}\u001a\b\u0012\u0004\u0012\u00020 0\u001fHÆ\u0003J\u000b\u0010~\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\t\u0010\u007f\u001a\u00020\u0011HÆ\u0003J\u0010\u0010\u0080\u0001\u001a\b\u0012\u0004\u0012\u00020$0\u001fHÆ\u0003JB\u0010\u0081\u0001\u001a:\u0012\u0013\u0012\u00110\u0003¢\u0006\f\b\'\u0012\b\b(\u0012\u0004\b\b()\u0012\u0019\u0012\u0017\u0012\u0004\u0012\u00020\u00030*¢\u0006\f\b\'\u0012\b\b(\u0012\u0004\b\b(+\u0012\u0004\u0012\u00020\u0017\u0018\u00010&HÆ\u0003J\u0012\u0010\u0082\u0001\u001a\n\u0012\u0004\u0012\u00020\u0017\u0018\u00010\u0014HÆ\u0003J\u0012\u0010\u0083\u0001\u001a\n\u0012\u0004\u0012\u00020\u0017\u0018\u00010\u0014HÆ\u0003J\u0012\u0010\u0084\u0001\u001a\n\u0012\u0004\u0012\u00020\u0017\u0018\u00010\u0014HÆ\u0003J\u0012\u0010\u0085\u0001\u001a\n\u0012\u0004\u0012\u00020\u0017\u0018\u00010\u0014HÆ\u0003J\u0012\u0010\u0086\u0001\u001a\n\u0012\u0004\u0012\u00020\u0017\u0018\u00010\u0014HÆ\u0003J\f\u0010\u0087\u0001\u001a\u0004\u0018\u00010\u0003HÆ\u0003JT\u0010\u0088\u0001\u001aG\b\u0001\u0012\u001f\u0012\u001d\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00170\u0016¢\u0006\f\b\'\u0012\b\b(\u0012\u0004\b\b(3\u0012\u0016\u0012\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\b0504\u0012\u0006\u0012\u0004\u0018\u00010\u0001\u0018\u00010&HÆ\u0003¢\u0006\u0002\u0010ZJ\u0012\u0010\u0089\u0001\u001a\n\u0012\u0004\u0012\u00020\u0017\u0018\u00010\u0014HÆ\u0003J\n\u0010\u008a\u0001\u001a\u00020\u0011HÆ\u0003J\f\u0010\u008b\u0001\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\f\u0010\u008c\u0001\u001a\u0004\u0018\u00010\u0003HÆ\u0003Jó\u0004\u0010\u008d\u0001\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00032\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u00032\b\b\u0002\u0010\u0007\u001a\u00020\b2\b\b\u0002\u0010\t\u001a\u00020\b2\b\b\u0002\u0010\n\u001a\u00020\b2\b\b\u0002\u0010\u000b\u001a\u00020\b2\b\b\u0002\u0010\f\u001a\u00020\b2\b\b\u0002\u0010\r\u001a\u00020\b2\b\b\u0002\u0010\u000e\u001a\u00020\b2\b\b\u0002\u0010\u000f\u001a\u00020\b2\b\b\u0002\u0010\u0010\u001a\u00020\u00112\b\b\u0002\u0010\u0012\u001a\u00020\u00112\u000e\b\u0002\u0010\u0013\u001a\b\u0012\u0004\u0012\u00020\u00110\u00142\u0014\b\u0002\u0010\u0015\u001a\u000e\u0012\u0004\u0012\u00020\u0011\u0012\u0004\u0012\u00020\u00170\u00162\b\b\u0002\u0010\u0018\u001a\u00020\u00112\u000e\b\u0002\u0010\u0019\u001a\b\u0012\u0004\u0012\u00020\b0\u00142\u0014\b\u0002\u0010\u001a\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\u00170\u00162\b\b\u0002\u0010\u001b\u001a\u00020\b2\b\b\u0002\u0010\u001c\u001a\u00020\b2\b\b\u0002\u0010\u001d\u001a\u00020\b2\u000e\b\u0002\u0010\u001e\u001a\b\u0012\u0004\u0012\u00020 0\u001f2\n\b\u0002\u0010!\u001a\u0004\u0018\u00010\u00032\b\b\u0002\u0010\"\u001a\u00020\u00112\u000e\b\u0002\u0010#\u001a\b\u0012\u0004\u0012\u00020$0\u001f2@\b\u0002\u0010%\u001a:\u0012\u0013\u0012\u00110\u0003¢\u0006\f\b\'\u0012\b\b(\u0012\u0004\b\b()\u0012\u0019\u0012\u0017\u0012\u0004\u0012\u00020\u00030*¢\u0006\f\b\'\u0012\b\b(\u0012\u0004\b\b(+\u0012\u0004\u0012\u00020\u0017\u0018\u00010&2\u0010\b\u0002\u0010,\u001a\n\u0012\u0004\u0012\u00020\u0017\u0018\u00010\u00142\u0010\b\u0002\u0010-\u001a\n\u0012\u0004\u0012\u00020\u0017\u0018\u00010\u00142\u0010\b\u0002\u0010.\u001a\n\u0012\u0004\u0012\u00020\u0017\u0018\u00010\u00142\u0010\b\u0002\u0010/\u001a\n\u0012\u0004\u0012\u00020\u0017\u0018\u00010\u00142\u0010\b\u0002\u00100\u001a\n\u0012\u0004\u0012\u00020\u0017\u0018\u00010\u00142\n\b\u0002\u00101\u001a\u0004\u0018\u00010\u00032M\b\u0002\u00102\u001aG\b\u0001\u0012\u001f\u0012\u001d\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00170\u0016¢\u0006\f\b\'\u0012\b\b(\u0012\u0004\b\b(3\u0012\u0016\u0012\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\b0504\u0012\u0006\u0012\u0004\u0018\u00010\u0001\u0018\u00010&2\u0010\b\u0002\u00106\u001a\n\u0012\u0004\u0012\u00020\u0017\u0018\u00010\u00142\b\b\u0002\u00107\u001a\u00020\u00112\n\b\u0002\u00108\u001a\u0004\u0018\u00010\u00032\n\b\u0002\u00109\u001a\u0004\u0018\u00010\u0003HÆ\u0001¢\u0006\u0003\u0010\u008e\u0001J\u0016\u0010\u008f\u0001\u001a\u00020\u00112\t\u0010\u0090\u0001\u001a\u0004\u0018\u00010\u0001HÖ\u0083\u0004J\u000b\u0010\u0091\u0001\u001a\u00020\bHÖ\u0081\u0004J\u000b\u0010\u0092\u0001\u001a\u00020\u0003HÖ\u0081\u0004R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b<\u0010=R\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b>\u0010=R\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b?\u0010=R\u0013\u0010\u0006\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b@\u0010=R\u0011\u0010\u0007\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\bA\u0010BR\u0011\u0010\t\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\bC\u0010BR\u0011\u0010\n\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\bD\u0010BR\u0011\u0010\u000b\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\bE\u0010BR\u0011\u0010\f\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\bF\u0010BR\u0011\u0010\r\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\bG\u0010BR\u0011\u0010\u000e\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\bH\u0010BR\u0011\u0010\u000f\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\bI\u0010BR\u0011\u0010\u0010\u001a\u00020\u0011¢\u0006\b\n\u0000\u001a\u0004\bJ\u0010KR\u0011\u0010\u0012\u001a\u00020\u0011¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010KR\u0017\u0010\u0013\u001a\b\u0012\u0004\u0012\u00020\u00110\u0014¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010LR\u001d\u0010\u0015\u001a\u000e\u0012\u0004\u0012\u00020\u0011\u0012\u0004\u0012\u00020\u00170\u0016¢\u0006\b\n\u0000\u001a\u0004\bM\u0010NR\u0011\u0010\u0018\u001a\u00020\u0011¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010KR\u0017\u0010\u0019\u001a\b\u0012\u0004\u0012\u00020\b0\u0014¢\u0006\b\n\u0000\u001a\u0004\bO\u0010LR\u001d\u0010\u001a\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\u00170\u0016¢\u0006\b\n\u0000\u001a\u0004\bP\u0010NR\u0011\u0010\u001b\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\bQ\u0010BR\u0011\u0010\u001c\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\bR\u0010BR\u0011\u0010\u001d\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\bS\u0010BR\u0017\u0010\u001e\u001a\b\u0012\u0004\u0012\u00020 0\u001f¢\u0006\b\n\u0000\u001a\u0004\bT\u0010UR\u0013\u0010!\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\bV\u0010=R\u0011\u0010\"\u001a\u00020\u0011¢\u0006\b\n\u0000\u001a\u0004\bW\u0010KR\u0017\u0010#\u001a\b\u0012\u0004\u0012\u00020$0\u001f¢\u0006\b\n\u0000\u001a\u0004\bX\u0010URI\u0010%\u001a:\u0012\u0013\u0012\u00110\u0003¢\u0006\f\b\'\u0012\b\b(\u0012\u0004\b\b()\u0012\u0019\u0012\u0017\u0012\u0004\u0012\u00020\u00030*¢\u0006\f\b\'\u0012\b\b(\u0012\u0004\b\b(+\u0012\u0004\u0012\u00020\u0017\u0018\u00010&¢\u0006\b\n\u0000\u001a\u0004\bY\u0010ZR\u0019\u0010,\u001a\n\u0012\u0004\u0012\u00020\u0017\u0018\u00010\u0014¢\u0006\b\n\u0000\u001a\u0004\b[\u0010LR\u0019\u0010-\u001a\n\u0012\u0004\u0012\u00020\u0017\u0018\u00010\u0014¢\u0006\b\n\u0000\u001a\u0004\b\\\u0010LR\u0019\u0010.\u001a\n\u0012\u0004\u0012\u00020\u0017\u0018\u00010\u0014¢\u0006\b\n\u0000\u001a\u0004\b]\u0010LR\u0019\u0010/\u001a\n\u0012\u0004\u0012\u00020\u0017\u0018\u00010\u0014¢\u0006\b\n\u0000\u001a\u0004\b^\u0010LR\u0019\u00100\u001a\n\u0012\u0004\u0012\u00020\u0017\u0018\u00010\u0014¢\u0006\b\n\u0000\u001a\u0004\b_\u0010LR\u0013\u00101\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b`\u0010=RX\u00102\u001aG\b\u0001\u0012\u001f\u0012\u001d\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00170\u0016¢\u0006\f\b\'\u0012\b\b(\u0012\u0004\b\b(3\u0012\u0016\u0012\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\b0504\u0012\u0006\u0012\u0004\u0018\u00010\u0001\u0018\u00010&¢\u0006\n\n\u0002\u0010b\u001a\u0004\ba\u0010ZR\u0019\u00106\u001a\n\u0012\u0004\u0012\u00020\u0017\u0018\u00010\u0014¢\u0006\b\n\u0000\u001a\u0004\bc\u0010LR\u0011\u00107\u001a\u00020\u0011¢\u0006\b\n\u0000\u001a\u0004\bd\u0010KR\u0013\u00108\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\be\u0010=R\u0013\u00109\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\bf\u0010=¨\u0006\u0093\u0001"
    }
    d2 = {
        "Ldev/wiojelt/turksinema/common/WioSettingsConfig;",
        "",
        "brandPrefix",
        "",
        "brandSuffix",
        "brandTitleTag",
        "summarySubtitle",
        "brandColor",
        "",
        "brandColorBorder",
        "sheetBg",
        "cardBg",
        "cardBgSubtle",
        "textPrimary",
        "textSecondary",
        "textMuted",
        "englishLabels",
        "",
        "isTvBoxSupported",
        "isTvBoxActive",
        "Lkotlin/Function0;",
        "onTvBoxToggled",
        "Lkotlin/Function1;",
        "",
        "isScanDurationSupported",
        "scanDurationSeconds",
        "onScanDurationChanged",
        "minScanDurationSeconds",
        "maxScanDurationSeconds",
        "tvBoxScanDurationSeconds",
        "items",
        "",
        "Ldev/wiojelt/turksinema/common/WioProviderSettingItem;",
        "selectionTitle",
        "compactSelectionPresets",
        "selectionPresets",
        "Ldev/wiojelt/turksinema/common/WioSelectionPreset;",
        "onSelectionPreset",
        "Lkotlin/Function2;",
        "Lkotlin/ParameterName;",
        "name",
        "presetId",
        "",
        "providerIds",
        "onSelectAll",
        "onSelectRecommended",
        "onSelectNone",
        "onWizardClick",
        "onCustomListClick",
        "customListSummary",
        "onAutoScanDomains",
        "statusCallback",
        "Lkotlin/coroutines/Continuation;",
        "Lkotlin/Pair;",
        "onSaveAndClose",
        "providersCollapsible",
        "telegramUrl",
        "coffeeUrl",
        "<init>",
        "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIIIIIIIZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;IIILjava/util/List;Ljava/lang/String;ZLjava/util/List;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function0;ZLjava/lang/String;Ljava/lang/String;)V",
        "getBrandPrefix",
        "()Ljava/lang/String;",
        "getBrandSuffix",
        "getBrandTitleTag",
        "getSummarySubtitle",
        "getBrandColor",
        "()I",
        "getBrandColorBorder",
        "getSheetBg",
        "getCardBg",
        "getCardBgSubtle",
        "getTextPrimary",
        "getTextSecondary",
        "getTextMuted",
        "getEnglishLabels",
        "()Z",
        "()Lkotlin/jvm/functions/Function0;",
        "getOnTvBoxToggled",
        "()Lkotlin/jvm/functions/Function1;",
        "getScanDurationSeconds",
        "getOnScanDurationChanged",
        "getMinScanDurationSeconds",
        "getMaxScanDurationSeconds",
        "getTvBoxScanDurationSeconds",
        "getItems",
        "()Ljava/util/List;",
        "getSelectionTitle",
        "getCompactSelectionPresets",
        "getSelectionPresets",
        "getOnSelectionPreset",
        "()Lkotlin/jvm/functions/Function2;",
        "getOnSelectAll",
        "getOnSelectRecommended",
        "getOnSelectNone",
        "getOnWizardClick",
        "getOnCustomListClick",
        "getCustomListSummary",
        "getOnAutoScanDomains",
        "Lkotlin/jvm/functions/Function2;",
        "getOnSaveAndClose",
        "getProvidersCollapsible",
        "getTelegramUrl",
        "getCoffeeUrl",
        "component1",
        "component2",
        "component3",
        "component4",
        "component5",
        "component6",
        "component7",
        "component8",
        "component9",
        "component10",
        "component11",
        "component12",
        "component13",
        "component14",
        "component15",
        "component16",
        "component17",
        "component18",
        "component19",
        "component20",
        "component21",
        "component22",
        "component23",
        "component24",
        "component25",
        "component26",
        "component27",
        "component28",
        "component29",
        "component30",
        "component31",
        "component32",
        "component33",
        "component34",
        "component35",
        "component36",
        "component37",
        "component38",
        "copy",
        "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIIIIIIIZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;IIILjava/util/List;Ljava/lang/String;ZLjava/util/List;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function0;ZLjava/lang/String;Ljava/lang/String;)Ldev/wiojelt/turksinema/common/WioSettingsConfig;",
        "equals",
        "other",
        "hashCode",
        "toString",
        "DiziMom"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final brandColor:I

.field private final brandColorBorder:I

.field private final brandPrefix:Ljava/lang/String;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field private final brandSuffix:Ljava/lang/String;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field private final brandTitleTag:Ljava/lang/String;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field private final cardBg:I

.field private final cardBgSubtle:I

.field private final coffeeUrl:Ljava/lang/String;
    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation
.end field

.field private final compactSelectionPresets:Z

.field private final customListSummary:Ljava/lang/String;
    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation
.end field

.field private final englishLabels:Z

.field private final isScanDurationSupported:Z

.field private final isTvBoxActive:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field private final isTvBoxSupported:Z

.field private final items:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ldev/wiojelt/turksinema/common/WioProviderSettingItem;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field private final maxScanDurationSeconds:I

.field private final minScanDurationSeconds:I

.field private final onAutoScanDomains:Lkotlin/jvm/functions/Function2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function2<",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lkotlin/Pair<",
            "Ljava/lang/Integer;",
            "Ljava/lang/Integer;",
            ">;>;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation
.end field

.field private final onCustomListClick:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation
.end field

.field private final onSaveAndClose:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation
.end field

.field private final onScanDurationChanged:Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function1<",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field private final onSelectAll:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation
.end field

.field private final onSelectNone:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation
.end field

.field private final onSelectRecommended:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation
.end field

.field private final onSelectionPreset:Lkotlin/jvm/functions/Function2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function2<",
            "Ljava/lang/String;",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation
.end field

.field private final onTvBoxToggled:Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function1<",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field private final onWizardClick:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation
.end field

.field private final providersCollapsible:Z

.field private final scanDurationSeconds:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field private final selectionPresets:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ldev/wiojelt/turksinema/common/WioSelectionPreset;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field private final selectionTitle:Ljava/lang/String;
    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation
.end field

.field private final sheetBg:I

.field private final summarySubtitle:Ljava/lang/String;
    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation
.end field

.field private final telegramUrl:Ljava/lang/String;
    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation
.end field

.field private final textMuted:I

.field private final textPrimary:I

.field private final textSecondary:I

.field private final tvBoxScanDurationSeconds:I


# direct methods
.method public constructor <init>()V
    .registers 43

    const/16 v40, 0x3f

    const/16 v41, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    const/16 v21, 0x0

    const/16 v22, 0x0

    const/16 v23, 0x0

    const/16 v24, 0x0

    const/16 v25, 0x0

    const/16 v26, 0x0

    const/16 v27, 0x0

    const/16 v28, 0x0

    const/16 v29, 0x0

    const/16 v30, 0x0

    const/16 v31, 0x0

    const/16 v32, 0x0

    const/16 v33, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    const/16 v36, 0x0

    const/16 v37, 0x0

    const/16 v38, 0x0

    const/16 v39, -0x1

    move-object/from16 v0, p0

    invoke-direct/range {v0 .. v41}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIIIIIIIZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;IIILjava/util/List;Ljava/lang/String;ZLjava/util/List;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function0;ZLjava/lang/String;Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIIIIIIIZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;IIILjava/util/List;Ljava/lang/String;ZLjava/util/List;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function0;ZLjava/lang/String;Ljava/lang/String;)V
    .registers 55
    .param p1, "brandPrefix"  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p2, "brandSuffix"  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p3, "brandTitleTag"  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p4, "summarySubtitle"  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/Nullable;
        .end annotation
    .end param
    .param p5, "brandColor"  # I
    .param p6, "brandColorBorder"  # I
    .param p7, "sheetBg"  # I
    .param p8, "cardBg"  # I
    .param p9, "cardBgSubtle"  # I
    .param p10, "textPrimary"  # I
    .param p11, "textSecondary"  # I
    .param p12, "textMuted"  # I
    .param p13, "englishLabels"  # Z
    .param p14, "isTvBoxSupported"  # Z
    .param p15, "isTvBoxActive"  # Lkotlin/jvm/functions/Function0;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p16, "onTvBoxToggled"  # Lkotlin/jvm/functions/Function1;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p17, "isScanDurationSupported"  # Z
    .param p18, "scanDurationSeconds"  # Lkotlin/jvm/functions/Function0;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p19, "onScanDurationChanged"  # Lkotlin/jvm/functions/Function1;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p20, "minScanDurationSeconds"  # I
    .param p21, "maxScanDurationSeconds"  # I
    .param p22, "tvBoxScanDurationSeconds"  # I
    .param p23, "items"  # Ljava/util/List;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p24, "selectionTitle"  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/Nullable;
        .end annotation
    .end param
    .param p25, "compactSelectionPresets"  # Z
    .param p26, "selectionPresets"  # Ljava/util/List;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p27, "onSelectionPreset"  # Lkotlin/jvm/functions/Function2;
        .annotation build Lorg/jetbrains/annotations/Nullable;
        .end annotation
    .end param
    .param p28, "onSelectAll"  # Lkotlin/jvm/functions/Function0;
        .annotation build Lorg/jetbrains/annotations/Nullable;
        .end annotation
    .end param
    .param p29, "onSelectRecommended"  # Lkotlin/jvm/functions/Function0;
        .annotation build Lorg/jetbrains/annotations/Nullable;
        .end annotation
    .end param
    .param p30, "onSelectNone"  # Lkotlin/jvm/functions/Function0;
        .annotation build Lorg/jetbrains/annotations/Nullable;
        .end annotation
    .end param
    .param p31, "onWizardClick"  # Lkotlin/jvm/functions/Function0;
        .annotation build Lorg/jetbrains/annotations/Nullable;
        .end annotation
    .end param
    .param p32, "onCustomListClick"  # Lkotlin/jvm/functions/Function0;
        .annotation build Lorg/jetbrains/annotations/Nullable;
        .end annotation
    .end param
    .param p33, "customListSummary"  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/Nullable;
        .end annotation
    .end param
    .param p34, "onAutoScanDomains"  # Lkotlin/jvm/functions/Function2;
        .annotation build Lorg/jetbrains/annotations/Nullable;
        .end annotation
    .end param
    .param p35, "onSaveAndClose"  # Lkotlin/jvm/functions/Function0;
        .annotation build Lorg/jetbrains/annotations/Nullable;
        .end annotation
    .end param
    .param p36, "providersCollapsible"  # Z
    .param p37, "telegramUrl"  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/Nullable;
        .end annotation
    .end param
    .param p38, "coffeeUrl"  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/Nullable;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "IIIIIIIIZZ",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;Z",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Integer;",
            ">;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;III",
            "Ljava/util/List<",
            "Ldev/wiojelt/turksinema/common/WioProviderSettingItem;",
            ">;",
            "Ljava/lang/String;",
            "Z",
            "Ljava/util/List<",
            "Ldev/wiojelt/turksinema/common/WioSelectionPreset;",
            ">;",
            "Lkotlin/jvm/functions/Function2<",
            "-",
            "Ljava/lang/String;",
            "-",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function2<",
            "-",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;-",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lkotlin/Pair<",
            "Ljava/lang/Integer;",
            "Ljava/lang/Integer;",
            ">;>;+",
            "Ljava/lang/Object;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;Z",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 53
    move-object/from16 v0, p0

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 54
    move-object/from16 v1, p1

    iput-object v1, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->brandPrefix:Ljava/lang/String;

    .line 55
    move-object/from16 v2, p2

    iput-object v2, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->brandSuffix:Ljava/lang/String;

    .line 56
    move-object/from16 v3, p3

    iput-object v3, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->brandTitleTag:Ljava/lang/String;

    .line 57
    move-object/from16 v4, p4

    iput-object v4, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->summarySubtitle:Ljava/lang/String;

    .line 58
    move/from16 v5, p5

    iput v5, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->brandColor:I

    .line 59
    move/from16 v6, p6

    iput v6, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->brandColorBorder:I

    .line 60
    move/from16 v7, p7

    iput v7, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->sheetBg:I

    .line 61
    move/from16 v8, p8

    iput v8, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->cardBg:I

    .line 62
    move/from16 v9, p9

    iput v9, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->cardBgSubtle:I

    .line 63
    move/from16 v10, p10

    iput v10, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->textPrimary:I

    .line 64
    move/from16 v11, p11

    iput v11, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->textSecondary:I

    .line 65
    move/from16 v12, p12

    iput v12, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->textMuted:I

    .line 67
    move/from16 v13, p13

    iput-boolean v13, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->englishLabels:Z

    .line 68
    move/from16 v14, p14

    iput-boolean v14, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->isTvBoxSupported:Z

    .line 69
    move-object/from16 v15, p15

    iput-object v15, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->isTvBoxActive:Lkotlin/jvm/functions/Function0;

    .line 70
    move-object/from16 v1, p16

    iput-object v1, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onTvBoxToggled:Lkotlin/jvm/functions/Function1;

    .line 71
    move/from16 v1, p17

    iput-boolean v1, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->isScanDurationSupported:Z

    .line 72
    move-object/from16 v1, p18

    iput-object v1, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->scanDurationSeconds:Lkotlin/jvm/functions/Function0;

    .line 73
    move-object/from16 v1, p19

    iput-object v1, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onScanDurationChanged:Lkotlin/jvm/functions/Function1;

    .line 74
    move/from16 v1, p20

    iput v1, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->minScanDurationSeconds:I

    .line 75
    move/from16 v1, p21

    iput v1, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->maxScanDurationSeconds:I

    .line 76
    move/from16 v1, p22

    iput v1, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->tvBoxScanDurationSeconds:I

    .line 77
    move-object/from16 v1, p23

    iput-object v1, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->items:Ljava/util/List;

    .line 78
    move-object/from16 v1, p24

    iput-object v1, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->selectionTitle:Ljava/lang/String;

    .line 79
    move/from16 v1, p25

    iput-boolean v1, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->compactSelectionPresets:Z

    .line 80
    move-object/from16 v1, p26

    iput-object v1, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->selectionPresets:Ljava/util/List;

    .line 81
    move-object/from16 v1, p27

    iput-object v1, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onSelectionPreset:Lkotlin/jvm/functions/Function2;

    .line 82
    move-object/from16 v1, p28

    iput-object v1, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onSelectAll:Lkotlin/jvm/functions/Function0;

    .line 83
    move-object/from16 v1, p29

    iput-object v1, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onSelectRecommended:Lkotlin/jvm/functions/Function0;

    .line 84
    move-object/from16 v1, p30

    iput-object v1, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onSelectNone:Lkotlin/jvm/functions/Function0;

    .line 85
    move-object/from16 v1, p31

    iput-object v1, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onWizardClick:Lkotlin/jvm/functions/Function0;

    .line 86
    move-object/from16 v1, p32

    iput-object v1, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onCustomListClick:Lkotlin/jvm/functions/Function0;

    .line 87
    move-object/from16 v1, p33

    iput-object v1, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->customListSummary:Ljava/lang/String;

    .line 88
    move-object/from16 v1, p34

    iput-object v1, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onAutoScanDomains:Lkotlin/jvm/functions/Function2;

    .line 89
    move-object/from16 v1, p35

    iput-object v1, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onSaveAndClose:Lkotlin/jvm/functions/Function0;

    .line 90
    move/from16 v1, p36

    iput-boolean v1, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->providersCollapsible:Z

    .line 91
    move-object/from16 v1, p37

    iput-object v1, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->telegramUrl:Ljava/lang/String;

    .line 92
    move-object/from16 v1, p38

    iput-object v1, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->coffeeUrl:Ljava/lang/String;

    .line 53
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIIIIIIIZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;IIILjava/util/List;Ljava/lang/String;ZLjava/util/List;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function0;ZLjava/lang/String;Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .registers 80

    .line 53
    move/from16 v0, p39

    and-int/lit8 v1, v0, 0x1

    if-eqz v1, :cond_9

    .line 54
    const-string v1, "WIO"

    goto :goto_b

    .line 53
    :cond_9
    move-object/from16 v1, p1

    :goto_b
    and-int/lit8 v2, v0, 0x2

    if-eqz v2, :cond_12

    .line 55
    const-string v2, "SİNEMA"

    goto :goto_14

    .line 53
    :cond_12
    move-object/from16 v2, p2

    :goto_14
    and-int/lit8 v3, v0, 0x4

    if-eqz v3, :cond_1b

    .line 56
    const-string v3, "Kontrol Paneli"

    goto :goto_1d

    .line 53
    :cond_1b
    move-object/from16 v3, p3

    :goto_1d
    and-int/lit8 v4, v0, 0x8

    if-eqz v4, :cond_23

    .line 57
    const/4 v4, 0x0

    goto :goto_25

    .line 53
    :cond_23
    move-object/from16 v4, p4

    :goto_25
    and-int/lit8 v6, v0, 0x10

    if-eqz v6, :cond_30

    .line 58
    const-string v6, "#FFB703"

    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v6

    goto :goto_32

    .line 53
    :cond_30
    move/from16 v6, p5

    :goto_32
    and-int/lit8 v7, v0, 0x20

    if-eqz v7, :cond_3d

    .line 59
    const-string v7, "#33FFFFFF"

    invoke-static {v7}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v7

    goto :goto_3f

    .line 53
    :cond_3d
    move/from16 v7, p6

    :goto_3f
    and-int/lit8 v8, v0, 0x40

    if-eqz v8, :cond_4a

    .line 60
    const-string v8, "#F20D0E12"

    invoke-static {v8}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v8

    goto :goto_4c

    .line 53
    :cond_4a
    move/from16 v8, p7

    :goto_4c
    and-int/lit16 v9, v0, 0x80

    if-eqz v9, :cond_57

    .line 61
    const-string v9, "#E6161820"

    invoke-static {v9}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v9

    goto :goto_59

    .line 53
    :cond_57
    move/from16 v9, p8

    :goto_59
    and-int/lit16 v10, v0, 0x100

    if-eqz v10, :cond_64

    .line 62
    const-string v10, "#B3161820"

    invoke-static {v10}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v10

    goto :goto_66

    .line 53
    :cond_64
    move/from16 v10, p9

    :goto_66
    and-int/lit16 v11, v0, 0x200

    if-eqz v11, :cond_71

    .line 63
    const-string v11, "#FFFFFF"

    invoke-static {v11}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v11

    goto :goto_73

    .line 53
    :cond_71
    move/from16 v11, p10

    :goto_73
    and-int/lit16 v12, v0, 0x400

    if-eqz v12, :cond_7e

    .line 64
    const-string v12, "#8E95A5"

    invoke-static {v12}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v12

    goto :goto_80

    .line 53
    :cond_7e
    move/from16 v12, p11

    :goto_80
    and-int/lit16 v13, v0, 0x800

    if-eqz v13, :cond_8b

    .line 65
    const-string v13, "#6E7681"

    invoke-static {v13}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v13

    goto :goto_8d

    .line 53
    :cond_8b
    move/from16 v13, p12

    :goto_8d
    and-int/lit16 v14, v0, 0x1000

    if-eqz v14, :cond_93

    .line 67
    const/4 v14, 0x0

    goto :goto_95

    .line 53
    :cond_93
    move/from16 v14, p13

    :goto_95
    and-int/lit16 v5, v0, 0x2000

    if-eqz v5, :cond_9b

    .line 68
    const/4 v5, 0x1

    goto :goto_9d

    .line 53
    :cond_9b
    move/from16 v5, p14

    :goto_9d
    and-int/lit16 v15, v0, 0x4000

    if-eqz v15, :cond_a7

    .line 69
    new-instance v15, Ldev/wiojelt/turksinema/common/WioSettingsConfig$$ExternalSyntheticLambda1;

    invoke-direct {v15}, Ldev/wiojelt/turksinema/common/WioSettingsConfig$$ExternalSyntheticLambda1;-><init>()V

    goto :goto_a9

    .line 53
    :cond_a7
    move-object/from16 v15, p15

    :goto_a9
    const v16, 0x8000

    and-int v16, v0, v16

    if-eqz v16, :cond_b6

    .line 70
    new-instance v16, Ldev/wiojelt/turksinema/common/WioSettingsConfig$$ExternalSyntheticLambda2;

    invoke-direct/range {v16 .. v16}, Ldev/wiojelt/turksinema/common/WioSettingsConfig$$ExternalSyntheticLambda2;-><init>()V

    goto :goto_b8

    .line 53
    :cond_b6
    move-object/from16 v16, p16

    :goto_b8
    const/high16 v17, 0x10000

    and-int v17, v0, v17

    if-eqz v17, :cond_c1

    .line 71
    const/16 v17, 0x0

    goto :goto_c3

    .line 53
    :cond_c1
    move/from16 v17, p17

    :goto_c3
    const/high16 v18, 0x20000

    and-int v18, v0, v18

    if-eqz v18, :cond_cf

    .line 72
    new-instance v18, Ldev/wiojelt/turksinema/common/WioSettingsConfig$$ExternalSyntheticLambda3;

    invoke-direct/range {v18 .. v18}, Ldev/wiojelt/turksinema/common/WioSettingsConfig$$ExternalSyntheticLambda3;-><init>()V

    goto :goto_d1

    .line 53
    :cond_cf
    move-object/from16 v18, p18

    :goto_d1
    const/high16 v19, 0x40000

    and-int v19, v0, v19

    if-eqz v19, :cond_dd

    .line 73
    new-instance v19, Ldev/wiojelt/turksinema/common/WioSettingsConfig$$ExternalSyntheticLambda4;

    invoke-direct/range {v19 .. v19}, Ldev/wiojelt/turksinema/common/WioSettingsConfig$$ExternalSyntheticLambda4;-><init>()V

    goto :goto_df

    .line 53
    :cond_dd
    move-object/from16 v19, p19

    :goto_df
    const/high16 v20, 0x80000

    and-int v20, v0, v20

    const/16 v21, 0xa

    if-eqz v20, :cond_ea

    .line 74
    move/from16 v20, v21

    goto :goto_ec

    .line 53
    :cond_ea
    move/from16 v20, p20

    :goto_ec
    const/high16 v22, 0x100000

    and-int v22, v0, v22

    if-eqz v22, :cond_f5

    .line 75
    const/16 v22, 0x1e

    goto :goto_f7

    .line 53
    :cond_f5
    move/from16 v22, p21

    :goto_f7
    const/high16 v23, 0x200000

    and-int v23, v0, v23

    if-eqz v23, :cond_fe

    .line 76
    goto :goto_100

    .line 53
    :cond_fe
    move/from16 v21, p22

    :goto_100
    const/high16 v23, 0x400000

    and-int v23, v0, v23

    if-eqz v23, :cond_10b

    .line 77
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v23

    goto :goto_10d

    .line 53
    :cond_10b
    move-object/from16 v23, p23

    :goto_10d
    const/high16 v24, 0x800000

    and-int v24, v0, v24

    if-eqz v24, :cond_116

    .line 78
    const-string v24, "Dil tercihi"

    goto :goto_118

    .line 53
    :cond_116
    move-object/from16 v24, p24

    :goto_118
    const/high16 v25, 0x1000000

    and-int v25, v0, v25

    if-eqz v25, :cond_121

    .line 79
    const/16 v25, 0x0

    goto :goto_123

    .line 53
    :cond_121
    move/from16 v25, p25

    :goto_123
    const/high16 v26, 0x2000000

    and-int v26, v0, v26

    if-eqz v26, :cond_12e

    .line 80
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v26

    goto :goto_130

    .line 53
    :cond_12e
    move-object/from16 v26, p26

    :goto_130
    const/high16 v27, 0x4000000

    and-int v27, v0, v27

    if-eqz v27, :cond_139

    .line 81
    const/16 v27, 0x0

    goto :goto_13b

    .line 53
    :cond_139
    move-object/from16 v27, p27

    :goto_13b
    const/high16 v28, 0x8000000

    and-int v28, v0, v28

    if-eqz v28, :cond_144

    .line 82
    const/16 v28, 0x0

    goto :goto_146

    .line 53
    :cond_144
    move-object/from16 v28, p28

    :goto_146
    const/high16 v29, 0x10000000

    and-int v29, v0, v29

    if-eqz v29, :cond_14f

    .line 83
    const/16 v29, 0x0

    goto :goto_151

    .line 53
    :cond_14f
    move-object/from16 v29, p29

    :goto_151
    const/high16 v30, 0x20000000

    and-int v30, v0, v30

    if-eqz v30, :cond_15a

    .line 84
    const/16 v30, 0x0

    goto :goto_15c

    .line 53
    :cond_15a
    move-object/from16 v30, p30

    :goto_15c
    const/high16 v31, 0x40000000  # 2.0f

    and-int v31, v0, v31

    if-eqz v31, :cond_165

    .line 85
    const/16 v31, 0x0

    goto :goto_167

    .line 53
    :cond_165
    move-object/from16 v31, p31

    :goto_167
    const/high16 v32, -0x80000000

    and-int v0, v0, v32

    if-eqz v0, :cond_16f

    .line 86
    const/4 v0, 0x0

    goto :goto_171

    .line 53
    :cond_16f
    move-object/from16 v0, p32

    :goto_171
    and-int/lit8 v32, p40, 0x1

    if-eqz v32, :cond_178

    .line 87
    const/16 v32, 0x0

    goto :goto_17a

    .line 53
    :cond_178
    move-object/from16 v32, p33

    :goto_17a
    and-int/lit8 v33, p40, 0x2

    if-eqz v33, :cond_181

    .line 88
    const/16 v33, 0x0

    goto :goto_183

    .line 53
    :cond_181
    move-object/from16 v33, p34

    :goto_183
    and-int/lit8 v34, p40, 0x4

    if-eqz v34, :cond_18a

    .line 89
    const/16 v34, 0x0

    goto :goto_18c

    .line 53
    :cond_18a
    move-object/from16 v34, p35

    :goto_18c
    and-int/lit8 v35, p40, 0x8

    if-eqz v35, :cond_193

    .line 90
    const/16 v35, 0x0

    goto :goto_195

    .line 53
    :cond_193
    move/from16 v35, p36

    :goto_195
    and-int/lit8 v36, p40, 0x10

    if-eqz v36, :cond_19c

    .line 91
    const-string v36, "https://t.me/wiolandcs3"

    goto :goto_19e

    .line 53
    :cond_19c
    move-object/from16 v36, p37

    :goto_19e
    and-int/lit8 v37, p40, 0x20

    if-eqz v37, :cond_1a5

    .line 92
    const-string v37, "https://kreosus.com/wiojelt"

    goto :goto_1a7

    .line 53
    :cond_1a5
    move-object/from16 v37, p38

    :goto_1a7
    move-object/from16 p1, p0

    move-object/from16 p33, v0

    move-object/from16 p2, v1

    move-object/from16 p3, v2

    move-object/from16 p4, v3

    move-object/from16 p5, v4

    move/from16 p15, v5

    move/from16 p6, v6

    move/from16 p7, v7

    move/from16 p8, v8

    move/from16 p9, v9

    move/from16 p10, v10

    move/from16 p11, v11

    move/from16 p12, v12

    move/from16 p13, v13

    move/from16 p14, v14

    move-object/from16 p16, v15

    move-object/from16 p17, v16

    move/from16 p18, v17

    move-object/from16 p19, v18

    move-object/from16 p20, v19

    move/from16 p21, v20

    move/from16 p23, v21

    move/from16 p22, v22

    move-object/from16 p24, v23

    move-object/from16 p25, v24

    move/from16 p26, v25

    move-object/from16 p27, v26

    move-object/from16 p28, v27

    move-object/from16 p29, v28

    move-object/from16 p30, v29

    move-object/from16 p31, v30

    move-object/from16 p32, v31

    move-object/from16 p34, v32

    move-object/from16 p35, v33

    move-object/from16 p36, v34

    move/from16 p37, v35

    move-object/from16 p38, v36

    move-object/from16 p39, v37

    invoke-direct/range {p1 .. p39}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIIIIIIIZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;IIILjava/util/List;Ljava/lang/String;ZLjava/util/List;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function0;ZLjava/lang/String;Ljava/lang/String;)V

    .line 93
    return-void
.end method

.method static final _init_$lambda$0()Z
    .registers 1

    .line 69
    const/4 v0, 0x0

    return v0
.end method

.method static final _init_$lambda$1(Z)Lkotlin/Unit;
    .registers 2
    .param p0, "it"  # Z

    .line 70
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final _init_$lambda$2()I
    .registers 1

    .line 72
    const/16 v0, 0x1e

    return v0
.end method

.method static final _init_$lambda$3(I)Lkotlin/Unit;
    .registers 2
    .param p0, "it"  # I

    .line 73
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public static synthetic copy$default(Ldev/wiojelt/turksinema/common/WioSettingsConfig;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIIIIIIIZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;IIILjava/util/List;Ljava/lang/String;ZLjava/util/List;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function0;ZLjava/lang/String;Ljava/lang/String;IILjava/lang/Object;)Ldev/wiojelt/turksinema/common/WioSettingsConfig;
    .registers 59

    move-object/from16 v0, p0

    move/from16 v1, p39

    and-int/lit8 v2, v1, 0x1

    if-eqz v2, :cond_b

    iget-object v2, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->brandPrefix:Ljava/lang/String;

    goto :goto_d

    :cond_b
    move-object/from16 v2, p1

    :goto_d
    and-int/lit8 v3, v1, 0x2

    if-eqz v3, :cond_14

    iget-object v3, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->brandSuffix:Ljava/lang/String;

    goto :goto_16

    :cond_14
    move-object/from16 v3, p2

    :goto_16
    and-int/lit8 v4, v1, 0x4

    if-eqz v4, :cond_1d

    iget-object v4, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->brandTitleTag:Ljava/lang/String;

    goto :goto_1f

    :cond_1d
    move-object/from16 v4, p3

    :goto_1f
    and-int/lit8 v5, v1, 0x8

    if-eqz v5, :cond_26

    iget-object v5, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->summarySubtitle:Ljava/lang/String;

    goto :goto_28

    :cond_26
    move-object/from16 v5, p4

    :goto_28
    and-int/lit8 v6, v1, 0x10

    if-eqz v6, :cond_2f

    iget v6, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->brandColor:I

    goto :goto_31

    :cond_2f
    move/from16 v6, p5

    :goto_31
    and-int/lit8 v7, v1, 0x20

    if-eqz v7, :cond_38

    iget v7, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->brandColorBorder:I

    goto :goto_3a

    :cond_38
    move/from16 v7, p6

    :goto_3a
    and-int/lit8 v8, v1, 0x40

    if-eqz v8, :cond_41

    iget v8, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->sheetBg:I

    goto :goto_43

    :cond_41
    move/from16 v8, p7

    :goto_43
    and-int/lit16 v9, v1, 0x80

    if-eqz v9, :cond_4a

    iget v9, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->cardBg:I

    goto :goto_4c

    :cond_4a
    move/from16 v9, p8

    :goto_4c
    and-int/lit16 v10, v1, 0x100

    if-eqz v10, :cond_53

    iget v10, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->cardBgSubtle:I

    goto :goto_55

    :cond_53
    move/from16 v10, p9

    :goto_55
    and-int/lit16 v11, v1, 0x200

    if-eqz v11, :cond_5c

    iget v11, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->textPrimary:I

    goto :goto_5e

    :cond_5c
    move/from16 v11, p10

    :goto_5e
    and-int/lit16 v12, v1, 0x400

    if-eqz v12, :cond_65

    iget v12, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->textSecondary:I

    goto :goto_67

    :cond_65
    move/from16 v12, p11

    :goto_67
    and-int/lit16 v13, v1, 0x800

    if-eqz v13, :cond_6e

    iget v13, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->textMuted:I

    goto :goto_70

    :cond_6e
    move/from16 v13, p12

    :goto_70
    and-int/lit16 v14, v1, 0x1000

    if-eqz v14, :cond_77

    iget-boolean v14, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->englishLabels:Z

    goto :goto_79

    :cond_77
    move/from16 v14, p13

    :goto_79
    and-int/lit16 v15, v1, 0x2000

    if-eqz v15, :cond_80

    iget-boolean v15, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->isTvBoxSupported:Z

    goto :goto_82

    :cond_80
    move/from16 v15, p14

    :goto_82
    move-object/from16 p1, v2

    and-int/lit16 v2, v1, 0x4000

    if-eqz v2, :cond_8b

    iget-object v2, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->isTvBoxActive:Lkotlin/jvm/functions/Function0;

    goto :goto_8d

    :cond_8b
    move-object/from16 v2, p15

    :goto_8d
    const v16, 0x8000

    and-int v16, v1, v16

    if-eqz v16, :cond_97

    iget-object v1, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onTvBoxToggled:Lkotlin/jvm/functions/Function1;

    goto :goto_99

    :cond_97
    move-object/from16 v1, p16

    :goto_99
    const/high16 v16, 0x10000

    and-int v16, p39, v16

    move-object/from16 p2, v1

    if-eqz v16, :cond_a4

    iget-boolean v1, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->isScanDurationSupported:Z

    goto :goto_a6

    :cond_a4
    move/from16 v1, p17

    :goto_a6
    const/high16 v16, 0x20000

    and-int v16, p39, v16

    move/from16 p3, v1

    if-eqz v16, :cond_b1

    iget-object v1, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->scanDurationSeconds:Lkotlin/jvm/functions/Function0;

    goto :goto_b3

    :cond_b1
    move-object/from16 v1, p18

    :goto_b3
    const/high16 v16, 0x40000

    and-int v16, p39, v16

    move-object/from16 p4, v1

    if-eqz v16, :cond_be

    iget-object v1, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onScanDurationChanged:Lkotlin/jvm/functions/Function1;

    goto :goto_c0

    :cond_be
    move-object/from16 v1, p19

    :goto_c0
    const/high16 v16, 0x80000

    and-int v16, p39, v16

    move-object/from16 p5, v1

    if-eqz v16, :cond_cb

    iget v1, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->minScanDurationSeconds:I

    goto :goto_cd

    :cond_cb
    move/from16 v1, p20

    :goto_cd
    const/high16 v16, 0x100000

    and-int v16, p39, v16

    move/from16 p6, v1

    if-eqz v16, :cond_d8

    iget v1, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->maxScanDurationSeconds:I

    goto :goto_da

    :cond_d8
    move/from16 v1, p21

    :goto_da
    const/high16 v16, 0x200000

    and-int v16, p39, v16

    move/from16 p7, v1

    if-eqz v16, :cond_e5

    iget v1, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->tvBoxScanDurationSeconds:I

    goto :goto_e7

    :cond_e5
    move/from16 v1, p22

    :goto_e7
    const/high16 v16, 0x400000

    and-int v16, p39, v16

    move/from16 p8, v1

    if-eqz v16, :cond_f2

    iget-object v1, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->items:Ljava/util/List;

    goto :goto_f4

    :cond_f2
    move-object/from16 v1, p23

    :goto_f4
    const/high16 v16, 0x800000

    and-int v16, p39, v16

    move-object/from16 p9, v1

    if-eqz v16, :cond_ff

    iget-object v1, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->selectionTitle:Ljava/lang/String;

    goto :goto_101

    :cond_ff
    move-object/from16 v1, p24

    :goto_101
    const/high16 v16, 0x1000000

    and-int v16, p39, v16

    move-object/from16 p10, v1

    if-eqz v16, :cond_10c

    iget-boolean v1, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->compactSelectionPresets:Z

    goto :goto_10e

    :cond_10c
    move/from16 v1, p25

    :goto_10e
    const/high16 v16, 0x2000000

    and-int v16, p39, v16

    move/from16 p11, v1

    if-eqz v16, :cond_119

    iget-object v1, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->selectionPresets:Ljava/util/List;

    goto :goto_11b

    :cond_119
    move-object/from16 v1, p26

    :goto_11b
    const/high16 v16, 0x4000000

    and-int v16, p39, v16

    move-object/from16 p12, v1

    if-eqz v16, :cond_126

    iget-object v1, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onSelectionPreset:Lkotlin/jvm/functions/Function2;

    goto :goto_128

    :cond_126
    move-object/from16 v1, p27

    :goto_128
    const/high16 v16, 0x8000000

    and-int v16, p39, v16

    move-object/from16 p13, v1

    if-eqz v16, :cond_133

    iget-object v1, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onSelectAll:Lkotlin/jvm/functions/Function0;

    goto :goto_135

    :cond_133
    move-object/from16 v1, p28

    :goto_135
    const/high16 v16, 0x10000000

    and-int v16, p39, v16

    move-object/from16 p14, v1

    if-eqz v16, :cond_140

    iget-object v1, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onSelectRecommended:Lkotlin/jvm/functions/Function0;

    goto :goto_142

    :cond_140
    move-object/from16 v1, p29

    :goto_142
    const/high16 v16, 0x20000000

    and-int v16, p39, v16

    move-object/from16 p15, v1

    if-eqz v16, :cond_14d

    iget-object v1, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onSelectNone:Lkotlin/jvm/functions/Function0;

    goto :goto_14f

    :cond_14d
    move-object/from16 v1, p30

    :goto_14f
    const/high16 v16, 0x40000000  # 2.0f

    and-int v16, p39, v16

    move-object/from16 p16, v1

    if-eqz v16, :cond_15a

    iget-object v1, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onWizardClick:Lkotlin/jvm/functions/Function0;

    goto :goto_15c

    :cond_15a
    move-object/from16 v1, p31

    :goto_15c
    const/high16 v16, -0x80000000

    and-int v16, p39, v16

    move-object/from16 p17, v1

    if-eqz v16, :cond_167

    iget-object v1, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onCustomListClick:Lkotlin/jvm/functions/Function0;

    goto :goto_169

    :cond_167
    move-object/from16 v1, p32

    :goto_169
    and-int/lit8 v16, p40, 0x1

    move-object/from16 p18, v1

    if-eqz v16, :cond_172

    iget-object v1, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->customListSummary:Ljava/lang/String;

    goto :goto_174

    :cond_172
    move-object/from16 v1, p33

    :goto_174
    and-int/lit8 v16, p40, 0x2

    move-object/from16 p19, v1

    if-eqz v16, :cond_17d

    iget-object v1, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onAutoScanDomains:Lkotlin/jvm/functions/Function2;

    goto :goto_17f

    :cond_17d
    move-object/from16 v1, p34

    :goto_17f
    and-int/lit8 v16, p40, 0x4

    move-object/from16 p20, v1

    if-eqz v16, :cond_188

    iget-object v1, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onSaveAndClose:Lkotlin/jvm/functions/Function0;

    goto :goto_18a

    :cond_188
    move-object/from16 v1, p35

    :goto_18a
    and-int/lit8 v16, p40, 0x8

    move-object/from16 p21, v1

    if-eqz v16, :cond_193

    iget-boolean v1, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->providersCollapsible:Z

    goto :goto_195

    :cond_193
    move/from16 v1, p36

    :goto_195
    and-int/lit8 v16, p40, 0x10

    move/from16 p22, v1

    if-eqz v16, :cond_19e

    iget-object v1, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->telegramUrl:Ljava/lang/String;

    goto :goto_1a0

    :cond_19e
    move-object/from16 v1, p37

    :goto_1a0
    and-int/lit8 v16, p40, 0x20

    if-eqz v16, :cond_1f3

    move-object/from16 p23, v1

    iget-object v1, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->coffeeUrl:Ljava/lang/String;

    move-object/from16 p38, p23

    move-object/from16 p39, v1

    move-object/from16 p24, p9

    move-object/from16 p25, p10

    move/from16 p26, p11

    move-object/from16 p27, p12

    move-object/from16 p28, p13

    move-object/from16 p29, p14

    move-object/from16 p30, p15

    move-object/from16 p31, p16

    move-object/from16 p32, p17

    move-object/from16 p33, p18

    move-object/from16 p34, p19

    move-object/from16 p35, p20

    move-object/from16 p36, p21

    move/from16 p37, p22

    move-object/from16 p16, v2

    move/from16 p9, v9

    move/from16 p10, v10

    move/from16 p11, v11

    move/from16 p12, v12

    move/from16 p13, v13

    move/from16 p14, v14

    move/from16 p15, v15

    move-object/from16 p17, p2

    move/from16 p18, p3

    move-object/from16 p19, p4

    move-object/from16 p20, p5

    move/from16 p21, p6

    move/from16 p22, p7

    move/from16 p23, p8

    move-object/from16 p3, v3

    move-object/from16 p4, v4

    move-object/from16 p5, v5

    move/from16 p6, v6

    move/from16 p7, v7

    move/from16 p8, v8

    goto :goto_23d

    :cond_1f3
    move-object/from16 p39, p38

    move-object/from16 p38, v1

    move/from16 p23, p8

    move-object/from16 p24, p9

    move-object/from16 p25, p10

    move/from16 p26, p11

    move-object/from16 p27, p12

    move-object/from16 p28, p13

    move-object/from16 p29, p14

    move-object/from16 p30, p15

    move-object/from16 p31, p16

    move-object/from16 p32, p17

    move-object/from16 p33, p18

    move-object/from16 p34, p19

    move-object/from16 p35, p20

    move-object/from16 p36, p21

    move/from16 p37, p22

    move-object/from16 p16, v2

    move/from16 p8, v8

    move/from16 p9, v9

    move/from16 p10, v10

    move/from16 p11, v11

    move/from16 p12, v12

    move/from16 p13, v13

    move/from16 p14, v14

    move/from16 p15, v15

    move-object/from16 p17, p2

    move/from16 p18, p3

    move-object/from16 p19, p4

    move-object/from16 p20, p5

    move/from16 p21, p6

    move/from16 p22, p7

    move-object/from16 p3, v3

    move-object/from16 p4, v4

    move-object/from16 p5, v5

    move/from16 p6, v6

    move/from16 p7, v7

    :goto_23d
    move-object/from16 p2, p1

    move-object/from16 p1, v0

    invoke-virtual/range {p1 .. p39}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIIIIIIIZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;IIILjava/util/List;Ljava/lang/String;ZLjava/util/List;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function0;ZLjava/lang/String;Ljava/lang/String;)Ldev/wiojelt/turksinema/common/WioSettingsConfig;

    move-result-object v0

    return-object v0
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .registers 2
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->brandPrefix:Ljava/lang/String;

    return-object v0
.end method

.method public final component10()I
    .registers 2

    iget v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->textPrimary:I

    return v0
.end method

.method public final component11()I
    .registers 2

    iget v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->textSecondary:I

    return v0
.end method

.method public final component12()I
    .registers 2

    iget v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->textMuted:I

    return v0
.end method

.method public final component13()Z
    .registers 2

    iget-boolean v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->englishLabels:Z

    return v0
.end method

.method public final component14()Z
    .registers 2

    iget-boolean v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->isTvBoxSupported:Z

    return v0
.end method

.method public final component15()Lkotlin/jvm/functions/Function0;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->isTvBoxActive:Lkotlin/jvm/functions/Function0;

    return-object v0
.end method

.method public final component16()Lkotlin/jvm/functions/Function1;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function1<",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onTvBoxToggled:Lkotlin/jvm/functions/Function1;

    return-object v0
.end method

.method public final component17()Z
    .registers 2

    iget-boolean v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->isScanDurationSupported:Z

    return v0
.end method

.method public final component18()Lkotlin/jvm/functions/Function0;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->scanDurationSeconds:Lkotlin/jvm/functions/Function0;

    return-object v0
.end method

.method public final component19()Lkotlin/jvm/functions/Function1;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function1<",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onScanDurationChanged:Lkotlin/jvm/functions/Function1;

    return-object v0
.end method

.method public final component2()Ljava/lang/String;
    .registers 2
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->brandSuffix:Ljava/lang/String;

    return-object v0
.end method

.method public final component20()I
    .registers 2

    iget v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->minScanDurationSeconds:I

    return v0
.end method

.method public final component21()I
    .registers 2

    iget v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->maxScanDurationSeconds:I

    return v0
.end method

.method public final component22()I
    .registers 2

    iget v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->tvBoxScanDurationSeconds:I

    return v0
.end method

.method public final component23()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ldev/wiojelt/turksinema/common/WioProviderSettingItem;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->items:Ljava/util/List;

    return-object v0
.end method

.method public final component24()Ljava/lang/String;
    .registers 2
    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation

    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->selectionTitle:Ljava/lang/String;

    return-object v0
.end method

.method public final component25()Z
    .registers 2

    iget-boolean v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->compactSelectionPresets:Z

    return v0
.end method

.method public final component26()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ldev/wiojelt/turksinema/common/WioSelectionPreset;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->selectionPresets:Ljava/util/List;

    return-object v0
.end method

.method public final component27()Lkotlin/jvm/functions/Function2;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function2<",
            "Ljava/lang/String;",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation

    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onSelectionPreset:Lkotlin/jvm/functions/Function2;

    return-object v0
.end method

.method public final component28()Lkotlin/jvm/functions/Function0;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation

    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onSelectAll:Lkotlin/jvm/functions/Function0;

    return-object v0
.end method

.method public final component29()Lkotlin/jvm/functions/Function0;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation

    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onSelectRecommended:Lkotlin/jvm/functions/Function0;

    return-object v0
.end method

.method public final component3()Ljava/lang/String;
    .registers 2
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->brandTitleTag:Ljava/lang/String;

    return-object v0
.end method

.method public final component30()Lkotlin/jvm/functions/Function0;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation

    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onSelectNone:Lkotlin/jvm/functions/Function0;

    return-object v0
.end method

.method public final component31()Lkotlin/jvm/functions/Function0;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation

    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onWizardClick:Lkotlin/jvm/functions/Function0;

    return-object v0
.end method

.method public final component32()Lkotlin/jvm/functions/Function0;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation

    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onCustomListClick:Lkotlin/jvm/functions/Function0;

    return-object v0
.end method

.method public final component33()Ljava/lang/String;
    .registers 2
    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation

    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->customListSummary:Ljava/lang/String;

    return-object v0
.end method

.method public final component34()Lkotlin/jvm/functions/Function2;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function2<",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lkotlin/Pair<",
            "Ljava/lang/Integer;",
            "Ljava/lang/Integer;",
            ">;>;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation

    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onAutoScanDomains:Lkotlin/jvm/functions/Function2;

    return-object v0
.end method

.method public final component35()Lkotlin/jvm/functions/Function0;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation

    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onSaveAndClose:Lkotlin/jvm/functions/Function0;

    return-object v0
.end method

.method public final component36()Z
    .registers 2

    iget-boolean v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->providersCollapsible:Z

    return v0
.end method

.method public final component37()Ljava/lang/String;
    .registers 2
    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation

    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->telegramUrl:Ljava/lang/String;

    return-object v0
.end method

.method public final component38()Ljava/lang/String;
    .registers 2
    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation

    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->coffeeUrl:Ljava/lang/String;

    return-object v0
.end method

.method public final component4()Ljava/lang/String;
    .registers 2
    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation

    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->summarySubtitle:Ljava/lang/String;

    return-object v0
.end method

.method public final component5()I
    .registers 2

    iget v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->brandColor:I

    return v0
.end method

.method public final component6()I
    .registers 2

    iget v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->brandColorBorder:I

    return v0
.end method

.method public final component7()I
    .registers 2

    iget v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->sheetBg:I

    return v0
.end method

.method public final component8()I
    .registers 2

    iget v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->cardBg:I

    return v0
.end method

.method public final component9()I
    .registers 2

    iget v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->cardBgSubtle:I

    return v0
.end method

.method public final copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIIIIIIIZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;IIILjava/util/List;Ljava/lang/String;ZLjava/util/List;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function0;ZLjava/lang/String;Ljava/lang/String;)Ldev/wiojelt/turksinema/common/WioSettingsConfig;
    .registers 78
    .param p1  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p2  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p3  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p4  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/Nullable;
        .end annotation
    .end param
    .param p15  # Lkotlin/jvm/functions/Function0;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p16  # Lkotlin/jvm/functions/Function1;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p18  # Lkotlin/jvm/functions/Function0;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p19  # Lkotlin/jvm/functions/Function1;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p23  # Ljava/util/List;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p24  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/Nullable;
        .end annotation
    .end param
    .param p26  # Ljava/util/List;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p27  # Lkotlin/jvm/functions/Function2;
        .annotation build Lorg/jetbrains/annotations/Nullable;
        .end annotation
    .end param
    .param p28  # Lkotlin/jvm/functions/Function0;
        .annotation build Lorg/jetbrains/annotations/Nullable;
        .end annotation
    .end param
    .param p29  # Lkotlin/jvm/functions/Function0;
        .annotation build Lorg/jetbrains/annotations/Nullable;
        .end annotation
    .end param
    .param p30  # Lkotlin/jvm/functions/Function0;
        .annotation build Lorg/jetbrains/annotations/Nullable;
        .end annotation
    .end param
    .param p31  # Lkotlin/jvm/functions/Function0;
        .annotation build Lorg/jetbrains/annotations/Nullable;
        .end annotation
    .end param
    .param p32  # Lkotlin/jvm/functions/Function0;
        .annotation build Lorg/jetbrains/annotations/Nullable;
        .end annotation
    .end param
    .param p33  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/Nullable;
        .end annotation
    .end param
    .param p34  # Lkotlin/jvm/functions/Function2;
        .annotation build Lorg/jetbrains/annotations/Nullable;
        .end annotation
    .end param
    .param p35  # Lkotlin/jvm/functions/Function0;
        .annotation build Lorg/jetbrains/annotations/Nullable;
        .end annotation
    .end param
    .param p37  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/Nullable;
        .end annotation
    .end param
    .param p38  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/Nullable;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "IIIIIIIIZZ",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;Z",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Integer;",
            ">;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;III",
            "Ljava/util/List<",
            "Ldev/wiojelt/turksinema/common/WioProviderSettingItem;",
            ">;",
            "Ljava/lang/String;",
            "Z",
            "Ljava/util/List<",
            "Ldev/wiojelt/turksinema/common/WioSelectionPreset;",
            ">;",
            "Lkotlin/jvm/functions/Function2<",
            "-",
            "Ljava/lang/String;",
            "-",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function2<",
            "-",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;-",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lkotlin/Pair<",
            "Ljava/lang/Integer;",
            "Ljava/lang/Integer;",
            ">;>;+",
            "Ljava/lang/Object;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;Z",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")",
            "Ldev/wiojelt/turksinema/common/WioSettingsConfig;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    new-instance v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move-object/from16 v3, p3

    move-object/from16 v4, p4

    move/from16 v5, p5

    move/from16 v6, p6

    move/from16 v7, p7

    move/from16 v8, p8

    move/from16 v9, p9

    move/from16 v10, p10

    move/from16 v11, p11

    move/from16 v12, p12

    move/from16 v13, p13

    move/from16 v14, p14

    move-object/from16 v15, p15

    move-object/from16 v16, p16

    move/from16 v17, p17

    move-object/from16 v18, p18

    move-object/from16 v19, p19

    move/from16 v20, p20

    move/from16 v21, p21

    move/from16 v22, p22

    move-object/from16 v23, p23

    move-object/from16 v24, p24

    move/from16 v25, p25

    move-object/from16 v26, p26

    move-object/from16 v27, p27

    move-object/from16 v28, p28

    move-object/from16 v29, p29

    move-object/from16 v30, p30

    move-object/from16 v31, p31

    move-object/from16 v32, p32

    move-object/from16 v33, p33

    move-object/from16 v34, p34

    move-object/from16 v35, p35

    move/from16 v36, p36

    move-object/from16 v37, p37

    move-object/from16 v38, p38

    invoke-direct/range {v0 .. v38}, Ldev/wiojelt/turksinema/common/WioSettingsConfig;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIIIIIIIZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;IIILjava/util/List;Ljava/lang/String;ZLjava/util/List;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function0;ZLjava/lang/String;Ljava/lang/String;)V

    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 7
    .param p1  # Ljava/lang/Object;
        .annotation build Lorg/jetbrains/annotations/Nullable;
        .end annotation
    .end param

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Ldev/wiojelt/turksinema/common/WioSettingsConfig;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    move-object v1, p1

    check-cast v1, Ldev/wiojelt/turksinema/common/WioSettingsConfig;

    iget-object v3, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->brandPrefix:Ljava/lang/String;

    iget-object v4, v1, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->brandPrefix:Ljava/lang/String;

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_18

    return v2

    :cond_18
    iget-object v3, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->brandSuffix:Ljava/lang/String;

    iget-object v4, v1, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->brandSuffix:Ljava/lang/String;

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_23

    return v2

    :cond_23
    iget-object v3, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->brandTitleTag:Ljava/lang/String;

    iget-object v4, v1, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->brandTitleTag:Ljava/lang/String;

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_2e

    return v2

    :cond_2e
    iget-object v3, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->summarySubtitle:Ljava/lang/String;

    iget-object v4, v1, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->summarySubtitle:Ljava/lang/String;

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_39

    return v2

    :cond_39
    iget v3, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->brandColor:I

    iget v4, v1, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->brandColor:I

    if-eq v3, v4, :cond_40

    return v2

    :cond_40
    iget v3, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->brandColorBorder:I

    iget v4, v1, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->brandColorBorder:I

    if-eq v3, v4, :cond_47

    return v2

    :cond_47
    iget v3, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->sheetBg:I

    iget v4, v1, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->sheetBg:I

    if-eq v3, v4, :cond_4e

    return v2

    :cond_4e
    iget v3, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->cardBg:I

    iget v4, v1, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->cardBg:I

    if-eq v3, v4, :cond_55

    return v2

    :cond_55
    iget v3, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->cardBgSubtle:I

    iget v4, v1, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->cardBgSubtle:I

    if-eq v3, v4, :cond_5c

    return v2

    :cond_5c
    iget v3, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->textPrimary:I

    iget v4, v1, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->textPrimary:I

    if-eq v3, v4, :cond_63

    return v2

    :cond_63
    iget v3, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->textSecondary:I

    iget v4, v1, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->textSecondary:I

    if-eq v3, v4, :cond_6a

    return v2

    :cond_6a
    iget v3, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->textMuted:I

    iget v4, v1, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->textMuted:I

    if-eq v3, v4, :cond_71

    return v2

    :cond_71
    iget-boolean v3, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->englishLabels:Z

    iget-boolean v4, v1, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->englishLabels:Z

    if-eq v3, v4, :cond_78

    return v2

    :cond_78
    iget-boolean v3, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->isTvBoxSupported:Z

    iget-boolean v4, v1, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->isTvBoxSupported:Z

    if-eq v3, v4, :cond_7f

    return v2

    :cond_7f
    iget-object v3, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->isTvBoxActive:Lkotlin/jvm/functions/Function0;

    iget-object v4, v1, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->isTvBoxActive:Lkotlin/jvm/functions/Function0;

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_8a

    return v2

    :cond_8a
    iget-object v3, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onTvBoxToggled:Lkotlin/jvm/functions/Function1;

    iget-object v4, v1, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onTvBoxToggled:Lkotlin/jvm/functions/Function1;

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_95

    return v2

    :cond_95
    iget-boolean v3, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->isScanDurationSupported:Z

    iget-boolean v4, v1, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->isScanDurationSupported:Z

    if-eq v3, v4, :cond_9c

    return v2

    :cond_9c
    iget-object v3, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->scanDurationSeconds:Lkotlin/jvm/functions/Function0;

    iget-object v4, v1, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->scanDurationSeconds:Lkotlin/jvm/functions/Function0;

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_a7

    return v2

    :cond_a7
    iget-object v3, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onScanDurationChanged:Lkotlin/jvm/functions/Function1;

    iget-object v4, v1, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onScanDurationChanged:Lkotlin/jvm/functions/Function1;

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_b2

    return v2

    :cond_b2
    iget v3, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->minScanDurationSeconds:I

    iget v4, v1, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->minScanDurationSeconds:I

    if-eq v3, v4, :cond_b9

    return v2

    :cond_b9
    iget v3, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->maxScanDurationSeconds:I

    iget v4, v1, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->maxScanDurationSeconds:I

    if-eq v3, v4, :cond_c0

    return v2

    :cond_c0
    iget v3, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->tvBoxScanDurationSeconds:I

    iget v4, v1, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->tvBoxScanDurationSeconds:I

    if-eq v3, v4, :cond_c7

    return v2

    :cond_c7
    iget-object v3, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->items:Ljava/util/List;

    iget-object v4, v1, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->items:Ljava/util/List;

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_d2

    return v2

    :cond_d2
    iget-object v3, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->selectionTitle:Ljava/lang/String;

    iget-object v4, v1, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->selectionTitle:Ljava/lang/String;

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_dd

    return v2

    :cond_dd
    iget-boolean v3, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->compactSelectionPresets:Z

    iget-boolean v4, v1, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->compactSelectionPresets:Z

    if-eq v3, v4, :cond_e4

    return v2

    :cond_e4
    iget-object v3, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->selectionPresets:Ljava/util/List;

    iget-object v4, v1, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->selectionPresets:Ljava/util/List;

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_ef

    return v2

    :cond_ef
    iget-object v3, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onSelectionPreset:Lkotlin/jvm/functions/Function2;

    iget-object v4, v1, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onSelectionPreset:Lkotlin/jvm/functions/Function2;

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_fa

    return v2

    :cond_fa
    iget-object v3, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onSelectAll:Lkotlin/jvm/functions/Function0;

    iget-object v4, v1, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onSelectAll:Lkotlin/jvm/functions/Function0;

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_105

    return v2

    :cond_105
    iget-object v3, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onSelectRecommended:Lkotlin/jvm/functions/Function0;

    iget-object v4, v1, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onSelectRecommended:Lkotlin/jvm/functions/Function0;

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_110

    return v2

    :cond_110
    iget-object v3, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onSelectNone:Lkotlin/jvm/functions/Function0;

    iget-object v4, v1, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onSelectNone:Lkotlin/jvm/functions/Function0;

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_11b

    return v2

    :cond_11b
    iget-object v3, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onWizardClick:Lkotlin/jvm/functions/Function0;

    iget-object v4, v1, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onWizardClick:Lkotlin/jvm/functions/Function0;

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_126

    return v2

    :cond_126
    iget-object v3, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onCustomListClick:Lkotlin/jvm/functions/Function0;

    iget-object v4, v1, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onCustomListClick:Lkotlin/jvm/functions/Function0;

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_131

    return v2

    :cond_131
    iget-object v3, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->customListSummary:Ljava/lang/String;

    iget-object v4, v1, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->customListSummary:Ljava/lang/String;

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_13c

    return v2

    :cond_13c
    iget-object v3, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onAutoScanDomains:Lkotlin/jvm/functions/Function2;

    iget-object v4, v1, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onAutoScanDomains:Lkotlin/jvm/functions/Function2;

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_147

    return v2

    :cond_147
    iget-object v3, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onSaveAndClose:Lkotlin/jvm/functions/Function0;

    iget-object v4, v1, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onSaveAndClose:Lkotlin/jvm/functions/Function0;

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_152

    return v2

    :cond_152
    iget-boolean v3, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->providersCollapsible:Z

    iget-boolean v4, v1, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->providersCollapsible:Z

    if-eq v3, v4, :cond_159

    return v2

    :cond_159
    iget-object v3, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->telegramUrl:Ljava/lang/String;

    iget-object v4, v1, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->telegramUrl:Ljava/lang/String;

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_164

    return v2

    :cond_164
    iget-object v3, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->coffeeUrl:Ljava/lang/String;

    iget-object v1, v1, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->coffeeUrl:Ljava/lang/String;

    invoke-static {v3, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_16f

    return v2

    :cond_16f
    return v0
.end method

.method public final getBrandColor()I
    .registers 2

    .line 58
    iget v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->brandColor:I

    return v0
.end method

.method public final getBrandColorBorder()I
    .registers 2

    .line 59
    iget v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->brandColorBorder:I

    return v0
.end method

.method public final getBrandPrefix()Ljava/lang/String;
    .registers 2
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 54
    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->brandPrefix:Ljava/lang/String;

    return-object v0
.end method

.method public final getBrandSuffix()Ljava/lang/String;
    .registers 2
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 55
    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->brandSuffix:Ljava/lang/String;

    return-object v0
.end method

.method public final getBrandTitleTag()Ljava/lang/String;
    .registers 2
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 56
    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->brandTitleTag:Ljava/lang/String;

    return-object v0
.end method

.method public final getCardBg()I
    .registers 2

    .line 61
    iget v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->cardBg:I

    return v0
.end method

.method public final getCardBgSubtle()I
    .registers 2

    .line 62
    iget v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->cardBgSubtle:I

    return v0
.end method

.method public final getCoffeeUrl()Ljava/lang/String;
    .registers 2
    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation

    .line 92
    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->coffeeUrl:Ljava/lang/String;

    return-object v0
.end method

.method public final getCompactSelectionPresets()Z
    .registers 2

    .line 79
    iget-boolean v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->compactSelectionPresets:Z

    return v0
.end method

.method public final getCustomListSummary()Ljava/lang/String;
    .registers 2
    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation

    .line 87
    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->customListSummary:Ljava/lang/String;

    return-object v0
.end method

.method public final getEnglishLabels()Z
    .registers 2

    .line 67
    iget-boolean v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->englishLabels:Z

    return v0
.end method

.method public final getItems()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ldev/wiojelt/turksinema/common/WioProviderSettingItem;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 77
    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->items:Ljava/util/List;

    return-object v0
.end method

.method public final getMaxScanDurationSeconds()I
    .registers 2

    .line 75
    iget v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->maxScanDurationSeconds:I

    return v0
.end method

.method public final getMinScanDurationSeconds()I
    .registers 2

    .line 74
    iget v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->minScanDurationSeconds:I

    return v0
.end method

.method public final getOnAutoScanDomains()Lkotlin/jvm/functions/Function2;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function2<",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lkotlin/Pair<",
            "Ljava/lang/Integer;",
            "Ljava/lang/Integer;",
            ">;>;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation

    .line 88
    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onAutoScanDomains:Lkotlin/jvm/functions/Function2;

    return-object v0
.end method

.method public final getOnCustomListClick()Lkotlin/jvm/functions/Function0;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation

    .line 86
    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onCustomListClick:Lkotlin/jvm/functions/Function0;

    return-object v0
.end method

.method public final getOnSaveAndClose()Lkotlin/jvm/functions/Function0;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation

    .line 89
    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onSaveAndClose:Lkotlin/jvm/functions/Function0;

    return-object v0
.end method

.method public final getOnScanDurationChanged()Lkotlin/jvm/functions/Function1;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function1<",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 73
    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onScanDurationChanged:Lkotlin/jvm/functions/Function1;

    return-object v0
.end method

.method public final getOnSelectAll()Lkotlin/jvm/functions/Function0;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation

    .line 82
    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onSelectAll:Lkotlin/jvm/functions/Function0;

    return-object v0
.end method

.method public final getOnSelectNone()Lkotlin/jvm/functions/Function0;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation

    .line 84
    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onSelectNone:Lkotlin/jvm/functions/Function0;

    return-object v0
.end method

.method public final getOnSelectRecommended()Lkotlin/jvm/functions/Function0;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation

    .line 83
    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onSelectRecommended:Lkotlin/jvm/functions/Function0;

    return-object v0
.end method

.method public final getOnSelectionPreset()Lkotlin/jvm/functions/Function2;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function2<",
            "Ljava/lang/String;",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation

    .line 81
    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onSelectionPreset:Lkotlin/jvm/functions/Function2;

    return-object v0
.end method

.method public final getOnTvBoxToggled()Lkotlin/jvm/functions/Function1;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function1<",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 70
    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onTvBoxToggled:Lkotlin/jvm/functions/Function1;

    return-object v0
.end method

.method public final getOnWizardClick()Lkotlin/jvm/functions/Function0;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation

    .line 85
    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onWizardClick:Lkotlin/jvm/functions/Function0;

    return-object v0
.end method

.method public final getProvidersCollapsible()Z
    .registers 2

    .line 90
    iget-boolean v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->providersCollapsible:Z

    return v0
.end method

.method public final getScanDurationSeconds()Lkotlin/jvm/functions/Function0;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 72
    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->scanDurationSeconds:Lkotlin/jvm/functions/Function0;

    return-object v0
.end method

.method public final getSelectionPresets()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ldev/wiojelt/turksinema/common/WioSelectionPreset;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 80
    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->selectionPresets:Ljava/util/List;

    return-object v0
.end method

.method public final getSelectionTitle()Ljava/lang/String;
    .registers 2
    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation

    .line 78
    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->selectionTitle:Ljava/lang/String;

    return-object v0
.end method

.method public final getSheetBg()I
    .registers 2

    .line 60
    iget v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->sheetBg:I

    return v0
.end method

.method public final getSummarySubtitle()Ljava/lang/String;
    .registers 2
    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation

    .line 57
    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->summarySubtitle:Ljava/lang/String;

    return-object v0
.end method

.method public final getTelegramUrl()Ljava/lang/String;
    .registers 2
    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation

    .line 91
    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->telegramUrl:Ljava/lang/String;

    return-object v0
.end method

.method public final getTextMuted()I
    .registers 2

    .line 65
    iget v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->textMuted:I

    return v0
.end method

.method public final getTextPrimary()I
    .registers 2

    .line 63
    iget v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->textPrimary:I

    return v0
.end method

.method public final getTextSecondary()I
    .registers 2

    .line 64
    iget v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->textSecondary:I

    return v0
.end method

.method public final getTvBoxScanDurationSeconds()I
    .registers 2

    .line 76
    iget v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->tvBoxScanDurationSeconds:I

    return v0
.end method

.method public hashCode()I
    .registers 5

    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->brandPrefix:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    mul-int/lit8 v1, v0, 0x1f

    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->brandSuffix:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v2

    add-int/2addr v1, v2

    mul-int/lit8 v0, v1, 0x1f

    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->brandTitleTag:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v2

    add-int/2addr v0, v2

    mul-int/lit8 v1, v0, 0x1f

    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->summarySubtitle:Ljava/lang/String;

    const/4 v3, 0x0

    if-nez v2, :cond_21

    move v2, v3

    goto :goto_27

    :cond_21
    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->summarySubtitle:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v2

    :goto_27
    add-int/2addr v1, v2

    mul-int/lit8 v0, v1, 0x1f

    iget v2, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->brandColor:I

    add-int/2addr v0, v2

    mul-int/lit8 v1, v0, 0x1f

    iget v2, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->brandColorBorder:I

    add-int/2addr v1, v2

    mul-int/lit8 v0, v1, 0x1f

    iget v2, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->sheetBg:I

    add-int/2addr v0, v2

    mul-int/lit8 v1, v0, 0x1f

    iget v2, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->cardBg:I

    add-int/2addr v1, v2

    mul-int/lit8 v0, v1, 0x1f

    iget v2, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->cardBgSubtle:I

    add-int/2addr v0, v2

    mul-int/lit8 v1, v0, 0x1f

    iget v2, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->textPrimary:I

    add-int/2addr v1, v2

    mul-int/lit8 v0, v1, 0x1f

    iget v2, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->textSecondary:I

    add-int/2addr v0, v2

    mul-int/lit8 v1, v0, 0x1f

    iget v2, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->textMuted:I

    add-int/2addr v1, v2

    mul-int/lit8 v0, v1, 0x1f

    iget-boolean v2, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->englishLabels:Z

    invoke-static {v2}, Ldev/wiojelt/turksinema/common/WioSettingsConfig$$ExternalSyntheticBackport0;->m(Z)I

    move-result v2

    add-int/2addr v0, v2

    mul-int/lit8 v1, v0, 0x1f

    iget-boolean v2, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->isTvBoxSupported:Z

    invoke-static {v2}, Ldev/wiojelt/turksinema/common/WioSettingsConfig$$ExternalSyntheticBackport0;->m(Z)I

    move-result v2

    add-int/2addr v1, v2

    mul-int/lit8 v0, v1, 0x1f

    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->isTvBoxActive:Lkotlin/jvm/functions/Function0;

    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    add-int/2addr v0, v2

    mul-int/lit8 v1, v0, 0x1f

    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onTvBoxToggled:Lkotlin/jvm/functions/Function1;

    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    add-int/2addr v1, v2

    mul-int/lit8 v0, v1, 0x1f

    iget-boolean v2, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->isScanDurationSupported:Z

    invoke-static {v2}, Ldev/wiojelt/turksinema/common/WioSettingsConfig$$ExternalSyntheticBackport0;->m(Z)I

    move-result v2

    add-int/2addr v0, v2

    mul-int/lit8 v1, v0, 0x1f

    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->scanDurationSeconds:Lkotlin/jvm/functions/Function0;

    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    add-int/2addr v1, v2

    mul-int/lit8 v0, v1, 0x1f

    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onScanDurationChanged:Lkotlin/jvm/functions/Function1;

    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    add-int/2addr v0, v2

    mul-int/lit8 v1, v0, 0x1f

    iget v2, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->minScanDurationSeconds:I

    add-int/2addr v1, v2

    mul-int/lit8 v0, v1, 0x1f

    iget v2, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->maxScanDurationSeconds:I

    add-int/2addr v0, v2

    mul-int/lit8 v1, v0, 0x1f

    iget v2, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->tvBoxScanDurationSeconds:I

    add-int/2addr v1, v2

    mul-int/lit8 v0, v1, 0x1f

    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->items:Ljava/util/List;

    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    add-int/2addr v0, v2

    mul-int/lit8 v1, v0, 0x1f

    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->selectionTitle:Ljava/lang/String;

    if-nez v2, :cond_af

    move v2, v3

    goto :goto_b5

    :cond_af
    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->selectionTitle:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v2

    :goto_b5
    add-int/2addr v1, v2

    mul-int/lit8 v0, v1, 0x1f

    iget-boolean v2, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->compactSelectionPresets:Z

    invoke-static {v2}, Ldev/wiojelt/turksinema/common/WioSettingsConfig$$ExternalSyntheticBackport0;->m(Z)I

    move-result v2

    add-int/2addr v0, v2

    mul-int/lit8 v1, v0, 0x1f

    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->selectionPresets:Ljava/util/List;

    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    add-int/2addr v1, v2

    mul-int/lit8 v0, v1, 0x1f

    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onSelectionPreset:Lkotlin/jvm/functions/Function2;

    if-nez v2, :cond_d0

    move v2, v3

    goto :goto_d6

    :cond_d0
    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onSelectionPreset:Lkotlin/jvm/functions/Function2;

    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_d6
    add-int/2addr v0, v2

    mul-int/lit8 v1, v0, 0x1f

    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onSelectAll:Lkotlin/jvm/functions/Function0;

    if-nez v2, :cond_df

    move v2, v3

    goto :goto_e5

    :cond_df
    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onSelectAll:Lkotlin/jvm/functions/Function0;

    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_e5
    add-int/2addr v1, v2

    mul-int/lit8 v0, v1, 0x1f

    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onSelectRecommended:Lkotlin/jvm/functions/Function0;

    if-nez v2, :cond_ee

    move v2, v3

    goto :goto_f4

    :cond_ee
    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onSelectRecommended:Lkotlin/jvm/functions/Function0;

    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_f4
    add-int/2addr v0, v2

    mul-int/lit8 v1, v0, 0x1f

    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onSelectNone:Lkotlin/jvm/functions/Function0;

    if-nez v2, :cond_fd

    move v2, v3

    goto :goto_103

    :cond_fd
    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onSelectNone:Lkotlin/jvm/functions/Function0;

    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_103
    add-int/2addr v1, v2

    mul-int/lit8 v0, v1, 0x1f

    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onWizardClick:Lkotlin/jvm/functions/Function0;

    if-nez v2, :cond_10c

    move v2, v3

    goto :goto_112

    :cond_10c
    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onWizardClick:Lkotlin/jvm/functions/Function0;

    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_112
    add-int/2addr v0, v2

    mul-int/lit8 v1, v0, 0x1f

    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onCustomListClick:Lkotlin/jvm/functions/Function0;

    if-nez v2, :cond_11b

    move v2, v3

    goto :goto_121

    :cond_11b
    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onCustomListClick:Lkotlin/jvm/functions/Function0;

    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_121
    add-int/2addr v1, v2

    mul-int/lit8 v0, v1, 0x1f

    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->customListSummary:Ljava/lang/String;

    if-nez v2, :cond_12a

    move v2, v3

    goto :goto_130

    :cond_12a
    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->customListSummary:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v2

    :goto_130
    add-int/2addr v0, v2

    mul-int/lit8 v1, v0, 0x1f

    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onAutoScanDomains:Lkotlin/jvm/functions/Function2;

    if-nez v2, :cond_139

    move v2, v3

    goto :goto_13f

    :cond_139
    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onAutoScanDomains:Lkotlin/jvm/functions/Function2;

    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_13f
    add-int/2addr v1, v2

    mul-int/lit8 v0, v1, 0x1f

    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onSaveAndClose:Lkotlin/jvm/functions/Function0;

    if-nez v2, :cond_148

    move v2, v3

    goto :goto_14e

    :cond_148
    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onSaveAndClose:Lkotlin/jvm/functions/Function0;

    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_14e
    add-int/2addr v0, v2

    mul-int/lit8 v1, v0, 0x1f

    iget-boolean v2, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->providersCollapsible:Z

    invoke-static {v2}, Ldev/wiojelt/turksinema/common/WioSettingsConfig$$ExternalSyntheticBackport0;->m(Z)I

    move-result v2

    add-int/2addr v1, v2

    mul-int/lit8 v0, v1, 0x1f

    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->telegramUrl:Ljava/lang/String;

    if-nez v2, :cond_160

    move v2, v3

    goto :goto_166

    :cond_160
    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->telegramUrl:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v2

    :goto_166
    add-int/2addr v0, v2

    mul-int/lit8 v1, v0, 0x1f

    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->coffeeUrl:Ljava/lang/String;

    if-nez v2, :cond_16e

    goto :goto_174

    :cond_16e
    iget-object v2, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->coffeeUrl:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v3

    :goto_174
    add-int/2addr v1, v3

    return v1
.end method

.method public final isScanDurationSupported()Z
    .registers 2

    .line 71
    iget-boolean v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->isScanDurationSupported:Z

    return v0
.end method

.method public final isTvBoxActive()Lkotlin/jvm/functions/Function0;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 69
    iget-object v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->isTvBoxActive:Lkotlin/jvm/functions/Function0;

    return-object v0
.end method

.method public final isTvBoxSupported()Z
    .registers 2

    .line 68
    iget-boolean v0, p0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->isTvBoxSupported:Z

    return v0
.end method

.method public toString()Ljava/lang/String;
    .registers 41
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    move-object/from16 v0, p0

    iget-object v1, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->brandPrefix:Ljava/lang/String;

    iget-object v2, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->brandSuffix:Ljava/lang/String;

    iget-object v3, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->brandTitleTag:Ljava/lang/String;

    iget-object v4, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->summarySubtitle:Ljava/lang/String;

    iget v5, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->brandColor:I

    iget v6, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->brandColorBorder:I

    iget v7, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->sheetBg:I

    iget v8, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->cardBg:I

    iget v9, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->cardBgSubtle:I

    iget v10, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->textPrimary:I

    iget v11, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->textSecondary:I

    iget v12, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->textMuted:I

    iget-boolean v13, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->englishLabels:Z

    iget-boolean v14, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->isTvBoxSupported:Z

    iget-object v15, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->isTvBoxActive:Lkotlin/jvm/functions/Function0;

    move-object/from16 v16, v15

    iget-object v15, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onTvBoxToggled:Lkotlin/jvm/functions/Function1;

    move-object/from16 v17, v15

    iget-boolean v15, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->isScanDurationSupported:Z

    move/from16 v18, v15

    iget-object v15, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->scanDurationSeconds:Lkotlin/jvm/functions/Function0;

    move-object/from16 v19, v15

    iget-object v15, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onScanDurationChanged:Lkotlin/jvm/functions/Function1;

    move-object/from16 v20, v15

    iget v15, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->minScanDurationSeconds:I

    move/from16 v21, v15

    iget v15, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->maxScanDurationSeconds:I

    move/from16 v22, v15

    iget v15, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->tvBoxScanDurationSeconds:I

    move/from16 v23, v15

    iget-object v15, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->items:Ljava/util/List;

    move-object/from16 v24, v15

    iget-object v15, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->selectionTitle:Ljava/lang/String;

    move-object/from16 v25, v15

    iget-boolean v15, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->compactSelectionPresets:Z

    move/from16 v26, v15

    iget-object v15, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->selectionPresets:Ljava/util/List;

    move-object/from16 v27, v15

    iget-object v15, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onSelectionPreset:Lkotlin/jvm/functions/Function2;

    move-object/from16 v28, v15

    iget-object v15, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onSelectAll:Lkotlin/jvm/functions/Function0;

    move-object/from16 v29, v15

    iget-object v15, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onSelectRecommended:Lkotlin/jvm/functions/Function0;

    move-object/from16 v30, v15

    iget-object v15, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onSelectNone:Lkotlin/jvm/functions/Function0;

    move-object/from16 v31, v15

    iget-object v15, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onWizardClick:Lkotlin/jvm/functions/Function0;

    move-object/from16 v32, v15

    iget-object v15, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onCustomListClick:Lkotlin/jvm/functions/Function0;

    move-object/from16 v33, v15

    iget-object v15, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->customListSummary:Ljava/lang/String;

    move-object/from16 v34, v15

    iget-object v15, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onAutoScanDomains:Lkotlin/jvm/functions/Function2;

    move-object/from16 v35, v15

    iget-object v15, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->onSaveAndClose:Lkotlin/jvm/functions/Function0;

    move-object/from16 v36, v15

    iget-boolean v15, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->providersCollapsible:Z

    move/from16 v37, v15

    iget-object v15, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->telegramUrl:Ljava/lang/String;

    move-object/from16 v38, v15

    iget-object v15, v0, Ldev/wiojelt/turksinema/common/WioSettingsConfig;->coffeeUrl:Ljava/lang/String;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    move-object/from16 v39, v15

    const-string v15, "WioSettingsConfig(brandPrefix="

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", brandSuffix="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", brandTitleTag="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", summarySubtitle="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", brandColor="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", brandColorBorder="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", sheetBg="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", cardBg="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", cardBgSubtle="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", textPrimary="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", textSecondary="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", textMuted="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v12}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", englishLabels="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v13}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", isTvBoxSupported="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v14}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", isTvBoxActive="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    move-object/from16 v1, v16

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", onTvBoxToggled="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    move-object/from16 v1, v17

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", isScanDurationSupported="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    move/from16 v1, v18

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", scanDurationSeconds="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    move-object/from16 v1, v19

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", onScanDurationChanged="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    move-object/from16 v1, v20

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", minScanDurationSeconds="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    move/from16 v1, v21

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", maxScanDurationSeconds="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    move/from16 v1, v22

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", tvBoxScanDurationSeconds="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    move/from16 v1, v23

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", items="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    move-object/from16 v1, v24

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", selectionTitle="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    move-object/from16 v1, v25

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", compactSelectionPresets="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    move/from16 v1, v26

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", selectionPresets="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    move-object/from16 v1, v27

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", onSelectionPreset="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    move-object/from16 v1, v28

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", onSelectAll="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    move-object/from16 v1, v29

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", onSelectRecommended="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    move-object/from16 v1, v30

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", onSelectNone="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    move-object/from16 v1, v31

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", onWizardClick="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    move-object/from16 v1, v32

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", onCustomListClick="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    move-object/from16 v1, v33

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", customListSummary="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    move-object/from16 v1, v34

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", onAutoScanDomains="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    move-object/from16 v1, v35

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", onSaveAndClose="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    move-object/from16 v1, v36

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", providersCollapsible="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    move/from16 v1, v37

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", telegramUrl="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    move-object/from16 v1, v38

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", coffeeUrl="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    move-object/from16 v1, v39

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ")"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
